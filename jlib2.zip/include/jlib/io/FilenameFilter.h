#ifndef JLIB_IO_FILENAMEFILTER
#define JLIB_IO_FILENAMEFILTER

#include <jlib/lang/String.h>

namespace jlib { namespace io {

class FilenameFilter {
public:
	virtual bool accept(const jlib::lang::String& path) = 0;
	virtual ~FilenameFilter() {}
};

}}

#endif
