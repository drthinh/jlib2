#ifndef JLIB_UTIL_ID_LIST
#define JLIB_UTIL_ID_LIST

#include <cassert>
#include <vector>

namespace jlib { namespace util {

template <typename T>
class id_list {
public:
	id_list(int maximumSize)
		: maximumSize(maximumSize), firstFree(0) {
	}

	int capacity() const {
		return static_cast<int>(array.size());
	}

	int add(T value) {
		int id = firstFree;

		if ( firstFree == capacity() ) {
			if ( capacity() == maximumSize ) {
				return -1;
			}

			array.push_back(node(value));
			++firstFree;
		} else {
			firstFree = array[id].nextFreeIndex; // advance free pointer
			array[id].value = value;
		}

		return id;
	}

	T lookup(int id) const {
		assert( id < capacity() );

		return array[id].value;
	}

	void remove(int id) {
		assert ( id < capacity() );

		array[id].nextFreeIndex = firstFree;
		firstFree = id;
	}

private:
    union node {
		node(const T& value) 
			: value(value) {
		}

		int nextFreeIndex;
		T value;
    };

	std::vector<node> array;
	int maximumSize;
    int firstFree;
};

}}

#endif
