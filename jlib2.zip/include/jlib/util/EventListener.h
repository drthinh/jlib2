#ifndef JLIB_UTIL_EVENTLISTENER
#define JLIB_UTIL_EVENTLISTENER

#include <vector>

namespace jlib { namespace util {

namespace imp {
	class EventDispatcherHelper;
}

class EventListener {
public:
	virtual ~EventListener();

protected:
	EventListener() {}

private:
	friend class jlib::util::imp::EventDispatcherHelper;

	void addDispatcher(jlib::util::imp::EventDispatcherHelper*);
	void removeDispatcher(jlib::util::imp::EventDispatcherHelper*);

	typedef std::vector<jlib::util::imp::EventDispatcherHelper*> 
		Dispatchers;
	Dispatchers dispatchers;
};

}}

#endif
