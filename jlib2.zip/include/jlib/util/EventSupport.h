#ifndef EVENTSUPPORT_H
#define EVENTSUPPORT_H

#include <vector>
#include <algorithm>
#include <cassert>

#include <jlib/util/EventListener.h>

namespace jlib { namespace util {

/**
 * An generic event class from which all event state objects 
 * shall be derived.
 * 
 * All Events are constructed with a reference to the object, 
 * the "source", that is logically deemed to be the object upon 
 * which the Event in question initially occurred upon. 
 */
template < class SourceT >
class EventObject {
public:
	/**
	 * The type of the "source" object.
	 */
	typedef SourceT source_type;

	/**
	 * Construct a new Event object.
	 */
	EventObject() : source(NULL) {
	}

	/**
	 * Get the object on which the Event initially occured.
	 *
	 * @return The object on which the Event initially occured.
	 */
	virtual source_type* getSource() const {
		return source;
	}

	/**
	 * Set the "source" object for this event, shall only be called
	 * by event supporting code, client code shall not call it.
	 *
	 * @param source The object on which the Event initially occured.
	 */
	void setSource(source_type* source) {
		this->source = source;
	}

private:
	source_type* source;
};

/**
 * base for EventDispatcher, in charge of non-templatized code
 */
class EventDispatcherBase {
protected:
	EventDispatcherBase() {
	}

	/**
	 * Test if there is no listeners currenly listening.
	 *
	 * @return true if no listeners.
	 */
	bool empty() const {
		return listeners.empty();
	}

	/**
	 * Get number of listeners
	 *
	 * @return number of listeners
	 */
	int getListenerCount() const {
		return static_cast<int>(listeners.size());
	}

	/**
	 * Get the listener at specified index
	 *
	 * @return a pointer to the listener at specified index
	 */
	EventListener* getListenerAt(int index) const {
		assert ( index >=0 && index < getListenerCount() );
		return listeners[index];
	}

	/**
	 * Add the specified event listener to receive events from this
	 * event dispatcher.
	 *
	 * @param l the event listener
	 */
	void addListener(EventListener*) {
		assert ( l != NULL );
		listeners.push_back(l);
	}

	/**
	 * Removes the specified event listener so that it no longer receives
	 * events from this dispather. 
	 *
	 * @param l the event listener
	 */
	void removeListener(EventListener* l) {
		assert ( l != NULL );

		ListenerList::iterator i = 
			std::remove(listeners.begin(), listeners.end(), l);
		listeners.erase(i);
	}

	typedef std::vector<EventListener*> ListenerList;
	ListenerList listeners;
};



/**
 * The core class of Event Supporting.
 * Objects of this class can transfer events from source object, namely, 
 * object on which events initially occured, to 0 to N listeners.
 */
template <class ListenerT>
class EventDispatcher : EventDispatcherBase {
public:
	/**
	 * Add the specified event listener to receive events from this
	 * event dispatcher.
	 *
	 * @param listener the event listener
	 */
	void addListener(ListenerT* listener) {
		EventDispatcherBase::addListener(listener);
	}

	/**
	 * Removes the specified event listener so that it no longer receives
	 * events from this dispather. 
	 *
	 * @param listener the event listener
	 */
	void removeListener(ListenerT* listener) {
		EventDispatcherBase::removeListener(listener);
	}

	using EventDispatcherBase::empty;
	using EventDispatcherBase::getListenerCount;

	/**
	 * Get the listener at specified index
	 *
	 * @return a pointer to the listener at specified index
	 */
	ListenerT* getListenerAt(int index ) const {
		return static_cast<ListenerT*>(
			EventDispatcher::getListenerAt(index));
	}


	/**
	 * Fire an event, the event will be dispatched to all registered 
	 * listeners.
	 *
	 * @param source the object on which the event initially occured.
	 * @param method the method by which the listener used to process
	 *               the event.
	 * @param e the event to fire
	 */
	template <class EventT>
	void fireEvent(typename EventT::source_type* source, 
			void (ListenerT::*method)(const EventT&), 
			const EventT& e) {
		const_cast<EventT&>(e).setSource(source);
		typename ListenerList::const_iterator i;
		for ( i = listeners.begin(); i != listeners.end(); ++i ) {
			((static_cast<ListenerT*>(*i))->*method)(e);
		}
	}
};

}}

#endif
