#ifndef JLIB_UTIL_EVENTOBJECT
#define JLIB_UTIL_EVENTOBJECT

namespace jlib { namespace util {

/**
 * An generic event class from which all event state objects 
 * shall be derived.
 * 
 * All Events are constructed with a reference to the object, 
 * the "source", that is logically deemed to be the object upon 
 * which the Event in question initially occurred upon. 
 */
template <class SourceT>
class EventObject {
public:
	/**
	 * The type of the "source" object.
	 */
	typedef SourceT source_type;

	/**
	 * Construct a new Event object.
	 */
	EventObject() : source(NULL) {
	}

	/**
	 * Get the object on which the Event initially occured.
	 *
	 * @return The object on which the Event initially occured.
	 */
	source_type* getSource() const {
		return source;
	}

	/**
	 * Set the "source" object for this event, shall only be called
	 * by event supporting code, client code shall not call it.
	 *
	 * @param source The object on which the Event initially occured.
	 */
	void setSource(source_type* source) {
		this->source = source;
	}

private:
	source_type* source;
};

}}

#endif
