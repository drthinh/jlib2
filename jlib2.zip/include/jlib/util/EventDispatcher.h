#ifndef JLIB_UTIL_EVENTDISPATCHER
#define JLIB_UTIL_EVENTDISPATCHER

#include <cassert>
#include <vector>

namespace jlib { namespace util {


class EventListener;

namespace imp {

	/**
	 * EventDispatcher helper, in charge of non-template code
	 */
	class EventDispatcherHelper {
	public:
		static EventDispatcherHelper* create();

		~EventDispatcherHelper();
		bool empty() const;
		int count() const;
		EventListener* at(int) const;
		void add(EventListener*);
		void remove(EventListener*);
	private:
		typedef std::vector<EventListener*> Listeners;
		Listeners listeners;
	};
}

/**
 * The core class of Event Supporting.
 * Objects of this class can transfer events from source object, namely, 
 * object on which events initially occured, to 0 to N listeners.
 */
template <class ListenerT>
class EventDispatcher {
public:
	EventDispatcher() 
		: imp(0) {
	}

	~EventDispatcher() {
		delete imp;
	}

	/**
	 * Add the specified event listener to receive events from this
	 * event dispatcher.
	 *
	 * @param listener the event listener
	 */
	void addListener(ListenerT* l) {
		assert (l);

		if (!imp) {
			imp = imp::EventDispatcherHelper::create();
		}

		imp->add(l);
	}

	/**
	 * Removes the specified event listener so that it no longer receives
	 * events from this dispather. 
	 *
	 * @param listener the event listener
	 */
	void removeListener(ListenerT* l) {
		assert (l && !empty());

		imp->remove(l);
	}

	/**
	 * Get the listener at specified index
	 *
	 * @return a pointer to the listener at specified index
	 */
	ListenerT* getListenerAt(int index) const {
		assert (index >=0 && index < getListenerCount());

		return static_cast<ListenerT*>(imp->at(index));
	}

	/**
	 * Test if there is no listeners currenly listening.
	 *
	 * @return true if no listeners.
	 */
	bool empty() const {
		return !imp || imp->empty();
	}

	/**
	 * Get number of listeners
	 *
	 * @return number of listeners
	 */
	int getListenerCount() const {
		return !imp ? 0 : imp->count();
	}

	/**
	 * Fire an event, the event will be dispatched to all registered 
	 * listeners.
	 *
	 * @param source the object in which the event is initiated.
	 * @param method the method by which the listener used to process
	 *               the event.
	 * @param e the event to fire
	 */
	template <class EventT>
	void fireEvent(typename EventT::source_type* source, 
		void (ListenerT::*method)(const EventT&), const EventT& e) {

		if (empty()) {
			return;
		}

		const_cast<EventT&>(e).setSource(source);
		for (int i=0; i<getListenerCount(); ++i) {
			ListenerT* l = getListenerAt(i);
			(l->*method)(e);
		}
	}

	/**
	 * Fire an mutable event, the event will be dispatched to all
	 * registered linteners. The listener may call <code>consume</code>
	 * of the delivered event.
	 *
	 * @param source the object in which the event is initiated.
	 * @param method the method by which the listener used to process
	 *               the event.
	 * @param e the event to fire
	 */
	template <class EventT>
	void fireMutableEvent(typename EventT::source_type* source, 
			void (ListenerT::*method)(EventT&), EventT& e) {

		if (empty()) {
			return;
		}

		e.setSource(source);
		for (int i=0; i<getListenerCount(); ++i) {
			ListenerT* l = getListenerAt(i);
			(l->*method)(e);
		}
	}

private:
	imp::EventDispatcherHelper* imp;
};

}}

#endif
