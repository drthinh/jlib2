#ifndef JLIB_UTIL_INTRUSIVE_LIST
#define JLIB_UTIL_INTRUSIVE_LIST

#include <iterator>
#include <cassert>

namespace jlib { namespace util {

template <class T>
class intrusive_list {
public:
	typedef std::size_t size_type;
	typedef std::ptrdiff_t difference_type;
	typedef T value_type;

	class node {
	protected:
		node() {
			next = prev = this;
		}
	private:
		friend class intrusive_list;
		node* next;
		node* prev;
	};

	class const_iterator {
	public:
		typedef std::bidirectional_iterator_tag iterator_category;

		const_iterator() : v(NULL) {
		}

		const_iterator(const node* v) : v(v) {
		}

		const T operator*() const {
			return static_cast<const T>(v);
		}

		const T* operator->() const {
			return static_cast<const T*>(&v);
		}

		const_iterator(const const_iterator& rhs) 
			: v(rhs.v) {
		}

		const_iterator& operator++() {
			v = next(v);
			return *this;
		}

		const_iterator operator++(int) {
			const_iterator result(*this);
			++*this;
			return result;
		}

		const_iterator& operator--() {
			v = prev(v);
			return *this;
		}

		const_iterator operator--(int) {
			const_iterator result(*this);
			--*this;
			return result;
		}

		bool operator==(const const_iterator& rhs) {
			return v == rhs.v;
		}

		bool operator!=(const const_iterator& rhs) {
			return v != rhs.v;
		}

	private:
		const node* v;
	};

	class iterator {
	public:
		typedef std::bidirectional_iterator_tag iterator_category;

		iterator() : v(NULL) {
		}

		iterator(node* v) : v(v) {
		}

		iterator(const iterator& rhs) 
			: v(rhs.v) {
		}

		T operator*() const {
			return static_cast<T>(v);
		}

		T* operator->() const {
			return static_cast<T*>(&v);
		}

		iterator& operator++() {
			v = next(v);
			return *this;
		}

		iterator operator++(int) {
			iterator result(*this);
			++(*this);
			return result;
		}

		iterator& operator--() {
			v = prev(v);
			return *this;
		}

		iterator operator--(int) {
			iterator result(*this);
			--*this;
			return result;
		}

		bool operator==(const iterator& rhs) {
			return v == rhs.v;
		}

		bool operator!=(const iterator& rhs) {
			return v != rhs.v;
		}

	private:
		node* v;
	};

	typedef std::reverse_iterator<iterator> reverse_iterator;
	typedef std::reverse_iterator<const_iterator> const_reverse_iterator;


	intrusive_list() {
		head.next = head.prev = &head;
		count = 0;
	}

	const_iterator begin() const {
		return const_iterator(static_cast<const T>(head.next));
	}

	const_iterator end() const {
		return const_iterator(static_cast<const T>(&head));
	}

	iterator begin() {
		return iterator(head.next);
	}

	iterator end() {
		return iterator(&head);
	}

	reverse_iterator rbegin() {
		return reverse_iterator(end());
	}

	reverse_iterator rend() {
		return reverse_iterator(begin());
	}

	const_reverse_iterator rbegin() const {
		return const_reverse_iterator(end());
	}

	const_reverse_iterator rend() const	{
		return const_reverse_iterator(begin());
	}

	size_t size() const {
		return count;
	}

	bool empty() const {
		return count == 0;
	}

	T front() {
		assert ( !empty() );

		return static_cast<T>(head.next);
	}

	const T front() const {
		assert ( !empty() );

		return static_cast<const T>(head->next);
	}

	T back() {
		assert ( !empty() );

		return static_cast<T>(head.prev);
	}

	const T back() const {
		assert ( !empty() );

		return static_cast<const T>(head->prev);
	}

	void push_back(T v) {
		assert ( is_orphan(v) );

		insert(head.prev, v);
	}

	void pop_back() {
		assert ( !empty() );

		remove(head.prev);
	}

	void push_front(T v) {
		assert ( is_orphan(v) );

		insert(&head, v);
	}

	void pop_front() {
		assert ( !empty() );

		remove(head.next);
	}

	void insert(iterator where, T v) {
		assert ( is_orphan(v) );

		node* w = *where;

		v->prev = w;
		v->next = w->next;
		w->next->prev = v;
		w->next = v;

		++count;
	}

	iterator erase(iterator where) {
		iterator result = (*where)->next;
		remove(*where);
		return result;
	}

	void clear() {
		while ( !empty() ) {
			remove(&front());
		}
	}

private:
	intrusive_list(const intrusive_list&);
	intrusive_list& operator=(const intrusive_list&);

	void remove(node* v) {
		assert ( !is_orphan(v) );

		v->next->prev = v->prev;
		v->prev->next = v->next;
		v->next = v->prev = v;

		--count;
	}

	static node* next(const node* v) {
		return v->next;
	}

	static node* prev(const node* v) {
		return v->prev;
	}

	static bool is_orphan(const node* v) {
		return v->next == v && v->prev == v;
	}

	node head;
	size_t count;
};

}}

#endif
