#ifndef JLIB_ENTRYPOINT
#define JLIB_ENTRYPOINT

#include <vector>
#include <jlib/lang/String.h>

typedef std::vector<jlib::lang::String> ArgumentList;

#define MAIN_CLASS(className) \
	class className;\
	void jlib_main(const ArgumentList& args) {\
		className::main(args); }

#endif
