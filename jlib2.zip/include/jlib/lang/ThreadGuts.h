#ifndef JLIB_LANG_THREADGUTS
#define JLIB_LANG_THREADGUTS

#include <string>

namespace jlib { namespace lang {

using std::string;
class Runnable;
class NativeThread;

class ThreadGuts {
public:
	Runnable* target;
	std::string name;
	int priority;
	NativeThread* peer;
	Thread* thread;
	Monitor lock;
};

}}

#endif
