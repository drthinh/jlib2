#ifndef JLIB_LANG_RUNTIME
#define JLIB_LANG_RUNTIME

namespace jlib { namespace lang {

class Thread;
class NativeFactory;

class Runtime {
public:
	static NativeFactory* nativeFactory();

protected:
	Runtime();
};

}}

#endif
