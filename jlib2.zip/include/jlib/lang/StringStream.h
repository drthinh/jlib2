#ifndef JLIB_UTIL_STRINGSTREAM
#define JLIB_UTIL_STRINGSTREAM

#include <sstream>

namespace jlib { namespace lang {

#ifdef _UNICODE
typedef std::wistringstream IStringStream;
typedef std::wostringstream OStringStream;
#else
typedef std::istringstream IStringStream;
typedef std::ostringstream OStringStream;
#endif

}}

#endif
