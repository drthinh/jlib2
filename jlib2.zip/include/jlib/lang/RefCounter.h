#ifndef JLIB_LANG_REFCOUNTER
#define JLIB_LANG_REFCOUNTER

namespace jlib { namespace lang {

class RefCounter {
public:
	RefCounter() 
		: counter(1) {
	}

	virtual ~RefCounter() {
	}

	void addRef() {
		++counter;
	}

	void release() {
		--counter;
		if ( counter == 0 ) {
			delete this;
		}
	}

private:
	int counter;
};

}}

#endif
