#ifndef JLIB_LANG_MONITOR
#define JLIB_LANG_MONITOR

namespace jlib { namespace lang {

class NativeMonitor;

class Monitor {
public:
	Monitor();
	virtual ~Monitor();

    /**
     * Causes current thread to wait until another thread invokes the 
     * {@link jlib::lang::Monitor#notify()} method or the 
     * {@link jlib::lang::Monitor#notifyAll()} method for this Monitor. 
     * In other word's this method behaves exactly as if it simply 
     * performs the call <tt>wait(0)</tt>.
     * <p>
     * The current thread must own this monitor. The thread releases 
	 * ownership of this monitor and waits until another thread 
     * notifies threads waiting on this object's monitor to wake up 
     * either through a call to the <code>notify</code> method or the 
     * <code>notifyAll</code> method. The thread then waits until it can 
     * re-obtain ownership of the monitor and resumes execution. 
     * <p>
     * This method should only be called by a thread that is the owner 
     * of this monitor. See the <code>notify</code> method for a 
     * description of the ways in which a thread can become the owner of 
     * a monitor.
     *
     * @exception  InterruptedException if another thread has interrupted
     *             the current thread.  The <i>interrupted status</i> of the
     *             current thread is cleared when this exception is thrown.
     * @see        jlib::lang::Monitor#notify()
     * @see        jlib::lang::Monitor#notifyAll()
     */
	void wait();

	/**
     * Causes current thread to wait until either another thread invokes the 
     * {@link jlib::lang::Monitor#notify()} method or the 
     * {@link jlib::lang::Monitor#notifyAll()} method for this object, or a 
     * specified amount of time has elapsed. 
     * <p>
     * The current thread must own this object's monitor. 
     * <p>
     * This method causes the current thread (call it <var>T</var>) to 
     * place itself in the wait set for this object and then to relinquish 
     * any and all synchronization claims on this object. Thread <var>T</var> 
     * becomes disabled for thread scheduling purposes and lies dormant 
     * until one of four things happens:
     * <ul>
     * <li>Some other thread invokes the <tt>notify</tt> method for this 
     * object and thread <var>T</var> happens to be arbitrarily chosen as 
     * the thread to be awakened. 
     * <li>Some other thread invokes the <tt>notifyAll</tt> method for this 
     * object. 
     * <li>Some other thread {@link java.lang.Thread#interrupt() interrupts} 
     * thread <var>T</var>. 
     * <li>The specified amount of real time has elapsed, more or less.  If 
     * <tt>timeout</tt> is zero, however, then real time is not taken into 
     * consideration and the thread simply waits until notified. 
     * </ul>
     * The thread <var>T</var> is then removed from the wait set for this 
     * object and re-enabled for thread scheduling. It then competes in the 
     * usual manner with other threads for the right to synchronize on the 
     * object; once it has gained control of the object, all its 
     * synchronization claims on the object are restored to the status quo 
     * ante - that is, to the situation as of the time that the <tt>wait</tt> 
     * method was invoked. Thread <var>T</var> then returns from the 
     * invocation of the <tt>wait</tt> method. Thus, on return from the 
     * <tt>wait</tt> method, the synchronization state of the object and of 
     * thread <tt>T</tt> is exactly as it was when the <tt>wait</tt> method 
     * was invoked. 
     * <p>
     * If the current thread is 
     * {@link java.lang.Thread#interrupt() interrupted} by another thread 
     * while it is waiting, then an <tt>InterruptedException</tt> is thrown. 
     * This exception is not thrown until the lock status of this object has 
     * been restored as described above.
     * <p>
     * Note that the <tt>wait</tt> method, as it places the current thread 
     * into the wait set for this object, unlocks only this object; any 
     * other objects on which the current thread may be synchronized remain 
     * locked while the thread waits.
     * <p>
     * This method should only be called by a thread that is the owner 
     * of this object's monitor. See the <code>notify</code> method for a 
     * description of the ways in which a thread can become the owner of 
     * a monitor. 
     *
     * @param      timeout   the maximum time to wait in milliseconds.
     * @exception  InterruptedException if another thread has interrupted
     *             the current thread.  The <i>interrupted status</i> of the
     *             current thread is cleared when this exception is thrown.
     * @see        jlib::lang::Monitor#notify()
     * @see        jlib::lang::Monitor#notifyAll()
     */
	void wait(long timeout);

	/**
     * Wakes up a single thread that is waiting on this monitor. If any 
	 * threads are waiting on this monitor, one of them is chosen to be 
	 * awakened. The choice is FIFO. A thread waits on a monitor by 
	 * calling one of the <code>wait</code> methods.
     * <p>
     * The awakened thread will not be able to proceed until the current 
     * thread relinquishes the lock on this monitor. The awakened thread 
	 * will compete in the usual manner with any other threads that might be 
     * actively competing to synchronize on this monitor; for example, the 
     * awakened thread enjoys no reliable privilege or disadvantage in being 
     * the next thread to lock this monitor.
     * <p>
     * This method should only be called by a thread that is the owner 
     * of this monitor. A thread becomes the owner of the monitor by 
	 * executing the body of a <code>synchronized</code> statement that 
	 * synchronizes on the monitor. 
     * <p>
     * Only one thread at a time can own a monitor. 
     *
     * @see        jlib::lang::Monitor#notifyAll()
     * @see        jlib::lang::Monitor#wait()
     */
	void notify();

    /**
     * Wakes up all threads that are waiting on this monitor. A thread 
	 * waits on an monitor by calling one of the <code>wait</code> methods.
     * <p>
     * The awakened threads will not be able to proceed until the current 
     * thread relinquishes the lock on this monitor. The awakened threads 
     * will compete in the usual manner with any other threads that might 
     * be actively competing to synchronize on this monitor; for example, 
     * the awakened threads enjoy no reliable privilege or disadvantage in 
     * being the next thread to lock this monitor.
     * <p>
     * This method should only be called by a thread that is the owner 
     * of this monitor. See the <code>notify</code> method for a 
     * description of the ways in which a thread can become the owner of 
     * a monitor. 
     *
     * @see        jlib::lang::Monitor#notify()
     * @see        jlib::lang::Monitor#wait()
     */
	void notifyAll();


	/**
	 * Acquire ownership of the monitor.
	 */
	void enter();

	/**
	 * Relinquish owenership of this monitor.
	 */
	void leave();

private:
	class NativeMonitor* peer;
};

inline void Monitor::wait() {
	wait(0);
}

}}

#endif
