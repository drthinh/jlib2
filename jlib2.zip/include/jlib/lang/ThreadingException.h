#ifndef JLIB_LANG_INTERRUPTEDEXCEPTION
#define JLIB_LANG_INTERRUPTEDEXCEPTION

#include <stdexcept>

namespace jlib { namespace lang {

/**
 * Thrown when a thread is waiting, sleeping, or otherwise paused 
 * for a long time and another thread interrupts it using the
 * <code>interrupt</code> method in class <code>Thread</code>. 
 *
 * @see jlib::lang::Monitor#wait()
 * @see jlib::lang::Monitor#wait(long)
 * @see jlib::lang::Monitor#wait(long, int)
 * @see jlib::lang::Monitor#sleep(long)
 * @see jlib::lang::Thread#interrupt()
 * @see jlib::lang::Thread#interrupted()
 */
class InterruptedException : public std::exception {
public:
	/**
	 * return pointer to message string
	 *
	 * @return a human readable message string
	 */
	const char* what() const throw() {
		return "thread interrupted";
	}
};

class ResourceException : public std::runtime_error {
public:
	explicit ResourceException(const std::string& reason)
		: runtime_error(reason) {
	}
};

}}

#endif
