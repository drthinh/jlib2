#ifndef JLIB_LANG_LOCK
#define JLIB_LANG_LOCK

namespace jlib { namespace lang {

template< typename MonitorType>
class lock_t {
public:
	lock_t(MonitorType& monitor)
		: monitor(monitor) {
		monitor.enter();
	}

	lock_t(MonitorType* monitor)
		: monitor(&monitor) {
		monitor->enter();
	}

	operator bool() {
		return true;
	}

	~lock_t() {
		monitor.leave();
	}

private:
#ifndef __GNUC__
	// GNU C++ complained this while MSVC and BCC not. I don't who
	// are right.
	lock_t(const lock_t& rhs);
#endif
	lock_t& operator=(const lock_t& rhs);


	MonitorType& monitor;
};

}}

#include "Monitor.h"

namespace jlib { namespace lang {
	typedef lock_t<jlib::lang::Monitor> Lock;
}}

#define synchronized(x) if ( jlib::lang::Lock l_o__c_k = x )
// used to be "#define synchronized(x) if ( jlib::lang::Lock l_o__c_k(x) )",
// up to the C++ standard, this seems to be incorrect, it can only be 
// accepted by MSVC. See C++ Language Specification, A5.

#endif
