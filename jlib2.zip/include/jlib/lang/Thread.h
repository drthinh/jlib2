#ifndef JLIB_LANG_THREAD
#define JLIB_LANG_THREAD

#include <string>
#include <assert.h>

#include <jlib/lang/Monitor.h>
#include <jlib/lang/Native.h>
#include <jlib/lang/Runnable.h>

// from winspool.h
#ifdef MIN_PRIORITY
#undef MIN_PRIORITY
const DWORD MIN_PRIORITY = 1;
#endif

// from winspool.h
#ifdef MAX_PRIORITY
#undef MAX_PRIORITY
const DWORD MAX_PRIORITY = 99;
#endif


namespace jlib { namespace lang {

class NativeThread;

/**
 * A thread is a thread of execution in a program. An application may 
 * have multiple threads of execution running concurrently. 
 */
class Thread : Runnable {
public:

	enum {
		/**
		 * The maximum priority that a thread can have. 
		 */
		MAX_PRIORITY = 10,

		/**
		 * The default priority that is assigned to a thread. 
		 */
		NORM_PRIORITY = 5,

		/**
		 * The minimum priority that a thread can have. 
		 */
		MIN_PRIORITY = 1,
	};

    /**
     * Allocates a new <code>Thread</code> object. This constructor has 
     * the same effect as <code>Thread(target,</code> <i>gname</i><code>)
	 * </code>, where <i>gname</i> is a newly generated name. Automatically 
	 * generated names are of the form <code>"Thread-"+</code><i>n</i>, 
	 * where <i>n</i> is an integer. 
     *
     * @param target the object whose <code>run</code> method is called.
     * @see   jlib::lang::Thread#Thread(jlib::lang::Runnable, std::string)
     */
	explicit Thread(Runnable* target);

	/**
     * Allocates a new <code>Thread</code> object so that it has 
     * <code>target</code> as its run object and has the specified 
     * <code>name</code> as its name.
     * <p>
     * If the <code>target</code> argument is not <code>null</code>, the 
     * <code>run</code> method of the <code>target</code> is called when 
     * this thread is started. If the target argument is 
     * <code>null</code>, this thread's <code>run</code> method is called 
     * when this thread is started. 
     * <p>
     * The priority of the newly created thread is set equal to the 
     * priority of the thread creating it, that is, the currently running 
     * thread. The method <code>setPriority</code> may be used to 
     * change the priority to a new value. 
     *
     * @param      target   the object whose <code>run</code> method is called.
     * @param      name     the name of the new thread.
	 *
     * @see        jlib::lang::Runnable#run()
     * @see        jlib::lang::Thread#run()
     * @see        jlib::lang::Thread#setPriority(int)
     */
	explicit Thread(Runnable* target, const std::string& name);

	virtual ~Thread();

	/**
     * Returns a pointer to the currently executing thread object.
     *
     * @return the currently executing thread.
     */
	static Thread currentThread();

    /**
     * Causes this thread to begin execution; the <code>run</code> 
	 * method of this thread was called. 
     * <p>
     * The result is that two threads are running concurrently: the 
     * current thread (which returns from the call to the 
     * <code>start</code> method) and the other thread (which executes its 
     * <code>run</code> method). 
     *
     * @see        jlib::lang::Thread#run()
     * @see        jlib::lang::Thread#stop()
     */
	void start();

    /**
     * Changes the name of this thread to be equal to the argument 
     * <code>name</code>. 
     *
     * @param      name   the new name for this thread.
	 *
     * @see        #getName
     * @see        jlib::lang::Thread#getName()
     */
	void setName(const std::string& name);

    /**
     * Returns this thread's name.
     *
     * @return  this thread's name.
     * @see     #setName
     * @see     jlib::lang::Thread#setName(std::string)
     */
	const std::string& getName() const;

    /**
     * Changes the priority of this thread. 
	 *
     * @param priority priority to set this thread to
	 *
     * @see        #getPriority
     * @see        jlib::lang::Thread#MAX_PRIORITY
     * @see        jlib::lang::Thread#MIN_PRIORITY
     */
	void setPriority(int priority);

    /**
     * Returns this thread's priority.
     *
     * @return  this thread's name.
     * @see     #setPriority
     * @see     jlib::lang::Thread#setPriority(int)
     */
	int getPriority() const;

	/**
     * Tests if this thread is alive. A thread is alive if it has 
     * been started and has not yet died. 
     *
     * @return  <code>true</code> if this thread is alive;
     *          <code>false</code> otherwise.
     */
	bool isAlive() const;

	/**
     * Waits at most <code>millis</code> milliseconds for this thread to 
     * die. A timeout of <code>0</code> means to wait forever. 
     *
     * @param      millis   the time to wait in milliseconds.
     * @exception  InterruptedException if another thread has interrupted
     *             the current thread.  The <i>interrupted status</i> of the
     *             current thread is cleared when this exception is thrown.
     */
	void join(long millis);

    /**
     * Waits for this thread to die. 
     *
     * @exception  InterruptedException if another thread has interrupted
     *             the current thread.  The <i>interrupted status</i> of the
     *             current thread is cleared when this exception is thrown.
     */
	void join();

	/**
     * Causes the currently executing thread object to temporarily pause 
     * and allow other threads to execute. 
     */
	static void yield();

    /**	
     * Causes the currently executing thread to sleep (temporarily cease 
     * execution) for the specified number of milliseconds. The thread 
     * does not lose ownership of any monitors.
     *
     * @param      millis   the length of time to sleep in milliseconds.
     * @exception  InterruptedException if another thread has interrupted
     *             the current thread.  The <i>interrupted status</i> of the
     *             current thread is cleared when this exception is thrown.
     */
	static void sleep(long millis);

	/**
     * Interrupts this thread.
     */
	void interrupt();

    /**
     * Tests whether this thread has been interrupted.  The <i>interrupted
     * status</i> of the thread is unaffected by this method.
     *
     * @return  <code>true</code> if this thread has been interrupted;
     *          <code>false</code> otherwise.
     * @see     jlib::lang::Thread#interrupted()
     */
	bool isInterrupted() const;

	/**
     * Destroys this thread, without any cleanup. Any monitors it has 
     * locked remain locked.
     */
    void destroy();

	/**
     * If this thread was constructed using a separate 
     * <code>Runnable</code> run object, then that 
     * <code>Runnable</code> object's <code>run</code> method is called; 
     * otherwise, this method does nothing and returns. 
     * <p>
     * Subclasses of <code>Thread</code> should override this method. 
     *
     * @see jlib::lang::Thread#start()
     * @see jlib::lang::Thread#Thread(jlib::lang::Runnable, std::string)
     * @see jlib::lang::Runnable#run()
     */
	virtual void run();

protected:
	/**
     * Allocates a new <code>Thread</code> object. This constructor has 
     * the same effect as <code>Thread(null,</code><i>gname</i><code>)
	 * </code>, where <b><i>gname</i></b> is a newly generated name. 
	 * Automatically generated names are of the form <code>"Thread-"+</code>
	 * <i>n</i>, where <i>n</i> is an integer. 
     * <p>
     * Threads created this way must have overridden their
     * <code>run()</code> method to actually do anything.
	 *
     * @see jlib::lang::Thread#Thread(jlib::lang::Runnable, std::string)
     */
	Thread();

	/**
	 * Allocates a new <code>Thread</code> object. This constructor has 
	 * the same effect as <code>Thread(null, name)</code>. 
	 *
	 * @param name the name of the new thread.
	 * @see jlib::lang::Thread#Thread(jlib::lang::Runnable, std::string)
	 */
	Thread(const std::string& name);
	
private:
	// for currentThread
	Thread(NativeThread* peer);

	// creating a thread from a thread is not allowed
	Thread(const Thread&);
	Thread& operator=(const Thread&);

	NativeThread* peer;
};

}}

#endif
