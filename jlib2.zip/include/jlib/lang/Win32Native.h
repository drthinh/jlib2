#ifndef JLIB_LANG_WIN32NATIVE
#define JLIB_LANG_WIN32NATIVE

#include <vector>

#include <jlib/util/intrusive_list.h>

#include <jlib/lang/Native.h>

namespace jlib { namespace win32 { namespace lang {

using namespace jlib::lang;

class Win32Monitor;
class Win32Thread;
class Win32NativeFactory;

class Win32Mutex {
public:
	Win32Mutex() {
		::InitializeCriticalSection(&cs);
		lockCount = 0;
	}

	void lock() {
		::EnterCriticalSection(&cs);
		++lockCount;
	}

	void unlock() {
		--lockCount;
		::LeaveCriticalSection(&cs);
	}

	~Win32Mutex() {
		::DeleteCriticalSection(&cs);
	}

	int getLockCount() const {
		return lockCount;
	}

private:
	CRITICAL_SECTION cs;
	int lockCount;
};

struct WaitingNode;
typedef jlib::util::intrusive_list<WaitingNode*> WaitingList;

struct WaitingNode : public WaitingList::node {
	WaitingNode(HANDLE event) 
		: event(event), notified(false) {
		}

	void notify() {
		::SetEvent(event);
		notified = true;
	}

	HANDLE event;
	bool notified;
};

class Win32Monitor : public NativeMonitor {
public:
	Win32Monitor();

	// NativeMonitor implementation
	void enter();
	void leave();
	void notify();
	void notifyAll();
	void wait(long timeout);

	// feature {Win32Thread}
	bool isLocking() const;
	void addWaiting(WaitingNode* t);
	void removeWaiting(WaitingNode* t);

private:
	Win32Monitor(const Win32Monitor&);
	Win32Monitor& operator=(const Win32Monitor&);
	Win32Mutex mutex;
	WaitingList waitings;
};


class Win32Thread : public NativeThread {
public:
	// for "JLIB" threads
	Win32Thread(Runnable* target, const std::string& name);

	// for external threads
	Win32Thread();

	~Win32Thread();

	void addRef();
	void release();
	
	// NativeThead implementation
	void setName(const std::string& name);
	const std::string& getName() const;

	void start();
	void interrupt();
	bool isInterrupted() const;
	void destroy();
	bool isAlive() const;

	void setPriority(int priority);
	int getPriority() const;

	void join(long millis);

	// feature {Win32Monitor}
	void wait(Win32Monitor* monitor, long timeout);

	// feature {Win32NativeFactory}
	static void sleep(long millis);

private:

	Win32Thread(const Win32Thread&);
	Win32Thread& operator=(const Win32Thread&);

	Runnable* target;
	std::string name;
	int priority;
	mutable Win32Monitor lock;
	LONG refCount;

	HANDLE handle;
	unsigned int id;

	HANDLE event;

	bool interrupted;

	static int javaPriorityToWin32Priority(int priority);
	static int Win32PriorityToJavaPriority(int priority);

	void threadProc();
	static unsigned int __stdcall sThreadProc(void* argv);
#ifdef MFC
	class CWinThread* mfcThread;
	static UINT __cdecl MFC_sThreadProc(LPVOID lParam);
#endif
};

template <typename T>
class TlsSlot {
public:
	TlsSlot() {
		slot = ::TlsAlloc();
		assert ( slot != TLS_OUT_OF_INDEXES);
	}

	void set(T v) {
		::TlsSetValue(slot, static_cast<LPVOID>(v));
	}

	T get() const {
		return static_cast<T>(::TlsGetValue(slot));
	}

	~TlsSlot() {
		::TlsFree(slot);
	}
private:
	DWORD slot;
};

class Win32NativeFactory : public NativeFactory {
public:
	Win32NativeFactory();
	~Win32NativeFactory();

	// NativeFactory implementation
	NativeMonitor* createMonitor(Monitor* peer);
	NativeThread* createThread(Runnable* target, const std::string& name);
	Win32Thread* currentThread();
	void sleep(long millis);
	void yield();

	// feature {Win32Thread}
	void registerThread(Win32Thread* thread);

	static Win32NativeFactory* instance();

private:
	Win32NativeFactory(const Win32NativeFactory&);
	Win32NativeFactory& operator=(const Win32NativeFactory&);

	TlsSlot<Win32Thread*> threadSlot;

	typedef std::vector<Win32Thread*> Win32ThreadList;
	Win32Monitor externalThreadsLock;
	Win32ThreadList externalThreads;

	static Win32NativeFactory* me;
};

inline Win32NativeFactory* Win32NativeFactory::instance() {
	return me;
}

}}}

#endif
