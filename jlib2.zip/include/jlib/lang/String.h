#ifndef JLIB_UTIL_STRING
#define JLIB_UTIL_STRING

#include <string>

namespace jlib { namespace lang {

#ifdef _UNICODE
	typedef std::wstring String;

#	ifndef _T
#		define _T(x)	L ## x
#	endif

#else
	typedef std::string String;

#	ifndef _T
#		define _T(x)	x
#	endif

#endif

}}

#endif
