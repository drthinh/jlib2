#ifndef JLIB_LANG_RUNNABLE
#define JLIB_LANG_RUNNABLE

namespace jlib { namespace lang {
/**
 * The Runnable interface should be implemented by any class whose 
 * instances are intended to be executed by a thread. The class must 
 * define a method of no arguments called run. 
 */
class Runnable {
public:
	/**
	 * When an object implementing interface Runnable is used to 
	 * create a thread, starting the thread causes the object's run 
	 * method to be called in that separately executing thread.
	 */
	virtual void run() = 0;

	virtual ~Runnable() {}
};

}}

#endif
