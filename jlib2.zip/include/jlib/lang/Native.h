
#ifndef JLIB_LANG_NATIVE
#define JLIB_LANG_NATIVE

#include <string>

namespace jlib { namespace lang {

class Thread;
class ThreadGuts;
class Monitor;
class ThreadGuts;
class Runnable;

class NativeMonitor {
public:
	virtual void enter() = 0;
	virtual void leave() = 0;
	virtual void notify() = 0;
	virtual void notifyAll() = 0;
	virtual void wait(long timeout) = 0;

	virtual ~NativeMonitor() {}
};

class NativeThread {
public:
	virtual void addRef() = 0;
	virtual void release() = 0;

	virtual void setName(const std::string& name) = 0;
	virtual const std::string& getName() const = 0;

	virtual void start() = 0;
	virtual void destroy() = 0;

	virtual void interrupt() = 0;
	virtual bool isInterrupted() const = 0;

	virtual bool isAlive() const = 0;

	virtual void setPriority(int priority) = 0;
	virtual int getPriority() const = 0;

	virtual void join(long millis) = 0;

	virtual ~NativeThread() {}
};

class NativeFactory {
public:
	virtual NativeMonitor* createMonitor(Monitor* target) = 0;
	virtual NativeThread* createThread(
		Runnable* target, const std::string& name) = 0;
	virtual NativeThread* currentThread() = 0;
	virtual void sleep(long millis) = 0;
	virtual void yield() = 0;

	virtual ~NativeFactory() {}
};

}}

#endif
