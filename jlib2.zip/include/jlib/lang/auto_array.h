#ifndef AUTO_ARRAY
#define AUTO_ARRAY

/**
 * A wrapper class that incapsulates a pointer allocated by
 * "operator new[]". The destructor can deallocate the memory
 * automatically by "operator delete[]"
 */
template <typename T>
class auto_array {
public:
	typedef T element_type;

	/**
	 * Construct a auto_array with a pointer allocated by "operator new[]".
	 *
	 * @param ptr the pointer to store
	 */
	explicit auto_array(T* ptr) throw() : ptr(ptr) {
	}

	/**
	 * Get the stored pointer.
	 *
	 * @return the stored pointer
	 */
	T* get() const throw() {
		return ptr;
	}

	/**
	 * Free the stored pointer and store the new one
	 *
	 * @param ptr the new pointer to store
	 */
	void reset(T* ptr = 0) {
		if ( this->ptr != ptr ) {
			delete[] ptr;
		}

		this->ptr = ptr;
	}

	/**
	 * Returns a reference to the element at specified position
	 *
	 * @param index the position of the element to access
	 *
	 * @return a reference to the element at specified position
	 */
	T& operator[](size_t index) throw() {
		return *(ptr + index);
	}

	/**
	 * Returns a const reference to the element at specified position
	 *
	 * @param index the position of the element to access
	 *
	 * @return a const reference to the element at specified position
	 */
	const T& operator[](size_t index) const throw() {
		return *(ptr+index);
	}

	/**
	 * release the stored pointer by using "operator delete[]"
	 */
	~auto_array() throw() {
		delete[] ptr;
	}

private:
	T* ptr;
};

#endif
