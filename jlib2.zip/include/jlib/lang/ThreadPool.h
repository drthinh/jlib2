#ifndef JLIB_LANG_THREADPOOL
#define JLIB_LANG_THREADPOOL

#include <queue>
#include <jlib/lang/Monitor.h>

namespace jlib { namespace lang {

class Thread;
class Runnable;

class ThreadPool {
public:
	ThreadPool(long waitTime = 5*60*1000);
	virtual ~ThreadPool();

	void execute(Runnable* target);

	void join();
	void join(long timeout);

	void setWaitTime(long waitTime);
	int getWaitTime() const;

	void setPriority(int);
	int getPriority() const;

	void close();

private:
	Runnable* waitNextTask();
	long waitTime;
	int priority;

	int numOfBusy;
	
	class PooledThread;
	typedef std::queue<Runnable*> TaskQueue;

	TaskQueue taskQueue;
	volatile int pooledCount;
	Monitor queueLock;

	volatile bool bejoined;

	void registerThread(PooledThread*);
	void unregisterThread(PooledThread*);
	volatile int threadCount;
	Monitor threadLock;
};

}}

#endif
