
template <ImpT>
class Reference {
public:
	Reference() {
	}
};

class NullReference {} null;