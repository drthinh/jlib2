#ifndef JLIB_DBC
#	define JLIB_DBC
#	include <cassert>
#	ifndef NDEBUG
#		define verify(f) assert(f)
#	else
#		define verify(f) ((void)(f))
#	endif
#endif
