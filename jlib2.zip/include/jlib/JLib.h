#ifndef JLIB_H
#define JLIB_H

#include <jlib/lang/String.h>
#include <jlib/entry_point.h>

using namespace jlib::lang;

#endif
