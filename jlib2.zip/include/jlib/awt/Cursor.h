#ifndef JLIB_AWT_CURSOR
#define JLIB_AWT_CURSOR

#include <jlib/lang/String.h>

namespace jlib { namespace awt {

using jlib::lang::String;

class Cursor {
public:
	enum {
		CUSTOM_CURSOR = -1,
		DEFAULT_CURSOR,
		CROSSHAIR_CURSOR,
		TEXT_CURSOR,
		WAIT_CURSOR,
		SW_RESIZE_CURSOR,
		SE_RESIZE_CURSOR,
		NW_RESIZE_CURSOR,
		NE_RESIZE_CURSOR,
		N_RESIZE_CURSOR,
		S_RESIZE_CURSOR,
		W_RESIZE_CURSOR,
		E_RESIZE_CURSOR,
		HAND_CURSOR,
		MOVE_CURSOR
	};

	static const Cursor& getPredefinedCursor(int type);
    static const Cursor& getDefaultCursor();

	Cursor();
    Cursor(int type);
	Cursor(const String& name);

	int getType() const;
	const String& getName() const;

	HCURSOR getPeer() const;

protected:
	Cursor(int type, LPCTSTR name, LPCTSTR nativeName);

	int type;
	String name;
	HCURSOR peer;

	class Predefined;
        friend class Predefined;
	static Predefined predefined;

	friend bool operator==(const Cursor& lhs, const Cursor& rhs);
};

inline int Cursor::getType() const {
	return type;
}

inline const String& Cursor::getName() const {
	return name;
}

inline HCURSOR Cursor::getPeer() const {
	return peer;
}

inline bool operator==(const Cursor& lhs, const Cursor& rhs) {
	return lhs.peer == rhs.peer;
}

inline bool operator!=(const Cursor& lhs, const Cursor& rhs) {
	return !( lhs == rhs);
}

}}

#endif
