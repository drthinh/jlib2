#ifndef JLIB_AWT_MENUBAR
#define JLIB_AWT_MENUBAR

#include <jlib/awt/MenuComponent.h>
#include <jlib/awt/MenuContainer.h>

#include <vector>

namespace jlib { namespace awt {

class Menu;

class MenuBar : public MenuComponent, public MenuContainer {
public:
    MenuBar();

	void addNotify();
	void removeNotify();

	const Font& getFont() const;

	bool isMenuBar() const;

	Menu* getHelpMenu() const;
	void setHelpMenu(Menu* m);

	Menu* add(Menu* m);
	void remove(int index);
	void remove(Menu* m);
	void remove(MenuComponent* mc);

	int getMenuCount() const;

	Menu* getMenu(int i) const;

	// WIN32
	HMENU getPeer() const;
	HACCEL getHACCEL() const;

private:
	typedef std::vector<Menu*> MenuList;
	MenuList menus;
    Menu* helpMenu;

	class ShortcutInfo;

	// peer operations
	HMENU peer;
	HMENU peer_createMenuBar();
	void peer_addHelpMenu(Menu* m);
	void peer_addMenu(Menu* m);
	void peer_delMenu(int index);
	void peer_dispose();

	HACCEL haccel;
	void peer_createShortcuts();
	void peer_delShortcuts();
};

inline const Font& MenuBar::getFont() const {
	return MenuComponent::getFont();
}

inline bool MenuBar::isMenuBar() const {
	return true;
}

inline HMENU MenuBar::getPeer() const {
	return peer;
}

inline HACCEL MenuBar::getHACCEL() const {
	return haccel;
}

}}

#endif
