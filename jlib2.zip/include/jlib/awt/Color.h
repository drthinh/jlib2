#ifndef JLIB_AWT_COLOR
#define JLIB_AWT_COLOR

namespace jlib { namespace awt {

class Color {
public:
	const static Color BLACK;
	const static Color BLUE;
	const static Color CYAN;
	const static Color DARKGRAY;
	const static Color GRAY;
	const static Color GREEN;
	const static Color LIGHTGRAY;
	const static Color MAGENTA;
	const static Color ORANGE;
	const static Color PINK;
	const static Color RED;
	const static Color WHITE;
	const static Color YELLOW;

	Color();
	Color(int r, int g, int b);
	Color(int rgb);

	int getRed() const;
	int getGreen() const;
	int getBlue() const;
	int getRGB() const;

	Color darker() const;
	Color brighter() const;

private:
	static const float FACTOR;

	friend bool operator==(const Color& lhs, const Color& rhs);
	friend bool operator!=(const Color& lhs, const Color& rhs);

	int value;
};

inline Color::Color() {
	value = 0xFF000000;
}

inline Color::Color(int r, int g, int b) {
	//value = ((r & 0xFF) << 16) |
	//		((g & 0xFF) << 8)  |
	//		((b & 0xFF) << 0);
	//value = RGB(r, g, b);
	value = ( (r & 0xFF) << 0 ) | 
			( (g & 0xFF) << 8 ) | 
			( (b & 0xFF) << 16 );
}

inline Color::Color(int rgb) {
	value = rgb;
}

inline int Color::getRed() const {
	//return (value >> 16) & 0xFF;
	//return GetRValue(value);
	return value & 0xFF;
}

inline int Color::getGreen() const {
	//return (value >> 8) & 0xFF;
	//return GetGValue(value);
	return ( value >> 8 ) & 0xFF;
}

inline int Color::getBlue() const {
	//return value & 0xFF;
	//return (value >> 16) & 0xFF;
	//return GetBValue(value);
	return ( value >> 16 ) & 0xFF;
}

inline int Color::getRGB() const {
	return value;
}

inline bool operator==(const Color& lhs, const Color& rhs) {
	return lhs.value == rhs.value;
}

inline bool operator!=(const Color& lhs, const Color& rhs) {
	return !(lhs == rhs);
}

}}

#endif
