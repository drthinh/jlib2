#ifndef JLIB_AWT_LAYOUTCONSTRAINT
#define JLIB_AWT_LAYOUTCONSTRAINT

namespace jlib { namespace awt {

class LayoutConstraint {
public:
	static LayoutConstraint nullConstraint;
protected:
	LayoutConstraint() {}

	LayoutConstraint(const LayoutConstraint&);
	LayoutConstraint& operator=(const LayoutConstraint&);
};

}}

#endif
