#ifndef JLIB_AWT_SCROLLPANE
#define JLIB_AWT_SCROLLPANE

#include <jlib/awt/Container.h>
#include <jlib/awt/AdjustmentListener.h>

namespace jlib { namespace awt {

class AdjustmentEvent;
class Adjustable;
class LayoutConstraint;
class ScrollPaneAdjustable;

class ScrollPane : public Container, AdjustmentListener {
public:
	enum ScrollbarDisplayPolicy {
		SCROLLBARS_AS_NEEDED,
		SCROLLBARS_ALWAYS,
		SCROLLBARS_NEVER,
	};

	ScrollPane(ScrollbarDisplayPolicy policy = SCROLLBARS_AS_NEEDED);
	~ScrollPane();

	ScrollbarDisplayPolicy getScrollbarDisplayPolicy() const;

	Dimension getViewportSize() const;

	int getHScrollbarHeight() const;
	int getVScrollbarWidth() const;

	Adjustable* getVAdjustable();
	Adjustable* getHAdjustable();

	void setScrollPosition(int x, int y);
	void setScrollPosition(const Point& p);
	Point getScrollPosition() const;

	void doLayout();

	//void printComponents(Graphics g);

	void addNotify();
	void addImpl(Component* comp, 
			const LayoutConstraint& constraints, int index);

private:
	void setLayout(LayoutManager*);

	Dimension calculateChildSize();

	ScrollbarDisplayPolicy scrollbarDisplayPolicy;
    ScrollPaneAdjustable* vAdjustable;
    ScrollPaneAdjustable* hAdjustable;

	void adjustmentValueChanged(const AdjustmentEvent&);

	// peer operations
	int peer_getHScrollbarHeight() const;
	int peer_getVScrollbarWidth() const;
	void peer_setInsets();
	void peer_childResized(int width, int height);
	void peer_setSpans(int parentWidth, int parentHeight,
			int childWidth, int childHeight);
	void peer_setScrollInfo(int orient, int max, 
			int page, bool disableNoScroll);

	void peer_setUnitIncrement(ScrollPaneAdjustable* adj, int u);
	void peer_setValue(Adjustable* adj, int v);

	friend class ScrollPaneAdjustable;

	// WIN32
	void handleScroll(int scrollCode, int pos, bool vertical);
	LPCTSTR getClassName() const;
	DWORD getWindowStyle() const;
	DWORD getWindowExStyle() const;

	bool wmMouseWheel(WPARAM wParam, LPARAM lParam);

	LRESULT windowProc(UINT message, WPARAM wParam, LPARAM lParam);
};

inline ScrollPane::ScrollbarDisplayPolicy 
ScrollPane::getScrollbarDisplayPolicy() const {
	return scrollbarDisplayPolicy;
}

}}

#endif
