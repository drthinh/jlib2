#ifndef JLIB_AWT_TEXTAREA
#define JLIB_AWT_TEXTAREA

#include <jlib/awt/TextComponent.h>

namespace jlib { namespace awt {

class TextArea : public TextComponent {
public:
	enum ScrollbarVisibility {
		SCROLLBARS_BOTH,
		SCROLLBARS_VERTICAL_ONLY,
		SCROLLBARS_HORIZONTAL_ONLY,
		SCROLLBARS_NONE,
	};

    TextArea(int rows, int columns);
	TextArea(const String& text = _T(""), int rows = 0, int columns = 0, 
			ScrollbarVisibility = SCROLLBARS_BOTH);

	void insert(const String& str, int pos);
	void append(const String& str);	
	void replaceRange(const String& str, int start, int end);

	int getScrollbarVisibility() const;

	int getRows() const;
	void setRows(int rows);

	int getColumns() const;
	void setColumns(int columns);

	Dimension getPreferredSize(int rows, int columns) const;
	Dimension getPreferredSize() const;

	Dimension getMinimumSize(int rows, int columns) const ;
	Dimension getMinimumSize() const;

private:
	int	rows;
	int	columns;

    ScrollbarVisibility scrollbarVisibility;

	// peer operations
	void peer_insert(const String& str, int pos);
	void peer_replaceRange(const String& str, int start, int end);
	Dimension peer_getPreferredSize(int row, int columns) const;
	Dimension peer_getMinimumSize(int rows, int columns) const;

	// WIN32
	DWORD getWindowStyle() const;
	DWORD getWindowExStyle() const;
};

inline int TextArea::getRows() const {
	return rows;
}

inline int TextArea::getColumns() const {
	return columns;
}

inline int TextArea::getScrollbarVisibility() const {
	return scrollbarVisibility;
}

}}

#endif
