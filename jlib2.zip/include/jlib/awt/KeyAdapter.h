#ifndef JLIB_AWT_EVENT_KEYADAPTER
#define JLIB_AWT_EVENT_KEYADAPTER


#include <jlib/awt/KeyListener.h>

namespace jlib { namespace awt {

class KeyAdapter : public KeyListener {
public:
	void keyTyped(KeyEvent&) {}
	void keyPressed(KeyEvent&) {}
	void keyReleased(KeyEvent&) {}
};

}}

#endif