#ifndef JLIB_AWT_EVENT_MOUSEMOTIONLISTENER
#define JLIB_AWT_EVENT_MOUSEMOTIONLISTENER

#include <jlib/util/EventListener.h>

namespace jlib { namespace awt {

class MouseMotionListener : public jlib::util::EventListener {
public:
    virtual void mouseDragged(MouseEvent&) = 0;
    virtual void mouseMoved(MouseEvent&) = 0;
};

}}

#endif
