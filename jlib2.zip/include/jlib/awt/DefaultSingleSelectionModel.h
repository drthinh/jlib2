#ifndef JLIB_AWT_DEFAULTSINGLESELECTIONMODEL
#define JLIB_AWT_DEFAULTSINGLESELECTIONMODEL

#include <jlib/awt/SingleSelectionModel.h>
#include <jlib/awt/ChangeListener.h>
#include <jlib/awt/ChangeEvent.h>
#include <jlib/util/EventDispatcher.h>

namespace jlib { namespace awt {

class DefaultSingleSelectionModel : public SingleSelectionModel {
public:
	DefaultSingleSelectionModel(int index = -1) 
		: index(index) {
	}

	int getSelectedIndex() const {
        return index;
    }

	void setSelectedIndex(int i) {
        if (index != i) {
            index = i;
			fireStateChanged();
        }
    }

	void clearSelection() {
        setSelectedIndex(-1);
    }

	bool isSelected() const {
		return getSelectedIndex() != -1;
    }

	void addChangeListener(ChangeListener* l) {
		changeEventDispatcher.addListener(l);
    }
    
	void removeChangeListener(ChangeListener* l) {
		changeEventDispatcher.removeListener(l);
    }

    void fireStateChanged() {
		if ( !changeEventDispatcher.empty() ) {
			changeEventDispatcher.fireEvent(this, 
					&ChangeListener::stateChanged, ChangeEvent());
		}
	}

private:
	int index;

	typedef jlib::util::EventDispatcher<ChangeListener> 
		ChangeEventDispatcher;
	ChangeEventDispatcher changeEventDispatcher;
};

}}

#endif
