#ifndef JLIB_AWT_GRIDBAGCONSTRAINTS
#define JLIB_AWT_GRIDBAGCONSTRAINTS

#include <jlib/awt/Insets.h>
#include <jlib/awt/LayoutConstraint.h>

#ifdef RELATIVE
#undef RELATIVE
#endif

namespace jlib { namespace awt {

class GridBagConstraints : public LayoutConstraint {
public:
	enum {
		RELATIVE = -1,
		REMAINDER = 0,
	};

	enum Fill {
		NONE,
		BOTH,
		HORIZONTAL,
		VERTICAL,
	};

	enum Anchor {
		// Aboulute
		CENTER,
		NORTH,
		NORTHEAST,
		EAST,
		SOUTHEAST,
		SOUTH,
		SOUTHWEST,
		WEST,
		NORTHWEST,

		// Relative
		PAGE_START,
		PAGE_END,
		LINE_START,
		LINE_END,
		FIRST_LINE_START,
		FIRST_LINE_END,
		LAST_LINE_START,
		LAST_LINE_END,
	};


	int gridx;
	int gridy;

	int gridwidth;
	int gridheight;

	double weightx;
	double weighty;

	Anchor anchor;

	Fill fill;

	Insets insets;

	int ipadx;
	int ipady;

	int tempX;
	int tempY;
	int tempWidth;
	int tempHeight;

	int minWidth;
	int minHeight;

	GridBagConstraints () 
		: insets(0, 0, 0, 0){
		gridx = RELATIVE;
		gridy = RELATIVE;
		gridwidth = 1;
		gridheight = 1;

		weightx = 0;
		weighty = 0;
		anchor = CENTER;
		fill = NONE;

		ipadx = 0;
		ipady = 0;
	}

	GridBagConstraints(const GridBagConstraints& rhs) {
		insets = rhs.insets;
		gridx = rhs.gridx;
		gridy = rhs.gridy;
		gridwidth = rhs.gridwidth;
		gridheight = rhs.gridheight;

		weightx = rhs.weightx;
		weighty = rhs.weighty;
		anchor = rhs.anchor;
		fill = rhs.fill;

		ipadx = rhs.ipadx;
		ipady = rhs.ipady;
	}
};

}}

#endif

