#ifndef JLIB_AWT_EVENT_MOUSEADAPTER
#define JLIB_AWT_EVENT_MOUSEADAPTER

#include <jlib/awt/MouseListener.h>

namespace jlib { namespace awt {

class MouseAdapter : public MouseListener {
public:
    void mouseClicked(MouseEvent&) {}
    void mousePressed(MouseEvent&) {}
    void mouseReleased(MouseEvent&) {}
    void mouseEntered(MouseEvent&) {}
    void mouseExited(MouseEvent&) {}
};

}}

#endif
