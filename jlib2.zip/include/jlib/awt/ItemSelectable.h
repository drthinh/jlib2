#ifndef JLIB_AWT_ITEMSELECTABLE
#define JLIB_AWT_ITEMSELECTABLE

namespace jlib { namespace awt {

class ItemListener;

class ItemSelectable {
public:
	virtual ~ItemSelectable() {}
    virtual void addItemListener(ItemListener*) = 0;
    virtual void removeItemListener(ItemListener*) = 0;
};

}}

#endif
