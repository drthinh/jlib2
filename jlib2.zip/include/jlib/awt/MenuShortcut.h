#ifndef JLIB_AWT_MENUSHORTCUT
#define JLIB_AWT_MENUSHORTCUT

namespace jlib { namespace awt {

class MenuShortcut {
public:
	MenuShortcut();
	explicit MenuShortcut(int key, bool useShiftModifier = false);

	bool operator!() const;

	int getKey() const;
	bool usesShiftModifier() const;

private:
	int key;
	bool usesShift;

	friend bool operator==(const MenuShortcut&, const MenuShortcut&);
};

inline MenuShortcut::MenuShortcut()
	: key(-1) {
}

inline MenuShortcut::MenuShortcut(int key, bool useShiftModifier) 
	: key(key), usesShift(useShiftModifier) {
}

inline int MenuShortcut::getKey() const {
	return key;
}

inline bool MenuShortcut::usesShiftModifier() const {
	return usesShift;
}

inline bool MenuShortcut::operator!() const {
	return key == -1;
}

inline bool operator==(const MenuShortcut& s1, const MenuShortcut& s2) {
	return s1.key == s2.key && s1.usesShift == s2.usesShift;
}

inline bool operator!=(const MenuShortcut& s1, const MenuShortcut& s2) {
	return !(s1 == s2);
}

}}

#endif
