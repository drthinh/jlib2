#ifndef JLIB_AWT_EVENT_HIERARCHYEVENT
#define JLIB_AWT_EVENT_HIERARCHYEVENT

#include <jlib/util/EventObject.h>

namespace jlib { namespace awt { 
	
class Container;
class Component;

class HierarchyEvent : public jlib::util::EventObject<Component> {
public:
	enum EventId {
		HIERARCHY_CHANGED,
		ANCESTOR_MOVED,
		ANCESTOR_RESIZED,
	};

	enum ChangeFlag {
		PARENT_CHANGED = 0x1,
		DISPLAYABILITY_CHANGED = 0x2,
		SHOWING_CHANGED = 0x4
	};

	HierarchyEvent(EventId id, Component* changed, Container* changedParent)
		: id(id), changed(changed), 
		changedParent(changedParent), changeFlags(0) {
	}

	HierarchyEvent(EventId id, Component* changed, 
		Container* changedParent, int changeFlags) 
		: id(id), changed(changed), 
		changedParent(changedParent), changeFlags(changeFlags) {
	}

	//Component* getComponent() const {
	//	return getSource();
	//}

	Component* getChanged() const {
		return changed;
	}

	Container* getChangedParent() const {
		return changedParent;
    }

	int getChangeFlags() const {
		return changeFlags;
    }

private:
	EventId id;
	Component* changed;
	Container* changedParent;
	int changeFlags;
};

}}

#endif
