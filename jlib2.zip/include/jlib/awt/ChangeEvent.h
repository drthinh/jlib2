#ifndef JLIB_AWT_EVENT_CHANGEEVENT
#define JLIB_AWT_EVENT_CHANGEEVENT

#include <jlib/util/EventObject.h>
#include <jlib/awt/ValueChangeable.h>

namespace jlib { namespace awt {

class ChangeEvent : public jlib::util::EventObject<ValueChangeable> {
public:
	ChangeEvent() {}
};

}}

#endif
