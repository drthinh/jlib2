#ifndef JLIB_AWT_LABEL
#define JLIB_AWT_LABEL

#include <jlib/awt/Component.h>

namespace jlib { namespace awt { 

class Label : public Component {
public:
	enum Alignment {
		LEFT,
		CENTER,
		RIGHT,
	};

	explicit Label(const String& text = _T(""), Alignment alignment = LEFT);
	~Label();

	void addNotify();

	Alignment getAlignment() const;
	void setAlignment(Alignment);

	const String& getText() const;
	void setText(const String&);

	Dimension getPreferredSize() const;

private:
	Alignment alignment;

	// win32
	void drawItem(DRAWITEMSTRUCT*);
	LPCTSTR getClassName() const;
	DWORD getWindowStyle() const;
};

inline Label::Alignment Label::getAlignment() const {
	return alignment;
}


inline const String& Label::getText() const {
	return text;
}

}}

#endif
