#ifndef JLIB_AWT_BORDERLAYOUT
#define JLIB_AWT_BORDERLAYOUT

#include <jlib/awt/LayoutManagerAdapter.h>

namespace jlib { namespace awt { 

class BorderLayout : public LayoutManagerAdapter {
public:
	class Constraint : public LayoutConstraint {
	private:
		friend class BorderLayout;
		Constraint() {}

		Constraint(const BorderLayout::Constraint&);
		Constraint& operator=(const BorderLayout::Constraint&);
	};

	static const Constraint NORTH;
	static const Constraint SOUTH;
	static const Constraint EAST;
	static const Constraint WEST;
	static const Constraint CENTER;
	static const Constraint BEFORE_FIRST_LINE;
	static const Constraint AFTER_LAST_LINE;
	static const Constraint BEFORE_LINE_BEGINS;
	static const Constraint AFTER_LINE_ENDS;
	static const Constraint& PAGE_START;
	static const Constraint& PAGE_END;
	static const Constraint& LINE_START;
	static const Constraint& LINE_END;

	BorderLayout(int hgap = 0, int vgap = 0);

	int getHgap() const;
	void setHgap(int hgap);

	int getVgap() const;
	void setVgap(int vgap);

	void addLayoutComponent(LayoutComponent* comp, 
			const LayoutConstraint& constraints);
	void removeLayoutComponent(LayoutComponent* comp);

	Dimension minimumLayoutSize(const LayoutContainer* target);
	Dimension preferredLayoutSize(const LayoutContainer* target);
	Dimension maximumLayoutSize(const LayoutContainer* target);

	void layoutContainer(LayoutContainer* target);
	
private:
	LayoutComponent* getChild(const Constraint& key, bool ltr);

	int hgap;
	int vgap;

	LayoutComponent* north;
	LayoutComponent* west;
	LayoutComponent* east;
	LayoutComponent* south;
	LayoutComponent* center;

	LayoutComponent* firstLine;
	LayoutComponent* lastLine;
	LayoutComponent* firstItem;
	LayoutComponent* lastItem;
};

inline int BorderLayout::getHgap() const{
	return hgap;
}

inline void BorderLayout::setHgap(int hgap) {
	this->hgap = hgap;
}

inline int BorderLayout::getVgap() const {
	return vgap;
}

inline void BorderLayout::setVgap(int vgap) {
	this->vgap = vgap;
}

}}

#endif
