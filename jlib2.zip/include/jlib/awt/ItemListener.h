#ifndef JLIB_AWT_EVENT_ITEMLISTENER
#define JLIB_AWT_EVENT_ITEMLISTENER

#include <jlib/util/EventListener.h>

namespace jlib { namespace awt {

class ItemEvent;

class ItemListener : public jlib::util::EventListener {
public:
	virtual void itemStateChanged(const ItemEvent&) = 0;
};

}}

#endif
