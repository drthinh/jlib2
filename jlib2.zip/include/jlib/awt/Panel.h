#ifndef JLIB_AWT_PANEL
#define JLIB_AWT_PANEL

#include <jlib/awt/Container.h>

namespace jlib { namespace awt {

class Panel : public Container {
public:
	Panel();
	Panel(LayoutManager* layout);
	virtual ~Panel();

private:
	class FlowLayout* defLayout;
};

}}

#endif
