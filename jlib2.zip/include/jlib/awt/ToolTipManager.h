#ifndef JLIB_AWT_TOOLTIPMANAGER
#define JLIB_AWT_TOOLTIPMANAGER

#include <jlib/awt/HierarchyListener.h>

namespace jlib { namespace awt {

class HierarchyEvent;
class Component;

class ToolTipManager : HierarchyListener {
public:
	void setEnabled(bool b);
	bool isEnabled() const;

	void setInitialDelay(int milliseconds);
	int getInitialDelay() const;

	void setDismissDelay(int milliseconds);
	int getDismissDelay() const;

	void setReshowDelay(int milliseconds);
	int getReshowDelay() const;

	void registerComponent(Component* comp);
	void unregisterComponent(Component* comp);

	static ToolTipManager& getSharedInstance();

protected:
	ToolTipManager();
	~ToolTipManager();

	void hierarchyChanged(const HierarchyEvent& e);

	void peer_create();
	void peer_destroy();
	void peer_register(Component* comp);
	void peer_unregister(Component* comp);
	void peer_setEnabled(bool b);
	void peer_setInitialDelay(int milliseconds);
	void peer_setDismissDelay(int milliseconds);
	void peer_setReshowDelay(int milliseconds);
	void peer_setDelay(int type, int milliseconds);

private:
	bool enabled;
	int initialDelay;
	int dismissDelay;
	int reshowDelay;

	HWND peer;
	static ToolTipManager* instance;
};

inline bool ToolTipManager::isEnabled() const {
	return enabled;
}

inline int ToolTipManager::getInitialDelay() const {
	return initialDelay;
}

inline int ToolTipManager::getDismissDelay() const {
	return dismissDelay;
}

inline int ToolTipManager::getReshowDelay() const {
	return reshowDelay;
}

}}

#endif
