#ifndef JLIB_AWT_TABBEDPANE
#define JLIB_AWT_TABBEDPANE

#include <jlib/awt/Container.h>
#include <jlib/awt/ValueChangeable.h>
#include <jlib/awt/Icon.h>
#include <jlib/awt/Tab.h>
#include <jlib/awt/BorderLayout.h>
#include <jlib/awt/Panel.h>
#include <jlib/awt/CardLayout.h>

#include <jlib/awt/ChangeListener.h>
#include <jlib/awt/ChangeEvent.h>

namespace jlib { namespace awt {

class ChangeEvent;
class SingleSelectionModel;

class TabbedPane : public Container, public TabConstants,
	public ValueChangeable, ChangeListener {
public:
	TabbedPane(Placement placement = TOP, 
		LayoutPolicy layoutPolicy = SCROLL_TAB_LAYOUT);

	void setModel(SingleSelectionModel* model);
	SingleSelectionModel* getModel() const;

	void addTab(const String& title, Component* comp);
	void addTab(const String& title, Icon* icon, 
			Component* comp, const String& tip = _T(""));

	void insertTab(const String& title, Icon* icon, 
			Component* comp, const String& tip, int index);
	void removeTabAt(int index);

	int getTabCount() const;

	void setTabLayoutPolicy(LayoutPolicy);
	LayoutPolicy getTabLayoutPolicy() const;

	void setTabPlacement(Placement);
	Placement getTabPlacement() const;

	int getSelectedIndex() const;
	void setSelectedIndex(int index);

	void setTitleAt(int index, const String& title);
	const String& getTitleAt(int index) const;

	void setComponentAt(int index, Component* comp);
	Component* getComponentAt(int index) const;

	void setToolTipTextAt(int index, const String& tip);
	const String& getToolTipTextAt(int index) const;

	void setIconAt(int index, const Icon*);
	const Icon* getIconAt(int index) const;

	void setForegroundAt(int index, Color c);
	Color getForegroundAt(int index) const;

	void setBackgroundAt(int index, Color c);
	Color getBackgroundAt(int index) const;

	void addChangeListener(ChangeListener*);
	void removeChangeListener(ChangeListener*);

	void setLayout(LayoutManager*);

private:
	void stateChanged(const ChangeEvent&);

	void placeTab();

	Tab tab;
	BorderLayout bl;
	Panel panel;
	CardLayout cl;

	SingleSelectionModel* model;

	typedef jlib::util::EventDispatcher<ChangeListener>
			ChangeEventDispatcher;
	ChangeEventDispatcher changeEventDispatcher;

	LRESULT windowProc(UINT, WPARAM, LPARAM);
};

inline void TabbedPane::setTabLayoutPolicy(TabbedPane::LayoutPolicy p) {
	tab.setLayoutPolicy(p);
}

inline TabbedPane::LayoutPolicy TabbedPane::getTabLayoutPolicy() const {
	return tab.getLayoutPolicy();
}

inline TabbedPane::Placement TabbedPane::getTabPlacement() const {
	return tab.getPlacement();
}

inline void TabbedPane::setToolTipTextAt(int index, const String& tip) {
	tab.setToolTipTextAt(index, tip);
}

inline const String& TabbedPane::getToolTipTextAt(int index) const {
	return tab.getToolTipTextAt(index);
}

inline void TabbedPane::setIconAt(int index, const Icon* icon) {
	tab.setIconAt(index, icon);
}

inline const Icon* TabbedPane::getIconAt(int index) const {
	return tab.getIconAt(index);
}

inline int TabbedPane::getTabCount() const {
	return tab.getTabCount();
}

inline SingleSelectionModel* TabbedPane::getModel() const {
	return model;
}

}}

#endif
