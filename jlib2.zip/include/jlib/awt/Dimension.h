#ifndef JLIB_AWT_DIMENSION
#define JLIB_AWT_DIMENSION

namespace jlib { namespace awt {

struct Dimension {
	int width;
	int height;

	Dimension(int w = 0, int h = 0) {
		height = h;
		width = w;
	}

	int getWidth() const {
		return width;
	}

	int getHeight() const {
		return height;
	}

	Dimension getSize() const {
		return *this;
	}

	void setSize(const Dimension& dim) {
		setSize(dim.width, dim.height);
	}

	void setSize(int w, int h) {
		width = w;
		height = h;
	}
};

inline bool operator==(const Dimension& lhs, const Dimension& rhs) {
	return lhs.width == rhs.width && lhs.height == rhs.height;
}

inline bool operator!=(const Dimension& lhs, const Dimension& rhs) {
	return !(lhs == rhs);
}

}}

#endif
