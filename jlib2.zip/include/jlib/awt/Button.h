#ifndef JLIB_AWT_BUTTON
#define JLIB_AWT_BUTTON

#include <jlib/awt/Component.h>
#include <jlib/awt/Actable.h>
#include <jlib/awt/ActionListener.h>

namespace jlib { namespace awt { 

using jlib::lang::String;

class Button : public Component, public Actable {
public:
	explicit Button(const String& label = _T(""));

	const String& getLabel() const;
	void setLabel(const String& label);

	void setActionCommand(const String& command);
	const String& getActionCommand() const;

	void addActionListener(ActionListener*);
	void removeActionListener(ActionListener*);

protected:
	void addNotify();

	typedef jlib::util::EventDispatcher<ActionListener>
		ActionEventDispatcher;
	ActionEventDispatcher actionEventDispatcher;

	Dimension getMinimumSize() const;

	const Color& getDefaultForeground() const;
	const Color& getDefaultBackground() const;

private:
	LPCTSTR getClassName() const;
	DWORD getWindowStyle() const;

	void drawItem(DRAWITEMSTRUCT* di);
	void handleCommand(UINT notifyCode);

	String actionCommand;
};

inline const String& Button::getLabel() const {
	return text;
}

inline void Button::setActionCommand(const String& command) {
	actionCommand = command;
}

inline const String& Button::getActionCommand() const {
	return actionCommand.empty() ? text : actionCommand;
}

}}

#endif
