#ifndef JLIB_AWT_PROGRESSBAR
#define JLIB_AWT_PROGRESSBAR

#include <jlib/awt/Canvas.h>
#include <jlib/awt/ValueChangeable.h>

#include <jlib/util/EventDispatcher.h>

#include <cassert>

namespace jlib { namespace awt {

class ChangeListener;
class Graphics;

class ProgressBar : public Canvas, public ValueChangeable {
public:
	enum Orientation {
		HORIZONTAL,
		VERTICAL
	};

	enum {
		defaultMinimum = 0,
		defaultMaximum = 100,
	};

    ProgressBar(Orientation orient = HORIZONTAL) {
		init(orient, defaultMinimum, defaultMaximum);
    }

	ProgressBar(int min, int max) {
		init(HORIZONTAL, min, max);
    }

	ProgressBar(Orientation orient, int min, int max) {
		init(orient, min, max);
	}

	Orientation getOrientation() const {
        return orientation;
    }

	void setOrientation(Orientation);

	bool isStringPainted() const {
        return shouldPaintString;
    }

	void setStringPainted(bool b);

	String getString() const;
	void setString(const String& s);

	double getPercentComplete() const;

	bool isBorderPainted() const {
        return shouldPaintBorder;
    }

	void setBorderPainted(bool b);

	void addChangeListener(ChangeListener*);
	void removeChangeListener(ChangeListener*);
      
    int getValue() const {
		return model.getValue();
	}

    int getMinimum() const {
		return model.getMinimum();
	}

    int getMaximum() const {
		return model.getMaximum();
	}

    void setValue(int v);
	void setMinimum(int v);
    void setMaximum(int v);

protected:
	virtual void paintBorder(Graphics& g);
	virtual void paintString(Graphics& g, 
			int x, int y, int width, int height, int boundary);
	virtual Point getStringPlacement(Graphics& g, 
			const String& progressString, 
			int x, int y, int width, int height);
	Dimension getMinimumSize() const;
	Dimension getPreferredSize() const;
	Dimension getMaximumSize() const;

	const Color& getDefaultForeground() const;
	const Color& getDefaultBackground() const;

private:
	Orientation orientation;
    bool shouldPaintBorder;

    String progressString;
	bool shouldPaintString;

	void init(Orientation orient, int minimum, int maximum);
	typedef jlib::util::EventDispatcher<ChangeListener>
		ChangeEventDispatcher;
	ChangeEventDispatcher changeEventDispatcher;

	void update(Graphics& g);
	void paint(Graphics& g);

	static const Dimension PREFERRED_INNER_HORIZONTAL;
    static const Dimension PREFERRED_INNER_VERTICAL;

	const Dimension& getPreferredInnerHorizontal() const {
		return PREFERRED_INNER_HORIZONTAL;
	}

	const Dimension& getPreferredInnerVertical() const {
		return PREFERRED_INNER_VERTICAL;
	}

	Color getSelectionForeground() const {
		return isForegroundSet() ? getForeground() : Color::BLUE;
	}

	Color getSelectionBackground() const {
		return isBackgroundSet() ? getBackground() : Color::WHITE;
	}

	class Model {
	public:
		int getMinimum() const {
			return minimum;
		}

		void setMinimum(int v) {
			assert(v <= value);
			this->minimum = v;
		}

		int getMaximum() const {
			return maximum;
		}

		void setMaximum(int v) {
			assert ( v >= value);
			this->maximum = v;
		}

		void setValue(int v) {
			assert ( minimum <= v && v <= maximum);
			value = v;
		}

		int getValue() const {
			return value;
		}

		void setRangeProperties(int value, int minimum, int maximum) {
			assert ( minimum <= value && value <= maximum);
			this->value = value;
			this->minimum = minimum;
			this->maximum = maximum;
		}

	private:
		int minimum;
		int maximum;
		int value;
	} model;
};

}}

#endif
