#ifndef JLIB_AWT_TEXTFIELD
#define JLIB_AWT_TEXTFIELD

#include <jlib/awt/TextComponent.h>
#include <jlib/awt/Actable.h>

namespace jlib { namespace awt {

class ActionListener;
class KeyEvent;


class TextField : public TextComponent, public Actable {
public:

	TextField(int columns)
		: TextComponent(_T("")), columns(columns), echoChar(0) {
    }

	TextField(const String& text = _T(""), int columns = 0);

    TCHAR getEchoChar() const;
    void setEchoChar(TCHAR c);
	bool echoCharIsSet() const;

    void setText(const String& t);

    int getColumns() const;
    void setColumns(int columns);

    Dimension getPreferredSize(int columns) const;
    Dimension getPreferredSize() const;

    Dimension getMinimumSize(int columns) const;
	Dimension getMinimumSize() const;

	void addActionListener(ActionListener*);
	void removeActionListener(ActionListener*);

protected:
	void processKeyEvent(const KeyEvent& e);

	typedef jlib::util::EventDispatcher<ActionListener>
			ActionEventDispatcher;
	ActionEventDispatcher actionEventDispatcher;

	void peer_setEchoChar(TCHAR echoChar);
	Dimension peer_getPreferredSize(int columns) const;
	Dimension peer_getMinimumSize(int columns) const;
	Dimension peer_getMinimumSize() const;

    int columns;
    TCHAR echoChar;

	// WIN32
	//bool filterEnterAndTabKeys(TCHAR ch, LPARAM flags);
	void fireActionEvent();
//	LRESULT windowProc(UINT message, WPARAM wParam, LPARAM lParam);
	DWORD getWindowStyle() const;
	DWORD getWindowExStyle() const;
};

inline TCHAR TextField::getEchoChar() const {
	return echoChar;
}

inline bool TextField::echoCharIsSet() const {
	return echoChar != 0;
}

inline int TextField::getColumns() const {
	return columns;
}

}}

#endif
