#ifndef JLIB_AWT_MENUCOMPONENT
#define JLIB_AWT_MENUCOMPONENT

#include <jlib/awt/Font.h>

namespace jlib { namespace awt {

class MenuContainer;

class MenuComponent {
public:
	MenuComponent();
	virtual ~MenuComponent();

	void setParent(MenuContainer* parent);
	MenuContainer* getParent() const;

	const Font& getFont() const;
	void setFont(const Font&);

    void removeNotify();

	bool isMenuBar() const;

protected:
	MenuContainer* parent;
	Font font;

	// peer operations
	virtual void peer_dispose();
};

inline bool MenuComponent::isMenuBar() const {
	return false;
}

inline MenuContainer* MenuComponent::getParent() const {
	return parent;
}

inline void MenuComponent::setParent(MenuContainer* parent) {
	this->parent = parent;
}

}}

#endif
