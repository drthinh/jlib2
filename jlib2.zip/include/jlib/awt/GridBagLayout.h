#ifndef JLIB_AWT_GRIDBAGLAYOUT
#define JLIB_AWT_GRIDBAGLAYOUT

#include <vector>
#include <map>

#include <cassert>

#include <jlib/awt/LayoutManagerAdapter.h>
#include <jlib/awt/LayoutConstraint.h>
#include <jlib/awt/Rectangle.h>
#include <jlib/awt/GridBagConstraints.h>

namespace jlib { namespace awt { 


struct GridBagLayoutInfo;

class GridBagLayout : public LayoutManagerAdapter {
public:
	enum {
		MAXGRIDSIZE = 512,
		MINSIZE = 1,
		PREFERREDSIZE = 2,
	};

	std::vector<int> columnWidths;
	std::vector<int> rowHeights;
	std::vector<double> columnWeights;
	std::vector<double> rowWeights;

	GridBagLayout();
	~GridBagLayout();

	void setConstraints(LayoutComponent* comp, 
	const GridBagConstraints& constraints);

	const GridBagConstraints& getConstraints(LayoutComponent* comp) const;

	/**
	 * Retrieves the constraints for the specified component.
	 * The return value is not a copy, but is the actual
	 * <code>GridBagConstraints</code> object used by the layout mechanism.
	 * @param       comp the component to be queried
	 * @return      the contraints for the specified componen.
	 */
	GridBagConstraints* lookupConstraints(LayoutComponent* comp);
  
    /**
     * Determines the origin of the layout area, in the graphics coordinate 
     * space of the target container.  This value represents the pixel 
     * coordinates of the top-left corner of the layout area regardless of
     * the <code>ComponentOrientation</code> value of the container.  This 
     * is distinct from the grid origin given by the cell coordinates (0,0).
     * Most applications do not call this method directly.
     * @return     the graphics origin of the cell in the top-left
     *             corner of the layout grid
     * @see        java.awt.ComponentOrientation
     * @since      JDK1.1
     */
	Point getLayoutOrigin() const;

    /**
     * Determines column widths and row heights for the layout grid.
     * <p>
     * Most applications do not call this method directly.
     * @return     an array of two arrays, containing the widths
     *                       of the layout columns and
     *                       the heights of the layout rows
     * @since      JDK1.1
     */
  //int [][] getLayoutDimensions ();

    /**
     * Determines the weights of the layout grid's columns and rows.
     * Weights are used to calculate how much a given column or row
     * stretches beyond its preferred size, if the layout has extra
     * room to fill.
     * <p>
     * Most applications do not call this method directly.
     * @return      an array of two arrays, representing the
     *                    horizontal weights of the layout columns
     *                    and the vertical weights of the layout rows
     * @since       JDK1.1
     */
  //double [][] getLayoutWeights();
    /**
     * Determines which cell in the layout grid contains the point
     * specified by <code>(x,&nbsp;y)</code>. Each cell is identified
     * by its column index (ranging from 0 to the number of columns
     * minus 1) and its row index (ranging from 0 to the number of
     * rows minus 1).
     * <p>
     * If the <code>(x,&nbsp;y)</code> point lies
     * outside the grid, the following rules are used.
     * The column index is returned as zero if <code>x</code> lies to the
     * left of the layout for a left-to-right container or to the right of
     * the layout for a right-to-left container.  The column index is returned
     * as the number of columns if <code>x</code> lies
     * to the right of the layout in a left-to-right container or to the left
     * in a right-to-left container.
     * The row index is returned as zero if <code>y</code> lies above the 
     * layout, and as the number of rows if <code>y</code> lies
     * below the layout.  The orientation of a container is determined by its
     * <code>ComponentOrientation</code> property.
     * @param      x    the <i>x</i> coordinate of a point
     * @param      y    the <i>y</i> coordinate of a point
     * @return     an ordered pair of indexes that indicate which cell
     *             in the layout grid contains the point
     *             (<i>x</i>,&nbsp;<i>y</i>).
     * @see        java.awt.ComponentOrientation
     * @since      JDK1.1
     */
	Point location(int x, int y);


    /**
     * Adds the specified component to the layout, using the specified
     * <code>constraints</code> object.  Note that constraints
     * are mutable and are, therefore, cloned when cached.
     *
     * @param      comp         the component to be added
     * @param      constraints  an object that determines how
     *                          the component is added to the layout
     * @exception IllegalArgumentException if <code>constraints</code>
     *		  is not a <code>GridBagConstraint</code>
     */
    void addLayoutComponent(LayoutComponent* comp, 
			const LayoutConstraint& constraints);

    /**
     * Removes the specified component from this layout.
     * <p>
     * Most applications do not call this method directly.
     * @param    comp   the component to be removed.
     * @see      java.awt.LayoutContainer#remove(java.awt.LayoutComponent)
     * @see      java.awt.LayoutContainer#removeAll()
     */
	void removeLayoutComponent(LayoutComponent* comp) ;

	/**
     * Determines the preferred size of the <code>target</code>
     * container using this grid bag layout.
     * <p>
     * Most applications do not call this method directly.
     * @param     target   the container in which to do the layout.
     * @see       java.awt.LayoutContainer#getPreferredSize
	 */
	Dimension preferredLayoutSize(const LayoutContainer* parent);

	/**
     * Determines the minimum size of the <code>target</code> container
     * using this grid bag layout.
     * <p>
     * Most applications do not call this method directly.
     * @param     target   the container in which to do the layout.
     * @see       java.awt.LayoutContainer#doLayout
	 */
	Dimension minimumLayoutSize(const LayoutContainer* parent);

    /**
     * Returns the maximum dimensions for this layout given the components
     * in the specified target container.
     * @param target the component which needs to be laid out
     * @see LayoutContainer
     * @see #minimumLayoutSize(LayoutContainer)
     * @see #preferredLayoutSize(LayoutContainer)
     */
    Dimension maximumLayoutSize(const LayoutContainer* target);

	/**
	 * Lays out the specified container using this grid bag layout.
	 * This method reshapes components in the specified container in
	 * order to satisfy the contraints of this <code>GridBagLayout</code>
	 * object.
	 * <p>
	 * Most applications do not call this method directly.
	 * @param parent the container in which to do the layout.
	 * @see java.awt.LayoutContainer
	 * @see java.awt.LayoutContainer#doLayout
	 */
	void layoutContainer(LayoutContainer* parent) {
		arrangeGrid(parent);
	}

protected:
	typedef std::map<LayoutComponent*, GridBagConstraints*> ComponentTable;
	ComponentTable comptable;

	GridBagConstraints defaultConstraints;

	GridBagLayoutInfo* layoutInfo;

	void getLayoutInfo(const LayoutContainer* parent, 
		int sizeflag, GridBagLayoutInfo* info);

	void adjustForGravity(
			const GridBagConstraints& constraints, Rectangle* r);
    /**
     * Figure out the minimum size of the
     * master based on the information from getLayoutInfo()
     * @since 1.4
     */
    Dimension getMinSize(const LayoutContainer* parent, 
			const GridBagLayoutInfo& info) const;

    bool rightToLeft;

    /**
     * Lay out the grid
     * @since 1.4
     */
    void arrangeGrid(LayoutContainer* parent);

private:
	void removeConstraints(LayoutComponent* comp);
};

}}

#endif

