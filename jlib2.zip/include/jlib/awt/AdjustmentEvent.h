#ifndef JLIB_AWT_EVENT_ADJUSTMENTEVENT
#define JLIB_AWT_EVENT_ADJUSTMENTEVENT

#include <jlib/util/EventObject.h>

namespace jlib { namespace awt {

class AdjustmentEvent : public jlib::util::EventObject<Adjustable> {
public:
	enum Type {
		UNIT_INCREMENT,
		UNIT_DECREMENT,
		BLOCK_DECREMENT,
		BLOCK_INCREMENT,
		TRACK,
	};

	AdjustmentEvent(Type type, int value) 
		: adjustmentType(type), value(value) {
    }
	
	Adjustable* getAdjustable() const {
        return getSource();
    }
	
	int getValue() const {
        return value;
    }

	Type getAdjustmentType() const {
        return adjustmentType;
    }

private:
	Type adjustmentType;
    int value;
};

}}

#endif
