#ifndef JLIB_AWT_MOUSESTATETRACKER
#define JLIB_AWT_MOUSESTATETRACKER

namespace jlib { namespace awt {

class Component;

class MouseStateTracker {
public:
	bool mouseDown(Component* comp, UINT flags, int x, int y, int button);
	bool mouseUp(Component* comp, UINT flags, int x, int y, int button);
	bool mouseMove(Component* comp, UINT flags, int x, int y);
	bool mouseLeave(Component* comp);

	static MouseStateTracker& instance();

private:
	MouseStateTracker();
	void filterEnter(Component* comp, int x, int y, int button);

	ULONG multiClickTime;
	int multiClickMaxX;
	int multiClickMaxY;

	HWND lastWnd;
	Component* lastClickComp;
	Component* lastComp;

	ULONG lastTime;
	int lastClickX;
	int lastClickY;
	int lastX;
	int lastY;
	int lastButton;
	int clickCount;

	bool dragged;
};

}}

#endif
