#ifndef JLIB_AWT_LAYOUTMANAGER
#define JLIB_AWT_LAYOUTMANAGER

#include <jlib/awt/LayoutConstraint.h>
#include <jlib/awt/Dimension.h>

namespace jlib { namespace awt { 

class LayoutComponent;
class LayoutContainer;

class LayoutManager {
public:
	virtual void addLayoutComponent(LayoutComponent* comp, 
			const LayoutConstraint& constraints) = 0;
	virtual void removeLayoutComponent(LayoutComponent* comp) = 0;

	virtual void layoutContainer(LayoutContainer* parent) = 0;

	virtual Dimension minimumLayoutSize(const LayoutContainer* parent) = 0;
	virtual Dimension preferredLayoutSize(const LayoutContainer* parent) = 0;
	virtual Dimension maximumLayoutSize(const LayoutContainer* target) = 0;

    virtual float getLayoutAlignmentX(const LayoutContainer* target) const = 0;
    virtual float getLayoutAlignmentY(const LayoutContainer* target) const = 0;

    virtual void invalidateLayout(LayoutContainer* target) = 0;

protected:
	virtual ~LayoutManager() {}
};

}}

#endif
