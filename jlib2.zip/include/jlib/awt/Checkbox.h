#ifndef JLIB_AWT_CHECKBOX
#define JLIB_AWT_CHECKBOX

#include <jlib/awt/Component.h>
#include <jlib/awt/ItemSelectable.h>

namespace jlib { namespace awt {

using jlib::lang::String;

class CheckboxGroup;
class ItemListener;

class Checkbox : public Component, public ItemSelectable {
public:
	explicit Checkbox(const String& label = _T(""), 
			bool state = false, CheckboxGroup* group = NULL);

	const String& getLabel() const;
	void setLabel(const String&);

	bool getState() const;
	void setState(bool);

	CheckboxGroup* getCheckboxGroup() const;
	void setCheckboxGroup(CheckboxGroup*);

	void addItemListener(ItemListener*);
	void removeItemListener(ItemListener*);

	Dimension getMinimumSize() const;

private:
	void addNotify();

	void handleCommand(UINT notifyCode);

	bool state;
	CheckboxGroup* group;

	typedef jlib::util::EventDispatcher<ItemListener>
			ItemEventDispatcher;
	ItemEventDispatcher itemEventDispatcher;

	friend class CheckboxGroup;
	void setStateInternal(bool state);

	// peer operations
	void peer_setState(bool state);

	LPCTSTR getClassName() const;
	DWORD getWindowStyle() const;
};


inline const String& Checkbox::getLabel() const {
	return text;
}

inline bool Checkbox::getState() const {
	return state;
}

inline CheckboxGroup* Checkbox::getCheckboxGroup() const {
	return group;
}

}}

#endif
