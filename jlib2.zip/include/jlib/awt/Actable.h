#ifndef JLIB_AWT_ACTABLE
#define JLIB_AWT_ACTABLE

namespace jlib { namespace awt {

class ActionListener;

class Actable {
public:
	virtual ~Actable() {}
	virtual void addActionListener(ActionListener*) = 0;
	virtual void removeActionListener(ActionListener*) = 0;
};

}}

#endif
