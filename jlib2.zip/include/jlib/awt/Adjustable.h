#ifndef JLIB_AWT_ADJUSTABLE
#define JLIB_AWT_ADJUSTABLE

namespace jlib { namespace awt {

class AdjustmentListener;

class Adjustable {
public:
	enum Orientation {
		HORIZONTAL,
		VERTICAL
	};

	virtual Orientation getOrientation() const = 0;

	virtual void setMinimum(int) = 0;
	virtual int getMinimum() const = 0;

	virtual void setMaximum(int) = 0;
	virtual int getMaximum() const = 0;

	virtual void setUnitIncrement(int) = 0;
	virtual int getUnitIncrement() const = 0;

	virtual void setBlockIncrement(int) = 0;
	virtual int getBlockIncrement() const = 0;

	virtual void setVisibleAmount(int) = 0;
	virtual int getVisibleAmount() const = 0;

	virtual void setValue(int) = 0;
	virtual int getValue() const = 0;

	virtual void addAdjustmentListener(AdjustmentListener*) = 0;
	virtual void removeAdjustmentListener(AdjustmentListener*) = 0;

	virtual ~Adjustable() {}
};

}}

#endif
