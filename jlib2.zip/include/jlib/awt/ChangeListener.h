#ifndef JLIB_AWT_EVENT_CHANGELISTENER
#define JLIB_AWT_EVENT_CHANGELISTENER

#include <jlib/util/EventListener.h>

namespace jlib { namespace awt {

class ChangeEvent;

class ChangeListener : public jlib::util::EventListener {
public:
	virtual void stateChanged(const ChangeEvent&) = 0;
};

}}

#endif
