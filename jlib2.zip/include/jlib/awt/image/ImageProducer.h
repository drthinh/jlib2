#ifndef JLIB_AWT_IMAGE_IMAGEPRODUCER
#define JLIB_AWT_IMAGE_IMAGEPRODUCER

namespace jlib { namespace awt { namespace image {

class ImageConsumer;

class ImageProducer {
public:
	virtual void addConsumer(ImageConsumer* ic) = 0;
	virtual bool isConsumer(ImageConsumer* ic) = 0;
	virtual void removeConsumer(ImageConsumer ic) = 0;
	virtual void startProduction(ImageConsumer* ic) = 0;
	virtual void requestTopDownLeftRightResend(ImageConsumer* ic) = 0;
};

}}}

#endif