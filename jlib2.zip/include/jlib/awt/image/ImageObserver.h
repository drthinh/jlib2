#ifndef JLIB_AWT_IMAGE_IMAGEOBSERVER
#define JLIB_AWT_IMAGE_IMAGEOBSERVER

namespace jlib { namespace awt { 

class Image;

namespace image {

class ImageObserver {
public:
	virtual bool imageUpdate(jlib::awt::Image* img, int infoflags, 
			int x, int y, int width, int height) = 0;
};

}}}

#endif
