#ifndef JLIB_AWT_SPLITPANE
#define JLIB_AWT_SPLITPANE

#include <jlib/awt/Container.h>
#include <jlib/awt/SplitPaneDivider.h>

namespace jlib { namespace awt {

class SplitPaneDivider;

class SplitPane : public Container {
public:
	enum Orientation {
		VERTICAL_SPLIT,
		HORIZONTAL_SPLIT
	};

    explicit SplitPane(Orientation orientation = HORIZONTAL_SPLIT, 
			bool continuousLayout = false, 
			Component* leftComponent = NULL, 
			Component* rightComponent = NULL);

	~SplitPane();

	void addNotify();

	void setBounds(int x, int y, int width, int height);

	void setDividerSize(int);
	int getDividerSize() const;

	void setLeftComponent(Component*);
    Component* getLeftComponent();

	void setTopComponent(Component*);
	Component* getTopComponent();

	void setRightComponent(Component*);
	Component* getRightComponent();

	void setBottomComponent(Component*);
	Component* getBottomComponent();

    void setOneTouchExpandable(bool);
	bool isOneTouchExpandable() const;

	void setLastDividerLocation(int);
	int getLastDividerLocation() const;

	void setOrientation(Orientation);
	Orientation getOrientation() const;

	void setContinuousLayout(bool);
	bool isContinuousLayout() const;

	void setResizeWeight(double);
	double getResizeWeight() const;

    void resetToPreferredSizes();

	void setDividerLocation(double);
	void setDividerLocation(int);
	int getDividerLocation() const;

	int getMinimumDividerLocation() const;
	int getMaximumDividerLocation() const;

	void remove(Component* component);
	void remove(int index);

	void removeAll();

protected:
	void addImpl(Component* comp, 
		const LayoutConstraint& constraint, int index);

	void processMouseEvent(MouseEvent& e);
	void processMouseMotionEvent(MouseEvent& e);

	void paint(Graphics& g);
	void update(Graphics& g);

    Component* leftComponent;
    Component* rightComponent;

	double resizeWeight;

protected:
	const Color& getDefaultBackground() const;

private:
	SplitPaneDivider divider;

	DWORD getWindowStyle() const;
};

}}

#endif
