#ifndef JLIB_AWT_EVENT_CONTAINEREVENT
#define JLIB_AWT_EVENT_CONTAINEREVENT

#include <jlib/util/EventObject.h>

namespace jlib { namespace awt {

class ContainerEvent : public jlib::util::EventObject<Container> {
public:
	enum EventId {
		COMPONENT_ADDED,
		COMPONENT_REMOVED,
	};

	ContainerEvent(EventId id, Component* child)
		: id(id), child(child) {
	}

	EventId getID() const {
		return id;
	}

	Container* getContainer() const {
		return getSource();
	}

	Component* getChild() const {
		return child;
	}

private:
	EventId id;
	Component* child;
};

}}

#endif
