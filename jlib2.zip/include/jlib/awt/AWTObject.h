#ifndef JLIB_AWT_AWTOBJECT
#define JLIB_AWT_AWTOBJECT

namespace jlib { namespace awt {

class AWTObject {
public:
	virtual ~AWTObject() {
	}
};

}}

#endif
