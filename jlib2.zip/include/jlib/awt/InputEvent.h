#ifndef JLIB_AWT_EVENT_INPUTEVENT_H
#define JLIB_AWT_EVENT_INPUTEVENT_H

#include <jlib/util/EventObject.h>

namespace jlib { namespace awt { 

class Component;

class InputEvent : public jlib::util::EventObject<Component> {
public:
	enum {
		SHIFT_MASK = 1,
		CTRL_MASK = 2,
		META_MASK = 4,
		ALT_MASK = 8,
		ALT_GRAPH_MASK = 1 << 5,
		BUTTON1_MASK = 1 << 4,
		BUTTON2_MASK = 8,
		BUTTON3_MASK = 4
	};

    InputEvent(long when, int modifiers) 
		: when(when), modifiers(modifiers), consumed(false) {
    }

    bool isShiftDown() const {
        return (modifiers & SHIFT_MASK) != 0;
    }

    bool isControlDown() const {
        return (modifiers & CTRL_MASK) != 0;
    }

    bool isMetaDown() const {
        return (modifiers & META_MASK) != 0;
    }

    bool isAltDown() const {
        return (modifiers & ALT_MASK) != 0;
    }

    bool isAltGraphDown() const {
		return (modifiers & InputEvent::ALT_GRAPH_MASK) != 0;
    }

    long getWhen() const {
        return when;
    }

    int getModifiers() const {
        return modifiers;
    }

    void consume() {
        consumed = true;
    }

    bool isConsumed() const {
        return consumed;
    }

private:
    long when;
    int modifiers;
	bool consumed;
};

}}

#endif
