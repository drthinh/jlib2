#ifndef JLIB_AWT_EVENT_COMPONENTADAPTER
#define JLIB_AWT_EVENT_COMPONENTADAPTER

#include <jlib/awt/ComponentListener.h>

namespace jlib { namespace awt {

class ComponentAdapter : public ComponentListener {
public:
	void componentResized(const ComponentEvent&) {}
	void componentMoved(const ComponentEvent&) {}
	void componentShown(const ComponentEvent&) {}
	void componentHidden(const ComponentEvent&) {}
};

}}

#endif
