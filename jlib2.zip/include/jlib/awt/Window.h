#ifndef JLIB_AWT_WINDOW
#define JLIB_AWT_WINDOW

#include <jlib/awt/Container.h>

namespace jlib { namespace awt {

class WindowListener;

class Window : public Container {
public:
	Window(Window* owner);
	virtual ~Window();

	void addNotify();

	void pack();

	void setVisible(bool);
	virtual void show();
	virtual void dispose();

	void toFront();
	void toBack();

	void addWindowListener(WindowListener*);
	void removeWindowListener(WindowListener*);

	bool isWindow() const;

	static Window* getActiveWindow();

protected:

	void updateInsets();

	Window* owner;
	class BorderLayout* defLayout;
	
	typedef std::vector<Window*> WindowList;
	WindowList ownedWindows;
	void addOwnedWindow(Window* w);
	void removeOwnedWindow(Window* w);

	typedef jlib::util::EventDispatcher<WindowListener>
			WindowEventDispatcher;
	WindowEventDispatcher windowEventDispatcher;

	// peer operations
	bool peer_updateInsets();
	void peer_toFront();
	void peer_toBack();

	// WIN32
	void wmClose();
	void wmMove(WPARAM wParam, LPARAM lParam);
	void wmSize(WPARAM wParam, LPARAM lParam);
	void wmActivate(WPARAM wParam, LPARAM lParam);
	virtual LRESULT windowProc(UINT message, WPARAM wParam, LPARAM lParam);

	static Window* currentActive;
};

inline bool Window::isWindow() const {
	return true;
}

}}

#endif
