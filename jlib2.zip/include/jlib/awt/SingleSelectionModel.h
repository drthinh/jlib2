#ifndef JLIB_AWT_SINGLESELECTINOMODEL
#define JLIB_AWT_SINGLESELECTINOMODEL

#include <jlib/awt/ValueChangeable.h>

namespace jlib { namespace awt {

class ChangeListener;


class SingleSelectionModel : public ValueChangeable {
public:
	virtual int getSelectedIndex() const = 0;
	virtual void setSelectedIndex(int) = 0;

    virtual void clearSelection() = 0;
	virtual bool isSelected() const = 0;
	virtual void addChangeListener(ChangeListener*) = 0;
    virtual void removeChangeListener(ChangeListener*) = 0;
};

}}

#endif
