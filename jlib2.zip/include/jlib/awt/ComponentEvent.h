#ifndef JLIB_AWT_EVENT_COMPONENTEVENT
#define JLIB_AWT_EVENT_COMPONENTEVENT

#include <jlib/util/EventObject.h>

namespace jlib { namespace awt {

class ComponentEvent : public jlib::util::EventObject<Component> {
public:
	enum EventId {
		COMPONENT_MOVED,
		COMPONENT_RESIZED,
		COMPONENT_SHOWN,
		COMPONENT_HIDDEN,
	};

	explicit ComponentEvent(EventId id)
		: id(id) {
	}

    Component* getComponent() const {
        return getSource();
    }

private:
	EventId id;
};

}}

#endif
