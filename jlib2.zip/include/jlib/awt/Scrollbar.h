#ifndef JLIB_AWT_SCROLLBAR
#define JLIB_AWT_SCROLLBAR

#include <jlib/awt/Component.h>
#include <jlib/awt/Adjustable.h>
#include <jlib/awt/AdjustmentEvent.h>

#include <jlib/util/EventDispatcher.h>

namespace jlib { namespace awt {

class AdjustmentListener;


class Scrollbar : public Component, public Adjustable {
public:
    Scrollbar(Orientation orientation = VERTICAL,
			int value = 0, int visible = 10, 
			int minimum = 0, int maximum = 100);

	void addNotify();

	Orientation getOrientation() const;
	void setOrientation(Orientation);

	int getValue() const;
	void setValue(int);

	int getMinimum() const;
	void setMinimum(int);
	
	int getMaximum() const;
	void setMaximum(int);

	int getVisibleAmount() const ;
	void setVisibleAmount(int);

	int getUnitIncrement() const;
	void setUnitIncrement(int);

	int getBlockIncrement() const;
	void setBlockIncrement(int);

	void setValues(int value, int visible, int minimum, int maximum);

	void addAdjustmentListener(AdjustmentListener*);
	void removeAdjustmentListener(AdjustmentListener*);

	Dimension getMinimumSize() const;

protected:
	const Color& getDefaultForeground() const;
	const Color& getDefaultBackground() const;

private:
	void init(Orientation orientation, int value, 
			int visible, int minimum, int maximum);
	int	value;
    int	maximum;
    int	minimum;
    int	visibleAmount;
    Orientation	orientation;
    int lineIncrement;
    int pageIncrement;

	mutable int oldScrollType;
	mutable int oldValue;
	void fireScrollEvent(AdjustmentEvent::Type code, int value);

	void lineUp(int value);
	void lineDown(int value);
	void pageUp(int value);
	void pageDown(int value);
	void dragBegin(int value);
	void dragAbsolute(int value);
	void dragEnd(int value);

	typedef jlib::util::EventDispatcher<AdjustmentListener> 
		AdjustmentEventDispatcher;
    AdjustmentEventDispatcher adjustmentEventDispatcher;

	// peer operations
	void peer_setLineIncrement(int v);
	void peer_setPageIncrement(int v);
	void peer_setValues(int value, int visibleAmout, 
			int minimum, int maxium);

	// WIN32
	void handleScroll(int scrollCode, int pos, bool vertical);

	LPCTSTR getClassName() const;
	DWORD getWindowStyle() const;
};

inline Scrollbar::Orientation Scrollbar::getOrientation() const {
	return orientation;
}

inline int Scrollbar::getValue() const {
	return value;
}

inline void Scrollbar::setValue(int newValue) {
	setValues(newValue, visibleAmount, minimum, maximum);
}

inline int Scrollbar::getMinimum() const {
	return minimum;
}

inline void Scrollbar::setMinimum(int newMinimum) {
	setValues(value, visibleAmount, newMinimum, maximum);
}

inline int Scrollbar::getMaximum() const {
	return maximum;
}

inline void Scrollbar::setMaximum(int newMaximum) {
	setValues(value, visibleAmount, minimum, newMaximum);
}

inline int Scrollbar::getVisibleAmount() const {
	return visibleAmount;
}

inline void Scrollbar::setVisibleAmount(int newAmount) {
	setValues(value, newAmount, minimum, maximum);
}

inline int Scrollbar::getUnitIncrement() const {
	return lineIncrement;
}

inline int Scrollbar::getBlockIncrement() const {
	return pageIncrement;
}

}}

#endif
