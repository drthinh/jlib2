#ifndef JLIB_AWT_EVENT_WINDOWADAPTER
#define JLIB_AWT_EVENT_WINDOWADAPTER


#include <jlib/awt/WindowListener.h>

namespace jlib { namespace awt {

class WindowAdapter : public WindowListener {
public:
	void windowOpened(const WindowEvent&) {}
    void windowClosing(const WindowEvent&) {}
    void windowClosed(const WindowEvent&) {}
    void windowIconified(const WindowEvent&) {}
    void windowDeiconified(const WindowEvent&) {}
    void windowActivated(const WindowEvent&) {}
    void windowDeactivated(const WindowEvent&) {}
};

}}

#endif
