#ifndef JLIB_AWT_CANVAS
#define JLIB_AWT_CANVAS

#include <jlib/awt/Component.h>

namespace jlib { namespace awt {

class Canvas : public Component {
public:
    Canvas();
	void update(Graphics& g);

protected:
	bool peer_shouldClearRectBeforePaint();

	// WIN32
	void wmSetCursor(WPARAM wParam, LPARAM lParam);
	bool wmMouseDown(WPARAM wParam, LPARAM lParam, int button);
	bool wmMouseUp(WPARAM wParam, LPARAM lParam, int button);
};

inline Canvas::Canvas() {
}

inline bool Canvas::peer_shouldClearRectBeforePaint() {
	return true;
}

}}

#endif
