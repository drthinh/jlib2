#ifndef JLIB_AWT_RECTANGLE
#define JLIB_AWT_RECTANGLE

#include <jlib/awt/Point.h>
#include <jlib/awt/Dimension.h>

namespace jlib { namespace awt { 

struct Rectangle 
#if __GNUC__ >= 3 && __GNUC_MINOR < 3 
	// workaround for GCC3.2 using declaration bug - c++/8205
	{

	int x, y, width, height;

	Rectangle()
		: x(0), y(0), width(0), height(0) {
	}

	Rectangle(int x, int y, int width, int height)
		: x(x), y(y), width(width), height(height) {
    }

	Rectangle(int width, int height) 
		: x(0), y(0), width(width), height(height) {
    }

    Rectangle(const Point& p, const Dimension& d) 
		: x(p.x), y(p.y), width(d.width), height(d.height) {
    }
    
    Rectangle(const Point& p) 
		: x(p.x), y(p.y), width(0), height(0) {
    }
    
    Rectangle(const Dimension& d) 
		: x(0), y(0), width(d.width), height(d.height) {
    }

	Point getLocation() const {
		return Point(x, y);
	}

	void setLocation(const Point& p) {
		x = p.x;
		y = p.y;
	}

	void translate(int dx, int dy) {
		Point p(x, y);
		p.translate(dx, dy);
		x = p.x;
		y = p.y;
	}

	Dimension getSize() const {
		return Dimension(width, height);
	}

	void setSize(const Dimension& d) {
		width = d.width;
		height = d.height;
	}

#else
	: protected Point, protected Dimension {
	using Point::x;
	using Point::y;
	using Point::getLocation;
	using Point::setLocation;
	using Point::translate;

	using Dimension::width;
	using Dimension::height;
	using Dimension::getSize;
	using Dimension::setSize;

	Rectangle(int x, int y, int width, int height)
		: Point(x, y), Dimension(width, height) {
    }

	Rectangle(int width, int height) 
		: Dimension(width, height) {
    }

    Rectangle(const Point& p, const Dimension& d) 
		: Point(p), Dimension(d) {
    }
    
    Rectangle(const Point& p) 
		: Point(p) {
    }
    
    Rectangle(const Dimension& d) 
		: Dimension(d) {
    }

	Rectangle() {
	}

#endif

	const Rectangle& getBounds() const {
		return *this;
	}

	void setBounds(const Rectangle& r) {
		setBounds(r.x, r.y, r.width, r.height);
	}

	void setBounds(int x, int y, int width, int height) {
		this->x = x;
		this->y = y;
		this->width = width;
		this->height = height;
	}

	bool contains(const Point& p) const {
		return contains(p.x, p.y);
	}

    bool contains(int X, int Y) const {
		int w = this->width;
		int h = this->height;
		if ((w | h) < 0) {
			// At least one of the dimensions is negative...
			return false;
		}

		// If either dimension is zero, tests below must return false...
		int x = this->x;
		int y = this->y;
		if (X < x || Y < y) {
			return false;
		}

		w += x;
		h += y;
		// overflow || intersect
		return (w < x || w > X) && (h < y || h > Y);
    }

 //   /**
 //    * Checks whether or not this <code>Rectangle</code> entirely contains 
 //    * the specified <code>Rectangle</code>.
 //    * @param     r   the specified <code>Rectangle</code>
 //    * @return    <code>true</code> if the <code>Rectangle</code> 
 //    *            is contained entirely inside this <code>Rectangle</code>; 
 //    *            <code>false</code> otherwise.
 //    * @since     JDK1.1
 //    */
 //   public bool contains(Rectangle r) {
	//return contains(r.x, r.y, r.width, r.height);
 //   }

 //   /**
 //    * Checks whether this <code>Rectangle</code> entirely contains 
 //    * the <code>Rectangle</code>
 //    * at the specified location (<i>X</i>,&nbsp;<i>Y</i>) with the
 //    * specified dimensions (<i>W</i>,&nbsp;<i>H</i>).
 //    * @param     X,&nbsp;Y  the specified coordinates
 //    * @param     W   the width of the <code>Rectangle</code>
 //    * @param     H   the height of the <code>Rectangle</code>
 //    * @return    <code>true</code> if the <code>Rectangle</code> specified by
 //    *            (<i>X</i>,&nbsp;<i>Y</i>,&nbsp;<i>W</i>,&nbsp;<i>H</i>)
 //    *            is entirely enclosed inside this <code>Rectangle</code>; 
 //    *            <code>false</code> otherwise.
 //    * @since     JDK1.1
 //    */
 //   public bool contains(int X, int Y, int W, int H) {
	//int w = this->width;
	//int h = this->height;
	//if ((w | h | W | H) < 0) {
	//    // At least one of the dimensions is negative...
	//    return false;
	//}
	//// Note: if any dimension is zero, tests below must return false...
	//int x = this->x;
	//int y = this->y;
	//if (X < x || Y < y) {
	//    return false;
	//}
	//w += x;
	//W += X;
	//if (W <= X) {
	//    // X+W overflowed or W was zero, return false if...
	//    // either original w or W was zero or
	//    // x+w did not overflow or
	//    // the overflowed x+w is smaller than the overflowed X+W
	//    if (w >= x || W > w) return false;
	//} else {
	//    // X+W did not overflow and W was not zero, return false if...
	//    // original w was zero or
	//    // x+w did not overflow and x+w is smaller than X+W
	//    if (w >= x && W > w) return false;
	//}
	//h += y;
	//H += Y;
	//if (H <= Y) {
	//    if (h >= y || H > h) return false;
	//} else {
	//    if (h >= y && H > h) return false;
	//}
	//return true;
 //   }

 //   /**
 //    * Determines whether or not this <code>Rectangle</code> and the specified 
 //    * <code>Rectangle</code> intersect. Two rectangles intersect if 
 //    * their intersection is nonempty. 
 //    *
 //    * @param r the specified <code>Rectangle</code>
 //    * @return    <code>true</code> if the specified <code>Rectangle</code> 
 //    *            and this <code>Rectangle</code> intersect; 
 //    *            <code>false</code> otherwise.
 //    */
 //   public bool intersects(Rectangle r) {
	//int tw = this->width;
	//int th = this->height;
	//int rw = r.width;
	//int rh = r.height;
	//if (rw <= 0 || rh <= 0 || tw <= 0 || th <= 0) {
	//    return false;
	//}
	//int tx = this->x;
	//int ty = this->y;
	//int rx = r.x;
	//int ry = r.y;
	//rw += rx;
	//rh += ry;
	//tw += tx;
	//th += ty;
	////      overflow || intersect
	//return ((rw < rx || rw > tx) &&
	//	(rh < ry || rh > ty) &&
	//	(tw < tx || tw > rx) &&
	//	(th < ty || th > ry));
 //   }

 //   /**
 //    * Computes the intersection of this <code>Rectangle</code> with the 
 //    * specified <code>Rectangle</code>. Returns a new <code>Rectangle</code> 
 //    * that represents the intersection of the two rectangles.
 //    * If the two rectangles do not intersect, the result will be
 //    * an empty rectangle.
 //    *
 //    * @param     r   the specified <code>Rectangle</code>
 //    * @return    the largest <code>Rectangle</code> contained in both the 
 //    *            specified <code>Rectangle</code> and in 
 //    *		  this <code>Rectangle</code>; or if the rectangles
 //    *            do not intersect, an empty rectangle.
 //    */
 //   public Rectangle intersection(Rectangle r) {
	//int tx1 = this->x;
	//int ty1 = this->y;
	//int rx1 = r.x;
	//int ry1 = r.y;
	//long tx2 = tx1; tx2 += this->width;
	//long ty2 = ty1; ty2 += this->height;
	//long rx2 = rx1; rx2 += r.width;
	//long ry2 = ry1; ry2 += r.height;
	//if (tx1 < rx1) tx1 = rx1;
	//if (ty1 < ry1) ty1 = ry1;
	//if (tx2 > rx2) tx2 = rx2;
	//if (ty2 > ry2) ty2 = ry2;
	//tx2 -= tx1;
	//ty2 -= ty1;
	//// tx2,ty2 will never overflow (they will never be
	//// larger than the smallest of the two source w,h)
	//// they might underflow, though...
	//if (tx2 < Integer.MIN_VALUE) tx2 = Integer.MIN_VALUE;
	//if (ty2 < Integer.MIN_VALUE) ty2 = Integer.MIN_VALUE;
	//return new Rectangle(tx1, ty1, (int) tx2, (int) ty2);
 //   }

 //   /**
 //    * Computes the union of this <code>Rectangle</code> with the 
 //    * specified <code>Rectangle</code>. Returns a new 
 //    * <code>Rectangle</code> that 
 //    * represents the union of the two rectangles
 //    * @param r the specified <code>Rectangle</code>
 //    * @return    the smallest <code>Rectangle</code> containing both 
 //    *		  the specified <code>Rectangle</code> and this 
 //    *		  <code>Rectangle</code>.
 //    */
 //   public Rectangle union(Rectangle r) {
	//int x1 = Math.min(x, r.x);
	//int x2 = Math.max(x + width, r.x + r.width);
	//int y1 = Math.min(y, r.y);
	//int y2 = Math.max(y + height, r.y + r.height);
	//return new Rectangle(x1, y1, x2 - x1, y2 - y1);
 //   }

 //   /**
 //    * Adds a point, specified by the integer arguments <code>newx</code>
 //    * and <code>newy</code>, to this <code>Rectangle</code>. The 
 //    * resulting <code>Rectangle</code> is
 //    * the smallest <code>Rectangle</code> that contains both the 
 //    * original <code>Rectangle</code> and the specified point.
 //    * <p>
 //    * After adding a point, a call to <code>contains</code> with the 
 //    * added point as an argument does not necessarily return
 //    * <code>true</code>. The <code>contains</code> method does not 
 //    * return <code>true</code> for points on the right or bottom 
 //    * edges of a <code>Rectangle</code>. Therefore, if the added point 
 //    * falls on the right or bottom edge of the enlarged 
 //    * <code>Rectangle</code>, <code>contains</code> returns 
 //    * <code>false</code> for that point.
 //    * @param newx,&nbsp;newy   the coordinates of the new point
 //    */
 //   public void add(int newx, int newy) {
	//int x1 = Math.min(x, newx);
	//int x2 = Math.max(x + width, newx);
	//int y1 = Math.min(y, newy);
	//int y2 = Math.max(y + height, newy);
	//x = x1;
	//y = y1;
	//width = x2 - x1;
	//height = y2 - y1;
 //   }

 //   /**
 //    * Adds the specified <code>Point</code> to this 
 //    * <code>Rectangle</code>. The resulting <code>Rectangle</code> 
 //    * is the smallest <code>Rectangle</code> that contains both the 
 //    * original <code>Rectangle</code> and the specified 
 //    * <code>Point</code>.
 //    * <p>
 //    * After adding a <code>Point</code>, a call to <code>contains</code> 
 //    * with the added <code>Point</code> as an argument does not 
 //    * necessarily return <code>true</code>. The <code>contains</code> 
 //    * method does not return <code>true</code> for points on the right 
 //    * or bottom edges of a <code>Rectangle</code>. Therefore if the added 
 //    * <code>Point</code> falls on the right or bottom edge of the 
 //    * enlarged <code>Rectangle</code>, <code>contains</code> returns 
 //    * <code>false</code> for that <code>Point</code>.
 //    * @param pt the new <code>Point</code> to add to this 
 //    *           <code>Rectangle</code>
 //    */
 //   public void add(Point pt) {
	//add(pt.x, pt.y);
 //   }

 //   /**
 //    * Adds a <code>Rectangle</code> to this <code>Rectangle</code>. 
 //    * The resulting <code>Rectangle</code> is the union of the two
 //    * rectangles. 
 //    * @param  r the specified <code>Rectangle</code>
 //    */
 //   public void add(Rectangle r) {
	//int x1 = Math.min(x, r.x);
	//int x2 = Math.max(x + width, r.x + r.width);
	//int y1 = Math.min(y, r.y);
	//int y2 = Math.max(y + height, r.y + r.height);
	//x = x1;
	//y = y1;
	//width = x2 - x1;
	//height = y2 - y1;
 //   }

 //   /**
 //    * Resizes the <code>Rectangle</code> both horizontally and vertically.
 //    * <p>
 //    * This method modifies the <code>Rectangle</code> so that it is 
 //    * <code>h</code> units larger on both the left and right side, 
 //    * and <code>v</code> units larger at both the top and bottom. 
 //    * <p>
 //    * The new <code>Rectangle</code> has (<code>x&nbsp;-&nbsp;h</code>, 
 //    * <code>y&nbsp;-&nbsp;v</code>) as its top-left corner, a 
 //    * width of 
 //    * <code>width</code>&nbsp;<code>+</code>&nbsp;<code>2h</code>, 
 //    * and a height of 
 //    * <code>height</code>&nbsp;<code>+</code>&nbsp;<code>2v</code>. 
 //    * <p>
 //    * If negative values are supplied for <code>h</code> and 
 //    * <code>v</code>, the size of the <code>Rectangle</code> 
 //    * decreases accordingly. 
 //    * The <code>grow</code> method does not check whether the resulting 
 //    * values of <code>width</code> and <code>height</code> are 
 //    * non-negative. 
 //    * @param h the horizontal expansion
 //    * @param v the vertical expansion
 //    */
 //   public void grow(int h, int v) {
	//x -= h;
	//y -= v;
	//width += h * 2;
	//height += v * 2;
 //   }

	bool isEmpty() const {
		return width <= 0 || height <= 0;
	}
};

}}

#endif
