#ifndef JLIB_AWT_EVENT_TEXTLISTENER
#define JLIB_AWT_EVENT_TEXTLISTENER

#include <jlib/util/EventListener.h>

namespace jlib { namespace awt {

class TextEvent;

class TextListener : public jlib::util::EventListener {
public:
    virtual void textValueChanged(const TextEvent&) = 0;
};

}}

#endif
