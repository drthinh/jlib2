#ifndef JLIB_AWT_SLIDER
#define JLIB_AWT_SLIDER

#include <jlib/awt/Component.h>
#include <jlib/awt/ValueChangeable.h>
#include <jlib/awt/ChangeListener.h>

namespace jlib { namespace awt {

class ChangeEvent;


class BoundedRangeModel;

class Slider : public Component, public ValueChangeable, ChangeListener {
public:
	enum Orientation {
		HORIZONTAL,
		VERTICAL
	};

	explicit Slider(Orientation orientation = HORIZONTAL);
	Slider(int min, int max);
	Slider(int min, int max, int value);
	Slider(Orientation orientation, int min, int max, int value);

	~Slider();

	void addNotify();

	Slider(BoundedRangeModel* brm);
	
	void addChangeListener(ChangeListener*);
	void removeChangeListener(ChangeListener*);

	BoundedRangeModel* getModel() const;
	void setModel(BoundedRangeModel*);

	int getValue() const;
	void setValue(int);

	int getMinimum() const;
	void setMinimum(int minimum);

	int getMaximum() const;
	void setMaximum(int maximum);

	bool getValueIsAdjusting() const;
	void setValueIsAdjusting(bool b);

	int getExtent() const;
	void setExtent(int extent);

	Orientation getOrientation() const;
	void setOrientation(Orientation orientation);

    bool getInverted() const;
	void setInverted(bool b);

	int getMajorTickSpacing() const;
	void setMajorTickSpacing(int n);

	int getMinorTickSpacing() const;
	void setMinorTickSpacing(int n);

	bool getSnapToTicks() const;
    bool getSnapToValue() const;

	void setSnapToTicks(bool b);
    void setSnapToValue(bool b);

	bool getPaintTicks() const;
	void setPaintTicks(bool b);

	bool getPaintTrack() const;
	void setPaintTrack(bool b);

	Dimension getMinimumSize() const;
	Dimension getPreferredSize() const;
	Dimension getMaximumSize() const;

protected:

	void init(Orientation orientation, int min, int max, int value);

	const Dimension& Slider::getPreferredHorizontalSize() const;
	const Dimension& Slider::getPreferredVerticalSize() const;
	const Dimension& Slider::getMinimumHorizontalSize() const;
	const Dimension& Slider::getMinimumVerticalSize() const;

	void stateChanged(const ChangeEvent& e);

	typedef jlib::util::EventDispatcher<ChangeListener>
			ChangeEventDispatcher;
	ChangeEventDispatcher changeEventDispatcher;

	BoundedRangeModel* model;
	bool owningModel;
	int majorTickSpacing;
	int minorTickSpacing;
	bool snapToTicks;
	bool snapToValue;
	Orientation orientation;

private:
    bool paintTicks;
    bool paintTrack;
    bool paintLabels;
    bool isInverted;

	static const Dimension PREFERRED_HORIZONTAL_SIZE;
	static const Dimension PREFERRED_VERTICAL_SIZE;
	static const Dimension MINIMUM_HORIZONTAL_SIZE;
	static const Dimension MINIMUM_VERTICAL_SIZE;

	// peer operations
	void peer_setOrientation(int orientation);
	void peer_setRangeProperties(int value, int extent, int min, int max);
	void peer_setValue(int v);
	void peer_setMinimum(int n);
	void peer_setMaximum(int n);
	void peer_setPaintTicks(bool b);
	void peer_setTickSpacing(int n);
	void peer_setPaintTrack(bool b);

	// WIN32
	bool scrolling;
	void handleScroll(int code, int pos, bool vertical);
	LRESULT handleNotify(NMHDR* nmHdr);

	LPCTSTR getClassName() const;
	DWORD getStyle() const;
};

}}

#endif
