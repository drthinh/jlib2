#ifndef JLIB_AWT_EVENT_KEYLISTENER
#define JLIB_AWT_EVENT_KEYLISTENER

#include <jlib/util/EventListener.h>

namespace jlib { namespace awt {

class ActionEvent;

class KeyListener : public jlib::util::EventListener {
public:
	virtual void keyTyped(KeyEvent&) = 0;
	virtual void keyPressed(KeyEvent&) = 0;
	virtual void keyReleased(KeyEvent&) = 0;
};

}}

#endif
