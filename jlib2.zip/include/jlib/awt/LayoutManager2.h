#ifndef JLIB_AWT_LAYOUTMANAGER2
#define JLIB_AWT_LAYOUTMANAGER2

#include <jlib/awt/LayoutManager.h>
#include <jlib/awt/LayoutConstraint.h>

namespace jlib { namespace awt { 

struct LayoutManager2 : LayoutManager {
};

}}

#endif
