#ifndef JLIB_AWT_GRIDBAGLAYOUT
#define JLIB_AWT_GRIDBAGLAYOUT

#include <jlib/awt/LayoutManagerAdapter.h>
#include <jlib/awt/SizeRequirements.h>

namespace jlib { namespace awt {

class BoxLayout : public LayoutManagerAdapter {
public:
	enum Axis {
		X_AXIS,
		Y_AXIS,
		LINE_AXIS,
		PAGE_AXIS
	};

	BoxLayout(LayoutContainer* target, Axis axis);
	virtual ~BoxLayout();

	void invalidateLayout(LayoutContainer* target);

	Dimension minimumLayoutSize(const LayoutContainer* target);
	Dimension preferredLayoutSize(const LayoutContainer* target);
	Dimension maximumLayoutSize(const LayoutContainer* target);

	float getLayoutAlignmentX(const LayoutContainer* target) const;
	float getLayoutAlignmentY(const LayoutContainer* target) const;

	void layoutContainer(LayoutContainer* target);

private:
	bool isTarget(const LayoutContainer* target) const;
	void checkRequests();

	int resolveAxis(int axis/*, ComponentOrientation o */);

	LayoutContainer* target;
	Axis axis;

	SizeRequirements* xChildren;
	SizeRequirements* yChildren;
	SizeRequirements xTotal;
	SizeRequirements yTotal;
};

}}

#endif
