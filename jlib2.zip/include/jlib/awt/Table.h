#ifndef JLIB_AWT_TABLE
#define JLIB_AWT_TABLE

#include <jlib/awt/Component.h>

namespace jlib { namespace awt {

class Table : public Component {
public:
	Table(int rows = 0, int columns = 0);

protected:
	void addNotify();

private:
	DWORD getWindowStyle() const;
	LPCTSTR getClassName() const;
};

}}

#endif
