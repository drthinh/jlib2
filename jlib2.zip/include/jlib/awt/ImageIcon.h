#ifndef JLIB_AWT_IMAGEICON
#define JLIB_AWT_IMAGEICON

#include <jlib/awt/Icon.h>
#include <jlib/lang/String.h>

namespace jlib { namespace awt {

class Image;

class ImageIcon : public Icon {
public:
	ImageIcon(const jlib::lang::String& filename);
	ImageIcon(Image* image);
	int getIconWidth() const;
	int getIconHeight() const;
	void paintIcon(Component* c, Graphics* g, int x, int y) const;
	Image* getImage() const;

	~ImageIcon();

private:
	Image* image;
	bool owned;
};

inline Image* ImageIcon::getImage() const {
	return image;
}

}}

#endif
