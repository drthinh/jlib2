#ifndef JLIB_AWT_KEYEVENTDISPATCHER
#define JLIB_AWT_KEYEVENTDISPATCHER

namespace jlib { namespace awt {

class KeyEventDispatcher {
public:
	virtual ~KeyEventDispatcher() {}
	virtual bool dispatchEvent(KeyEvent& e) = 0;
};

}

#endif
