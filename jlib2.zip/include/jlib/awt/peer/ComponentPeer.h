#ifndef JLIB_AWT_PEER_COMPONENTPEER
#define JLIB_AWT_PEER_COMPONENTPEER

namespace jlib { namespace awt {

class Component;

namespace peer {

template <class TargetT>
class PeerObject {
public:
	PeerObject(TargetT* target)
		: target(target) {
		}

	TargetT* getTarget() {
		return target;
	}

private:
	TargetT* target;
};


class ComponentPeer {
public:
	virtual ~ComponentPeer() {
	}

	void setVisible(boolean b);
    void setEnabled(boolean b);
    void paint(Graphics g);
    void repaint(long tm, int x, int y, int width, int height);
    void print(Graphics g);
    void setBounds(int x, int y, int width, int height);
    //void                handleEvent(AWTEvent e);
    //void                coalescePaintEvent(PaintEvent e);
    Point		getLocationOnScreen();
    Dimension		getPreferredSize();
    Dimension		getMinimumSize();
    //ColorModel		getColorModel();
    //java.awt.Toolkit	getToolkit();
    Graphics		getGraphics();
    FontMetrics		getFontMetrics(Font font);
    void		dispose();
    void		setForeground(Color c);
    void		setBackground(Color c);
    void		setFont(Font f);
    void 		setCursor(Cursor cursor);
    void		requestFocus();
    bool		isFocusTraversable();

    //Image 		createImage(ImageProducer producer);
    //Image 		createImage(int width, int height);
    //boolean		prepareImage(Image img, int w, int h, ImageObserver o);
    //int			checkImage(Image img, int w, int h, ImageObserver o);
    //GraphicsConfiguration getGraphicsConfiguration();

private:
	Component* target;
};

}}}
#endif