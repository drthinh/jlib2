#ifndef JLIB_AWT_FOCUSTRAVERSALPOLICY
#define JLIB_AWT_FOCUSTRAVERSALPOLICY

namespace java { namespace awt {

class Component;
class Container;
class Window;

class FocusTraversalPolicy {
public:
	virtual ~FocusTraversalPolicy() {}

    virtual Component* getComponentAfter(
			Container* focusCycleRoot, Component* aComponent);
	virtual Component* getComponentBefore(
			Container* focusCycleRoot, Component* aComponent);
	virtual Component* getFirstComponent(Container* focusCycleRoot);
	virtual Component* getLastComponent(Container* focusCycleRoot);
	virtual Component* getDefaultComponent(Container* focusCycleRoot);

    virtual Component* getInitialComponent(Window* window) {
        Component* def = getDefaultComponent(window);
        if (def == NULL && window->isFocusableWindow()) {
            def = window;
		}
        return def;
    }
};

}}

#endif
