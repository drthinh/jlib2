#ifndef JLIB_AWT_SPRING
#define JLIB_AWT_SPRING

namespace jlib { namespace awt {

class Spring {
public:

};

}}
#endif