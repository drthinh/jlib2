#ifndef JLIB_AWT_EVENT_CONTAINERLISTENER
#define JLIB_AWT_EVENT_CONTAINERLISTENER

#include <jlib/util/EventListener.h>

namespace jlib { namespace awt {

class ContainerEvent;

class ContainerListener : public jlib::util::EventListener {
public:
    virtual void componentAdded(const ContainerEvent&) = 0;
    virtual void componentRemoved(const ContainerEvent&) = 0;
};

}}

#endif
