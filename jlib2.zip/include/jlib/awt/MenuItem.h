#ifndef JLIB_AWT_MENUITEM
#define JLIB_AWT_MENUITEM

#include <jlib/awt/MenuComponent.h>
#include <jlib/awt/Actable.h>
#include <jlib/awt/MenuShortcut.h>

#include <jlib/util/EventDispatcher.h>

namespace jlib { 

namespace util {
	template <typename T> class id_list;
}
	
namespace awt {

class ActionListener;
class Menu;

class MenuItem : public MenuComponent, public Actable {
public:
	MenuItem(const String& label = _T(""), 
			const MenuShortcut& s = MenuShortcut());

	virtual void addNotify();

	const String& getLabel() const;
	void setLabel(const String&);

	bool isEnabled() const;
	void setEnabled(bool);
	const MenuShortcut& getShortcut() const ;

	void setShortcut(const MenuShortcut&);
	void deleteShortcut();
    void deleteShortcut(MenuShortcut s);

    MenuItem* getShortcutMenuItem(MenuShortcut s);
	void setActionCommand(const String&);

	const String& getActionCommand() const;

	void addActionListener(ActionListener*);
	void removeActionListener(ActionListener*);

	// WIN32
	Menu* getParentMenu();
	void handleCommand();
	virtual void doMenuEvent(int modifiers);

	int getId() const;

	static MenuItem* getFromId(int id);

protected:
	String label;
	bool enabled;
	
	String actionCommand;

	bool isSeparator() const;

	typedef jlib::util::EventDispatcher<ActionListener>
		ActionEventDispatcher;
	ActionEventDispatcher actionEventDispatcher;

	MenuShortcut shortcut;

	// win32
	int id;
	static jlib::util::id_list<MenuItem*> cmdIdList;

	// peer operations
	void peer_createMenuItem();
	void peer_setLabel(const String& label);
	void peer_setEnabled(bool b);
	void peer_dispose();
};

inline int MenuItem::getId() const {
	return id;
}

}}

#endif
