#ifndef JLIB_AWT_EVENT_HIERARCHYLISTENER
#define JLIB_AWT_EVENT_HIERARCHYLISTENER

#include <jlib/util/EventListener.h>

namespace jlib { namespace awt {

class HierarchyEvent;

class HierarchyListener : public jlib::util::EventListener {
public:
	virtual void hierarchyChanged(const HierarchyEvent&) = 0;
};

}}

#endif
