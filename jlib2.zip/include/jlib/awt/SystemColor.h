#ifndef JLIB_AWT_SYSTEMCOLOR
#define JLIB_AWT_SYSTEMCOLOR

#include <jlib/awt/Color.h>

#ifdef TEXT
#undef TEXT
#endif

namespace jlib { namespace awt {

class SystemColor : public Color{
public:
    static SystemColor DESKTOP;

    static SystemColor ACTIVE_CAPTION;
    static SystemColor ACTIVE_CAPTION_TEXT;
    static SystemColor ACTIVE_CAPTION_BORDER;
    static SystemColor INACTIVE_CAPTION;
    static SystemColor INACTIVE_CAPTION_TEXT;
    static SystemColor INACTIVE_CAPTION_BORDER;

    static SystemColor WINDOW;
    static SystemColor WINDOW_BORDER;
    static SystemColor WINDOW_TEXT;

    static SystemColor MENU;
    static SystemColor MENU_TEXT;

    static SystemColor TEXT;
    static SystemColor TEXT_TEXT;
    static SystemColor TEXT_HIGHLIGHT;
    static SystemColor TEXT_HIGHLIGHT_TEXT;
    static SystemColor TEXT_INACTIVE_TEXT;

    static SystemColor CONTROL;
    static SystemColor CONTROL_TEXT;
    static SystemColor CONTROL_HIGHLIGHT;
    static SystemColor CONTROL_LT_HIGHLIGHT;
    static SystemColor CONTROL_SHADOW;
    static SystemColor CONTROL_DK_SHADOW;

    static SystemColor SCROLLBAR;

    static SystemColor INFO;
    static SystemColor INFO_TEXT;
private:
	SystemColor(int index);
};

}}

#endif
