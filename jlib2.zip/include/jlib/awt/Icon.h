#ifndef JLIB_AWT_ICON
#define JLIB_AWT_ICON

namespace jlib { namespace awt {

class Component;
class Graphics;

class Icon {
public:
	virtual int getIconWidth() const = 0;
	virtual int getIconHeight() const = 0;
	virtual void paintIcon(Component* c, Graphics* g, int x, int y) const = 0;

	virtual ~Icon() {}
};

}}

#endif
