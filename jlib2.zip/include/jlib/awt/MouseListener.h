#ifndef JLIB_AWT_EVENT_MOUSELISTENER
#define JLIB_AWT_EVENT_MOUSELISTENER

#include <jlib/util/EventListener.h>

namespace jlib { namespace awt {

class MouseListener : public jlib::util::EventListener {
public:
    virtual void mouseClicked(MouseEvent&) = 0;
    virtual void mousePressed(MouseEvent&) = 0;
    virtual void mouseReleased(MouseEvent&) = 0;
    virtual void mouseEntered(MouseEvent&) = 0;
    virtual void mouseExited(MouseEvent&) = 0;
};

}}

#endif
