#ifndef JLIB_AWT_GRIDLAYOUT
#define JLIB_AWT_GRIDLAYOUT

#include <jlib/awt/LayoutManagerAdapter.h>


namespace jlib { namespace awt { 

class GridLayout : public LayoutManagerAdapter {
public:
	GridLayout(int rows = 1, int cols = 0, int hgap = 0, int vgap = 0);

	int getRows() const;
	void setRows(int rows);

	int getColumns() const;
	void setColumns(int cols);

	int getHgap() const;
    void setHgap(int hgap);

	int getVgap() const;
	void setVgap(int vgap);

	Dimension preferredLayoutSize(LayoutContainer* parent);
	Dimension minimumLayoutSize(const LayoutContainer* parent);

	void layoutContainer(LayoutContainer* parent);

private:
	int rows;
	int cols;
	int hgap;
	int vgap;
};

inline int GridLayout::getRows() const {
	return rows;
}

inline int GridLayout::getColumns() const {
	return cols;
}

inline int GridLayout::getHgap() const {
	return hgap;
}

inline void GridLayout::setHgap(int hgap) {
	this->hgap = hgap;
}

inline int GridLayout::getVgap() const {
	return vgap;
}

inline void GridLayout::setVgap(int vgap) {
	this->vgap = vgap;
}


}}

#endif
