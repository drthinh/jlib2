#ifndef JLIB_AWT_DIALOG
#define JLIB_AWT_DIALOG

#include <jlib/awt/Window.h>

namespace jlib { namespace awt {

class Frame;

class Dialog : public Window {
public:
	Dialog(Frame* owner, const String& title = _T(""), bool modal = false);

	Dialog(Dialog* owner, const String& title = _T(""), bool modal = false);

	void addNotify();

    bool isModal() const;
	void setModal(bool b);

	const String& getTitle() const;
	void setTitle(const String& title);

	bool isResizable() const;
	void setResizable(bool b);

	void setVisible(bool b);

protected:
	const Color& getDefaultForeground() const;
	const Color& getDefaultBackground() const;

private:
	bool modal;
	bool resizable;

	void peer_setTitle(const String& title);
	//Color peer_getDefaultColor();
	void peer_setResizable(bool b);

	mutable std::vector<HWND> disabledWindows;
	void peer_modalsetEnabledParentWindows(bool b);

	static BOOL CALLBACK windowsDisableProc(HWND hwnd, LPARAM lParam);

	LPCTSTR getClassName() const;

	DWORD getWindowStyle() const;

	static LPCTSTR className;
};

inline bool Dialog::isModal() const {
	return modal;
}

inline void Dialog::setModal(bool b) {
	this->modal = b;
}


inline const String& Dialog::getTitle() const {
	return text;
}

inline bool Dialog::isResizable() const {
	return resizable;
}

}}

#endif
