#ifndef JLIB_AWT_TAB
#define JLIB_AWT_TAB

#include <jlib/awt/Component.h>
#include <jlib/awt/ValueChangeable.h>

#include <vector>

namespace jlib { namespace awt {

class ChangeListener;
class Icon;

class TabConstants {
public:
	enum LayoutPolicy {
		SCROLL_TAB_LAYOUT,
		WRAP_TAB_LAYOUT
	};

	enum Placement {
		TOP,
		BOTTOM,
		LEFT,
		RIGHT
	};
};

class Tab : public Component, public ValueChangeable, public TabConstants {
public:
	Tab(Placement placement = TOP, 
		LayoutPolicy layoutPolicy = SCROLL_TAB_LAYOUT);

	~Tab();

	void setPlacement(Placement);
	Placement getPlacement() const;

	void setLayoutPolicy(LayoutPolicy);
	LayoutPolicy getLayoutPolicy() const;

	void setSelectedIndex(int index);
	int getSelectedIndex() const;

	int getTabCount() const;
	const String& getTab(int index) const;

	void setTitleAt(int index, const String& title);
	const String& getTitleAt(int index) const;

	void setToolTipTextAt(int index, const String& tip);
	const String& getToolTipTextAt(int index) const;

	void setIconAt(int index, const Icon* icon);
	const Icon* getIconAt(int index) const;

	void setForegroundAt(int index, Color c);
	Color getForegroundAt(int index) const;

	void setBackgroundAt(int index, Color c);
	Color getBackgroundAt(int index) const;

	void insertTab(const String& title, const Icon* icon,
			const String& tip, int index);
	void removeTabAt(int index);

	void addNotify();
	void removeNotify();

	void addChangeListener(ChangeListener*);
	void removeChangeListener(ChangeListener*);

protected:
	Dimension getPreferredSize() const;

private:
	Placement placement;
	LayoutPolicy layoutPolicy;
	struct TabInfo {
		TabInfo(const String& title, 
			const Icon* icon, const String& toolTip)
			: title(title), icon(icon), toolTip(toolTip){
		}

		String title;
		const Icon* icon;
		String toolTip;
		Color fore;
		bool foreSet;
		Color back;
		bool backSet;
	};

	typedef std::vector<TabInfo> TabInfoList;
	TabInfoList tabs;
	int selectedIndex;

	typedef jlib::util::EventDispatcher<ChangeListener>
			ChangeEventDispatcher;
	ChangeEventDispatcher changeEventDispatcher;

	// peer operations
	void peer_insertTab(const TabInfo& info, int index);
	void peer_removeTabAt(int index);
	void peer_setPlacement(Placement v);
	void peer_setLayoutPolicy(LayoutPolicy v);
	void peer_setSelectedIndex(int index);
	void peer_setTitleAt(int index, const String& title);
	void peer_setIconAt(int index, const Icon* icon);
	Dimension peer_getPreferredSize() const;

	// win32
	void drawItem(DRAWITEMSTRUCT* di);
	LRESULT handleNotify(NMHDR*);
	LPCTSTR getClassName() const;
	DWORD getWindowStyle() const;

	LRESULT windowProc(UINT, WPARAM, LPARAM);

	void* imageList;
};

inline Tab::Placement Tab::getPlacement() const {
	return placement;
}

inline Tab::LayoutPolicy Tab::getLayoutPolicy() const {
	return layoutPolicy;
}

inline int Tab::getSelectedIndex() const {
	return selectedIndex;
}

}}

#endif
