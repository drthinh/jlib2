#ifndef JLIB_AWT_INSETS
#define JLIB_AWT_INSETS

namespace jlib { namespace awt { 

class Insets {
public:
	Insets(int top = 0, int left = 0, 
		int bottom = 0, int right = 0) 
		: left(left), top(top), right(right), bottom(bottom) {
	}

	int left;
	int top;
	int right;
	int bottom;
};

inline bool operator==(const Insets& lhs, const Insets& rhs) {
	return lhs.left == rhs.left && lhs.top == rhs.top &&
			lhs.right == rhs.right && lhs.bottom == rhs.bottom;
}

inline bool operator!=(const Insets& lhs, const Insets& rhs) {
	return !(lhs == rhs);
}

}}

#endif
