#ifndef JLIB_AWT_EVENT_ACTIONLISTENER
#define JLIB_AWT_EVENT_ACTIONLISTENER

#include <jlib/util/EventListener.h>

namespace jlib { namespace awt {

class ActionEvent;

class ActionListener : public jlib::util::EventListener {
public:
    /**
     * Invoked when an action occurs.
     */
    virtual void actionPerformed(const ActionEvent&) = 0;
};

}}

#endif
