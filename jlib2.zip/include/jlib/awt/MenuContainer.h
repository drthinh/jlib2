#ifndef JLIB_AWT_MENUCONTAINER
#define JLIB_AWT_MENUCONTAINER

namespace jlib { namespace awt {

class Font;
class MenuComponent;

class MenuContainer {
public:
	virtual const Font& getFont() const = 0;
	virtual void remove(MenuComponent* comp) = 0;
};

}}

#endif
