#ifndef JLIB_AWT_EVENT_ITEMEVENT
#define JLIB_AWT_EVENT_ITEMEVENT

#include <jlib/util/EventObject.h>
#include <jlib/awt/ItemSelectable.h>
#include <jlib/lang/String.h>

namespace jlib { namespace awt {

using jlib::lang::String;

class ItemEvent : public jlib::util::EventObject<ItemSelectable> {
public:
	enum State {
		SELECTED,
		DESELECTED
	};

	ItemEvent(const String& item, State stateChange)
		: item(item), stateChange(stateChange) {
    }

	const String& getItem() const {
        return item;
    }

	State getStateChange() const {
        return stateChange;
    }

private:
    String item;
    State stateChange;
};

}}

#endif
