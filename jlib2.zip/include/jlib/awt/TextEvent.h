#ifndef JLIB_AWT_EVENT_TEXTEVENT
#define JLIB_AWT_EVENT_TEXTEVENT

#include <jlib/util/EventObject.h>

namespace jlib { namespace awt {

class TextEvent : public jlib::util::EventObject<TextComponent> {
};

}}

#endif
