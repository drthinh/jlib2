#ifndef WIN32_VK_REDEF
#define WIN32_VK_REDEF

namespace jlib { namespace awt {

	class VirtualKeyCode { 
	public:
		enum {
			/*
			* Virtual Keys, Standard Set
			*/
#ifdef VK_LBUTTON
#undef VK_LBUTTON
#endif
			VK_LBUTTON = 0x01,

#ifdef VK_RBUTTON
#undef VK_RBUTTON
#endif
			VK_RBUTTON = 0x02,

#ifdef VK_CANCEL
#undef VK_CANCEL
#endif
			VK_CANCEL = 0x03,

#ifdef VK_MBUTTON
#undef VK_MBUTTON
#endif
			VK_MBUTTON = 0x04,    /* NOT contiguous with L & RBUTTON */


#if(_WIN32_WINNT >= 0x0500)

#ifdef VK_XBUTTON1
#undef VK_XBUTTON1
#endif
			VK_XBUTTON1 = 0x05,    /* NOT contiguous with L & RBUTTON */

#ifdef VK_XBUTTON2
#undef VK_XBUTTON2
#endif
			VK_XBUTTON2 = 0x06,    /* NOT contiguous with L & RBUTTON */

#endif /* _WIN32_WINNT >= 0x0500 */

			/*
			* 0x07 : unassigned
			*/

#ifdef VK_BACK
#undef VK_BACK
#endif
			VK_BACK = 0x08,

#ifdef VK_TAB
#undef VK_TAB
#endif
			VK_TAB = 0x09,

			/*
			* 0x0A - 0x0B : reserved
			*/

#ifdef VK_CLEAR
#undef VK_CLEAR
#endif
			VK_CLEAR = 0x0C,

#ifdef VK_RETURN
#undef VK_RETURN
#endif
			VK_RETURN = 0x0D,

#ifdef VK_SHIFT
#undef VK_SHIFT
#endif
			VK_SHIFT = 0x10,

#ifdef VK_CONTROL
#undef VK_CONTROL
#endif
			VK_CONTROL = 0x11,

#ifdef VK_MENU
#undef VK_MENU
#endif
			VK_MENU = 0x12,

#ifdef VK_PAUSE
#undef VK_PAUSE
#endif
			VK_PAUSE = 0x13,

#ifdef VK_CAPITAL
#undef VK_CAPITAL
#endif
			VK_CAPITAL = 0x14,


#ifdef VK_KANA
#undef VK_KANA
#endif
			VK_KANA = 0x15,

#ifdef VK_HANGEUL
#undef VK_HANGEUL
#endif
			VK_HANGEUL = 0x15,  /* old name - should be here for compatibility */

#ifdef VK_HANGUL
#undef VK_HANGUL
#endif
			VK_HANGUL = 0x15,

#ifdef VK_JUNJA
#undef VK_JUNJA
#endif
			VK_JUNJA = 0x17,

#ifdef VK_FINAL
#undef VK_FINAL
#endif
			VK_FINAL = 0x18,

#ifdef VK_HANJA
#undef VK_HANJA
#endif
			VK_HANJA = 0x19,

#ifdef VK_KANJI
#undef VK_KANJI
#endif
			VK_KANJI = 0x19,


#ifdef VK_ESCAPE
#undef VK_ESCAPE
#endif
			VK_ESCAPE = 0x1B,


#ifdef VK_CONVERT
#undef VK_CONVERT
#endif
			VK_CONVERT = 0x1C,

#ifdef VK_NONCONVERT
#undef VK_NONCONVERT
#endif
			VK_NONCONVERT = 0x1D,

#ifdef VK_ACCEPT
#undef VK_ACCEPT
#endif
			VK_ACCEPT = 0x1E,

#ifdef VK_MODECHANGE
#undef VK_MODECHANGE
#endif
			VK_MODECHANGE = 0x1F,


#ifdef VK_SPACE
#undef VK_SPACE
#endif
			VK_SPACE = 0x20,

#ifdef VK_PRIOR
#undef VK_PRIOR
#endif
			VK_PRIOR = 0x21,

#ifdef VK_NEXT
#undef VK_NEXT
#endif
			VK_NEXT = 0x22,

#ifdef VK_END
#undef VK_END
#endif
			VK_END = 0x23,

#ifdef VK_HOME
#undef VK_HOME
#endif
			VK_HOME = 0x24,

#ifdef VK_LEFT
#undef VK_LEFT
#endif
			VK_LEFT = 0x25,

#ifdef VK_UP
#undef VK_UP
#endif
			VK_UP = 0x26,

#ifdef VK_RIGHT
#undef VK_RIGHT
#endif
			VK_RIGHT = 0x27,

#ifdef VK_DOWN
#undef VK_DOWN
#endif
			VK_DOWN = 0x28,

#ifdef VK_SELECT
#undef VK_SELECT
#endif
			VK_SELECT = 0x29,

#ifdef VK_PRINT
#undef VK_PRINT
#endif
			VK_PRINT = 0x2A,

#ifdef VK_EXECUTE
#undef VK_EXECUTE
#endif
			VK_EXECUTE = 0x2B,

#ifdef VK_SNAPSHOT
#undef VK_SNAPSHOT
#endif
			VK_SNAPSHOT = 0x2C,

#ifdef VK_INSERT
#undef VK_INSERT
#endif
			VK_INSERT = 0x2D,

#ifdef VK_DELETE
#undef VK_DELETE
#endif
			VK_DELETE = 0x2E,

#ifdef VK_HELP
#undef VK_HELP
#endif
			VK_HELP = 0x2F,


			/*
			* VK_0 - VK_9 are the same as ASCII '0' - '9' (0x30 - 0x39)
			* 0x40 : unassigned
			* VK_A - VK_Z are the same as ASCII 'A' - 'Z' (0x41 - 0x5A)
			*/

#ifdef VK_LWIN
#undef VK_LWIN
#endif
			VK_LWIN = 0x5B,

#ifdef VK_RWIN
#undef VK_RWIN
#endif
			VK_RWIN = 0x5C,

#ifdef VK_APPS
#undef VK_APPS
#endif
			VK_APPS = 0x5D,

			/*
			* 0x5E : reserved
			*/

#ifdef VK_SLEEP
#undef VK_SLEEP
#endif
			VK_SLEEP = 0x5F,


#ifdef VK_NUMPAD0
#undef VK_NUMPAD0
#endif
			VK_NUMPAD0 = 0x60,

#ifdef VK_NUMPAD1
#undef VK_NUMPAD1
#endif
			VK_NUMPAD1 = 0x61,

#ifdef VK_NUMPAD2
#undef VK_NUMPAD2
#endif
			VK_NUMPAD2 = 0x62,

#ifdef VK_NUMPAD3
#undef VK_NUMPAD3
#endif
			VK_NUMPAD3 = 0x63,

#ifdef VK_NUMPAD4
#undef VK_NUMPAD4
#endif
			VK_NUMPAD4 = 0x64,

#ifdef VK_NUMPAD5
#undef VK_NUMPAD5
#endif
			VK_NUMPAD5 = 0x65,

#ifdef VK_NUMPAD6
#undef VK_NUMPAD6
#endif
			VK_NUMPAD6 = 0x66,

#ifdef VK_NUMPAD7
#undef VK_NUMPAD7
#endif
			VK_NUMPAD7 = 0x67,

#ifdef VK_NUMPAD8
#undef VK_NUMPAD8
#endif
			VK_NUMPAD8 = 0x68,

#ifdef VK_NUMPAD9
#undef VK_NUMPAD9
#endif
			VK_NUMPAD9 = 0x69,

#ifdef VK_MULTIPLY
#undef VK_MULTIPLY
#endif
			VK_MULTIPLY = 0x6A,

#ifdef VK_ADD
#undef VK_ADD
#endif
			VK_ADD = 0x6B,

#ifdef VK_SEPARATOR
#undef VK_SEPARATOR
#endif
			VK_SEPARATOR = 0x6C,

#ifdef VK_SUBTRACT
#undef VK_SUBTRACT
#endif
			VK_SUBTRACT = 0x6D,

#ifdef VK_DECIMAL
#undef VK_DECIMAL
#endif
			VK_DECIMAL = 0x6E,

#ifdef VK_DIVIDE
#undef VK_DIVIDE
#endif
			VK_DIVIDE = 0x6F,

#ifdef VK_F1
#undef VK_F1
#endif
			VK_F1 = 0x70,
#ifdef VK_F2
#undef VK_F2
#endif
			VK_F2 = 0x71,
#ifdef VK_F3
#undef VK_F3
#endif
			VK_F3 = 0x72,
#ifdef VK_F4
#undef VK_F4
#endif
			VK_F4 = 0x73,
#ifdef VK_F5
#undef VK_F5
#endif
			VK_F5 = 0x74,
#ifdef VK_F6
#undef VK_F6
#endif
			VK_F6 = 0x75,
#ifdef VK_F7
#undef VK_F7
#endif
			VK_F7 = 0x76,
#ifdef VK_F8
#undef VK_F8
#endif
			VK_F8 = 0x77,
#ifdef VK_F9
#undef VK_F9
#endif
			VK_F9 = 0x78,
#ifdef VK_F10
#undef VK_F10
#endif
			VK_F10 = 0x79,
#ifdef VK_F11
#undef VK_F11
#endif
			VK_F11 = 0x7A,
#ifdef VK_F12
#undef VK_F12
#endif
			VK_F12 = 0x7B,
#ifdef VK_F13
#undef VK_F13
#endif
			VK_F13 = 0x7C,
#ifdef VK_F14
#undef VK_F14
#endif
			VK_F14 = 0x7D,
#ifdef VK_F15
#undef VK_F15
#endif
			VK_F15 = 0x7E,
#ifdef VK_F16
#undef VK_F16
#endif
			VK_F16 = 0x7F,
#ifdef VK_F17
#undef VK_F17
#endif
			VK_F17 = 0x80,
#ifdef VK_F18
#undef VK_F18
#endif
			VK_F18 = 0x81,
#ifdef VK_F19
#undef VK_F19
#endif
			VK_F19 = 0x82,
#ifdef VK_F20
#undef VK_F20
#endif
			VK_F20 = 0x83,
#ifdef VK_F21
#undef VK_F21
#endif
			VK_F21 = 0x84,
#ifdef VK_F22
#undef VK_F22
#endif
			VK_F22 = 0x85,
#ifdef VK_F23
#undef VK_F23
#endif
			VK_F23 = 0x86,
#ifdef VK_F24
#undef VK_F24
#endif
			VK_F24 = 0x87,

			/*
			* 0x88 - 0x8F : unassigned
			*/

#ifdef VK_NUMLOCK
#undef VK_NUMLOCK
#endif
			VK_NUMLOCK = 0x90,

#ifdef VK_SCROLL
#undef VK_SCROLL
#endif
			VK_SCROLL = 0x91,

			/*
			* NEC PC-9800 kbd definitions
			*/

#ifdef VK_OEM_NEC_EQUAL
#undef VK_OEM_NEC_EQUAL
#endif
			VK_OEM_NEC_EQUAL = 0x92,   // '=' key on numpad,

			/*
			* Fujitsu/OASYS kbd definitions
			*/

#ifdef VK_OEM_FJ_JISHO
#undef VK_OEM_FJ_JISHO
#endif
			VK_OEM_FJ_JISHO = 0x92,   // 'Dictionary' key,

#ifdef VK_OEM_FJ_MASSHOU
#undef VK_OEM_FJ_MASSHOU
#endif
			VK_OEM_FJ_MASSHOU = 0x93,   // 'Unregister word' key,

#ifdef VK_OEM_FJ_TOUROKU
#undef VK_OEM_FJ_TOUROKU
#endif
			VK_OEM_FJ_TOUROKU = 0x94,   // 'Register word' key,

#ifdef VK_OEM_FJ_LOYA
#undef VK_OEM_FJ_LOYA
#endif
			VK_OEM_FJ_LOYA = 0x95,   // 'Left OYAYUBI' key,

#ifdef VK_OEM_FJ_ROYA
#undef VK_OEM_FJ_ROYA
#endif
			VK_OEM_FJ_ROYA = 0x96,   // 'Right OYAYUBI' key,


			/*
			* 0x97 - 0x9F : unassigned
			*/

			/*
			* VK_L* & VK_R* - left and right Alt, Ctrl and Shift virtual keys.
			* Used only as parameters to GetAsyncKeyState() and GetKeyState().
			* No other API or message will distinguish left and right keys in this way.
			*/

#ifdef VK_LSHIFT
#undef VK_LSHIFT

#endif
			VK_LSHIFT = 0xA0,

#ifdef VK_RSHIFT
#undef VK_RSHIFT
#endif
			VK_RSHIFT = 0xA1,

#ifdef VK_LCONTROL
#undef VK_LCONTROL
#endif
			VK_LCONTROL = 0xA2,

#ifdef VK_RCONTROL
#undef VK_RCONTROL
#endif
			VK_RCONTROL = 0xA3,

#ifdef VK_LMENU
#undef VK_LMENU
#endif
			VK_LMENU = 0xA4,

#ifdef VK_RMENU
#undef VK_RMENU
#endif
			VK_RMENU = 0xA5,


#if(_WIN32_WINNT >= 0x0500)

#ifdef VK_BROWSER_BACK
#undef VK_BROWSER_BACK
#endif
			VK_BROWSER_BACK = 0xA6,

#ifdef VK_BROWSER_FORWARD
#undef VK_BROWSER_FORWARD
#endif
			VK_BROWSER_FORWARD = 0xA7,

#ifdef VK_BROWSER_REFRESH
#undef VK_BROWSER_REFRESH
#endif
			VK_BROWSER_REFRESH = 0xA8,
#ifdef VK_BROWSER_STOP
#undef VK_BROWSER_STOP
#endif
			VK_BROWSER_STOP = 0xA9,

#ifdef VK_BROWSER_SEARCH
#undef VK_BROWSER_SEARCH
#endif
			VK_BROWSER_SEARCH = 0xAA,

#ifdef VK_BROWSER_FAVORITES
#undef VK_BROWSER_FAVORITES
#endif
			VK_BROWSER_FAVORITES = 0xAB,

#ifdef VK_BROWSER_HOME
#undef VK_BROWSER_HOME
#endif
			VK_BROWSER_HOME = 0xAC,


#ifdef VK_VOLUME_MUTE
#undef VK_VOLUME_MUTE
#endif
			VK_VOLUME_MUTE = 0xAD,

#ifdef VK_VOLUME_DOWN
#undef VK_VOLUME_DOWN
#endif
			VK_VOLUME_DOWN = 0xAE,

#ifdef VK_VOLUME_UP
#undef VK_VOLUME_UP
#endif
			VK_VOLUME_UP = 0xAF,

#ifdef VK_MEDIA_NEXT_TRACK
#undef VK_MEDIA_NEXT_TRACK
#endif
			VK_MEDIA_NEXT_TRACK = 0xB0,

#ifdef VK_MEDIA_PREV_TRACK
#undef VK_MEDIA_PREV_TRACK
#endif
			VK_MEDIA_PREV_TRACK = 0xB1,

#ifdef VK_MEDIA_STOP
#undef VK_MEDIA_STOP
#endif
			VK_MEDIA_STOP = 0xB2,

#ifdef VK_MEDIA_PLAY_PAUSE
#undef VK_MEDIA_PLAY_PAUSE
#endif
			VK_MEDIA_PLAY_PAUSE = 0xB3,

#ifdef VK_LAUNCH_MAIL
#undef VK_LAUNCH_MAIL
#endif
			VK_LAUNCH_MAIL = 0xB4,

#ifdef VK_LAUNCH_MEDIA_SELECT
#undef VK_LAUNCH_MEDIA_SELECT
#endif
			VK_LAUNCH_MEDIA_SELECT = 0xB5,

#ifdef VK_LAUNCH_APP1
#undef VK_LAUNCH_APP1
#endif
			VK_LAUNCH_APP1 = 0xB6,

#ifdef VK_LAUNCH_APP2
#undef VK_LAUNCH_APP2
#endif
			VK_LAUNCH_APP2 = 0xB7,


#endif /* _WIN32_WINNT >= 0x0500 */

			/*
			* 0xB8 - 0xB9 : reserved
			*/

#ifdef VK_OEM_1
#undef VK_OEM_1
#endif
			VK_OEM_1 = 0xBA,   // ',:' for US,

#ifdef VK_OEM_PLUS
#undef VK_OEM_PLUS
#endif
			VK_OEM_PLUS = 0xBB,   // '+' any country,

#ifdef VK_OEM_COMMA
#undef VK_OEM_COMMA
#endif
			VK_OEM_COMMA = 0xBC,   // ',' any country,

#ifdef VK_OEM_MINUS
#undef VK_OEM_MINUS
#endif
			VK_OEM_MINUS = 0xBD,   // '-' any country,

#ifdef VK_OEM_PERIOD
#undef VK_OEM_PERIOD
#endif
			VK_OEM_PERIOD = 0xBE,   // '.' any country,

#ifdef VK_OEM_2
#undef VK_OEM_2
#endif
			VK_OEM_2 = 0xBF,   // '/?' for US,

#ifdef VK_OEM_3
#undef VK_OEM_3
#endif
			VK_OEM_3 = 0xC0,   // '`~' for US,

			/*
			* 0xC1 - 0xD7 : reserved
			*/

			/*
			* 0xD8 - 0xDA : unassigned
			*/

#ifdef VK_OEM_4
#undef VK_OEM_4
#endif
			VK_OEM_4 = 0xDB,  //  '[{' for US,

#ifdef VK_OEM_5
#undef VK_OEM_5
#endif
			VK_OEM_5 = 0xDC,  //  '\|' for US,

#ifdef VK_OEM_6
#undef VK_OEM_6
#endif
			VK_OEM_6 = 0xDD,  //  ']}' for US,

#ifdef VK_OEM_7
#undef VK_OEM_7
#endif
			VK_OEM_7 = 0xDE,  //  ''"' for US,

#ifdef VK_OEM_8
#undef VK_OEM_8
#endif
			VK_OEM_8 = 0xDF,


			/*
			* 0xE0 : reserved
			*/

			/*
			* Various extended or enhanced keyboards
			*/

#ifdef VK_OEM_AX
#undef VK_OEM_AX
#endif
			VK_OEM_AX = 0xE1,  //  'AX' key on Japanese AX kbd,

#ifdef VK_OEM_102
#undef VK_OEM_102
#endif
			VK_OEM_102 = 0xE2,  //  "<>" or "\|" on RT 102-key kbd.,

#ifdef VK_ICO_HELP
#undef VK_ICO_HELP
#endif
			VK_ICO_HELP = 0xE3,  //  Help key on ICO,

#ifdef VK_ICO_00
#undef VK_ICO_00
#endif
			VK_ICO_00 = 0xE4,  //  00 key on ICO,


#if(WINVER >= 0x0400)

#ifdef VK_PROCESSKEY
#undef VK_PROCESSKEY
#endif
			VK_PROCESSKEY = 0xE5,

#endif /* WINVER >= 0x0400 */

#ifdef VK_ICO_CLEAR
#undef VK_ICO_CLEAR
#endif
			VK_ICO_CLEAR = 0xE6,



#if(_WIN32_WINNT >= 0x0500)

#ifdef VK_PACKET
#undef VK_PACKET
#endif
			VK_PACKET = 0xE7,

#endif /* _WIN32_WINNT >= 0x0500 */

			/*
			* 0xE8 : unassigned
			*/

			/*
			* Nokia/Ericsson definitions
			*/

#ifdef VK_OEM_RESET
#undef VK_OEM_RESET
#endif
			VK_OEM_RESET = 0xE9,

#ifdef VK_OEM_JUMP
#undef VK_OEM_JUMP
#endif
			VK_OEM_JUMP = 0xEA,

#ifdef VK_OEM_PA1
#undef VK_OEM_PA1
#endif
			VK_OEM_PA1 = 0xEB,

#ifdef VK_OEM_PA2
#undef VK_OEM_PA2
#endif
			VK_OEM_PA2 = 0xEC,

#ifdef VK_OEM_PA3
#undef VK_OEM_PA3
#endif
			VK_OEM_PA3 = 0xED,

#ifdef VK_OEM_WSCTRL
#undef VK_OEM_WSCTRL
#endif
			VK_OEM_WSCTRL = 0xEE,

#ifdef VK_OEM_CUSEL
#undef VK_OEM_CUSEL
#endif
			VK_OEM_CUSEL = 0xEF,

#ifdef VK_OEM_ATTN
#undef VK_OEM_ATTN
#endif
			VK_OEM_ATTN = 0xF0,

#ifdef VK_OEM_FINISH
#undef VK_OEM_FINISH
#endif
			VK_OEM_FINISH = 0xF1,

#ifdef VK_OEM_COPY
#undef VK_OEM_COPY
#endif
			VK_OEM_COPY = 0xF2,

#ifdef VK_OEM_AUTO
#undef VK_OEM_AUTO
#endif
			VK_OEM_AUTO = 0xF3,

#ifdef VK_OEM_ENLW
#undef VK_OEM_ENLW
#endif
			VK_OEM_ENLW = 0xF4,

#ifdef VK_OEM_BACKTAB
#undef VK_OEM_BACKTAB
#endif
			VK_OEM_BACKTAB = 0xF5,


#ifdef VK_ATTN
#undef VK_ATTN
#endif
			VK_ATTN = 0xF6,

#ifdef VK_CRSEL
#undef VK_CRSEL
#endif
			VK_CRSEL = 0xF7,

#ifdef VK_EXSEL
#undef VK_EXSEL
#endif
			VK_EXSEL = 0xF8,

#ifdef VK_EREOF
#undef VK_EREOF
#endif
			VK_EREOF = 0xF9,

#ifdef VK_PLAY
#undef VK_PLAY
#endif
			VK_PLAY = 0xFA,

#ifdef VK_ZOOM
#undef VK_ZOOM
#endif
			VK_ZOOM = 0xFB,

#ifdef VK_NONAME
#undef VK_NONAME
#endif
			VK_NONAME = 0xFC,

#ifdef VK_PA1
#undef VK_PA1
#endif
			VK_PA1 = 0xFD,

#ifdef VK_OEM_CLEAR
#undef VK_OEM_CLEAR
#endif
			VK_OEM_CLEAR = 0xFE,


			// java specific key codes
			VK_ENTER = VK_RETURN,
			VK_BACK_SPACE = VK_BACK,
			VK_PAGE_UP = VK_PRIOR,
			VK_PAGE_DOWN = VK_NEXT,
			// 0xFF : reserved
		};

	};

}}

#endif