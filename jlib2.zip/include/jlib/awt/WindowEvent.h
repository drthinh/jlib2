#ifndef JLIB_AWT_EVENT_WINDOWEVENT
#define JLIB_AWT_EVENT_WINDOWEVENT

#include <jlib/util/EventObject.h>

namespace jlib { namespace awt { 
	
class Window;	
	
class WindowEvent : public jlib::util::EventObject<Window> {
public:
	enum EventId {
		WINDOW_OPENED,
		WINDOW_CLOSING,
	    WINDOW_CLOSED,
		WINDOW_ICONIFIED,
		WINDOW_DEICONIFIED,
		WINDOW_ACTIVATED,
		WINDOW_DEACTIVATED,
		WINDOW_GAINED_FOCUS,
		WINDOW_LOST_FOCUS,
		WINDOW_STATE_CHANGED,
	};

    WindowEvent(EventId id, Window* opposite,
		int oldState, int newState) 
		: id(id), opposite(opposite), 
		oldState(oldState), newState(newState) {
    }

    WindowEvent(EventId id, Window* opposite) 
		: id(id), opposite(opposite), 
		oldState(0), newState(0) {
    }

	WindowEvent(EventId id, int oldState, int newState)
		: id(id), opposite(NULL), 
		oldState(oldState), newState(newState) {
	}

	explicit WindowEvent(EventId id)
		: id(id), opposite(NULL), oldState(0), newState(0) {
	}

	EventId getID() const {
		return id;
	}

	Window* getWindow() const {
		return getSource();
	}

	Window* getOppositeWindow() const {
		return opposite;
	}

	int getOldState() const {
		return oldState;
	}

	int getNewState() const {
		return newState;
	}

private:
	EventId id;
	Window* opposite;

	int oldState;
	int newState;
};

}}

#endif
