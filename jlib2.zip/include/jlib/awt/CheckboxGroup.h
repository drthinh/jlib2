#ifndef JLIB_AWT_CHECKBOXGROUP
#define JLIB_AWT_CHECKBOXGROUP

namespace jlib { namespace awt {

class Checkbox;

class CheckboxGroup {
public:
	CheckboxGroup();

	Checkbox* getSelectedCheckbox() const;
	void setSelectedCheckbox(Checkbox* box);

private:
	Checkbox* selectedCheckbox;
};

inline Checkbox* CheckboxGroup::getSelectedCheckbox() const {
	return selectedCheckbox;
}

}}

#endif
