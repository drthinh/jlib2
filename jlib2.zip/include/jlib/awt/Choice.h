#ifndef JLIB_AWT_CHOICE
#define JLIB_AWT_CHOICE

#include <jlib/awt/Component.h>
#include <jlib/awt/ItemSelectable.h>

#include <vector>

namespace jlib { namespace awt {

class ItemListener;


class Choice : public Component, public ItemSelectable {
public:
	Choice();

    int getItemCount() const;

	const String& getItem(int index) const;

	void add(const String& item);
	void addItem(const String& item);

	void insert(const String& item, int index);

	void remove(const String& item);
	void remove(int position);
    void removeAll();

	String getSelectedItem() const;
    int getSelectedIndex() const;

	void select(int pos);
	void select(const String& str);

	void setBounds(int x, int y, int width, int height);

	void addItemListener(ItemListener*);
    void removeItemListener(ItemListener*);

protected:
	void addItemNoInvalidate(const String& item);
	void removeNoInvalidate(int position);

	void resetDropDownHeight();
	int getTotalHeight();
	int getDropDownHeight();
	int getFieldHeight();

	void addNotify();

	Dimension getMinimumSize() const;

protected:
	const Color& getDefaultForeground() const;
	const Color& getDefaultBackground() const;

	typedef std::vector<String> ItemsList;
    ItemsList items;
    int selectedIndex;

	typedef jlib::util::EventDispatcher<ItemListener>
			ItemEventDispatcher;
	ItemEventDispatcher itemEventDispatcher;

	void handleCommand(UINT notifyCode);

	LPCTSTR getClassName() const;
	DWORD getWindowStyle() const;
};

inline int Choice::getItemCount() const {
	return static_cast<int>(items.size());
}

inline void Choice::add(const String& item) {
	addItem(item);
}

inline String Choice::getSelectedItem() const {
	return selectedIndex >= 0 ? getItem(selectedIndex) : NULL;
}

inline int Choice::getSelectedIndex() const {
	return selectedIndex;
}

}}

#endif
