#ifndef JLIB_AWT_EVENT_CONTAINERADAPTER
#define JLIB_AWT_EVENT_CONTAINERADAPTER

#include <jlib/awt/ContainerListener.h>

namespace jlib { namespace awt {

class ContainerAdapter : public ContainerListener {
public:
    void componentAdded(const ContainerEvent&) {}
    void componentRemoved(const ContainerEvent&) {}
};

}}

#endif
