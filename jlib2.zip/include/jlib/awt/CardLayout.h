#ifndef JLIB_AWT_CARDLAYOUT
#define JLIB_AWT_CARDLAYOUT

#include <jlib/awt/LayoutManagerAdapter.h>
#include <jlib/lang/String.h>

#include <vector>

namespace jlib { namespace awt {

using jlib::lang::String;

class CardLayout : public LayoutManagerAdapter {
public:
	class Constraints : public LayoutConstraint {
	public:
		Constraints(const String& name) 
			: name(name) {
		}

		const String& getName() const {
			return name;
		}

	private:
		String name;
	};

    CardLayout(int hgap = 0, int vgap = 0);

	int getHgap() const;
	void setHgap(int hgap);

    int getVgap() const;
	void setVgap(int vgap);

    void addLayoutComponent(LayoutComponent* comp, 
			const LayoutConstraint& constraints);

	void removeLayoutComponent(LayoutComponent* comp);

    Dimension preferredLayoutSize(const LayoutContainer* parent);
	Dimension minimumLayoutSize(const LayoutContainer* parent);
    Dimension maximumLayoutSize(const LayoutContainer* target);

    void layoutContainer(LayoutContainer* parent);

    void first(LayoutContainer* parent);
    void next(LayoutContainer* parent);
    void previous(LayoutContainer* parent);
    void last(LayoutContainer* parent);

    void show(LayoutContainer* parent, const String& name);

private:
	void show(LayoutContainer* parent, int index);
	bool isTarget(const LayoutContainer* parent) const;

	int hgap;
	int vgap;

	struct Card {
		Card(const String& name, LayoutComponent* comp)
			: name(name), comp(comp) {
		}

		String name;
		LayoutComponent* comp;
	};

	typedef std::vector<Card> CardList;
	CardList cards;

	int currentCard;
};

inline CardLayout::CardLayout(int hgap, int vgap)
	: hgap(hgap), vgap(vgap), currentCard(0) {
}

inline int CardLayout::getHgap() const {
	return hgap;
}

inline void CardLayout::setHgap(int hgap) {
	this->hgap = hgap;
}

inline int CardLayout::getVgap() const {
	return vgap;
}

inline void CardLayout::setVgap(int vgap) {
	this->vgap = vgap;
}

}}

#endif
