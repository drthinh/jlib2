#ifndef JLIB_AWT_DEFAULTBOUNDEDRANGEMODEL
#define JLIB_AWT_DEFAULTBOUNDEDRANGEMODEL

#include <jlib/awt/BoundedRangeModel.h>
#include <jlib/util/EventDispatcher.h>

namespace jlib { namespace awt {

class DefaultBoundedRangeModel : public BoundedRangeModel {
public:
	DefaultBoundedRangeModel();
	DefaultBoundedRangeModel(int value, int extent, int min, int max);

	int getMinimum() const;
	void setMinimum(int);

	int getMaximum() const;
	void setMaximum(int);

	int getValue() const;
	void setValue(int);

	void setValueIsAdjusting(bool);
	bool getValueIsAdjusting() const;

	int getExtent() const;
	void setExtent(int);

	void setRangeProperties(int value, int extent, 
			int min, int max, bool adjusting);

	void addChangeListener(ChangeListener*);
	void removeChangeListener(ChangeListener*);

private:
	void fireStateChanged();

    int value;
    int extent;
    int min;
    int max;
    bool adjusting;

	typedef jlib::util::EventDispatcher<ChangeListener>
			ChangeEventDispatcher;
	ChangeEventDispatcher eventDispatcher;
};

}}

#endif
