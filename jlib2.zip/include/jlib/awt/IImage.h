#ifndef JLIB_AWT_IIMAGE
#define JLIB_AWT_IIMAGE

namespace jlib { namespace awt {

namespace image {
	class ImageObserver;
};

using jlib::awt::image::ImageObserver;

class IImage {
public:
	virtual ~IImage() {}

    virtual int getWidth(ImageObserver* observer) const = 0;
    virtual int getHeight(ImageObserver* observer) const = 0;
};

}}

#endif
