#ifndef JLIB_AWT_EVENT_FOCUSLISTENER
#define JLIB_AWT_EVENT_FOCUSLISTENER

#include <jlib/util/EventListener.h>

namespace jlib { namespace awt {

class FocusEvent;

class FocusListener : public jlib::util::EventListener {
public:
	virtual void focusGained(const FocusEvent&) = 0;
	virtual void focusLost(const FocusEvent&) = 0;
};

}}

#endif
