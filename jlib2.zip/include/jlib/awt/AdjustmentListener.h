#ifndef JLIB_AWT_EVENT_ADJUSTMENTLISTENER
#define JLIB_AWT_EVENT_ADJUSTMENTLISTENER

#include <jlib/util/EventListener.h>

namespace jlib { namespace awt {

class AdjustmentEvent;

class AdjustmentListener : public jlib::util::EventListener {
public:
	virtual void adjustmentValueChanged(const AdjustmentEvent&) = 0;
};

}}

#endif
