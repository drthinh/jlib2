#ifndef JLIB_AWT_AWTEVENT
#define JLIB_AWT_AWTEVENT

#include <jlib/util/EventObject.h>

namespace jlib { namespace awt {

template <class EventSource>
class AWTEvent : public jlib::util::EventObject<EventSource> {
public:
	typedef AWTEvent<EventSource> SuperEvent;

	enum {
		COMPONENT_EVENT_MASK = 0x01,
		CONTAINER_EVENT_MASK = 0x02,
		FOCUS_EVENT_MASK = 0x04,
		KEY_EVENT_MASK = 0x08,
		MOUSE_EVENT_MASK = 0x10,
		MOUSE_MOTION_EVENT_MASK = 0x20,
		WINDOW_EVENT_MASK = 0x40,
		ACTION_EVENT_MASK = 0x80,
		ADJUSTMENT_EVENT_MASK = 0x100,
		ITEM_EVENT_MASK = 0x200,
		TEXT_EVENT_MASK = 0x400,
		INPUT_METHOD_EVENT_MASK = 0x800,
		INPUT_METHODS_ENABLED_MASK = 0x1000,
		PAINT_EVENT_MASK = 0x2000,
		INVOCATION_EVENT_MASK = 0x4000,
		HIERARCHY_EVENT_MASK = 0x8000,
		HIERARCHY_BOUNDS_EVENT_MASK = 0x10000,
		RESERVED_ID_MAX = 1999
	};

    /**
     * Constructs an AWTEvent object with the specified source object and type.
     * @param source the object where the event originated
     * @id the event type
     */
	AWTEvent(int id) 
		: id(id), consumed(false) {
	}

	virtual ~AWTEvent() {
	}

	int getID() const {
		return id;
	}

protected: 
	void consume();
	bool isConsumed() const {
		return consumed;
	}

	int id;
	bool consumed;
};

//template <class EventSource, class EventId>
//inline EventId AWTEvent<EventSource, EventId>::getID() const {
//	return id;
//}

//template <class EventSource>
//inline bool AWTEvent<EventSource>::isConsumed() const {
//   return consumed;
//}

//template <class EventSource>
//inline AWTEvent<EventSource>::AWTEvent(int id) 
//		: id(id), consumed(false) {
 //   switch(id) {
	//case ActionEvent::ACTION_PERFORMED:
	//case ItemEvent::ITEM_STATE_CHANGED:
	//case AdjustmentEvent::ADJUSTMENT_VALUE_CHANGED:
	//case TextEvent::TEXT_VALUE_CHANGED:
	//	consumed = true;
	//	break;
	//default:
	//	break;
 //   }
//}

//template <class T>
//inline void AWTEvent<T>::consume() {
//	switch(id) {
//	case KeyEvent.KEY_PRESSED:
//	case KeyEvent.KEY_RELEASED:
//	case MouseEvent.MOUSE_PRESSED:
//	case MouseEvent.MOUSE_RELEASED:
//	case MouseEvent.MOUSE_MOVED:
//	case MouseEvent.MOUSE_DRAGGED:
//	case MouseEvent.MOUSE_ENTERED:
//	case MouseEvent.MOUSE_EXITED:
//	case InputMethodEvent.INPUT_METHOD_TEXT_CHANGED:
//	case InputMethodEvent.CARET_POSITION_CHANGED:
//		consumed = true;
//		break;
//	default:
//		// event type cannot be consumed
//	}
//}


}}

#endif
