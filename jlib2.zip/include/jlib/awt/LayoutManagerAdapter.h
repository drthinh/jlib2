#ifndef JLIB_AWT_LAYOUTMANAGERADAPTER
#define JLIB_AWT_LAYOUTMANAGERADAPTER

#include <jlib/awt/LayoutManager.h>
#include <jlib/awt/LayoutContainer.h>
#include <jlib/awt/LayoutComponent.h>
#include <jlib/awt/Insets.h>

namespace jlib { namespace awt {

class LayoutManagerAdapter : public LayoutManager {
public:
	void addLayoutComponent(LayoutComponent* /*comp*/, 
		const LayoutConstraint& /*constraints*/) {}
	void removeLayoutComponent(LayoutComponent* /*comp*/) {}

	void layoutContainer(LayoutContainer* /*parent*/) {}

	Dimension minimumLayoutSize(const LayoutContainer* /*parent*/) { 
		return Dimension(0, 0);
	}

	Dimension preferredLayoutSize(const LayoutContainer* parent) {
		return minimumLayoutSize(parent);
	}

	Dimension maximumLayoutSize(const LayoutContainer* target) {
		return preferredLayoutSize(target);
	}

	float getLayoutAlignmentX(const LayoutContainer* /*target*/) const {
		return 0.5f;
	}

	float getLayoutAlignmentY(const LayoutContainer* /*target*/) const {
		return 0.5f;
	}

	void invalidateLayout(LayoutContainer* /*target*/) {}
};

}}

#endif
