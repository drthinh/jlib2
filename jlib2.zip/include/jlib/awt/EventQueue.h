#ifndef JLIB_AWT_EVENTQUEUE
#define JLIB_AWT_EVENTQUEUE

#include <jlib/lang/Monitor.h>

namespace jlib { 
	
namespace lang {
	class Runnable;
}

namespace awt {

using jlib::lang::Runnable;

class EventQueue {
public:
	EventQueue();
	~EventQueue();

	static EventQueue* instance();

	void enter();
	void leave();

	static bool isEventDispatchThread();
	static void invokeLater(Runnable* target);
	static void invokeAndWait(Runnable* target);

	int getResult();

	HWND getMessageWindow() const;

private:
	void privateInvokeLater(Runnable* target);
	void privateInvokeAndWait(Runnable* target);
	
	void processInvocationEvent(BOOL* waiting, Runnable* target);

	DWORD threadId;
	void win32MessageLoop();
	jlib::lang::Monitor invocationLock;
	int result;

	HWND invocationHandler;
	static LRESULT CALLBACK invocationHandlerWindowProc(
		HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	static EventQueue* me;
};

inline EventQueue* EventQueue::instance() {
	return me;
}

inline int EventQueue::getResult() {
	return result;
}

inline HWND EventQueue::getMessageWindow() const {
	return  invocationHandler;
}

}}

#endif
