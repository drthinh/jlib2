#ifndef JLIB_AWT_MENU
#define JLIB_AWT_MENU

#include <jlib/awt/MenuItem.h>
#include <jlib/awt/MenuContainer.h>

#include <vector>

namespace jlib { namespace awt {


class Menu : public MenuItem, public MenuContainer {
public:
    Menu(const String& label = _T(""), bool tearOff = false);

	void addNotify();
	void removeNotify();

	const Font& getFont() const;

	bool isTearOff() const;

	bool isHelpMenu() const;
	void setHelpMenu(bool b);

	int getItemCount() const;

	MenuItem* getItem(int index) const;

	MenuItem* add(MenuItem* mi);

	void insert(MenuItem* menuItem, int index);
	
	void addSeparator();
    void insertSeparator(int index);

	void remove(int index);
	void remove(MenuItem* item);

	void removeAll();

	void remove(MenuComponent* mc);

	HMENU getPeer() const;

private:
	static MenuItem* getSeparator();
	typedef std::vector<MenuItem*> MenuItemList;
	MenuItemList items;

    bool tearOff;
    bool isHelp;

	// peer operations
	HMENU peer;
	HMENU peer_createMenu();
	void peer_addItem(MenuItem* mi);
	void peer_insertItem(MenuItem* mi, int index);
	void peer_delItem(int index);
	void peer_dispose();
};

inline HMENU Menu::getPeer() const {
	return peer;
}

inline bool Menu::isHelpMenu() const {
	return isHelp;
}

inline void Menu::setHelpMenu(bool b) {
	isHelp = b;
}

inline const Font& Menu::getFont() const {
	return MenuComponent::getFont();
}

inline void Menu::remove(MenuComponent* mcomp) {
	remove(static_cast<MenuItem*>(mcomp));
}

}}

#endif
