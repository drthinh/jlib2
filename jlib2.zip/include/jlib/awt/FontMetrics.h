#ifndef JLIB_AWT_FONTMETRICS
#define JLIB_AWT_FONTMETRICS

#include <jlib/lang/String.h>
#include <jlib/awt/Font.h>

namespace jlib { namespace awt {

using jlib::lang::String;

class FontMetrics {
public:
	int getLeading() const;
	int getAscent() const;
	int getDescent() const;
	int getHeight() const;
	int getMaxAscent() const;
	int getMaxDescent() const;
	int getMaxAdvance() const;
	int charWidth(TCHAR ch) const;
	int stringWidth(const String& str) const;
	int charsWidth(const TCHAR* data, int off, int len) const;

	FontMetrics(const Font& font);
private:
	Font font;
	int ascent;
	int descent;
	int leading;
};

}}

#endif
