#ifndef JLIB_AWT_COMPONENT
#define JLIB_AWT_COMPONENT

#include <jlib/awt/LayoutComponent.h>

#include <jlib/awt/Rectangle.h>
#include <jlib/awt/image/ImageObserver.h>

#include <jlib/awt/Color.h>
#include <jlib/awt/Font.h>
#include <jlib/awt/FontMetrics.h>
#include <jlib/awt/Cursor.h>

#include <jlib/util/EventDispatcher.h>

#include <memory> // for auto_ptr

namespace jlib { namespace awt {

using jlib::lang::String;

class ComponentListener;
class MouseListener;
class MouseMotionListener;
class MouseEvent;
class KeyListener;
class KeyEvent;
class FocusListener;
class HierarchyListener;
class HierarchyEvent;

class Container;
class Graphics;

class Component : protected Rectangle, 
	public LayoutComponent, public jlib::awt::image::ImageObserver {
public:
    static const float TOP_ALIGNMENT;
    static const float CENTER_ALIGNMENT;
    static const float BOTTOM_ALIGNMENT;
    static const float LEFT_ALIGNMENT;
    static const float RIGHT_ALIGNMENT;

	Component();
	virtual ~Component();

	virtual void setVisible(bool);
	bool isVisible() const;

	virtual void addNotify();
	virtual void removeNotify();

	bool isShowing() const;
	bool isDisplayable() const;

	virtual void show();
	virtual void hide();

	const Rectangle& getBounds() const;
	void setBounds(int x, int y, int width, int height);

	void setLocation(int x, int y);
	using Rectangle::getLocation;

	void setSize(int width, int height);
	using Rectangle::getSize;

	int getX() const;
	int getY() const;
	int getWidth() const;
	int getHeight() const;

	void setForeground(const Color&);
	void unsetForeground();
	const Color& getForeground() const;
	bool isForegroundSet() const;

	void setBackground(const Color&);
	void unsetBackground();
	const Color& getBackground() const;
	bool isBackgroundSet() const;

	void setFont(const Font&);
	void unsetFont();
	const Font& getFont() const;
	bool isFontSet() const;

	FontMetrics getFontMetrics() const;

	void setCursor(const Cursor&);
	void unsetCursor();
	const Cursor& getCursor() const;
	bool isCursorSet() const;

	void setEnabled(bool);
	bool isEnabled() const;

	void setToolTipText(const String&);
	const String& getToolTipText() const;

	bool isValid() const;

	virtual Dimension getMinimumSize() const;
	virtual Dimension getPreferredSize() const;
	virtual Dimension getMaximumSize() const;

	float getAlignmentX() const;
	float getAlignmentY() const;

	void setParent(Container*);
	Container* getParent() const;

	virtual void doLayout() {}

	std::auto_ptr<Graphics> getGraphics() const;

	virtual void paint(Graphics& g);
	virtual void update(Graphics& g);

	void repaint();
	void repaint(int x, int y, int width, int height);

	void addComponentListener(ComponentListener*);
	void removeComponentListener(ComponentListener*);

	virtual void processMouseEvent(MouseEvent& e);
	virtual void processMouseMotionEvent(MouseEvent& e);
	void addMouseListener(MouseListener*);
	void removeMouseListener(MouseListener*);

	void addMouseMotionListener(MouseMotionListener*);
	void removeMouseMotionListener(MouseMotionListener*);

	virtual void processKeyEvent(KeyEvent& e);
	void addKeyListener(KeyListener*);
	void removeKeyListener(KeyListener*);

	void addFocusListener(FocusListener*);
	void removeFocusListener(FocusListener*);

	virtual void processHierarchyEvent(	const HierarchyEvent& e);
	void addHierarchyListener(HierarchyListener*);
	void removeHierarchyListener(HierarchyListener*);

	bool imageUpdate(Image* img, int infoflags, 
		int x, int y, int width, int height);

	// these two methods are provided to eliminate "dynamic_cast"s.
	virtual bool isContainer() const;
	virtual bool isWindow() const;

	// If the window is created by jlib, return the component.
	static Component* getComponent(HWND hwnd);
	
protected:

	mutable Dimension minSize;
	mutable Dimension prefSize;

	Color foreground;
	bool foregroundSet;
	Color background;
	bool backgroundSet;

	virtual const Color& getDefaultForeground() const;
	virtual const Color& getDefaultBackground() const;

	Font font;
	bool fontSet;

	Cursor cursor;
	bool cursorSet;

	bool visible;
	Container* parent;
	String text;

	String toolTipText;

	bool enabled;

	bool valid;
	virtual void invalidate();
	virtual void validate();

	typedef jlib::util::EventDispatcher<
			ComponentListener> ComponentEventDispatcher;
	ComponentEventDispatcher componentEventDispatcher;

	typedef jlib::util::EventDispatcher<
			MouseListener> MouseEventDispatcher;
	MouseEventDispatcher mouseEventDispatcher;

	typedef jlib::util::EventDispatcher<
			MouseMotionListener> 
			MouseMotionEventDispatcher;
	MouseMotionEventDispatcher mouseMotionEventDispatcher;

	typedef jlib::util::EventDispatcher<
			KeyListener> KeyEventDispatcher;
	KeyEventDispatcher keyEventDispatcher;

	typedef jlib::util::EventDispatcher<
			FocusListener> FocusEventDispatcher;
	FocusEventDispatcher focusEventDispatcher;

	typedef jlib::util::EventDispatcher<
			HierarchyListener> HierarchyEventDispatcher;
	HierarchyEventDispatcher hierarchyEventDispatcher;

	friend class Container;

	// WIN32
	public:	HWND getPeer() const;
	void peer_paintDamagedAreaImmediately();

protected:	
	// peer operations
	static LPCTSTR className;
	void peer_initClass();

	HWND peer;
	HWND peer_create();
	void peer_destroy();

	void peer_setBounds(int x, int y, int width, int height);

	UINT id;
	void setId(UINT id);
	UINT getId() const;

	void peer_setForeground();

	mutable HBRUSH backgroundBrush;
	HBRUSH getBackgroundBrush() const;
	void peer_setBackground();
	void peer_setVisible(bool b);

	void peer_setFont(const Font& font);

	void peer_setCursor(const Cursor& cursor);

	void peer_setEnabled(bool b);

	virtual bool peer_shouldClearRectBeforePaint();

	DWORD getClassStyle() const;

	virtual LPCTSTR getClassName() const;

	WNDPROC defaultWndProc;
	virtual DWORD getWindowStyle() const;
	virtual DWORD getWindowExStyle() const;

	// messages
	virtual void drawItem(DRAWITEMSTRUCT* di);
	virtual void handleCommand(UINT notifyCode);
	virtual void handleScroll(int code, int pos, bool vertical);
	virtual LRESULT handleNotify(NMHDR* nmHdr);

	bool wmSetCursor(WPARAM wParam, LPARAM lParam);
	bool wmMouseMove(WPARAM wParam, LPARAM lParam);
	bool wmMouseLeave();
	virtual bool wmMouseDown(WPARAM wParam, LPARAM lParam, int button);
	virtual bool wmMouseUp(WPARAM wParam, LPARAM lParam, int button);
	void wmShowWindow(WPARAM wParam, LPARAM lParam);
	void wmPaint();

	bool wmKeyDown(WPARAM wParam, LPARAM lParam, bool system);
	bool wmKeyUp(WPARAM wParam, LPARAM lParam, bool system);
	bool wmChar(WPARAM wParam, LPARAM lParam, bool system);

	void wmFocusChange(WPARAM wParam, LPARAM lParam, bool gained);

	virtual LRESULT windowProc(UINT message, WPARAM wParam, LPARAM lParam);

	void subClassWindow();
	static LRESULT CALLBACK jlib_awt_Component_wndProc(
			HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

	// uncopiable
	Component(const Component& other);
	Component& operator=(const Component& other);
};


inline bool Component::isVisible() const {
	return visible;
}

inline void Component::show() {
	setVisible(true);
}

inline void Component::hide() {
	setVisible(false);
}

inline const Rectangle& Component::getBounds() const {
	return Rectangle::getBounds();
}

inline int Component::getX() const {
	return x;
}

inline int Component::getY() const {
	return y;
}

inline int Component::getWidth() const {
	return width;
}

inline int Component::getHeight() const {
	return height;
}

inline bool Component::isEnabled() const {
	return enabled;
}

inline const String& Component::getToolTipText() const {
	return toolTipText;
}

inline bool Component::isValid() const {
	return valid;
}

inline bool Component::isDisplayable() const {
	return peer != NULL;
}

inline bool Component::isForegroundSet() const {
	return foregroundSet;
}

inline bool Component::isBackgroundSet() const {
	return backgroundSet;
}

inline bool Component::isFontSet() const {
	return fontSet;
}

inline bool Component::isCursorSet() const {
	return cursorSet;
}

inline Dimension Component::getMinimumSize() const {
	return minSize;
}

inline float Component::getAlignmentX() const {
	return CENTER_ALIGNMENT;
}

inline float Component::getAlignmentY() const {
	return CENTER_ALIGNMENT;
}

inline Container* Component::getParent() const {
	return parent;
}

inline void Component::setParent(Container* con) {
	parent = con;
}

inline HWND Component::getPeer() const {
	return peer;
}

inline bool Component::isContainer() const {
	return false;
}

inline bool Component::isWindow() const {
	return false;
}

inline UINT Component::getId() const {
	return id;
}

inline DWORD Component::getWindowStyle() const {
	return WS_CHILD | WS_CLIPSIBLINGS;
}

inline DWORD Component::getWindowExStyle() const {
	return 0;
}

inline void Component::drawItem(DRAWITEMSTRUCT* /*di*/) {}
inline void Component::handleCommand(UINT /*notifyCode*/) {}
inline void Component::handleScroll(int /*code*/, int /*pos*/, bool /*vertical*/) {}
inline LRESULT Component::handleNotify(NMHDR* /*nmHdr*/) { return 0; }

}}

#endif
