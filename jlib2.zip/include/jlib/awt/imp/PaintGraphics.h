#ifndef JLIB_AWT_IMP_PAINTGRAPHICS
#define JLIB_AWT_IMP_PAINTGRAPHICS

#include <jlib/awt/imp/DCGraphics.h>

namespace jlib { namespace awt { namespace imp {

class PaintGraphics : public DCGraphics {
public:
	PaintGraphics(Component* target) 
		: target(target) {
		assert ( target != NULL );
	}

	~PaintGraphics() {
		if ( getPeer() != NULL ) {
			::EndPaint(target->getPeer(), &ps);
		}
	}

	void setColor(Color c) {
		ensurePeer();
		GraphicsImp::setColor(c);
	}

	void fillRect(int x, int y, int width, int height) {
		ensurePeer();
		GraphicsImp::fillRect(x, y, width, height);
	}

	void clearRect(int x, int y, int width, int height) {
		ensurePeer();
		GraphicsImp::clearRect(x, y, width, height);
	}

	void fillPolygon(const int* xPoints, const int* yPoints, int nPoints) {
		ensurePeer();
		GraphicsImp::fillPolygon(xPoints, yPoints, nPoints);
	}

	bool drawImage(const Image& img, int x, int y, ImageObserver* observer) {
		ensurePeer();
		return GraphicsImp::drawImage(img, x, y, observer);
	}
private:
	void ensurePeer() {
		if ( getPeer() == NULL ) {
			HDC dc = ::BeginPaint(target->getPeer(), &ps);
			assert ( dc != NULL );
			setPeer(dc);

			setColor(target->getForeground());
			setBackground(target->getBackground());
		}
	}

	Component* target;
	PAINTSTRUCT ps;
};

}}}

#endif
