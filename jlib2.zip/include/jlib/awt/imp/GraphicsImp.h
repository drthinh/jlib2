#ifndef JLIB_AWT_IMP_GRAPHICSIMP
#define JLIB_AWT_IMP_GRAPHICSIMP

#include <jlib/awt/IGraphics.h>
#include <jlib/lang/RefCounter.h>

namespace jlib { namespace awt { namespace imp {

class GraphicsImp : public IGraphics, public jlib::lang::RefCounter {};

}}}

#endif
