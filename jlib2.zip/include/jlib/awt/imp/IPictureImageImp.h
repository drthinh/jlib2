#ifndef JLIB_AWT_IMP_IPICTUREIMAGEIMP
#define JLIB_AWT_IMP_IPICTUREIMAGEIMP

#include <jlib/awt/Image.h>
#include <jlib/lang/String.h>
#include <jlib/awt/Dimension.h>

struct IPicture;

namespace jlib { namespace awt { 

namespace imp {

class IPictureImageImp : public Image {
public:
	IPictureImageImp(const jlib::lang::String& name);
	~IPictureImageImp();

	int getWidth(jlib::awt::image::ImageObserver* observer) const;
    int getHeight(jlib::awt::image::ImageObserver* observer) const;
	bool drawTo(HDC dc, int x, int y, 
			jlib::awt::image::ImageObserver* observer) const;

	HICON getHICON() const;
private:
	void initSizes();
	static void HMToDevice(HDC dc, jlib::awt::Dimension* d);
	IPicture* pic;
	mutable jlib::awt::Dimension size;
	mutable jlib::awt::Dimension hmSize;
};

}}}

#endif
