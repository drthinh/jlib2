#ifndef JLIB_AWT_IMP_GDIOBJ
#define JLIB_AWT_IMP_GDIOBJ

#include <jlib/awt/Color.h>

namespace jlib { namespace awt { namespace imp {

class DCSelector {
public:
	DCSelector(HDC dc, HGDIOBJ obj)
		: dc(dc) {
		old = ::SelectObject(dc, obj);
	}

	~DCSelector() {
		::SelectObject(dc, old);
	}
private:
	HDC dc;
	HGDIOBJ old;
};

class Pen {
public:
	Pen(jlib::awt::Color c = Color::BLACK)
		: color(c), peer(NULL) {
	}

	~Pen();

	void setColor(jlib::awt::Color c);

	jlib::awt::Color getColor() const {
		return color;
	}

	HPEN get() const;

	static HPEN getPredefined(int index);

private:
	jlib::awt::Color color;
	mutable HPEN peer;
};

class Brush {
public:
	Brush(jlib::awt::Color c = jlib::awt::Color::WHITE)
		: color(c), peer(NULL) {
		}

	~Brush();

	void setColor(jlib::awt::Color c);

	jlib::awt::Color getColor() const {
		return color;
	}

	HBRUSH get() const;

	static HBRUSH getPredefined(int index);

private:
	jlib::awt::Color color;
	mutable HBRUSH peer;
};

}}}

#endif
