#ifndef JLIB_AWT_IMP_IMAGEIMP
#define JLIB_AWT_IMP_IMAGEIMP

#include <jlib/awt/IImage.h>
#include <jlib/lang/RefCounter.h>

namespace jlib { namespace awt { namespace imp {

class GraphicsImp;

class ImageImp : 
	public jlib::awt::IImage, 
	public jlib::lang::RefCounter {
public:
	virtual bool drawTo(GraphicsImp& g, 
			int x, int y, ImageObserver* observer) const = 0;
};

}}}

#endif
