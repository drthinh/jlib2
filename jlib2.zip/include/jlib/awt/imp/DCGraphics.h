#ifndef JLIB_AWT_IMP_DCGRAPHICS
#define JLIB_AWT_IMP_DCGRAPHICS

#include <jlib/awt/Graphics.h>
#include <jlib/awt/Font.h>

#include <jlib/awt/imp/GdiObj.h>

namespace jlib { namespace awt { namespace imp {

class DCGraphics : public Graphics {
public:
	DCGraphics(HDC peer = NULL);

	void setFont(const jlib::awt::Font& f);
	const jlib::awt::Font& getFont() const;

	void setColor(Color c);
	virtual Color getColor() const;
	void drawLine(int x1, int y1, int x2, int y2);
	void drawRect(int x, int y, int width, int height);
	void fillRect(int x, int y, int width, int height);
	void clearRect(int x, int y, int width, int height);
	void draw3DRect(int x, int y, int width, int height, bool raised);
	void fill3DRect(int x, int y, int width, int height, bool raised);
	void drawArc(int x, int y, int width, int height,
			int startAngle, int arcAngle);
	void fillArc(int x, int y, int width, int height,
			int startAngle, int arcAngle);
	void fillPolygon(const int* xPoints, const int* yPoints, int nPoints);
	bool drawImage(const Image& img, int x, int y, 
			jlib::awt::image::ImageObserver* observer);
	void drawString(const String& str, int x, int y);
	void drawChars(const TCHAR* chars, int off, int len, int x, int y);

	void setXORMode(Color c);
	void setPaintMode();

	void setClip(int x, int y, int width, int height);
	void clipRect(int x, int y, int width, int height);
	Rectangle getClipBounds() const;

	void translate(int x, int y);

	HDC getPeer() const {
		return peer;
	}

protected:
	void setPeer(HDC dc);

	void setBackground(Color c);
	Color getBackground() const {
		return backColor;
	}
	
private:
	void angleToCoord(int angle, int width, int height, int *x, int *y);
	void arc(int x, int y, int width, int height,
			int startAngle, int arcAngle, bool fill);

	HDC peer;
	Color foreColor;
	Color backColor;
	Font font;

	void changeClip(int x, int y, int width, int height, bool set);

	// Cached objects
	Pen forePen;
	Pen backPen;
	Brush foreBrush;
	Brush backBrush;
};

inline Color DCGraphics::getColor() const {
	return foreColor;
}

}}}

#endif
