#ifndef JLIB_AWT_IMP_GETDCGRAPHICS
#define JLIB_AWT_IMP_GETDCGRAPHICS

#include <jlib/awt/imp/DCGraphics.h>

namespace jlib { namespace awt { namespace imp {

class GetDCGraphics : public DCGraphics {
public:
	GetDCGraphics(const Component* target);
	~GetDCGraphics();

private:
	const Component* target;
};

}}}

#endif
