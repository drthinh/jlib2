#ifndef JLIB_AWT_EVENT_WINDOWLISTENER
#define JLIB_AWT_EVENT_WINDOWLISTENER

#include <jlib/util/EventListener.h>

namespace jlib { namespace awt {

class WindowEvent;

class WindowListener : public jlib::util::EventListener {
public:
    /**
     * Invoked the first time a window is made visible.
     */
    virtual void windowOpened(const WindowEvent&) = 0;

    /**
     * Invoked when the user attempts to close the window
     * from the window's system menu.  If the program does not 
     * explicitly hide or dispose the window while processing 
     * this event, the window close operation will be cancelled.
     */
    virtual void windowClosing(const WindowEvent&) = 0;

    /**
     * Invoked when a window has been closed as the result
     * of calling dispose on the window.
     */
    virtual void windowClosed(const WindowEvent&) = 0;

    /**
     * Invoked when a window is changed from a normal to a
     * minimized state. For many platforms, a minimized window 
     * is displayed as the icon specified in the window's 
     * iconImage property.
     * @see java.awt.Frame#setIconImage
     */
    virtual void windowIconified(const WindowEvent&) = 0;

    /**
     * Invoked when a window is changed from a minimized
     * to a normal state.
     */
    virtual void windowDeiconified(const WindowEvent&) = 0;

    /**
     * Invoked when the window is set to be the user's
     * active window, which means the window (or one of its
     * subcomponents) will receive keyboard events.
     */
    virtual void windowActivated(const WindowEvent&) = 0;

    /**
     * Invoked when a window is no longer the user's active
     * window, which means that keyboard events will no longer
     * be delivered to the window or its subcomponents.
     */
    virtual void windowDeactivated(const WindowEvent&) = 0;
};

}}

#endif
