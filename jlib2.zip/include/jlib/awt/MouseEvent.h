#ifndef JLIB_AWT_EVENT_MOUSEEVENT
#define JLIB_AWT_EVENT_MOUSEEVENT

#include <jlib/awt/InputEvent.h>
#include <jlib/awt/Point.h>

#ifdef MOUSE_MOVED
#undef MOUSE_MOVED
const int MOUSE_MOVED = 0x0001;
#endif

namespace jlib { namespace awt {

class MouseEvent : public InputEvent, private Point {
public:
	enum EventId {
		MOUSE_CLICKED,
		MOUSE_PRESSED,
		MOUSE_RELEASED,
		MOUSE_MOVED,
		MOUSE_ENTERED,
		MOUSE_EXITED,
		MOUSE_DRAGGED,
		MOUSE_LAST
	};

	MouseEvent(EventId id, long when, int modifiers,
		int x, int y, int clickCount, bool popupTrigger)
		: InputEvent(when, modifiers), Point(x, y), id(id),
		clickCount(clickCount), popupTrigger(popupTrigger) {
	}

	EventId getID() const {
		return id;
	}

	const Point& getPoint() const {
		return *this;
	}

	int getX() const {
		return x;
	}

	int getY() const {
		return y;
	}

	void translatePoint(int x, int y) {
		Point::translate(x, y);
	}

	int getClickCount() const {
		return clickCount;
	}

	bool isPopupTrigger() const {
		return popupTrigger;
	}

private:
	EventId id;
	int clickCount;
	bool popupTrigger;
};

}}

#endif
