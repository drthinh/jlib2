#ifndef JLIB_AWT_EVENT_MOUSEMOTIONADAPTER
#define JLIB_AWT_EVENT_MOUSEMOTIONADAPTER

#include <jlib/awt/MouseMotionListener.h>

namespace jlib { namespace awt {

class MouseMotionAdapter : public MouseMotionListener {
public:
	void mouseDragged(MouseEvent&) {}
	void mouseMoved(MouseEvent&) {}
};

}}

#endif
