#ifndef JLIB_AWT_FILEDIALOG
#define JLIB_AWT_FILEDIALOG

#include <jlib/awt/Dialog.h>


namespace jlib { 

	namespace io {
		class FilenameFilter;
	}
	
namespace awt {

class FileDialog : public Dialog {
public:
	enum Mode {
		LOAD,
		SAVE
	};

	explicit FileDialog(Frame* parent, 
			const String& title = _T(""), Mode mode = LOAD);

	void setVisible(bool);

	Mode getMode() const;
	void setMode(Mode);

	const String& getDirectory() const;
	void setDirectory(const String&);

	const String& getFile() const;
	void setFile(const String&);

	jlib::io::FilenameFilter* getFilenameFilter() const;
	void setFilenameFilter(jlib::io::FilenameFilter*);

private:
	void peer_addNotify();
	void peer_setDirectory(const String&);
	void peer_setFile(const String&);
	
	//win32 

	static UINT_PTR CALLBACK 
	OFNHookProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

	Mode mode;
	String dir;
	String file;
	jlib::io::FilenameFilter* filter;
};

inline FileDialog::Mode FileDialog::getMode() const {
	return mode;
}

inline const String& FileDialog::getDirectory() const {
	return dir;
}

inline const String& FileDialog::getFile() const {
	return file;
}

inline jlib::io::FilenameFilter* FileDialog::getFilenameFilter() const {
	return filter;
}

inline void FileDialog::setFilenameFilter(jlib::io::FilenameFilter* filter) {
	this->filter = filter;
}

}}

#endif
