#ifndef JLIB_AWT_TOOLKIT
#define JLIB_AWT_TOOLKIT

#include <vector>

#include <jlib/lang/String.h>
#include <jlib/awt/Dimension.h>

namespace jlib { namespace awt {

class MenuItem;
class Container;

using jlib::lang::String;

class EventQueue;
class Component;
class Image;

class Toolkit {
public:
	static Toolkit* getDefaultToolkit();
	Dimension getScreenSize() const;
	int getScreenResolution() const;
	void beep();

	std::auto_ptr<Image> createImage(const String& filename);

	// WIN32
	HMODULE getModuleHandle() const;
	void startEventLoop();
	void stopEventLoop();
	EventQueue& getSystemEventQueue();

	void addDisplayable(Component*);
	void removeDisplayable(Component*);
	Component* getComponent(HWND hwnd) const;

protected:
	Toolkit(HMODULE hmod);
	~Toolkit();

	static Toolkit* toolkit;

public: static int windowsKeyToJavaKey(UINT windowsKey, int modifiers);
public: static WORD javaKeyToWindowsKey(int javaKey);
public: static int getJavaModifiers(int mouseButton);


private:
	std::vector<Component*> displayableComponents;
	HMODULE hmod;
	jlib::awt::EventQueue* eventQueue;
};

inline Toolkit* Toolkit::getDefaultToolkit() {
	return toolkit;
}

}}

#endif
