#ifndef JLIB_AWT_FRAME
#define JLIB_AWT_FRAME

#include <jlib/awt/Window.h>
#include <jlib/awt/MenuContainer.h>

namespace jlib { namespace awt {

class MenuBar;
class Image;

class Frame : public Window, public MenuContainer {
public:
	Frame();
	Frame(const String& title);
	virtual ~Frame();
	void setVisible(bool b);
	void show();

	void addNotify();
	void removeNotify();

	void setTitle(const String& title);
	const String& getTitle() const;

	void setIconImage(Image* img);
	Image* getIconImage() const;

	void setMenuBar(MenuBar* mb);
	MenuBar* getMenuBar();

	void setUndecorated(bool b);
	bool isUndecorated() const;

	// MenuContainer methods
	const Font& getFont() const;
	void remove(MenuComponent* mcomp);
#if __GNUC__ >=3 && __GNUC_MINOR < 3
	void remove(int index) {
		Window::remove(index);
	}

	void remove(Component* comp) {
		Window::remove(comp);
	}
#else
	using Window::remove;
#endif

protected:
	const Color& getDefaultForeground() const;
	const Color& getDefaultBackground() const;

protected:
	MenuBar* menuBar;
	Image* iconImage;
	bool undecorated;

	// peer operations
	void peer_setTitle(const String& title);
	//Color peer_getDefaultColor();
	void peer_setMenuBar();
	void peer_setIconImage(Image* img);

	// WIN32
	DWORD getClassStyle() const;
	DWORD getWindowStyle() const;
	DWORD getWindowExStyle() const;

	static int numOfFrames;
};

inline const String& Frame::getTitle() const {
	return text;
}

inline void Frame::setMenuBar(MenuBar* mb) {
	menuBar = mb;
}

inline MenuBar* Frame::getMenuBar() {
	return menuBar;
}

inline bool Frame::isUndecorated() const {
	return undecorated;
}

inline const Font& Frame::getFont() const {
	return Window::getFont();
}

}}

#endif
