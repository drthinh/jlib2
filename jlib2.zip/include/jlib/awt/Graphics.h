#ifndef JLIB_AWT_GRAPHICS
#define JLIB_AWT_GRAPHICS

#include <jlib/awt/Color.h>
#include <jlib/awt/Rectangle.h>
#include <jlib/lang/String.h>

namespace jlib { namespace awt {

namespace image {
	class ImageObserver; 
}

using jlib::lang::String;

class Font;
class Image;

class FontMetrics;

class Graphics {
public:
	virtual void setColor(Color c) = 0;
	virtual Color getColor() const = 0;

	virtual void setFont(const Font& f) = 0;
	virtual const Font& getFont() const = 0;

	virtual void drawLine(int x1, int y1, int x2, int y2) = 0;

	virtual void drawRect(int x, int y, int width, int height) = 0;
	virtual void fillRect(int x, int y, int width, int height) = 0;
	virtual void clearRect(int x, int y, int width, int height) = 0;

	virtual void draw3DRect(int x, int y, int width, int height, 
			bool raised) = 0;
	virtual void fill3DRect(int x, int y, int width, int height,
			bool raised) = 0;

	virtual void drawArc(int x, int y, int width, int height,
			int startAngle, int arcAngle) = 0;
	virtual void fillArc(int x, int y, int width, int height,
			int startAngle, int arcAngle) = 0;

	virtual void fillPolygon(
			const int* xPoints, const int* yPoints, int nPoints) = 0;

	virtual bool drawImage(const Image& img, int x, int y, 
			jlib::awt::image::ImageObserver* observer) = 0;

	virtual void drawString(const String& str, int x, int y) = 0;
	virtual void drawChars(const TCHAR* chars, 
			int off, int len, int x, int y) = 0;

	virtual void setClip(int x, int y, int width, int height) = 0;
	virtual void clipRect(int x, int y, int width, int height) = 0;
	virtual Rectangle getClipBounds() const = 0;

	virtual void setXORMode(Color c) = 0;
	virtual void setPaintMode() = 0;

	virtual void translate(int x, int y) = 0;

	virtual ~Graphics() {}
};

}}

#endif
