#ifndef JLIB_AWT_EVENT_FOCUSEVENT
#define JLIB_AWT_EVENT_FOCUSEVENT

#include <jlib/util/EventObject.h>

namespace jlib { namespace awt {

class FocusEvent : public jlib::util::EventObject<Component> {
public:
	enum EventId {
		FOCUS_GAINED,
		FOCUS_LOST
	};

	explicit FocusEvent(EventId id, bool temporary = false,
		Component* opposite = NULL)
		: id(id), temporary(temporary), opposite(opposite) {
    }

	bool isTemporary() const {
        return temporary;
    }

	Component* getOppositeComponent() const {
		return opposite;
	}

private:
	EventId id;
	bool temporary;
	Component* opposite;
};

}}

#endif
