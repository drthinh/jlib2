#ifndef JLIB_AWT_LAYOUTCOMPONENT
#define JLIB_AWT_LAYOUTCOMPONENT

#include <jlib/awt/Rectangle.h>

namespace jlib { namespace awt {

class LayoutComponent {
public:
	virtual ~LayoutComponent() {}

	virtual void setVisible(bool) = 0;
	virtual bool isVisible() const = 0;

	virtual void setBounds(int x, int y, int width, int height) = 0;
	virtual const Rectangle& getBounds() const = 0;

	virtual Dimension getMinimumSize() const = 0;
	virtual Dimension getPreferredSize() const = 0;
	virtual Dimension getMaximumSize() const = 0;

	virtual float getAlignmentX() const = 0;
	virtual float getAlignmentY() const = 0;

	virtual void invalidate() = 0;
	virtual void validate() = 0;
};

}}

#endif
