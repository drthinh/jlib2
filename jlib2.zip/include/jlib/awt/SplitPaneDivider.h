#ifndef JLIB_AWT_SPLITPANEDIVIDER
#define JLIB_AWT_SPLITPANEDIVIDER

#include <jlib/awt/Rectangle.h>

namespace jlib { namespace awt {

class MouseEvent;
class SplitPane;
class Graphics;

class SplitPaneDivider : private Rectangle {
public:
	SplitPaneDivider(SplitPane* target, 
			bool vertical = true, bool continuousLayout = false);

	const Rectangle& getBounds() const;

	void setSize(int dividerSize);
	int getSize() const;

	void setLocation(int location);
	int getLocation() const;

	void setLastLocation(int v);
	int getLastLocation() const;

	void setOneTouchExpandable(bool v);
	bool isOneTouchExpandable() const;

	void setVertical(bool vertical);
	bool isVertical() const;

	void setContinuousLayout(bool v);
	bool isContinuousLayout() const;

	void invalidate();
	void validate();

	void processMouseEvent(const MouseEvent& e);

	void paint(Graphics& g);

private:
	void updateBounds();

	void mousePressed(const Point& point);
	void mouseMoved(const Point& point);
	void mouseDragged(const Point& point);
	void mouseReleased(const Point& point);
	void mouseExited();

	void calcOneTouchButtonRect(Rectangle* left, Rectangle* right);

	void drawOneTouchButtons(Graphics& g);

	int doTracking(const Point& point);
	void drawResizeLine(const Rectangle& rect);

	void setSplitCursor();

	SplitPane* target;

	bool vertical;
	bool continuousLayout;
	bool oneTouchExpandable;
	int lastLocation;

	mutable bool valid;

	bool tracking;
	int zDelta;
	int prevLocation;

	SplitPaneDivider(const SplitPaneDivider&);
	SplitPaneDivider& operator=(const SplitPaneDivider&);
};

}}

#endif
