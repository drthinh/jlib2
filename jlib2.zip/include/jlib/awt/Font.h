#ifndef JLIB_AWT_FONT
#define JLIB_AWT_FONT

#include <jlib/lang/String.h>

namespace jlib { namespace awt {

using jlib::lang::String;

class Font {
public:
	enum {
		PLAIN = 0,
		BOLD = 1,
		ITALIC = 2
	};

	Font() 
		: style(0), size(0) {
	}

    Font(const String& name, int style, int size);

	~Font() {
	}

	bool operator!() const {
		return name.empty();
	}

	const String& getName() const {
		return name;
	}

	int getStyle() const {
		return style;
	}

	int getSize() const {
		return size;
	}

    bool isPlain() const {
		return style == 0;
    }

	bool isBold() const {
		return (style & BOLD) != 0;
	}

	bool isItalic() const {
		return (style & ITALIC) != 0;
	}

	HFONT getPeer() const;

private:
	String name;
    int style;
    int size;

	mutable HFONT peer;

	class NativeFontCache;
	static NativeFontCache cache;

	friend bool operator==(const Font&, const Font&);
};

inline bool operator==(const Font& f1, const Font& f2) {
	return f1.size == f2.size && f1.style == f2.style && 
			f1.name == f2.name;
}

inline bool operator!=(const Font& f1, const Font& f2) {
	  return !(f1 == f2);
}

}}

#endif
