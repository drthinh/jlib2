#ifndef JLIB_AWT_VALUABLECHANGEABLE
#define JLIB_AWT_VALUABLECHANGEABLE

namespace jlib { namespace awt {

class ChangeListener;

class ValueChangeable {
public:
	virtual ~ValueChangeable() {}
	virtual void addChangeListener(ChangeListener*) = 0;
	virtual void removeChangeListener(ChangeListener*) = 0;
};

}}

#endif
