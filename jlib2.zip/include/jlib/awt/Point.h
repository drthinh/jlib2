#ifndef JLIB_AWT_POINT
#define JLIB_AWT_POINT

namespace jlib { namespace awt { 

struct Point {
    int x;
    int y;

	Point()
		: x(0), y(0) {
    }

	Point(int x, int y)
		: x(x), y(y) {
    }

	Point getLocation() const {
		return *this;
	}

	void setLocation(const Point& p) {
		setLocation(p.x, p.y);
    }	

	void setLocation(int x, int y) {
		this->x = x;
		this->y = y;
    }	

	void translate(int dx, int dy) {
		this->x += dx;
		this->y += dy;
	}
};

}}

#endif
