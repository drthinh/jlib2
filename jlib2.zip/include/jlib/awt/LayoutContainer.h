#ifndef JLIB_AWT_LAYOUTCONTAINTER
#define JLIB_AWT_LAYOUTCONTAINTER

namespace jlib { namespace awt { 

class Insets;
class LayoutManager;

class LayoutContainer {
public:
	virtual int getComponentCount() const = 0;
	virtual LayoutComponent* getComponent(int index) const = 0;

	virtual const Insets& getInsets() const = 0;
	virtual Dimension getSize() const = 0;

	virtual void setLayout(LayoutManager* mgr) = 0;
	virtual LayoutManager* getLayout() const = 0;

	virtual void doLayout() = 0;

	virtual void setVisible(bool b) = 0;
	virtual bool isVisible() const = 0;

	virtual void invalidate() = 0;
	virtual void validate() = 0;
};

}}

#endif
