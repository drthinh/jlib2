

class FontCache {
public:
	~NativeFontCache() {
		FontCache::iterator i;
		for ( i = cache.begin(); i != cache.end(); ++i ) {
			::DeleteObject(i->second);
		}
	}

	HFONT get(const Font& font) {
		FontDescriptor desc(font);
		FontCache::iterator i = cache.find(desc);
		HFONT hf = NULL;
		if ( i == cache.end() ) {
			hf = createFont(font);
			cache.insert(FontCache::value_type(desc, hf));
		} else {
			hf = i->second;
		}

		assert ( hf !=NULL );

		return hf;
	}

private:

	HFONT createFont(const Font& font) {
		LOGFONT lf = {0};
		lf.lfHeight = font.getSize();
		lf.lfItalic = font.isItalic();
		lf.lfWeight = font.isBold() ? 700 : 400;
		_tcsncpy(lf.lfFaceName, 
				font.getName().data(), font.getName().length());

		return ::CreateFontIndirect(&lf);
	}

	struct FontDescriptor {
		FontDescriptor(const Font& f)
			: name(f.getName()), style(f.getStyle()), size(f.getSize()) {
			}

		String name;
		int style;
		int size;
		HFONT peer;
	};

	class CachedFont {
	public:
		CachedFont(FontDescriptor* desc)
			: name(, style, size), peer(NULL) {
		}

			String getName() {
				desc->getName();
			}

		FontDescriptor* desc;
	};

	struct FontComparator {
		bool operator()(const CachedFont& l, 
				const CachedFont& r) const {
			if ( l.size < r.size ) {
				return true;
			} else if ( l.size > r.size ) {
				return false;
			} else if ( l.style < r.style ) {
				return true;
			} else if ( l.style > r.style ) {
				return false;
			} else if ( l.name < r.name ) {
				return true;
			} 

			return false;
		}
	};

	typedef std::map<FontDescriptor, HFONT, FontComparator> FontCache;
	mutable FontCache cache;
};