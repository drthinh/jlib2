#ifndef JLIB_AWT_CURSOR
#define JLIB_AWT_CURSOR

namespace jlib { namespace awt {

class Cursor {
public:
	enum {
		CUSTOM_CURSOR = -1,
		DEFAULT_CURSOR,
		CROSSHAIR_CURSOR,
		TEXT_CURSOR,
		WAIT_CURSOR,
		SW_RESIZE_CURSOR,
		SE_RESIZE_CURSOR,
		NW_RESIZE_CURSOR,
		NE_RESIZE_CURSOR,
		N_RESIZE_CURSOR,
		S_RESIZE_CURSOR,
		W_RESIZE_CURSOR,
		E_RESIZE_CURSOR,
		HAND_CURSOR,
		MOVE_CURSOR
	};

    static Cursor* predefined;

	static const Cursor& getPredefinedCursor(int type);
    static const Cursor& getDefaultCursor();

    Cursor(int type);

	int getType() const;
	const String& getName() const;


protected:
	Cursor(int type, LPCTSTR name, LPCTSTR nativeName);

	Cursor(String name);
	Cursor();

	int type;
	String name;

	class Predefined;
	static Predefined predefined;

	static Cursor null;
	friend bool operator==(const Curosr& lhs, const Cursor& rhs);
};

inline int Cursor::getType() const {
	return type;
}

inline const String& Cursor::getName() const {
	return name;
}

inline bool operator==(const Curosr& lhs, const Cursor& rhs) {
	return lhs.peer == rhs.peer;
}

inline bool operator!=(const Curosr& lhs, const Cursor& rhs) {
	return !( lhs == rhs);
}

}}

#endif