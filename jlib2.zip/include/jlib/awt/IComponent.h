#ifndef JLIB_AWT_ICOMPONENT
#define JLIB_AWT_ICOMPONENT

namespace jlib { namespace awt {

using jlib::lang::String;

class IComponent {
public:
	virtual ~IComponent() {}

	virtual void setVisible(bool b) = 0;
	bool isVisible() const = 0;

	bool isShowing() const = 0;
	bool isDisplayable() const = 0;

	virtual void show() = 0;
	virtual void hide() = 0;

	virtual void setBounds(int x, int y, int width, int height) = 0;
	virtual const Rectangle& getBounds() const = 0;


	virtual Dimension getMinimumSize() const = 0;
	virtual Dimension getPreferredSize() const = 0;
	virtual Dimension getMaximumSize() const = 0;

	float getAlignmentX() const = 0;
	float getAlignmentY() const = 0;

	virtual void invalidate() = 0;
	virtual void validate() = 0;

protected:
	// uncopiable
	IComponent(const IComponent& other);
	IComponent& operator=(const IComponent& other);
};

}}

#endif
