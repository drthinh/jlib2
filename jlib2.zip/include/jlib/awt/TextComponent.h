#ifndef JLIB_AWT_TEXTCOMPONENT
#define JLIB_AWT_TEXTCOMPONENT

#include <jlib/awt/Component.h>

namespace jlib { namespace awt {

class TextListener;

class TextComponent : public Component {
public:
	void addNotify();
	void removeNotify();
	virtual void setText(const String&);

	const String& getText() const;
	String getSelectedText() const;

	bool isEditable() const;
	void setEditable(bool);

	int getSelectionStart() const;
	void setSelectionStart(int);

	int getSelectionEnd() const;
	void setSelectionEnd(int);
    
	void select(int selectionStart, int selectionEnd);
	void selectAll();

	void setCaretPosition(int);
	int getCaretPosition() const;

	void addTextListener(TextListener*);
	void removeTextListener(TextListener*);

protected:
	TextComponent(const String& text);

	bool editable;

	mutable int selectionStart;
	mutable int selectionEnd;

	typedef jlib::util::EventDispatcher<TextListener> TextEventDispatcher;
	TextEventDispatcher textEventDispatcher;

	const Color& getDefaultForeground() const;
	const Color& getDefaultBackground() const;

	// peer operations
	void peer_setText(const String&);
	String peer_getText() const;

	void peer_setEditable(bool);

	int peer_getSelectionStart() const;
	int peer_getSelectionEnd() const;
	void peer_select(int start, int end);

	int peer_getCaretPosition() const;
	void peer_setCaretPosition(int);

	// WIN32
	void handleCommand(UINT notifyCode);
	LPCTSTR getClassName() const;
};

inline bool TextComponent::isEditable() const {
	return editable;
}

}}

#endif
