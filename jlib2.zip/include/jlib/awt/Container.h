#ifndef JLIB_AWT_CONTAINTER
#define JLIB_AWT_CONTAINTER

#include <jlib/awt/Canvas.h>
#include <jlib/awt/LayoutContainer.h>
#include <jlib/awt/Insets.h>

#include <vector>

namespace jlib { namespace awt { 


class ContainerListener;
class LayoutManager;
class LayoutConstraint;

class Container : public Canvas, public LayoutContainer {
public:
	Container()
		: layoutMgr(NULL) {
	}

	void setVisible(bool);
	bool isVisible() const;

	void addNotify();
	void removeNotify();

	void setFont(const Font&);

	void add(Component* comp);
	void add(Component* comp, int index);
	void add(Component* comp, const LayoutConstraint& constraints);
	void add(Component* comp, 
		const LayoutConstraint& constraints, int index);

	void remove(Component* comp);
	void remove(int index);

	int getComponentCount() const;
	Component* getComponent(int index) const;

	Dimension getSize() const;

	Dimension getMinimumSize() const;
	Dimension getPreferredSize() const;
	Dimension getMaximumSize() const;
	const Insets& getInsets() const;

	void setLayout(LayoutManager*);
	LayoutManager* getLayout() const;

	void doLayout();

	void invalidate();
	void validate();

	bool isContainer() const;

	void addContainerListener(ContainerListener*);
	void removeContainerListener(ContainerListener*);

protected:
	virtual void addImpl(Component* comp, 
			const LayoutConstraint& constraints, int index);

	void validateTree();
	void invalidateTree();

	typedef std::vector<Component*> ChildrenList;
	ChildrenList children;

	Insets insets;
	LayoutManager* layoutMgr;

	typedef jlib::util::EventDispatcher<
			ContainerListener> ContainerEventDispatcher;
	ContainerEventDispatcher containerEventDispatcher;

	// peer operations

	// WIN32
	void wmCommand(WPARAM wParam, LPARAM lParam);
	LRESULT wmNotify(WPARAM wParam, LPARAM lParam);
	HBRUSH wmCtlColor(HDC dc, HWND hwnd);
	void wmScroll(WPARAM wParam, LPARAM lParam, bool vertical);

	LRESULT windowProc(UINT message, WPARAM wParam, LPARAM lParam);

	DWORD getWindowStyle() const;
	DWORD getWindowExStyle() const;
};

inline int Container::getComponentCount() const {
	return static_cast<int>(children.size());
}

inline Component* Container::getComponent(int index) const {
	return children[index];
}

inline Dimension Container::getSize() const {
	return Component::getSize();
}

inline bool Container::isVisible() const {
	return Component::isVisible();
}

inline LayoutManager* Container::getLayout() const {
	return layoutMgr;
}

inline bool Container::isContainer() const {
	return true;
}

}}

#endif
