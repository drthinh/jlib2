#ifndef JLIB_AWT_CHECKBOXMENUITEM
#define JLIB_AWT_CHECKBOXMENUITEM

#include <jlib/awt/MenuItem.h>
#include <jlib/awt/ItemSelectable.h>
#include <jlib/util/EventDispatcher.h>

namespace jlib { namespace awt {

class ItemListener;


class CheckboxMenuItem : public MenuItem, public ItemSelectable {
public:
	CheckboxMenuItem(const String& label = _T(""), bool state = false);

	void addNotify();

	bool getState() const;
	void setState(bool);

	void addItemListener(ItemListener*);
	void removeItemListener(ItemListener*);

private:
	typedef jlib::util::EventDispatcher<ItemListener>
			ItemEventDispatcher;
	ItemEventDispatcher itemEventDispatcher;

	bool state;

	// WIN32
	void doMenuEvent(int modifiers);

	class CheckBitmap {
	public:
		CheckBitmap();
		~CheckBitmap();
		HBITMAP getBitmap() const;
	private:
		mutable HBITMAP bitmap;
	};

	static CheckBitmap checkBitmap;

	// peer operations
	void peer_setState(bool b);
};

inline bool CheckboxMenuItem::getState() const {
	return state;
}

}}

#endif
