#ifndef JLIB_AWT_BOUNDEDRANGEMODEL
#define JLIB_AWT_BOUNDEDRANGEMODEL

#include <jlib/awt/ValueChangeable.h>

namespace jlib { namespace awt {

class ChangeListener;


class BoundedRangeModel : public ValueChangeable {
public:
	virtual int getMinimum() const = 0;
	virtual void setMinimum(int) = 0;

	virtual int getMaximum() const = 0;
	virtual void setMaximum(int) = 0;

	virtual int getValue() const = 0;
	virtual void setValue(int) = 0;

	virtual void setValueIsAdjusting(bool) = 0;
	virtual bool getValueIsAdjusting() const = 0;

	virtual int getExtent() const = 0;
	virtual void setExtent(int) = 0;

	virtual void setRangeProperties(int value, int extent, 
			int min, int max, bool adjusting) = 0;

	virtual void addChangeListener(ChangeListener*) = 0;
	virtual void removeChangeListener(ChangeListener*) = 0;
};

}}

#endif
