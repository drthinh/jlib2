#ifndef JLIB_AWT_EVENT_ACTIONEVENT
#define JLIB_AWT_EVENT_ACTIONEVENT

#include <jlib/util/EventObject.h>
#include <jlib/awt/Actable.h>
#include <jlib/lang/String.h>

namespace jlib { namespace awt {

using jlib::lang::String;

class ActionEvent : public jlib::util::EventObject<Actable> {
public:
	explicit ActionEvent(const String& command)
		: actionCommand(command), modifiers(0) {
	}

    ActionEvent(const String& command, int modifiers)
		: actionCommand(command), modifiers(modifiers) {
    }

    const String& getActionCommand() const {
		return actionCommand;
	}

	int getModifiers() const {
		return modifiers;
	}

private:
	String actionCommand;
	int modifiers;
};

}}

#endif
