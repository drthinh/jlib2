#ifndef JLIB_AWT_KEYBOARDFOCUSMANAGER
#define JLIB_AWT_KEYBOARDFOCUSMANAGER

#include <jlib/awt/KeyEventDispatcher.h>

namespace jlib { namespace awt {

class KeyboardFocusManager : public KeyEventDispatcher {
public:
	KeyboardFocusManager() {
	}

	static KeyboardFocusManager* getCurrentKeyboardFocusManager();

	void addKeyEventDispatcher(KeyEventDispatcher*);
	void removeKeyEventDispatcher(KeyEventDispatcher*);

	bool dispatchEvent(KeyEvent&);
	void processKeyEvent(Component* comp, KeyEvent& e);
};

}}

#endif
