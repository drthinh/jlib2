#ifndef JLIB_AWT_IMAGE
#define JLIB_AWT_IMAGE

namespace jlib { namespace awt {

namespace image {
	class ImageObserver;
};

class Image {
public:
    virtual int getWidth(
		jlib::awt::image::ImageObserver* observer) const = 0;
    virtual int getHeight(
		jlib::awt::image::ImageObserver* observer) const = 0;

	virtual ~Image() {}
};

}}

#endif
