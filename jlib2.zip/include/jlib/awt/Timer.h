#ifndef JLIB_AWT_TIMER
#define JLIB_AWT_TIMER

#include <jlib/awt/Actable.h>
#include <jlib/util/EventDispatcher.h>

namespace jlib { namespace awt {

class ActionListener;


class Timer : public Actable {
public:
	Timer(int millisecsDelay, ActionListener* listener);
	~Timer();

	void addActionListener(ActionListener*);
	void removeActionListener(ActionListener*);

	void setDelay(int millisecs);
	int getDelay() const;

	void start();
	void stop();
	bool isRunning() const;

private:
	int delay;
	bool running;

	typedef jlib::util::EventDispatcher<ActionListener> 
		ActionEventDispatcher; 
	ActionEventDispatcher dispatcher;

	// peer operations
	void peer_setDelay(int millisecs);
	void peer_stop();
	static void CALLBACK 
	timerProc(HWND hwnd, UINT message, UINT_PTR idEvent, DWORD dwTime);
};

inline int Timer::getDelay() const {
	return delay;
}

inline bool Timer::isRunning() const {
	return running;
}


}}

#endif
