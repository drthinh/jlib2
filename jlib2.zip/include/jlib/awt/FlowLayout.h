#ifndef JLIB_AWT_FLOWLAYOUT
#define JLIB_AWT_FLOWLAYOUT

#include <jlib/awt/LayoutManagerAdapter.h>

namespace jlib { namespace awt { 

class FlowLayout : public LayoutManagerAdapter {
public:
	enum Alignment {
		LEFT,
		CENTER,
		RIGHT,
		LEADING,
		TRAILING
	};

	explicit FlowLayout(Alignment align = CENTER, 
			int hgap = 5, int vgap = 5);

	Alignment getAlignment() const;
	void setAlignment(Alignment);

	int getHgap() const;
	void setHgap(int);

	int getVgap() const;
	void setVgap(int);

	Dimension preferredLayoutSize(const LayoutContainer* target);
	Dimension minimumLayoutSize(const LayoutContainer* target);

	void layoutContainer(LayoutContainer* target);

private:
	void moveComponents(LayoutContainer* target, 
		int x, int y, int width, int height, 
		int rowStart, int rowEnd, bool ltr);

	Alignment align;

	int hgap;
	int vgap;
};

inline FlowLayout::FlowLayout(Alignment align, int hgap, int vgap)
	: align(align), hgap(hgap), vgap(vgap) {
}

inline FlowLayout::Alignment FlowLayout::getAlignment() const {
	return align;
}

inline void FlowLayout::setAlignment(FlowLayout::Alignment align) {
	this->align = align;
}

inline int FlowLayout::getHgap() const {
	return hgap;
}

inline void FlowLayout::setHgap(int hgap) {
	this->hgap = hgap;
}

inline int FlowLayout::getVgap() const{
	return vgap;
}

inline void FlowLayout::setVgap(int vgap) {
	this->vgap = vgap;
}

}}

#endif
