#ifndef JLIB_AWT_SIZEREQUIREMENTS
#define JLIB_AWT_SIZEREQUIREMENTS

namespace jlib { namespace awt {

class SizeRequirements {
public:
    int minimum;
    int preferred;
    int maximum;
	float alignment;

    SizeRequirements() {
		minimum = 0;
		preferred = 0;
		maximum = 0;
		alignment = 0.5f;
    }

	SizeRequirements(int min, int pref, int max, float a) {
		minimum = min;
		preferred = pref;
		maximum = max;
		alignment = a > 1.0f ? 1.0f : a < 0.0f ? 0.0f : a;
    }

	static SizeRequirements getTiledSizeRequirements(
		const SizeRequirements* children, int len);

    static SizeRequirements getAlignedSizeRequirements(
		const SizeRequirements* children, int len);

	static void calculateTiledPositions(
			int allocated, const SizeRequirements& total,
			const SizeRequirements* children, int childrenLen,
			int* offsets, int* spans);

    static void calculateTiledPositions(int allocated,
			const SizeRequirements& total,
			const SizeRequirements* children, int childrenLen,
			int* offsets, int* spans, bool forward);

	static void calculateAlignedPositions(int allocated,
			const SizeRequirements& total,
			const SizeRequirements* children, int childrenLen,
			int* offsets, int* spans) ;

	static void calculateAlignedPositions(int allocated,
			const SizeRequirements& total,
			const SizeRequirements* children, int childrenLen,
			int* offsets, int* spans, bool normal);

private:
    static void compressedTile(int allocated, 
			long min, long pref, long max,
			const SizeRequirements* children, int childrenLen,
			int* offsets, int* spans, bool forward);

	static void expandedTile(int allocated, long min, long pref, long max,
		const SizeRequirements* children, int childrenLen,
		int* offsets, int* spans, bool forward);
}; 

}}

#endif
