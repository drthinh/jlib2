#ifndef JLIB_AWT_EVENT_COMPONENTLISTENER
#define JLIB_AWT_EVENT_COMPONENTLISTENER

#include <jlib/util/EventListener.h>

namespace jlib { namespace awt {

class ComponentEvent;

class ComponentListener : public jlib::util::EventListener {
public:
    virtual void componentResized(const ComponentEvent&) = 0;
    virtual void componentMoved(const ComponentEvent&) = 0;
    virtual void componentShown(const ComponentEvent&) = 0;
    virtual void componentHidden(const ComponentEvent&) = 0;
};

}}

#endif
