#ifndef JLIB_AWT_EVENT_FOCUSADAPTER
#define JLIB_AWT_EVENT_FOCUSADAPTER

#include <jlib/awt/FocusListener.h>

namespace jlib { namespace awt {

class FocusAdapter : public FocusListener {
public:
	void focusGained(const FocusEvent&) {}
	void focusLost(const FocusEvent&) {}
};

}}

#endif
