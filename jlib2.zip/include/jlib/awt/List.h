#ifndef JLIB_AWT_LIST
#define JLIB_AWT_LLST

#include <jlib/awt/Component.h>
#include <jlib/awt/Actable.h>
#include <jlib/awt/ItemSelectable.h>

#include <vector>

namespace jlib { namespace awt {

class ActionListener;
class ItemListener;


class List : public Component, public ItemSelectable, public Actable {
public:
	typedef std::vector<String> ItemsList;
	typedef std::vector<int> SelectedList;

    List(int rows = 0, bool multipleMode = false) 
		: rows(rows != 0 ? rows : DEFAULT_VISIBLE_ROWS), 
		multipleMode(multipleMode), visibleIndex(-1) {
    }

    void addNotify();
	void removeNotify();

	int getItemCount() const;

	String getItem(int index) const;

    const ItemsList& getItems() const;

    void add(const String& item);
	void add(const String& item, int index);

    void replaceItem(const String& newValue, int index);

    void removeAll();

	void remove(const String& item);
	void remove(int position);

	int getSelectedIndex() const;
    SelectedList getSelectedIndexes() const;

	String getSelectedItem() const;
    ItemsList getSelectedItems() const;

    void select(int index);

    void deselect(int index);
    bool isIndexSelected(int index) const;

	int getRows() const;

    bool isMultipleMode() const;
	void setMultipleMode(bool b);

	int getVisibleIndex() const;

    void makeVisible(int index);

    Dimension getPreferredSize(int rows) const;
    Dimension getPreferredSize() const;

    Dimension getMinimumSize(int rows) const;
	Dimension getMinimumSize() const;

	void addItemListener(ItemListener*);
    void removeItemListener(ItemListener*);

	void addActionListener(ActionListener*);
	void removeActionListener(ActionListener*);

protected:
	const Color& getDefaultForeground() const;
	const Color& getDefaultBackground() const;

private:
	typedef jlib::util::EventDispatcher<ItemListener>
		ItemEventDispatcher;
	ItemEventDispatcher itemEventDispatcher;

	typedef jlib::util::EventDispatcher<ActionListener>
		ActionEventDispatcher;
	ActionEventDispatcher actionEventDispatcher;

	enum { DEFAULT_VISIBLE_ROWS = 4 };

	int rows;
    bool multipleMode;
	int	visibleIndex;

	ItemsList items;
	SelectedList selected;

	void delItems(int start, int end);

	DWORD getWindowStyle() const;
	LPCTSTR getClassName() const;
	void handleCommand(UINT notifyCode);
};


inline int List::getItemCount() const {
	return static_cast<int>(items.size());
}

inline String List::getItem(int index) const {
	return items[index];
}

inline const List::ItemsList& List::getItems() const {
	return items;
}

inline int List::getRows() const {
	return rows;
}

inline bool List::isMultipleMode() const {
	return multipleMode;
}

}}

#endif
