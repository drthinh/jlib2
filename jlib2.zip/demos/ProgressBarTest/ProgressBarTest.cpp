#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tchar.h>

#include <jlib/jlib.h>

#include <jlib/lang/Thread.h>
#include <jlib/lang/ThreadingException.h>
#include <jlib/lang/StringStream.h>

#include <jlib/awt/Toolkit.h>

#include <jlib/awt/Frame.h>

#include <jlib/awt/Label.h>
#include <jlib/awt/Button.h>
#include <jlib/awt/Checkbox.h>
#include <jlib/awt/TextField.h>
#include <jlib/awt/TextArea.h>
#include <jlib/awt/ScrollBar.h>
#include <jlib/awt/Image.h>

#include <jlib/awt/ScrollPane.h>

#include <jlib/awt/BorderLayout.h>

#include <jlib/awt/Panel.h>

#include <jlib/awt/WindowAdapter.h>
#include <jlib/awt/WindowEvent.h>

#include <jlib/awt/ActionListener.h>
#include <jlib/awt/ActionEvent.h>

#include <jlib/awt/ItemListener.h>
#include <jlib/awt/ItemEvent.h>

#include <jlib/awt/AdjustmentListener.h>
#include <jlib/awt/AdjustmentEvent.h>

#include <jlib/awt/ChangeListener.h>
#include <jlib/awt/ChangeEvent.h>

#include <jlib/awt/ProgressBar.h>

#include <jlib/awt/EventQueue.h>

#include <jlib/awt/ToolTipManager.h>


using namespace jlib::awt;

//#ifndef NDEBUG
//#define _CRTDBG_MAP_ALLOC
//#include <stdlib.h>
//#include <crtdbg.h>
//#define DEBUG_NEW new (_NORMAL_BLOCK, __FILE__, __LINE__)
//#define new DEBUG_NEW
//#endif

class ProgressBarTest : public Frame, 
	WindowAdapter, ActionListener, ItemListener, ChangeListener,
	AdjustmentListener, Runnable {

	std::auto_ptr<Image> iconImage;

	// Progress Panel controls
	Label value;
	ProgressBar progressBar;
	ProgressBar bar2;

	Panel progressPanel;

	// Control Panel controls
	Checkbox vertical;
	Checkbox paintBorder;
	Checkbox paintString;
	//Checkbox verticalSplit;
	//Checkbox oneTouchExpandable;
	//Checkbox continuousLayout;
	Label valueLabel;
	class ValueScroll : public Scrollbar {
	public:
		ValueScroll()
			: Scrollbar(Scrollbar::HORIZONTAL, 0, 0, 0, 100) {
			}

		Dimension getPreferredSize() const {
			Dimension d = Scrollbar::getPreferredSize();
			d.width += getMaximum() - getMinimum();
			return d;
		}
	} valueScroll;
	TextField valueText;

	Button startThread;
	bool stopping;
	Panel controlPanel;

	void valueChanged(Component* source, int v) {
		progressBar.setValue(v);

		OStringStream oss;
		oss << v;

		value.setText(oss.str());

		if ( source != &valueText ) {
			valueText.setText(oss.str());
		}

		if ( source != &valueScroll ) {
			valueScroll.setValue(v);
		}
	}

	void actionPerformed(const ActionEvent& e) {
		if (e.getSource() == &valueText) {
			String s = valueText.getText();
			int v = _ttoi(s.c_str());
			valueChanged(&valueText, v);
		} else if (e.getSource() == &startThread) {
			if (startThread.getLabel() == _T("Start")) {
				stopping = false;
				Thread t(this);
				t.start();
			} else {
				stopping = true;
			}
		}
	}

	void itemStateChanged(const ItemEvent& e) {
		if ( e.getSource() == &vertical ) {
			if ( e.getStateChange() == ItemEvent::SELECTED ) {
				progressBar.setOrientation(ProgressBar::VERTICAL);
			} else {
				progressBar.setOrientation(ProgressBar::HORIZONTAL);
			}
			validate();
		} else if ( e.getSource() == &paintBorder ) {
			progressBar.setBorderPainted(
                e.getStateChange() == ItemEvent::SELECTED);
			validate();
		} else if ( e.getSource() == &paintString ) {
			progressBar.setStringPainted(
				e.getStateChange() == ItemEvent::SELECTED);
			validate();
		}
	}

	void stateChanged(const ChangeEvent& e) {
		if ( e.getSource() == &progressBar ) {
			int v = progressBar.getValue(); 
			OStringStream oss;
			oss << v;
			value.setText(oss.str());
			v = progressBar.getMaximum() - v;
			bar2.setValue(v);
			OStringStream oss2;
			oss2 << _T("Percentage : ") << v;
			bar2.setString(oss2.str());
		}
	}

	void adjustmentValueChanged(const AdjustmentEvent& e) {
		if ( e.getSource() == &valueScroll ) {
			valueChanged(&valueScroll, e.getValue());
		}
	}

	struct LabelMutator : public Runnable {
		void run() {
			button->setLabel(label);
		}
		Button* button;
		String label;
	};

	struct ValueChanger : public Runnable {
		ValueChanger(ProgressBar* bar)
			: bar(bar), maxWasReached(false) {
		}

		bool isMaxReached() const {
			return maxWasReached;
		}

		void run() {
			if ( bar->getValue() == bar->getMaximum() ) {
				maxWasReached = true;
			} else {
				bar->setValue(bar->getValue() + 1);
				bar->setToolTipText(bar->getString());
			}
		}

		ProgressBar* bar;
		bool maxWasReached;
	};


	void run() {
		LabelMutator labelMutator;
		ValueChanger valueChanger(&progressBar);

		labelMutator.button = &startThread;

		labelMutator.label = _T("Stop");

		EventQueue::invokeAndWait(&labelMutator);

		while ( !stopping ) {
			try {
				Thread::sleep(500);
			} catch ( InterruptedException& ) {
				break;
			}

			EventQueue::invokeAndWait(&valueChanger);

			if ( valueChanger.maxWasReached ) {
				break;
			}
		}

		labelMutator.label = _T("Start");

		EventQueue::invokeAndWait(&labelMutator);
	}

	ProgressBarTest() 
		: Frame(_T("ProgressBarTest")) {

		setupProgressPanel();
		add(&progressPanel);

		setupControlPanel();
		add(&controlPanel, BorderLayout::SOUTH);

		progressBar.setValue(50);
		//progressBar.setString(_T("This is a test"));
		progressBar.setStringPainted(true);

		progressBar.setFont(
			Font(_T("MS Sans Serif"), Font::PLAIN, 40));

		addWindowListener(this);

		iconImage = Toolkit::getDefaultToolkit()->createImage(
			_T("plane.ico"));
		setIconImage(iconImage.get());
	}

	void setupProgressPanel() {
		progressBar.addChangeListener(this);
		//ToolTipManager::getSharedInstance().registerComponent(&progressBar);
		progressBar.setToolTipText(_T("Test ProgressBar\nLine2"));
		progressPanel.add(&progressBar);
		
		value.setText(_T("50"));
		progressPanel.add(&value);

		bar2.setToolTipText(_T("Another ProgressBar"));
		bar2.setForeground(Color(0, 192, 0));
		bar2.setMaximum(progressBar.getMaximum());
		bar2.setMinimum(progressBar.getMinimum());
		bar2.setValue(progressBar.getMaximum() - progressBar.getValue());
		bar2.setStringPainted(true);
		progressPanel.add(&bar2);
	}

	void setupControlPanel() {
		vertical.setLabel(_T("vertical"));
		vertical.setState(false);
		vertical.addItemListener(this);
		controlPanel.add(&vertical);

		paintBorder.setLabel(_T("paint border"));
		paintBorder.setState(true);
		paintBorder.addItemListener(this);
		controlPanel.add(&paintBorder);

		paintString.setLabel(_T("paint string"));
		paintString.setState(true);
		paintString.addItemListener(this);
		controlPanel.add(&paintString);

		valueLabel.setText(_T("Value"));
		controlPanel.add(&valueLabel);

		valueScroll.setOrientation(Scrollbar::HORIZONTAL);
		valueScroll.setMaximum(progressBar.getMaximum()+1);
		valueScroll.setMinimum(progressBar.getMinimum());
		valueScroll.setValue(progressBar.getValue());
		valueScroll.addAdjustmentListener(this);
		controlPanel.add(&valueScroll);

		stopping = false;
		startThread.setLabel(_T("Start"));
		startThread.addActionListener(this);
		controlPanel.add(&startThread);

		valueText.setText(_T("50"));
		valueText.addActionListener(this);
		controlPanel.add(&valueText);
	}

	void windowClosing(const WindowEvent&) {
		// FIXME : Stop the thread
		dispose();
	}

public:
	static void main(const ArgumentList&) {
		//ToolTipManager::getSharedInstance().setInitialDelay(0);
		ToolTipManager::getSharedInstance().setDismissDelay(1000);
		//ToolTipManager::getSharedInstance().setReshowDelay(1000);
		ProgressBarTest test;
		//test.setUndecorated(true);
		test.setBounds(0, 0, 800, 480);
		test.show();
	}
};

MAIN_CLASS(ProgressBarTest)
