#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <jlib/jlib.h>

#include <jlib/lang/StringStream.h>
#include <jlib/awt/Frame.h>

#include <jlib/awt/Label.h>
#include <jlib/awt/Button.h>
#include <jlib/awt/Checkbox.h>

#include <jlib/awt/ScrollPane.h>

#include <jlib/awt/BorderLayout.h>
#include <jlib/awt/BoxLayout.h>
#include <jlib/awt/GridLayout.h>

#include <jlib/awt/Panel.h>

#include <jlib/awt/WindowAdapter.h>
#include <jlib/awt/WindowEvent.h>
#include <jlib/awt/ActionListener.h>
#include <jlib/awt/ActionEvent.h>

using namespace jlib::awt;


class ScrollPaneTest : public Frame, 
		public WindowAdapter, public ActionListener {

	typedef std::vector<Label*> LabelList;
	LabelList labels;
	Panel p;
	BoxLayout boxLayout;
	BorderLayout borderLayout;
	ScrollPane sp;
	Panel p2;
	GridLayout gl;

	static const int ROW_COUNT = 30;
	static const int COLUMN_COUNT = 2;
	Checkbox checkBoxes[COLUMN_COUNT * ROW_COUNT];
	Button button;

	ScrollPaneTest() 
		: Frame("ScrollPaneTest"), 
		boxLayout(&p, BoxLayout::Y_AXIS), 
		sp(ScrollPane::SCROLLBARS_ALWAYS),
		gl(ROW_COUNT, COLUMN_COUNT),
		button("Button") {
		p.setLayout(&gl);
		for(int i=0; i<COLUMN_COUNT * ROW_COUNT; ++i) {
			OStringStream oss;
			oss << "ScrollPane Test, button " << i;
			Checkbox* l = &checkBoxes[i];
			l->setLabel(oss.str());
			l->setBounds(10, 20*i, 200, 20);
			p.add(l);
		}

		//p.add(&button);

		p2.setLayout(&borderLayout);
		p2.add(&p);

		sp.add(&p2);
		add(&sp);

		addWindowListener(this);
	}

	void windowClosing(const WindowEvent&) {
		dispose();
	}

	void actionPerformed(const ActionEvent&) {
	}

public:
	static void main(const ArgumentList&) {
		ScrollPaneTest test;
		test.setBounds(0, 0, 320, 240);
		test.show();
	}
};

MAIN_CLASS(ScrollPaneTest)
