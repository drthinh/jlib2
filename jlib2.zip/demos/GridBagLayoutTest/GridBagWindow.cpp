#include <windows.h>

#include <jlib/jlib.h>
#include <jlib/awt/Frame.h>
#include <jlib/awt/Panel.h>
#include <jlib/awt/Button.h>
#include <jlib/awt/GridBagLayout.h>
#include <jlib/awt/WindowAdapter.h>
#include <jlib/awt/WindowEvent.h>

using namespace jlib::awt;

class GridBagWindow : public Panel, WindowAdapter {
	static const bool shouldFill = true;
	static const bool shouldWeightX = true;
	GridBagLayout gridbag;
	Button button1, button2, button3, button4, button5;

public:
	GridBagWindow() {
		GridBagConstraints c;
		setLayout(&gridbag);

		if (shouldFill) {
			//natural height, maximum width
			c.fill = GridBagConstraints::HORIZONTAL; 
		}

		button1.setLabel("Button 1");
		if (shouldWeightX) {
			c.weightx = 0.5;
		}
		c.gridx = 0;
		c.gridy = 0;
		gridbag.setConstraints(&button1, c);
		add(&button1);

		button2.setLabel("2");
		c.gridx = 1;
		c.gridy = 0;
		gridbag.setConstraints(&button2, c);
		add(&button2);

		button3.setLabel("Button 3");
		c.gridx = 2;
		c.gridy = 0;
		gridbag.setConstraints(&button3, c);
		add(&button3);

		button4.setLabel("Long-Named Button 4");
		c.ipady = 40;      //make this component tall
		c.weightx = 0.0;
		c.weighty = 1.0;
		c.fill = GridBagConstraints::BOTH;
		c.gridwidth = 3;
		c.gridx = 0;
		c.gridy = 1;
		gridbag.setConstraints(&button4, c);
		c.fill = GridBagConstraints::NONE;
		c.weighty = 0.0;
		c.weightx = 0.0;
		add(&button4);

		button5.setLabel("Button 5");
		c.ipady = 0;       //reset to default
		//c.weighty = 1.0;   //request any extra vertical space
		c.anchor = GridBagConstraints::SOUTH; //bottom of space
		c.insets = Insets(10,0,0,0);  //top padding
		c.gridx = 1;       //aligned with button 2
		c.gridwidth = 2;   //2 columns wide
		c.gridy = 2;       //third row
		gridbag.setConstraints(&button5, c);
		add(&button5);
	}
};

class TestFrame : public Frame, WindowAdapter {
	GridBagWindow gbw;
	TestFrame() 
		: Frame("GridBagLayout") {
		add(&gbw);
		addWindowListener(this);
	}

	void windowClosing(const WindowEvent& e) {
		dispose();
	}

public:

	static void main(const ArgumentList&) {
		TestFrame t;
		t.pack();
		t.show();
	}
};

MAIN_CLASS(TestFrame)
