/*
 * Copyright (c) 2002 Sun Microsystems, Inc. All  Rights Reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * -Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 * 
 * -Redistribution in binary form must reproduct the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the distribution.
 * 
 * Neither the name of Sun Microsystems, Inc. or the names of contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 * 
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
 * ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN AND ITS LICENSORS SHALL NOT
 * BE LIABLE FOR ANY DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT
 * OF OR RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THE SOFTWARE OR ITS
 * DERIVATIVES. IN NO EVENT WILL SUN OR ITS LICENSORS BE LIABLE FOR ANY LOST
 * REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL,
 * INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY
 * OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE, EVEN
 * IF SUN HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * You acknowledge that Software is not designed, licensed or intended for
 * use in the design, construction, operation or maintenance of any nuclear
 * facility.
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <vector>

#include <jlib/jlib.h>
#include <jlib/awt/Panel.h>
#include <jlib/awt/MouseListener.h>
#include <jlib/awt/MouseMotionListener.h>
#include <jlib/awt/MouseEvent.h>
#include <jlib/awt/Graphics.h>


using namespace jlib::awt;


class DrawPanel : public Panel, MouseListener, MouseMotionListener {
public:
	enum Mode { LINES, POINTS };

	DrawPanel() : mode(LINES), x1(0), y1(0), x2(0), y2(0) {
		setBackground(Color::WHITE);
		addMouseMotionListener(this);
		addMouseListener(this);
	}

	void setDrawMode(Mode m) {
		mode = m;
	}

private:
	Mode mode;

	typedef std::vector<Rectangle> Lines;
	typedef std::vector<Color> Colors;

	Lines lines;
	Colors colors;
	int x1, y1;
	int x2, y2;

	void mouseDragged(MouseEvent& e) {
		e.consume();
		switch (mode) {
			case LINES:
				x2 = e.getX();
				y2 = e.getY();
				break;
			case POINTS:
				colors.push_back(getForeground());
				lines.push_back(Rectangle(x1, y1, e.getX(), e.getY()));
				x1 = e.getX();
				y1 = e.getY();
				break;
		}

		repaint();
	}

	void mouseMoved(MouseEvent&) {}

	void mousePressed(MouseEvent& e) {
		e.consume();
		switch (mode) {
		case LINES:
			x1 = e.getX();
			y1 = e.getY();
			x2 = -1;
			break;
		case POINTS:
			colors.push_back(getForeground());
			lines.push_back(Rectangle(e.getX(), e.getY(), -1, -1));
			x1 = e.getX();
			y1 = e.getY();
			repaint();
			break;
		}
	}

	void mouseReleased(MouseEvent& e) {
		e.consume();
		switch (mode) {
			case LINES:
				colors.push_back(getForeground());
				lines.push_back(Rectangle(x1, y1, e.getX(), e.getY()));
				x2 = -1;
				break;
			case POINTS:
				break;
		}

		repaint();
	}

	void mouseEntered(MouseEvent&) {}
	void mouseExited(MouseEvent&) {}
	void mouseClicked(MouseEvent&) {}

	void paint(Graphics& g) {
		size_t np = lines.size();

		// draw the current lines
		g.setColor(getForeground());
		for ( size_t i=0; i < np; ++i ) {
			
			g.setColor(colors[i]);
			const Rectangle& p = lines[i];
			if ( p.width != -1 ) {
				g.drawLine(p.x, p.y, p.width, p.height);
			} else {
				g.drawLine(p.x, p.y, p.x, p.y);
			}
		}

		if ( mode == LINES ) {
			g.setColor(getForeground());
			if ( x2 != -1 ) {
				g.drawLine(x1, y1, x2, y2);
			}
		}
	}

	Dimension getPreferredSize() const {
		return Dimension(300, 300);
	}
};

#include <jlib/awt/Canvas.h>
#include <jlib/awt/Checkbox.h>
#include <jlib/awt/CheckboxGroup.h>
#include <jlib/awt/Choice.h>
#include <jlib/awt/ItemListener.h>
#include <jlib/awt/ItemEvent.h>
#include <jlib/awt/BorderLayout.h>


class DrawControls : public Panel, ItemListener {
    DrawPanel* target;
	CheckboxGroup group;
	Checkbox colors[6];
	Choice shapes;
public:
	DrawControls(DrawPanel* target) : target(target) {

		setBackground(Color::LIGHTGRAY);
		target->setForeground(Color::RED);
		Color c[6] = {Color::RED, Color::GREEN, Color::BLUE, 
			Color::PINK, Color::ORANGE, Color::BLACK};

		for ( int i=0; i<6; ++i ) {
			colors[i].setCheckboxGroup(&group);
			colors[i].addItemListener(this);
			colors[i].setForeground(c[i]);
			add(&colors[i]);
		}

		target->setForeground(Color::BLACK);

		shapes.addItemListener(this);
		shapes.addItem("Lines");
		shapes.addItem("Points");
		shapes.setBackground(Color::LIGHTGRAY);
		add(&shapes);
    }

    void paint(Graphics& g) {
		g.setColor(Color::LIGHTGRAY);
		const Rectangle& r = getBounds();
		
		g.draw3DRect(0, 0, r.width, r.height, false);

		int n = getComponentCount();
		for ( int i=0; i<n; ++i ) {
			Component* comp = getComponent(i);
			if ( comp != &shapes ) {
				const Point& loc = comp->getLocation();
				const Dimension& d = comp->getSize();
				g.setColor(comp->getForeground());
				g.drawRect(loc.x-1, loc.y-1, d.width+2, d.height+2);
			}
		}
	}

	void itemStateChanged(const ItemEvent& e) {
		if ( e.getSource() != &shapes) {
			target->setForeground(
				static_cast<Checkbox*>(e.getSource())->getForeground());
		} else {
			String choice = e.getItem();
			if ( choice == _T("Lines") ) {
				target->setDrawMode(DrawPanel::LINES);
			} else if ( choice == _T("Points") ) {
				target->setDrawMode(DrawPanel::POINTS);
			}
		}
	}
};

class DrawTest : public Panel {
    DrawPanel panel;
    DrawControls controls;
	BorderLayout borderLayout;

public:
	DrawTest() : controls(&panel) {
		setLayout(&borderLayout);
		add(&panel);
		add(&controls, BorderLayout::SOUTH);
    }
};

#include <jlib/awt/Frame.h>
#include <jlib/awt/WindowAdapter.h>

class TestFrame : public Frame, WindowAdapter {
	TestFrame() : Frame(_T("DrawTest")) {
		addWindowListener(this);
	}

	void windowClosing(const WindowEvent&) {
		dispose();
	}

public:
    static void main(const ArgumentList&) {
		DrawTest drawTest;

		TestFrame f;
		
		f.add(&drawTest);
		f.pack();
		f.show();
    }
};

MAIN_CLASS(TestFrame)
