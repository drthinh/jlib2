#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tchar.h>

#include <jlib/jlib.h>

#include <jlib/lang/StringStream.h>

#include <jlib/awt/Frame.h>
#include <jlib/awt/Dialog.h>

#include <jlib/awt/Menu.h>
#include <jlib/awt/MenuBar.h>
#include <jlib/awt/MenuItem.h>
#include <jlib/awt/MenuShortcut.h>
#include <jlib/awt/CheckboxMenuItem.h>

#include <jlib/awt/Slider.h>

#include <jlib/awt/Label.h>
#include <jlib/awt/Button.h>
#include <jlib/awt/TextField.h>
#include <jlib/awt/TextArea.h>
#include <jlib/awt/Table.h>

#include <jlib/awt/Scrollbar.h>

#include <jlib/awt/BorderLayout.h>

#include <jlib/awt/Panel.h>

#include <jlib/awt/WindowAdapter.h>
#include <jlib/awt/WindowEvent.h>
#include <jlib/awt/ActionListener.h>
#include <jlib/awt/ActionEvent.h>

#include <jlib/awt/ComponentAdapter.h>
#include <jlib/awt/ComponentEvent.h>

#include <jlib/awt/FileDialog.h>
#include <jlib/io/FilenameFilter.h>

using namespace jlib::awt;
using namespace jlib::io;

class TestDialog : public Dialog, 
	WindowAdapter, ComponentAdapter, ActionListener {
	TextField bounds;
	Scrollbar sb;
	Label l3;
	Panel okCancel;
	Button setResize;
	Button ok, cancel;

	void windowClosing(const WindowEvent&) {
		dispose();
	}

	String RectangleToString(const Rectangle& r) {
		OStringStream oss;
		oss << _T("[x=") << r.x 
			<< _T(", y=") << r.y
			<< _T(", width=") << r.width
			<< _T(", heigth=") << r.height << ']';
		return oss.str();
	}

	void componentMoved(const ComponentEvent&) {
		bounds.setText(RectangleToString(getBounds()));
	}

	void componentResized(const ComponentEvent&) {
		bounds.setText(RectangleToString(getBounds()));
	}

	void actionPerformed(const ActionEvent& e) {
		if ( e.getSource() == &setResize ) {
			if ( isResizable() ) {
				setResize.setLabel(_T("Set resizable"));
				setResizable(false);
			} else {
				setResize.setLabel(_T("Stop resizable"));
				setResizable(true);
			}
			validate();
		} else {
			dispose();
		}
	}

public:
	TestDialog(Frame* owner) 
		: Dialog(owner, _T("TestDialog"), true),
			l3(_T("Label3")), 
			ok(_T("OK")), cancel(_T("Cancel")){

				setBackground(Color::BLUE);
		//bounds.setAlignment(Label::CENTER);
		add(&bounds, BorderLayout::NORTH);
		add(&sb, BorderLayout::WEST);
		add(&l3, BorderLayout::EAST);

		setResize.setLabel(_T("Set resizable"));
		add(&setResize);
		setResize.addActionListener(this);

		okCancel.add(&ok);
		ok.addActionListener(this);
		okCancel.add(&cancel);
		cancel.addActionListener(this);
		add(&okCancel, BorderLayout::SOUTH);
		addWindowListener(this);
		addComponentListener(this);
	}
};

class DialogTest : public Frame, public FilenameFilter,
	public WindowAdapter, public ActionListener {

	Label label;

	MenuBar menuBar;
	Menu fileMenu;
	MenuItem openFile;
	MenuItem saveFile;
	MenuItem showDialog;
	Slider slider;

	TextArea textArea;
	Table table;

	DialogTest() 
		: Frame(_T("DialogTest")), label(_T("DialogTest"), Label::CENTER),
		fileMenu(_T("&File")), 
		openFile(_T("&Open")),
		saveFile(_T("&Save")),
		showDialog(_T("show dialog")) {

		showDialog.setShortcut(MenuShortcut(_T('D')));
		menuBar.add(&fileMenu);

		openFile.addActionListener(this);
		fileMenu.add(&openFile);
		saveFile.addActionListener(this);
		fileMenu.add(&saveFile);
		fileMenu.addSeparator();
		fileMenu.add(&showDialog);
		showDialog.addActionListener(this);
		
		setMenuBar(&menuBar);

		//add(&label);
		//add(&textArea);
		add(&table);

		slider.setPaintTicks(true);
		slider.setMinorTickSpacing(10);
		//slider.setExtent(20);
		add(&slider, BorderLayout::NORTH);

		addWindowListener(this);
	}

	bool accept(const String& path) {
		OutputDebugString(path.c_str());
		OutputDebugString(_T("\n"));
		return false;
	}

	void windowClosing(const WindowEvent&) {
		dispose();
	}

	void actionPerformed(const ActionEvent& e) {
		if ( e.getSource() == &openFile ) {
			FileDialog fd(this, _T("Open..."));
			fd.setDirectory(_T("fasfdfd"));
			fd.setFilenameFilter(this);
			fd.show();
			setTitle(fd.getFile() + _T(" ----- ") + fd.getDirectory());
		} else if ( e.getSource() == &saveFile ) {
			FileDialog fd(this, _T("Save As ..."), FileDialog::SAVE);
			fd.setDirectory(_T("src"));
			fd.show();
			setTitle(fd.getFile() + _T(" ----- ") + fd.getDirectory());
		} else if ( e.getSource() == &showDialog ) {
			TestDialog td(this);
			td.setBounds(10, 10, 320, 240);
			td.show();
		}
	}

public:
	static void main(const ArgumentList&) {
		DialogTest test;
		test.setForeground(Color::GREEN);
		test.setBackground(Color::BLACK);
		test.setBounds(0, 0, 320, 240);
		test.show();
	}
};

MAIN_CLASS(DialogTest)
