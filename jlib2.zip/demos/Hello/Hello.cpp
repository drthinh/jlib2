#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <jlib/jlib.h>
#include <jlib/awt/Frame.h>
#include <jlib/awt/Label.h>
#include <jlib/awt/WindowAdapter.h>
#include <jlib/awt/WindowEvent.h>

using namespace jlib::awt;

class Hello : public Frame, WindowAdapter {
	Label hello;

	Hello()
		: Frame(_T("Hello")), hello(_T("Hello, world!"), Label::CENTER) {
		add(&hello);

		addWindowListener(this);
	}

	void windowClosing(const WindowEvent&) {
		dispose();
	}

public:
	static void main(const ArgumentList&) {
		Hello hello;
		hello.pack();
		hello.show();
	}
};

MAIN_CLASS(Hello)
