/*
 * Copyright (c) 2002 Sun Microsystems, Inc. All  Rights Reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * -Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 * 
 * -Redistribution in binary form must reproduct the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the distribution.
 * 
 * Neither the name of Sun Microsystems, Inc. or the names of contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 * 
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
 * ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN AND ITS LICENSORS SHALL NOT
 * BE LIABLE FOR ANY DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT
 * OF OR RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THE SOFTWARE OR ITS
 * DERIVATIVES. IN NO EVENT WILL SUN OR ITS LICENSORS BE LIABLE FOR ANY LOST
 * REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL,
 * INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY
 * OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE, EVEN
 * IF SUN HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * You acknowledge that Software is not designed, licensed or intended for
 * use in the design, construction, operation or maintenance of any nuclear
 * facility.
 */ 
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tchar.h>
#include <cmath>
#include <ctime>

#include <jlib/jlib.h>

#include <jlib/lang/Thread.h>
#include <jlib/lang/ThreadingException.h>

#include <jlib/awt/Frame.h>
#include <jlib/awt/Panel.h>

#include <jlib/awt/EventQueue.h>

#include <jlib/awt/MouseEvent.h>
#include <jlib/awt/MouseAdapter.h>
#include <jlib/awt/WindowEvent.h>
#include <jlib/awt/WindowAdapter.h>

#include <jlib/awt/Graphics.h>

using namespace jlib::awt;

class Clock : public Canvas, Runnable {
	Thread timer;       // The thread that displays clock
	int lastxs, lastys, lastxm,
		lastym, lastxh, lastyh;  // Dimensions used to draw hands 
	String lastdate;             // String to hold date displayed
	Font clockFaceFont;          // Font for number display on clock
	Color handColor;             // Color of main hands and dial
	Color numberColor;           // Color of second hand and numbers
	int xcenter, ycenter; // Center position

	bool stopping;

	struct Repainter : public Runnable {
		Repainter(Clock* nt) : nt(nt) {
		}

		void run() {
			nt->repaint();
		}

		Clock* nt;
	} repainter;

public:
	Clock() 
		: timer(this), 
		clockFaceFont(_T("Times New Roman"), Font::PLAIN, 18), 
			xcenter(80), ycenter(55), repainter(this) {

		lastxs = lastys = lastxm = lastym = lastxh = lastyh = 0;

		handColor = Color::BLUE;
		numberColor = Color::DARKGRAY;

		setBackground(Color::WHITE);

		handColor = Color::BLUE;
		numberColor = Color::BLACK;

		setSize(300,300);              // Set clock window size

		stopping = false;
		timer.start();
	}

	~Clock() {
		stop();
	}

private:
	// Paint is the main part of the program
	void update(Graphics& g) {
		int xh, yh, xm, ym, xs, ys;
		int s = 0, m = 10, h = 10;

		struct tm *newtime;
		time_t t;
		time(&t);
		newtime = localtime(&t);
		s = newtime->tm_sec;
		m = newtime->tm_min;
		h = newtime->tm_hour;

		// Set position of the ends of the hands
		const float PI = 3.1415926f;
		xs = (int) (std::cos(s * PI / 30 - PI / 2) * 45 + xcenter);
		ys = (int) (std::sin(s * PI / 30 - PI / 2) * 45 + ycenter);
		xm = (int) (std::cos(m * PI / 30 - PI / 2) * 40 + xcenter);
		ym = (int) (std::sin(m * PI / 30 - PI / 2) * 40 + ycenter);
		xh = (int) (std::cos((h*30 + m / 2) * PI / 180 - PI / 2) * 30
			+ xcenter);
		yh = (int) (std::sin((h*30 + m / 2) * PI / 180 - PI / 2) * 30
			+ ycenter);

		// Get the date to print at the bottom
		TCHAR* buffer = _tasctime(newtime);
		String today(buffer, _tcslen(buffer) - 1);

		g.setFont(clockFaceFont);
		// Erase if necessary
		g.setColor(getBackground());
		if (xs != lastxs || ys != lastys) {
			g.drawLine(xcenter, ycenter, lastxs, lastys);
			g.drawString(lastdate, 5, 125);
		}
		if (xm != lastxm || ym != lastym) {
			g.drawLine(xcenter, ycenter-1, lastxm, lastym);
			g.drawLine(xcenter-1, ycenter, lastxm, lastym); 
		}
		if (xh != lastxh || yh != lastyh) {
			g.drawLine(xcenter, ycenter-1, lastxh, lastyh);
			g.drawLine(xcenter-1, ycenter, lastxh, lastyh); 
		}

		// Draw date and hands
		g.setColor(numberColor);
		g.drawString(today, 5, 125);    
		g.drawLine(xcenter, ycenter, xs, ys);
		g.setColor(handColor);
		g.drawLine(xcenter, ycenter-1, xm, ym);
		g.drawLine(xcenter-1, ycenter, xm, ym);
		g.drawLine(xcenter, ycenter-1, xh, yh);
		g.drawLine(xcenter-1, ycenter, xh, yh);
		lastxs = xs; lastys = ys;
		lastxm = xm; lastym = ym;
		lastxh = xh; lastyh = yh;
		lastdate = today;
	}

	void paint(Graphics& g) {
		g.setFont(clockFaceFont);
		// Draw the circle and numbers
		g.setColor(handColor);
		g.drawArc(xcenter-50, ycenter-50, 100, 100, 0, 360);
		g.setColor(numberColor);
		g.drawString(_T("9"), xcenter-45, ycenter+3); 
		g.drawString(_T("3"), xcenter+40, ycenter+3);
		g.drawString(_T("12"), xcenter-5, ycenter-37);
		g.drawString(_T("6"), xcenter-3, ycenter+45);

		// Draw date and hands
		g.setColor(numberColor);
		g.drawString(lastdate, 5, 125);    
		g.drawLine(xcenter, ycenter, lastxs, lastys);
		g.setColor(handColor);
		g.drawLine(xcenter, ycenter-1, lastxm, lastym);
		g.drawLine(xcenter-1, ycenter, lastxm, lastym);
		g.drawLine(xcenter, ycenter-1, lastxh, lastyh);
		g.drawLine(xcenter-1, ycenter, lastxh, lastyh); 
	}

	void stop() {
		stopping = true;
		timer.interrupt();
		timer.join();
	}

	void run() {
		while ( !stopping ) {
			try {
				Thread::sleep(500);
				EventQueue::invokeLater(&repainter);
			} catch (const InterruptedException&) {
			}
		}
	}

	String getAppletInfo() const {
		return _T("Title: A Clock \n")
			 _T("Author: Rachel Gollub, 1995 \n")
			 _T("An analog clock.");
	}
};

class TestFrame : public Frame, WindowAdapter {
	TestFrame() : Frame(_T("Blink")) {
		addWindowListener(this);
	}

	void windowClosing(const WindowEvent&) {
		dispose();
	}

public:
	static void main(const ArgumentList&) {
		TestFrame f;
		Clock clock;
		f.add(&clock);
		f.setSize(306, 322);
		f.show();
	}
};

MAIN_CLASS(TestFrame)
