#include <windows.h>
#include <jlib/jlib.h>

#include <jlib/awt/TabbedPane.h>
#include <jlib/awt/ImageIcon.h>
#include <jlib/awt/Frame.h>
#include <jlib/awt/Button.h>
#include <jlib/awt/List.h>
#include <jlib/awt/TextArea.h>
#include <jlib/awt/BorderLayout.h>

#include <jlib/awt/WindowAdapter.h>
#include <jlib/awt/WindowEvent.h>

#include <jlib/awt/Label.h>
#include <jlib/awt/CheckboxGroup.h>
#include <jlib/awt/Checkbox.h>
#include <jlib/awt/TextField.h>
#include <jlib/awt/TextListener.h>
#include <jlib/awt/ItemEvent.h>
#include <jlib/awt/ItemListener.h>

#include <jlib/awt/DefaultSingleSelectionModel.h>

using namespace jlib::awt;

class TestModel : public DefaultSingleSelectionModel {
public:
	TestModel() : DefaultSingleSelectionModel(0) { }
};


class ControlPanel : public Panel, public ItemListener, ActionListener {
	Label l;
	CheckboxGroup group;
	Checkbox top;
	Checkbox left;
	Checkbox bottom;
	Checkbox right;

	Label l2;
	TextField title;

	TestModel model;
	Checkbox useModel;

	TabbedPane* pane;

public:
	ControlPanel(TabbedPane* pane)
		: l(_T("Tab Placement")), 
		top(_T("top"), true, &group), 
		left(_T("left"), false, &group),
		bottom(_T("bottom"), false, &group),
		right(_T("right"), false, &group),
		l2(_T("Title")), title(_T("Title")),
		useModel(_T("useModel")), pane(pane) 
	{
		title.addActionListener(this);
		add(&l2);
		add(&title);

		top.addItemListener(this);
		left.addItemListener(this);
		bottom.addItemListener(this);
		right.addItemListener(this);

		add(&l);
		add(&top);
		add(&left);
		add(&bottom);
		add(&right);

		useModel.addItemListener(this);
		add(&useModel);
	}

	void itemStateChanged(const ItemEvent& e) {
		if ( e.getSource() == &useModel ) {
			if ( e.getStateChange() == ItemEvent::SELECTED ) {
				pane->setModel(&model);
			} else {
				pane->setModel(NULL);
			}
		}

		TabbedPane::Placement placement;
		if ( group.getSelectedCheckbox() == &top ) {
			placement = TabbedPane::TOP;
		} else if ( group.getSelectedCheckbox() == &left ) {
			placement = TabbedPane::LEFT;
		} else if ( group.getSelectedCheckbox() == &bottom ) {
			placement = TabbedPane::BOTTOM;
		} else {
			placement = TabbedPane::RIGHT;
		}

		pane->setTabPlacement(placement);
		pane->validate();

		assert ( pane->getTabPlacement() == placement );
		
	}

	void actionPerformed(const ActionEvent&) {
		int selected = pane->getSelectedIndex();
		pane->setTitleAt(selected, title.getText());

		assert ( pane->getTitleAt(selected) == title.getText() );
	}
};

#include <stdio.h>
class TabbedPaneTest : public Frame, ChangeListener, WindowAdapter {
	TabbedPane pane;

	Button b;
	List l;
	TextArea ta;

	ImageIcon plane;
	ImageIcon rocket;
	ImageIcon bicycle;

	ControlPanel controlPanel;

	TabbedPaneTest() 
		: Frame("TabbedPaneTest"), 
			pane(TabbedPane::TOP, TabbedPane::WRAP_TAB_LAYOUT),
			plane(_T("plane.ico")), rocket(_T("rocket.ico")), 
			bicycle(_T("bicycle.ico")), controlPanel(&pane) {

		b.setLabel(_T("Test Button"));
		l.add(_T("Item 1"));
		l.add(_T("Item 2"));
		ta.setText(_T("This is a TextArea"));

		pane.addTab("Button", &plane, &b, "A Button Tip");
		pane.addTab("List", &rocket, &l, "List List");
		pane.addTab("TextArea", &bicycle, &ta, "Good Luck !");

		pane.setSelectedIndex(1);
		assert ( pane.getSelectedIndex() == 1 );

		pane.setBackgroundAt(0, Color::RED);
		pane.setBackgroundAt(1, Color::GREEN);
		pane.setBackgroundAt(2, Color::BLUE);

		pane.addChangeListener(this);
		add(&pane);

		add(&controlPanel, BorderLayout::NORTH);

		addWindowListener(this);

		assert ( pane.getComponentAt(0) == &b );
		assert ( pane.getComponentAt(1) == &l );
		assert ( pane.getComponentAt(2) == &ta );
	}

	void stateChanged(const ChangeEvent&) {
		int selected = pane.getSelectedIndex();
		assert ( pane.getComponentAt(selected) != NULL );
		if ( pane.getModel() != NULL ) {
			assert ( pane.getModel()->getSelectedIndex() == 
					pane.getSelectedIndex() );
		}
	}

	void windowClosing(const WindowEvent&) {
		dispose();
	}

public:
	static void main(const ArgumentList&) {
		TabbedPaneTest t;
		printf("%d, %d, %d, %d", 
			t.getBounds().x, 
			t.getBounds().y, 
			t.getBounds().width, 
			t.getBounds().height); 
		t.pack();
		printf("%d, %d, %d, %d", 
			t.getBounds().x, 
			t.getBounds().y, 
			t.getBounds().width, 
			t.getBounds().height); 
		t.show();
	}
};

MAIN_CLASS(TabbedPaneTest)
