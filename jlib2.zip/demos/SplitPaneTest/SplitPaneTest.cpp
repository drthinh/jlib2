#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tchar.h>

#include <jlib/jlib.h>

#include <jlib/lang/StringStream.h>
#include <jlib/awt/Frame.h>

#include <jlib/awt/Label.h>
#include <jlib/awt/Button.h>
#include <jlib/awt/Checkbox.h>
#include <jlib/awt/TextField.h>
#include <jlib/awt/TextArea.h>
#include <jlib/awt/Canvas.h>

#include <jlib/awt/Graphics.h>
#include <jlib/awt/Image.h>
#include <jlib/awt/Toolkit.h>

#include <jlib/awt/ScrollPane.h>

#include <jlib/awt/BorderLayout.h>
#include <jlib/awt/BoxLayout.h>
#include <jlib/awt/GridLayout.h>

#include <jlib/awt/Panel.h>

#include <jlib/awt/WindowAdapter.h>
#include <jlib/awt/WindowEvent.h>

#include <jlib/awt/ItemListener.h>
#include <jlib/awt/ItemEvent.h>

#include <jlib/awt/ActionListener.h>
#include <jlib/awt/ActionEvent.h>

#include <jlib/awt/SplitPane.h>

using namespace jlib::awt;

class ImageCanvas : public Canvas {
public:
	ImageCanvas(String imageName) {
		setCursor(Cursor::getPredefinedCursor(Cursor::HAND_CURSOR));
		img = Toolkit::getDefaultToolkit()->createImage(imageName);
	}

	void update(Graphics& g) {
		g.setFont(Font(_T("Courier"), Font::BOLD, 10));

		int x = (getWidth() - img->getWidth(this))/2;
		int y = (getHeight() - img->getHeight(this))/2;
		g.drawImage(*img, x, y, this);

		if ( x > 0 ) {
			g.clearRect(0, 0, x, getHeight());
			g.clearRect(x+img->getWidth(this), 0, x, getHeight());
		}

		if ( y > 0 ) {
			int xx = x > 0 ? x : 0;
			int w = getWidth() - xx - xx;
			g.clearRect(xx, 0, w, y);
			g.clearRect(xx, y + img->getHeight(this), w, y);
		}
	}

	void paint(Graphics& g) {
		update(g);
	}

	DWORD getWindowExStyle() const {
		return WS_EX_CLIENTEDGE;
	}

private:
	std::auto_ptr<Image> img;
};

class SplitPaneTest : public Frame, 
	WindowAdapter, ItemListener, ActionListener {

	Button button1;
	Button button2;
	TextArea text1;
	TextArea text2;
	SplitPane splitPane;

	ImageCanvas img1;

	Checkbox verticalSplit;
	Checkbox oneTouchExpandable;
	Checkbox continuousLayout;

	Label dividerSizeLabel;
	TextField dividerSize;

	Panel controlPanel;

	void itemStateChanged(const ItemEvent& e) {
		if ( e.getSource() == &verticalSplit ) {
			splitPane.setOrientation(verticalSplit.getState() ? 
				SplitPane::VERTICAL_SPLIT : SplitPane::HORIZONTAL_SPLIT);
		} else if ( e.getSource() == &oneTouchExpandable ) {
			splitPane.setOneTouchExpandable(oneTouchExpandable.getState());
		} else if ( e.getSource() == &continuousLayout ) {
			splitPane.setContinuousLayout(continuousLayout.getState());
		}
	}

	void actionPerformed(const ActionEvent& e) {
		if ( e.getSource() == &dividerSize ) {
			IStringStream iss(dividerSize.getText());
			int size;
			iss >> size;
			splitPane.setDividerSize(size);
		}
	}

	SplitPaneTest() 
		: Frame(_T("SplitPaneTest")), 
		button1(_T("This is a test")),
		button2(_T("Hello world !")),
		text1(_T("This is a test")),
		text2(_T("Hello world !")), 
		img1(_T("moon.jpg")) {

		//splitPane.setBackground(Color::RED);
		//splitPane.setOrientation(SplitPane::VERTICAL_SPLIT);
		//splitPane.setOrientation(SplitPane::VERTICAL_SPLIT);
		splitPane.setContinuousLayout(false);
		splitPane.setOneTouchExpandable(false);
		//splitPane.setDividerSize(24);
		splitPane.setDividerLocation(100);
		splitPane.setResizeWeight(0.5);

		splitPane.setLeftComponent(&img1);
		//splitPane.setLeftComponent(&button1);
		splitPane.setRightComponent(&button2);

		add(&splitPane);

		verticalSplit.setLabel(_T("Vertical Split"));
		controlPanel.add(&verticalSplit);
		verticalSplit.addItemListener(this);

		oneTouchExpandable.setLabel(_T("One Touch Expandable"));
		controlPanel.add(&oneTouchExpandable);
		oneTouchExpandable.addItemListener(this);

		continuousLayout.setLabel(_T("Coninuous Layout"));
		controlPanel.add(&continuousLayout);
		continuousLayout.addItemListener(this);

		dividerSizeLabel.setText(_T("Divider Size"));
		controlPanel.add(&dividerSizeLabel);
		controlPanel.add(&dividerSize);
		dividerSize.setText(_T("8"));
		dividerSize.addActionListener(this);

		add(&controlPanel, BorderLayout::SOUTH);

		addWindowListener(this);
	}

	void windowClosing(const WindowEvent&) {
		dispose();
	}

public:
	static void main(const ArgumentList&) {
		SplitPaneTest test;
		test.setBounds(0, 0, 800, 480);
		test.show();
	}
};

MAIN_CLASS(SplitPaneTest)
