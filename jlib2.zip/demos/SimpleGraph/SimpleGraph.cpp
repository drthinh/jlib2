/*
 * Copyright (c) 2002 Sun Microsystems, Inc. All  Rights Reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * -Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 * 
 * -Redistribution in binary form must reproduct the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the distribution.
 * 
 * Neither the name of Sun Microsystems, Inc. or the names of contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 * 
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
 * ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN AND ITS LICENSORS SHALL NOT
 * BE LIABLE FOR ANY DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT
 * OF OR RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THE SOFTWARE OR ITS
 * DERIVATIVES. IN NO EVENT WILL SUN OR ITS LICENSORS BE LIABLE FOR ANY LOST
 * REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL,
 * INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY
 * OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE, EVEN
 * IF SUN HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * You acknowledge that Software is not designed, licensed or intended for
 * use in the design, construction, operation or maintenance of any nuclear
 * facility.
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <cmath>

#include <jlib/jlib.h>
#include <jlib/awt/Frame.h>
#include <jlib/awt/Panel.h>
#include <jlib/awt/WindowEvent.h>
#include <jlib/awt/WindowAdapter.h>

#include <jlib/awt/Graphics.h>


using jlib::awt::Frame;
using jlib::awt::Panel;
using jlib::awt::WindowAdapter;
using jlib::awt::WindowEvent;
using jlib::awt::Graphics;

class GraphApplet : public Panel, WindowAdapter {
	double f(double x) {
		return (std::cos(x/5) + std::sin(x/7) + 2) * getSize().height / 4;
	}

	void paint(Graphics& g) {
		for (int x = 0 ; x < getSize().width ; x++) {
			g.drawLine(x, (int)f(x), x + 1, (int)f(x + 1));
		}
	}

	String getAppletInfo() const {
		return _T("Draws a sin graph.");
	}

	void windowClosing(const WindowEvent& e) {
		e.getSource()->dispose();
	}

public:
	static void main(const ArgumentList&) {
		GraphApplet g;
		Frame f(_T("SimpleGraph"));
		f.add(&g);
		f.addWindowListener(&g);
		f.setSize(200, 200);
		f.show();
	}
};

MAIN_CLASS(GraphApplet)
