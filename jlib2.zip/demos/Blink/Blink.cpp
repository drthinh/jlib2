/*
* Copyright (c) 2002 Sun Microsystems, Inc. All  Rights Reserved.
* 
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
* 
* -Redistributions of source code must retain the above copyright
*  notice, this list of conditions and the following disclaimer.
* 
* -Redistribution in binary form must reproduct the above copyright
*  notice, this list of conditions and the following disclaimer in
*  the documentation and/or other materials provided with the distribution.
* 
* Neither the name of Sun Microsystems, Inc. or the names of contributors
* may be used to endorse or promote products derived from this software
* without specific prior written permission.
* 
* This software is provided "AS IS," without a warranty of any kind. ALL
* EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
* ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN AND ITS LICENSORS SHALL NOT
* BE LIABLE FOR ANY DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT
* OF OR RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THE SOFTWARE OR ITS
* DERIVATIVES. IN NO EVENT WILL SUN OR ITS LICENSORS BE LIABLE FOR ANY LOST
* REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL,
* INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY
* OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE, EVEN
* IF SUN HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* 
* You acknowledge that Software is not designed, licensed or intended for
* use in the design, construction, operation or maintenance of any nuclear
* facility.
*/
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tchar.h>

#include <cmath>

#include <jlib/jlib.h>
#include <jlib/awt/Panel.h>
#include <jlib/awt/ActionListener.h>
#include <jlib/awt/ActionEvent.h>
#include <jlib/awt/Timer.h>
#include <jlib/awt/Graphics.h>

using namespace jlib::awt;


class Blink : public Canvas, ActionListener {
	Timer timer;              // Schedules the blinking
	String labelString;       // The label for the window
	int delay;                // the delay time between blinks
	Font font;

public:
	Blink() 
		: timer(400, this), 
		font(_T("Times New Roman"), Font::PLAIN, 24) {
		labelString = _T("This is the next best thing to sliced bread!")
			_T(" Toast, toast, toast, butter, jam, toast, marmite, toast.");
		setFont(font);
		timer.start();
	}

	~Blink() {
		timer.stop();
	}

	void actionPerformed(const ActionEvent&) {
		repaint();
	}

	double random() {
		return (double)std::rand() / (double)RAND_MAX;
	}

	Dimension getPreferredSize() const {
		return Dimension(300, 100);
	}

	void paint(Graphics& g) {
		int fontSize = g.getFont().getSize();
		int x = 0, y = fontSize, space;
		int red =   (int) ( 50 * random());
		int green = (int) ( 50 * random());
		int blue =  (int) (256 * random());
		Dimension d = getSize();
		g.setColor(Color::BLACK);
		FontMetrics fm = getFontMetrics();
		space = fm.stringWidth(_T(" "));
		TCHAR labelString[0x100];
		_tcscpy(labelString, this->labelString.c_str());
		const TCHAR* word = _tcstok(labelString, _T(" "));
		while ( word != NULL ) {
			int w = fm.stringWidth(word) + space;
			if (x + w > d.width) {
				x = 0;
				y += fontSize;  //move word to next line if it doesn't fit
			}
			if ( random() < 0.5 ) {
				g.setColor(Color((red + y*30) % 256, 
					(green + x/3) % 256, blue));
			} else {
				g.setColor(getBackground());
			}

			g.drawString(word, x, y);
			x += w;  //shift to the right to draw the next word
			word = _tcstok(NULL, _T(" "));
		}
	}

	void stop() {
		timer.stop();  //stops the timer
	}
};

#include <jlib/awt/Frame.h>
#include <jlib/awt/WindowAdapter.h>

class TestFrame : public Frame, WindowAdapter {
	TestFrame() : Frame(_T("Blink")) {
		addWindowListener(this);
	}

	void windowClosing(const WindowEvent&) {
		dispose();
	}

public:
	static void main(const ArgumentList&) {
		TestFrame f;
		Blink blink;
		f.add(&blink);
		f.pack();
		f.show();
	}
};

MAIN_CLASS(TestFrame)
