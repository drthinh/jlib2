#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tchar.h>

#include <jlib/jlib.h>

#include <jlib/awt/Frame.h>

#include <jlib/awt/Menu.h>
#include <jlib/awt/MenuBar.h>
#include <jlib/awt/MenuItem.h>
#include <jlib/awt/CheckboxMenuItem.h>

#include <jlib/awt/WindowAdapter.h>
#include <jlib/awt/WindowEvent.h>
#include <jlib/awt/ActionListener.h>
#include <jlib/awt/ActionEvent.h>

#include <jlib/awt/KeyEvent.h>

using namespace jlib::awt;

class MenuTest : public Frame, WindowAdapter, ActionListener {
	MenuBar menuBar;
	Menu fileMenu;
	MenuItem openFile;
	MenuItem saveFile;
	MenuItem exit;
	Menu viewMenu;
	CheckboxMenuItem viewToolbar;
	CheckboxMenuItem viewStatusBar;

	MenuTest()
		: Frame(_T("MenuTest")), 
		fileMenu(_T("&File")), 
		openFile(_T("&Open"), MenuShortcut(KeyEvent::O)),
		saveFile(_T("&Save")),
		exit(_T("E&xit"), MenuShortcut(KeyEvent::X)),
		viewMenu(_T("&View")),
		viewToolbar(_T("&Toolbar"), true),
		viewStatusBar(_T("St&atusBar")) {


		menuBar.add(&fileMenu);
			fileMenu.add(&openFile);
			fileMenu.add(&saveFile);
			fileMenu.addSeparator();
			fileMenu.add(&exit);
			exit.addActionListener(this);
		
		menuBar.add(&viewMenu);
			viewMenu.add(&viewToolbar);
			viewMenu.add(&viewStatusBar);

		setMenuBar(&menuBar);

		addWindowListener(this);
	}

	void windowClosing(const WindowEvent&) {
		dispose();
	}

	void actionPerformed(const ActionEvent&) {
		dispose();
	}

public:
	static void main(const ArgumentList&) {
		MenuTest test;
		test.setBounds(0, 0, 320, 240);
		test.show();
	}
};

MAIN_CLASS(MenuTest)
