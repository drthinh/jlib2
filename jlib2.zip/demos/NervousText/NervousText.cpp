/*
 * Copyright (c) 2002 Sun Microsystems, Inc. All  Rights Reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * -Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 * 
 * -Redistribution in binary form must reproduct the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the distribution.
 * 
 * Neither the name of Sun Microsystems, Inc. or the names of contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 * 
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
 * ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN AND ITS LICENSORS SHALL NOT
 * BE LIABLE FOR ANY DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT
 * OF OR RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THE SOFTWARE OR ITS
 * DERIVATIVES. IN NO EVENT WILL SUN OR ITS LICENSORS BE LIABLE FOR ANY LOST
 * REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL,
 * INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY
 * OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE, EVEN
 * IF SUN HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * You acknowledge that Software is not designed, licensed or intended for
 * use in the design, construction, operation or maintenance of any nuclear
 * facility.
 */ 
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <cmath>
#include <ctime>

#include <jlib/jlib.h>
#include <jlib/awt/Frame.h>
#include <jlib/awt/Panel.h>

#include <jlib/awt/Timer.h>

#include <jlib/awt/ActionEvent.h>
#include <jlib/awt/ActionListener.h>

#include <jlib/awt/MouseEvent.h>
#include <jlib/awt/MouseAdapter.h>
#include <jlib/awt/WindowEvent.h>
#include <jlib/awt/WindowAdapter.h>

#include <jlib/awt/Graphics.h>

using namespace jlib::awt;

class NervousText : public Panel, ActionListener, MouseAdapter {
	String banner;		// The text to be displayed
	String bannerChars;	// The same text as an array of characters
	String attributes;	// Character attributes ('^' for superscript)
	Timer timer;
	bool suspended;

	enum {
		REGULAR_WD = 15,
		REGULAR_HT = 36,
		SMALL_WD = 12,
		SMALL_HT = 24,
	};

	Font regularFont;
	Font smallFont;

public:
	NervousText() 
		: timer(100, this),
		regularFont(_T("Times New Roman"), Font::BOLD, REGULAR_HT),
		smallFont(_T("Times New Roman"), Font::BOLD, SMALL_HT) {

		banner = getText();

		int wd = 0;
		for ( unsigned int i = 0; i < banner.length(); ++i) {
			TCHAR c = banner[i];
			TCHAR a = 0;
			if ( c == _T('^') ) {
				++i;
				if ( i < banner.length() ) {
					c = banner[i];
					a = _T('^');
					wd += SMALL_WD - REGULAR_WD;
				} else {
					break;
				}
			}
			bannerChars.push_back(c);
			attributes.push_back(a);
			wd += REGULAR_WD;
		}

		suspended = false;

		setSize(wd + 10, 50);

		std::srand((unsigned)time(NULL));

		addMouseListener(this);
		timer.start();
	}

	~NervousText() {
		timer.stop();
	}

	void actionPerformed(const ActionEvent&) {
		repaint();
	}

	double random() {
		return (double)std::rand() / (double)RAND_MAX;
	}

	void paint(Graphics& g) {
		for ( unsigned int i = 0, x = 0; i < bannerChars.length(); ++i ) {
			int wd, ht;
			if (attributes[i] == _T('^')) {
				wd = SMALL_WD;
				ht = SMALL_HT;
				g.setFont(smallFont);
			} else {
				wd = REGULAR_WD;
				ht = REGULAR_HT;
				g.setFont(regularFont);
			}
			int px = (int) (10 * random() + x);
			int py = (int) (10 * random() + ht);
			g.drawChars(bannerChars.data(), i, 1, px, py);
			x += wd;
		}
	}

	void mousePressed(const MouseEvent&) {
		suspended = !suspended;
		if ( suspended ) {
			timer.stop();
		} else {
			timer.start();
		}
	}

	String getText() {
		return _T("Java^T^M 2 SDK, Standard Edition v1.4");
	}
};

#include <jlib/awt/FocusAdapter.h>

class TestFrame : public Frame, WindowAdapter, public FocusAdapter {
	TestFrame() : Frame(_T("NervousText")) {
		addWindowListener(this);
	}

	void windowClosing(const WindowEvent&) {
		dispose();
	}

public:
	static void main(const ArgumentList&) {
		//::GdiSetBatchLimit(1);
		TestFrame fm;
		fm.addFocusListener(&fm);
		NervousText nt;
		fm.add(&nt);
		fm.setSize(534, 100);
		fm.show();
	}
};

MAIN_CLASS(TestFrame)
