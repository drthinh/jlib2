/*
 * Copyright (c) 2002 Sun Microsystems, Inc. All  Rights Reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * -Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 * 
 * -Redistribution in binary form must reproduct the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the distribution.
 * 
 * Neither the name of Sun Microsystems, Inc. or the names of contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 * 
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
 * ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN AND ITS LICENSORS SHALL NOT
 * BE LIABLE FOR ANY DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT
 * OF OR RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THE SOFTWARE OR ITS
 * DERIVATIVES. IN NO EVENT WILL SUN OR ITS LICENSORS BE LIABLE FOR ANY LOST
 * REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL,
 * INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY
 * OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE, EVEN
 * IF SUN HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * You acknowledge that Software is not designed, licensed or intended for
 * use in the design, construction, operation or maintenance of any nuclear
 * facility.
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tchar.h>

#include <jlib/jlib.h>

#include <jlib/lang/StringStream.h>

#include <jlib/awt/Frame.h>
#include <jlib/awt/Panel.h>
#include <jlib/awt/Button.h>
#include <jlib/awt/TextField.h>
#include <jlib/awt/Graphics.h>
#include <jlib/awt/BorderLayout.h>

#include <jlib/awt/ActionListener.h>
#include <jlib/awt/ActionEvent.h>
#include <jlib/awt/WindowAdapter.h>

using namespace jlib::awt;


class ArcCanvas : public Canvas {
	int		startAngle;
	int		endAngle;
	bool	filled;
	Font	font;

public:

	ArcCanvas()
		: startAngle(0), endAngle(45), filled(false),
		font(_T("Courier"), Font::BOLD, 12) {
		}

	void paint(Graphics& g) {
		Rectangle r = getBounds();
		int hlines = r.height / 10;
		int vlines = r.width / 10;

		g.setColor(Color::PINK);
		for (int i = 1; i <= hlines; i++) {
			g.drawLine(0, i * 10, r.width, i * 10);
		}
		for (int i = 1; i <= vlines; i++) {
			g.drawLine(i * 10, 0, i * 10, r.height);
		}

		g.setColor(Color::RED);
		if (filled) {
			g.fillArc(0, 0, r.width - 1, r.height - 1, startAngle, endAngle);
		} else {
			g.drawArc(0, 0, r.width - 1, r.height - 1, startAngle, endAngle);
		}

		g.setColor(Color::BLACK);
		g.setFont(font);
		g.drawLine(0, r.height / 2, r.width, r.height / 2);
		g.drawLine(r.width / 2, 0, r.width / 2, r.height);
		g.drawLine(0, 0, r.width, r.height);
		g.drawLine(r.width, 0, 0, r.height);
		int sx = 10;
		int sy = r.height - 28;
		OStringStream oss;
		oss << "S = " << startAngle;
		g.drawString(oss.str(), sx, sy);
		oss.rdbuf()->pubseekpos(0);
		oss << "E = " << endAngle;
		g.drawString(oss.str(), sx, sy + 14);
	}

	void redraw(bool filled, int start, int end) {
		this->filled = filled;
		this->startAngle = start;
		this->endAngle = end;
		repaint();
	}

	Dimension getPreferredSize() const {
		return Dimension(300, 300);
	}
};

class ArcControls : public Panel, public ActionListener {
	ArcCanvas& canvas;
	TextField s;
	TextField e;
	Button fill;
	Button draw;
	bool isFill;

public:
	ArcControls(ArcCanvas& canvas) 
		: canvas(canvas), 
			s(_T("0"), 4), e(_T("45"), 4), 
			fill(_T("Fill")), draw(_T("Draw")), isFill(false) {
		s.addActionListener(this);
		add(&s);
		e.addActionListener(this);
		add(&e);
		fill.addActionListener(this);
		add(&fill);
		draw.addActionListener(this);
		add(&draw);
	}

	void actionPerformed(const ActionEvent& ev) {
		if ( ev.getSource() == &fill ) {
			isFill = true;
		} else if ( ev.getSource() == &draw ) {
			isFill = false;
		}

		canvas.redraw(isFill, _ttoi(s.getText().c_str()), 
				_ttoi(e.getText().c_str()));
	}
};

class ArcTest : public Frame, public WindowAdapter{
	ArcCanvas canvas;       // The drawing area to display arcs
	ArcControls controls;   // The controls for marking and filling arcs

	BorderLayout borderLayout;

	ArcTest()
		: Frame(_T("ArcTest")), controls(canvas) {
	}

	void init() {
		setLayout(&borderLayout);
		add(&canvas, BorderLayout::CENTER);
		add(&controls, BorderLayout::SOUTH);
		addWindowListener(this);
	}

	void destroy() {
		remove(&controls);
		remove(&canvas);
	}

	void start() {
		controls.setEnabled(true);
	}

	void stop() {
		controls.setEnabled(false);
	}

	String getAppletInfo() const {
		return _T("An interactive test of the Graphics.drawArc and \n")
			_T("Graphics.fillArc routines. Can be run \n")
			_T("either as a standalone application by typing 'java ArcTest'\n")
			_T("or as an applet in the AppletViewer.");
	}

	void windowClosing(const WindowEvent&) {
		dispose();
	}

public:
	static void main(const ArgumentList&) {
		ArcTest	arcTest;

		//arcTest.setUndecorated(true);

		arcTest.init();
		arcTest.start();

		arcTest.pack();
		arcTest.show();
	}
};

MAIN_CLASS(ArcTest)
