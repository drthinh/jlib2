#include <win32/win32.h>

#include <jlib/awt/Choice.h>
#include <jlib/awt/ItemListener.h>
#include <jlib/awt/ItemEvent.h>
#include <jlib/awt/Container.h>

#include <jlib/awt/SystemColor.h>

#include <commctrl.h>

#include <algorithm>
#include <cassert>

using namespace jlib::awt;

Choice::Choice()
	: selectedIndex(-1) {
}

void Choice::addNotify() {
	Component::addNotify();
	subClassWindow();

	ItemsList::iterator i;
	for ( i = items.begin(); i != items.end(); ++i ) {
		::SendMessage(peer, CB_ADDSTRING, 0, (LPARAM)i->c_str());
	}

	resetDropDownHeight();

	if ( selectedIndex >= 0 ) {
		::SendMessage(peer, CB_SETCURSEL, selectedIndex, 0);
	}
}

Dimension Choice::getMinimumSize() const {
	if ( peer != NULL ) {
		FontMetrics fm = getFontMetrics();
		int width = 0;
		ItemsList::const_iterator i;
		for ( i = items.begin(); i != items.end(); ++i ) {
			int w = fm.stringWidth(*i);
			if ( width < w ) {
				width = w;
			}
		}

		int height = fm.getHeight() + 6;
		if ( height < 15 ) {
			height = 15;
		}

		minSize.setSize(width + 28, height);

		return minSize;
	}

	return Component::getMinimumSize();
}

const String& Choice::getItem(int index) const {
	assert ( index >= 0 && index < getItemCount() );

	return items[index];
}

void Choice::addItem(const String& item) {
	addItemNoInvalidate(item);

	// This could change the preferred size of the Component.
	if (valid) {
		invalidate();
	}
}

void Choice::addItemNoInvalidate(const String& item) {
	assert ( item != _T("") );

	items.push_back(item);
	if ( peer != NULL ) {
		::SendMessage(peer, CB_ADDSTRING, 0, (LPARAM)item.c_str());
		resetDropDownHeight();
	}
	if (selectedIndex < 0) {
		select(0);
	}
}


void Choice::insert(const String& item, int index) {
	assert ( index >=0 );

	items.insert(items.begin() + index, item);

	addItemNoInvalidate(item);

	// This could change the preferred size of the Component.
	if (valid) {
		invalidate();
	}
}

void Choice::remove(const String& item) {
	ItemsList::iterator i = std::find(items.begin(), items.end(), item);
	assert ( i != items.end() );

	removeNoInvalidate(static_cast<int>(i - items.begin()));
	if (valid) {
		invalidate();
	}
}

void Choice::remove(int position) {
	removeNoInvalidate(position);

	// This could change the preferred size of the Component.
	if (valid) {
		invalidate();
	}
}

void Choice::removeNoInvalidate(int position) {
	items.erase(items.begin() + position);

	if ( peer != NULL ) {
		::SendMessage(peer, CB_DELETESTRING, position, 0);
		resetDropDownHeight();
	}

	// Adjust selectedIndex if selected item was removed.
	if (items.empty()) {
		selectedIndex = -1;
	} else if (selectedIndex == position) {
		select(0);
	} else if (selectedIndex > position) {
		select(selectedIndex-1);
	}
}

void Choice::removeAll() {
	if ( peer != NULL ) {
		::SendMessage(peer, CB_RESETCONTENT, 0, 0);
		resetDropDownHeight();
	}

	items.clear();
	selectedIndex = -1;

	// This could change the preferred size of the Component.
	if ( valid ) {
		invalidate();
	}
}

void Choice::select(int pos) {
	assert ( pos <= getItemCount() && pos >= 0 );

	if ( !items.empty() ) {
		selectedIndex = pos;
		if (peer != NULL) {
			::SendMessage(peer, CB_SETCURSEL, pos, 0);
		}
	}
}

void Choice::select(const String& str) {
	ItemsList::iterator i = std::find(items.begin(), items.end(), str);
	if ( i != items.end() ) {
		select(static_cast<int>(i - items.begin()));
	}
}

void Choice::setBounds(int x, int y, int w, int h) {
	if ( peer != NULL ) {
		int fieldHeight = getFieldHeight();
		if ( parent != NULL && parent->getLayout() != NULL &&
			fieldHeight > 0 && fieldHeight < h) {
				y += (h - fieldHeight) / 2;
		}

		int totalHeight = getTotalHeight();
		Component::setBounds(x, y, w, totalHeight);

		RECT rc;
		::GetClientRect(peer, &rc);
		width = rc.right;
		height = rc.bottom;
	} else {
		Component::setBounds(x, y, width, height);
	}
}

void Choice::resetDropDownHeight() {
	assert ( peer != NULL );
	RECT rc;
	::GetWindowRect(peer, &rc);

	int totalHeight = getTotalHeight();
	::SetWindowPos(peer, NULL, 0, 0, rc.right - rc.left, totalHeight, 
			SWP_NOACTIVATE|SWP_NOMOVE|SWP_NOZORDER);
}

int Choice::getTotalHeight() {
	assert ( peer != NULL );
	
	int dropDownHeight = getDropDownHeight();
	int fieldHeight = getFieldHeight();
	int borderHeight = ::GetSystemMetrics(SM_CYBORDER);
	return dropDownHeight + fieldHeight + borderHeight;
}

int Choice::getDropDownHeight() {
	assert ( peer != NULL );

	int itemHeight = static_cast<int>(
			::SendMessage(peer, CB_GETITEMHEIGHT, 0, 0));
	int numOfItemsToShow = getItemCount() > 8 ? getItemCount() : 8;
	//ComboBox_SetMinVisible(peer, numOfItemsToShow);
	//::SendMessage(peer, CB_SETMINVISIBLE, (WPARAM)numOfItemsToShow;
	return itemHeight * numOfItemsToShow + itemHeight/2;
}

int Choice::getFieldHeight() {
	assert ( peer != NULL );

	int fieldHeight = static_cast<int>(
			::SendMessage(peer, CB_GETITEMHEIGHT, (WPARAM)-1, 0));
	fieldHeight += ::GetSystemMetrics(SM_CYEDGE) * 2;
	return fieldHeight;
}

const Color& Choice::getDefaultForeground() const {
	return SystemColor::WINDOW_TEXT;
}

const Color& Choice::getDefaultBackground() const {
	return SystemColor::WINDOW;
}

void Choice::addItemListener(ItemListener* l) {
	itemEventDispatcher.addListener(l);
}

void Choice::removeItemListener(ItemListener* l) {
	itemEventDispatcher.removeListener(l);
}

void Choice::handleCommand(UINT notifyCode) {
	if ( notifyCode == CBN_SELCHANGE ) {
		select(static_cast<int>(::SendMessage(peer, CB_GETCURSEL, 0, 0)));
		ItemEvent event(getSelectedItem(), ItemEvent::SELECTED);
		itemEventDispatcher.fireEvent(this, 
				&ItemListener::itemStateChanged, event);
	}
}

LPCTSTR Choice::getClassName() const {
	return _T("ComboBox");
}

DWORD Choice::getWindowStyle() const {
	return WS_CHILD|WS_CLIPSIBLINGS|WS_VSCROLL|WS_TABSTOP|
		CBS_DROPDOWNLIST;
}
