#include <win32/win32.h>

#include <jlib/awt/ToolTipManager.h>
#include <jlib/verify.h>
#include <jlib/awt/Component.h>
#include <jlib/awt/HierarchyEvent.h>
#include <jlib/awt/Toolkit.h>

#define _WIN32_IE 0x0500
#include <commctrl.h>

#include <limits>

using namespace jlib::awt;


ToolTipManager* ToolTipManager::instance = NULL;

ToolTipManager& ToolTipManager::getSharedInstance() {
	static ToolTipManager instance;
	return instance;
}

ToolTipManager::ToolTipManager() {
	assert ( instance == NULL );
	enabled = true;
	peer = NULL;

	initialDelay = ::GetDoubleClickTime();
	dismissDelay = initialDelay * 10;
	reshowDelay = initialDelay / 5;
}

ToolTipManager::~ToolTipManager() {
	if ( peer != NULL ) {
		::DestroyWindow(peer);
	}
}

void ToolTipManager::setEnabled(bool b) {
	if ( enabled != b ) {
		enabled = b;
		if ( peer != NULL ) {
			peer_setEnabled(b);	
		}
	}
}

void ToolTipManager::setInitialDelay(int milliseconds) {
	if ( initialDelay != milliseconds ) {
		initialDelay = milliseconds;
		if ( peer != NULL ) {
			peer_setInitialDelay(milliseconds);
		}
	}
}

void ToolTipManager::setDismissDelay(int milliseconds) {
	if ( dismissDelay != milliseconds ) {
		dismissDelay = milliseconds;
		if ( peer != NULL ) {
			peer_setDismissDelay(milliseconds);
		}
	}
}

void ToolTipManager::setReshowDelay(int milliseconds) {
	if ( reshowDelay != milliseconds ) {
		reshowDelay = milliseconds;
		if ( peer != NULL ) {
			peer_setReshowDelay(milliseconds);
		}
	}
}

void ToolTipManager::registerComponent(Component* comp) {
	assert ( comp != NULL );

	comp->addHierarchyListener(this);

	if ( comp->isDisplayable() ) {
		peer_register(comp);
	}
}

void ToolTipManager::unregisterComponent(Component* comp) {
	assert ( comp != NULL );

	if ( comp->isDisplayable() ) {
		peer_unregister(comp);
	}

	comp->removeHierarchyListener(this);
}

void ToolTipManager::hierarchyChanged(const HierarchyEvent& e) {
	if ( e.getChangeFlags() & HierarchyEvent::DISPLAYABILITY_CHANGED ) {
		Component* tippedComponent = e.getSource();
		if ( e.getSource()->isDisplayable() ) {
			if ( peer == NULL ) {
				peer_create();
			}
			peer_register(tippedComponent);
		} else {
			peer_unregister(tippedComponent);
		}
	}
}

// peer operations

void ToolTipManager::peer_create() {
	INITCOMMONCONTROLSEX iccex; 
	iccex.dwSize = sizeof(INITCOMMONCONTROLSEX);
	iccex.dwICC = ICC_WIN95_CLASSES;

	::InitCommonControlsEx(&iccex);

	peer =  CreateWindowEx(WS_EX_TOPMOST, TOOLTIPS_CLASS,
			NULL, WS_POPUP|TTS_NOPREFIX|TTS_ALWAYSTIP,		
			0, 0, 0, 0, NULL, NULL,
			Toolkit::getDefaultToolkit()->getModuleHandle(), NULL);

	assert ( peer != NULL );

	::SendMessage(peer, TTM_SETMAXTIPWIDTH, 0, 
			std::numeric_limits<INT>::max());

	peer_setEnabled(enabled);

	peer_setInitialDelay(initialDelay);
	peer_setDismissDelay(dismissDelay);
	peer_setReshowDelay(reshowDelay);
}

void ToolTipManager::peer_destroy() {
	assert ( peer != NULL );

	::DestroyWindow(peer);
	peer = NULL;
}

void ToolTipManager::peer_register(Component* comp) {
	assert ( peer != NULL );

	TOOLINFO ti;
	ti.cbSize = sizeof(ti);
	ti.uFlags = TTF_SUBCLASS|TTF_IDISHWND;
	ti.hinst = NULL;
	ti.lpszText = const_cast<LPTSTR>(comp->getToolTipText().c_str());
	ti.hwnd = comp->getPeer();
	assert ( ti.hwnd != NULL );
	ti.uId = reinterpret_cast<UINT_PTR>(ti.hwnd);
	verify(::SendMessage(peer, TTM_ADDTOOL, 
			0, reinterpret_cast<LPARAM>(&ti)));
}

void ToolTipManager::peer_unregister(Component* comp) {
	assert ( peer != NULL );

	TOOLINFO ti;
	ti.cbSize = sizeof(ti);
	
	ti.hwnd = comp->getPeer();
	ti.uId = reinterpret_cast<UINT_PTR>(ti.hwnd);
	::SendMessage(peer, TTM_DELTOOL, 0, reinterpret_cast<LPARAM>(&ti));
}

void ToolTipManager::peer_setEnabled(bool b) {
	assert ( peer != NULL );

	::SendMessage(peer, TTM_ACTIVATE, (WPARAM)(BOOL)b, 0);
}

void ToolTipManager::peer_setInitialDelay(int milliseconds) {
	peer_setDelay(TTDT_INITIAL, milliseconds);
}

void ToolTipManager::peer_setDismissDelay(int milliseconds) {
	peer_setDelay(TTDT_AUTOPOP, milliseconds);
}

void ToolTipManager::peer_setReshowDelay(int milliseconds) {
	peer_setDelay(TTDT_RESHOW, milliseconds);
}

void ToolTipManager::peer_setDelay(int type, int milliseconds) {
	assert ( peer != NULL );
	::SendMessage(peer, TTM_SETDELAYTIME, (WPARAM)(DWORD)type,
			(LPARAM)(INT)MAKELONG(milliseconds, 0));
}
