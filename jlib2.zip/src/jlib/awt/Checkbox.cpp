#include <win32/win32.h>

#include <jlib/awt/Checkbox.h>
#include <jlib/awt/CheckboxGroup.h>
#include <jlib/awt/Container.h>

#include <jlib/awt/ItemEvent.h>
#include <jlib/awt/ItemListener.h>
#include <jlib/util/EventDispatcher.h>

#include <cassert>

using namespace jlib::awt;

using jlib::lang::String;

Checkbox::Checkbox(const String& label, bool state, CheckboxGroup* group)
	: state(state), group(group) {
	text = label;
	if (state && group != NULL) {
		group->setSelectedCheckbox(this);
	}
}

void Checkbox::addNotify() {
	Component::addNotify();
	subClassWindow();

	peer_setState(state);
}

void Checkbox::setLabel(const String& label) {
	bool testvalid = false;

	if (label != text) {
		text = label;

		if (peer != NULL) {
			::SetWindowText(peer, text.c_str());
		}

		testvalid = true;
	}

	// This could change the preferred size of the Component.
	if (testvalid && valid) {
		invalidate();
	}
}

void Checkbox::setState(bool state) {
	CheckboxGroup* group = this->group;
	if (group != NULL) {
		if (state) {
			group->setSelectedCheckbox(this);
		} else if (group->getSelectedCheckbox() == this) {
			state = true;
		}
	}

	setStateInternal(state);
}

void Checkbox::setCheckboxGroup(CheckboxGroup* g) {
	CheckboxGroup* group = this->group;
	if (group != NULL) {
		group->setSelectedCheckbox(NULL);
	}

	group = g;
	if (peer != NULL) {
		if ((g == NULL && group != NULL) || 
				(g != NULL && group == NULL)) {
			DWORD dwStyle = ::GetWindowLong(peer, GWL_STYLE);
			dwStyle &= ~(BS_CHECKBOX | BS_AUTOCHECKBOX | BS_RADIOBUTTON);
			dwStyle |= g == NULL ? 
				BS_CHECKBOX|BS_AUTOCHECKBOX : BS_RADIOBUTTON;
			::SetWindowLong(peer, GWL_STYLE, dwStyle);
		}
	}
}

void Checkbox::addItemListener(ItemListener* l) {
	itemEventDispatcher.addListener(l);
}

void Checkbox::removeItemListener(ItemListener* l) {
	itemEventDispatcher.removeListener(l);
}

void Checkbox::setStateInternal(bool state) {
	this->state = state;
	if ( peer != NULL ) {
		peer_setState(state);
	}
}

void Checkbox::peer_setState(bool state) {
	assert (peer != NULL);

	::SendMessage(peer, BM_SETCHECK, 
			state ? BST_CHECKED : BST_UNCHECKED, 0);
}

Dimension Checkbox::getMinimumSize() const {
	if (!isValid()) {
		FontMetrics fm = getFontMetrics();
		int w = fm.stringWidth(text);
		int h = fm.getHeight();
		h += 8;
		if ( h > 15 ) {
			h = 15;
		}
		minSize.setSize(w + 30, h);
	}

	return minSize;
}

LPCTSTR Checkbox::getClassName() const {
	return _T("Button");
}

DWORD Checkbox::getWindowStyle() const {
	DWORD dwStyle = WS_CHILD|WS_CLIPSIBLINGS|WS_TABSTOP;
	if (group != NULL) {
		dwStyle |= BS_RADIOBUTTON;
	} else {
		dwStyle |= BS_CHECKBOX|BS_AUTOCHECKBOX;
	}

	return dwStyle;
}

void Checkbox::handleCommand(UINT notifyCode) {
	if (notifyCode == BN_CLICKED) {
		bool state = !getState();
		setState(state);
		ItemEvent event(getLabel(), 
				state ? ItemEvent::SELECTED :ItemEvent::DESELECTED);
		itemEventDispatcher.fireEvent(this, 
				&ItemListener::itemStateChanged, event);
	}
}
