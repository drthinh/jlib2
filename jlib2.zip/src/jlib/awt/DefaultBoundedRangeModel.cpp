#include <jlib/awt/DefaultBoundedRangeModel.h>

#include <jlib/awt/ChangeListener.h>
#include <jlib/awt/ChangeEvent.h>

#include <limits>

using namespace jlib::awt;


DefaultBoundedRangeModel::DefaultBoundedRangeModel() {
	value = 0;
	extent = 0;
	min = 0;
	max = 100;
	adjusting = false; 
}

DefaultBoundedRangeModel::DefaultBoundedRangeModel(int value, int extent, int min, int max) {
	setRangeProperties(value, extent, min, max, false);
}

int DefaultBoundedRangeModel::getMinimum() const {
	return min;
}

void DefaultBoundedRangeModel::setMinimum(int n) {
	int newMax = std::max(n, max);
	int newValue = std::max(n, value);
	int newExtent = std::min(newMax - newValue, extent);
	setRangeProperties(newValue, newExtent, n, newMax, adjusting); 
}

int DefaultBoundedRangeModel::getMaximum() const {
	return max;
}

void DefaultBoundedRangeModel::setMaximum(int n) {
	int newMin = std::min(n, min);
	int newValue = std::min(n, value);
	int newExtent = std::min(n - newValue, extent);

	setRangeProperties(newValue, newExtent, newMin, n, adjusting);
}

int DefaultBoundedRangeModel::getValue() const {
	return value;
}

void DefaultBoundedRangeModel::setValue(int v) {
	int newValue = std::max(v, min);
	if ( newValue + extent > max ) {
		newValue = max - extent; 
	}

	setRangeProperties(newValue, extent, min, max, adjusting); 
}

void DefaultBoundedRangeModel::setValueIsAdjusting(bool b) {
	setRangeProperties(value, extent, min, max, b); 
}

bool DefaultBoundedRangeModel::getValueIsAdjusting() const {
	return adjusting;
}

int DefaultBoundedRangeModel::getExtent() const {
	return extent;
}

void DefaultBoundedRangeModel::setExtent(int v) {
	int newExtent = std::max(0, v);
	if ( value + newExtent > max ) {
		newExtent = max - value;
	}

	setRangeProperties(value, newExtent, min, max, adjusting); 
}

void DefaultBoundedRangeModel::setRangeProperties(int newValue, 
		int newExtent, int newMin, int newMax, bool newAdjusting) {
	if (newMin > newMax) {
		newMin = newMax;
	}

	if (newValue > newMax) {
		newMax = newValue;
	}

	if (newValue < newMin) {
		newMin = newValue;
	}

	if (((__int64)newExtent + (__int64)newValue) > newMax) {
		newExtent = newMax - newValue;
	}

	if ( newExtent < 0 ) {
		newExtent = 0;
	}

    bool isChange = newValue != value || newExtent != extent ||
        newMin != min || newMax != max || newAdjusting != adjusting;

    if ( isChange ) {
        value = newValue;
        extent = newExtent;
        min = newMin;
        max = newMax;
        adjusting = newAdjusting;

        fireStateChanged();
    } 
}

void DefaultBoundedRangeModel::addChangeListener(ChangeListener* l) {
	eventDispatcher.addListener(l);
}

void DefaultBoundedRangeModel::removeChangeListener(ChangeListener* l) {
	eventDispatcher.removeListener(l);
}

void DefaultBoundedRangeModel::fireStateChanged() {
	eventDispatcher.fireEvent(this, &ChangeListener::stateChanged, 
			ChangeEvent());
}
