#include <win32/win32.h>

#include <jlib/awt/Container.h>
#include <jlib/awt/LayoutManager.h>
#include <jlib/awt/LayoutConstraint.h>

#include <jlib/awt/ContainerListener.h>
#include <jlib/awt/ContainerEvent.h>

#include <jlib/awt/Toolkit.h>

#include <jlib/awt/Scrollbar.h>
#include <jlib/awt/MenuItem.h>

#include <functional>
#include <algorithm>
#include <cassert>

using std::distance;
using std::for_each;
using std::mem_fun;

using namespace jlib::awt;


void Container::setVisible(bool b) {
	Component::setVisible(b);
	if ( b ) {
		ChildrenList::iterator i;
		for ( i = children.begin(); i != children.end(); ++i ) {
			if ( (*i)->isVisible() ) {
				(*i)->setVisible(b);
			}
		}
	}
}

void Container::setLayout(LayoutManager* mgr) {
	layoutMgr = mgr;
	if ( valid ) {
		invalidate();
	}
}

void Container::add(Component* comp) {
	addImpl(comp, LayoutConstraint::nullConstraint, -1);
}

void Container::add(Component* comp, int index) {
	addImpl(comp, LayoutConstraint::nullConstraint, index);
}

void Container::add(Component* comp, const LayoutConstraint& constraints) {
	addImpl(comp, constraints, -1);
}

void Container::add(Component* comp, 
		const LayoutConstraint& constraints, int index) {
	addImpl(comp, constraints, index);
}

void Container::addImpl(Component* comp, 
		const LayoutConstraint& constraints, int index) {
	assert ( index >= -1 && index <= getComponentCount() );

	comp->setParent(this);

	if ( index == -1 ) {
		index = getComponentCount();
	}

	comp->setId(index);

	if ( index == getComponentCount() ) {
		children.push_back(comp);
	} else {
		for ( size_t i=index; i<children.size(); ++i ) {
			children[i]->setId(i+1);
		}
		children.insert(children.begin() + index, comp);
	}
	
	if ( valid ) {
		invalidate();
	}

	if ( peer != NULL ) {
		comp->addNotify();
	}

	if ( layoutMgr != NULL ) {
		layoutMgr->addLayoutComponent(comp, constraints);
	}

	if ( !containerEventDispatcher.empty() ) {
		ContainerEvent event(ContainerEvent::COMPONENT_ADDED, comp);
		containerEventDispatcher.fireEvent(this,
				&ContainerListener::componentAdded, event);
	}
}

void Container::remove(Component* comp) {
	assert ( comp != NULL );

	ChildrenList::iterator i = 
			std::find(children.begin(), children.end(), comp);

	if ( i != children.end() ) {
		remove(static_cast<int>(distance(children.begin(), i)));
	}
}

void Container::remove(int index) {
	assert ( index >= 0 && index < getComponentCount() );

	Component* comp = children[index];
	if ( peer != NULL ) {
		comp->removeNotify();
	}

	comp->setParent(NULL);

	if ( layoutMgr != NULL ) {
		layoutMgr->removeLayoutComponent(comp);
	}

	for ( size_t i=index+1; i<children.size(); ++i ) {
		children[i]->setId(i-1);
	}
	children.erase(children.begin() + index);

	if ( valid ) {
		invalidate();
	}

	if ( !containerEventDispatcher.empty() ) {
		ContainerEvent event(ContainerEvent::COMPONENT_REMOVED, comp);
		containerEventDispatcher.fireEvent(this,
				&ContainerListener::componentRemoved, event);
	}
}

const Insets& Container::getInsets() const {
	return insets;
}

Dimension Container::getMinimumSize() const {
	if ( !isValid() ) {
		minSize = layoutMgr != NULL ? 
				layoutMgr->minimumLayoutSize(this) : 
				Component::getMinimumSize();
	}

	return minSize;
}

Dimension Container::getPreferredSize() const {
	if ( !isValid() ) {
		prefSize = layoutMgr != NULL ? 
				layoutMgr->preferredLayoutSize(this) : 
				Component::getPreferredSize();
	}
	return prefSize;
}

Dimension Container::getMaximumSize() const {
	return layoutMgr != NULL ? 
		layoutMgr->maximumLayoutSize(this) : Component::getMaximumSize();
}

void Container::doLayout() {
	if ( layoutMgr != NULL ) {
		layoutMgr->layoutContainer(this);
	}
}

void Container::addNotify() {
	Canvas::addNotify();
	if ( !children.empty() ) {
		for_each(children.begin(), children.end(), 
				mem_fun(&Component::addNotify));
	}
}

void Container::removeNotify() {
	if ( !children.empty() ) {
		for_each(children.begin(), children.end(), 
				mem_fun(&Component::removeNotify));
	}

	Component::removeNotify();
}

void Container::invalidate() {
	if ( layoutMgr != NULL ) {
		layoutMgr->invalidateLayout(this);
	}

	Component::invalidate();
}

void Container::validate() {
	if (!valid && peer != NULL) {
		//Cursor oldCursor = getCursor();
		//HWND hwnd = this->peer;
		//if (hwnd != NULL) {
		//	peer_beginValidate();
		//}
		validateTree();
		valid = true;
		//if (hwnd != NULL) {
		//	peer_endValidate();
		//}
	}
}

void Container::validateTree() {
	if ( !valid ) {
		doLayout();
		ChildrenList::iterator i;
		for ( i = children.begin() ; i != children.end() ; ++i ) {
			Component* c = *i;
			if ( c->isContainer() && !c->isWindow() && !c->isValid() ) {
				static_cast<Container*>(c)->validateTree();
			} else {
				c->valid = true;
			}
		}
	}

	valid = true;
}

void Container::invalidateTree() {
	ChildrenList::iterator i;
	for ( i = children.begin(); i != children.end(); ++i ) {
		if ( (*i)->isContainer() ) {
			Container* con = static_cast<Container*>(*i);
			con->invalidateTree();
		} else {
			if ((*i)->valid) {
				(*i)->invalidate();
			}
		}
	}

	if ( valid ) {
		invalidate();
	}
}

void Container::addContainerListener(ContainerListener* l) {
	containerEventDispatcher.addListener(l);
}

void Container::removeContainerListener(ContainerListener* l) {
	containerEventDispatcher.removeListener(l);
}

void Container::setFont(const Font& font) {
	if ( font != getFont() ) {
		Component::setFont(font);
		invalidateTree();
	}
}

// peer operations

// win32

HBRUSH Container::wmCtlColor(HDC dc, HWND hwnd) {
	UINT id = ::GetWindowLong(hwnd, GWL_ID);
	if ( id >= children.size() ) {
		return NULL;
	}

	Component* c = children[id];

	::SetTextColor(dc, c->getForeground().getRGB());
	::SetBkColor(dc, c->getBackground().getRGB());

	return c->getBackgroundBrush();
}

void Container::wmCommand(WPARAM wParam, LPARAM lParam) {
	UINT notifyCode = static_cast<UINT>(HIWORD(wParam));
	int id = static_cast<int>(LOWORD(wParam));
	if ( lParam == 0 ) { // from a menu or accelerator
		assert ( notifyCode == 0 || notifyCode == 1 );
		MenuItem* mi = MenuItem::getFromId(id);
		if ( mi != NULL ) {
			mi->handleCommand();
		}
	} else {
		if ( id >= 0 && id < getComponentCount() ) {
			children[id]->handleCommand(notifyCode);
		}
	}
}

LRESULT Container::wmNotify(WPARAM wParam, LPARAM lParam) {
	int id = static_cast<int>(wParam);
	NMHDR* nmHdr = reinterpret_cast<NMHDR*>(lParam);
	if ( id >=0 && id < getComponentCount() ) {
		return children[id]->handleNotify(nmHdr);
	}

	return 0;
}

void Container::wmScroll(WPARAM wParam, LPARAM lParam, bool vertical) {
	Component* scrolled = NULL;

	HWND hwnd = reinterpret_cast<HWND>(lParam);
	if ( hwnd == NULL ) {
		scrolled = this;
	} else {
		ChildrenList::iterator i;
		for ( i = children.begin(); i != children.end(); ++i ) {
			if ( (*i)->getPeer() == hwnd ) {
				scrolled = *i;
				break;
			}
		}
	}

	if ( scrolled != NULL ) {
		int scrollCode = LOWORD(wParam);
		int pos = HIWORD(wParam);
		scrolled->handleScroll(scrollCode, pos, vertical);
	}
}

LRESULT Container::windowProc(UINT message, WPARAM wParam, LPARAM lParam) {
	switch ( message ) {
	case WM_DRAWITEM:
		children[wParam]->drawItem(
				reinterpret_cast<DRAWITEMSTRUCT*>(lParam));
		return TRUE;

	case WM_CTLCOLORBTN:
	case WM_CTLCOLORDLG:
	case WM_CTLCOLOREDIT:
	case WM_CTLCOLORLISTBOX:
	case WM_CTLCOLORSCROLLBAR:
	case WM_CTLCOLORSTATIC: {
		HBRUSH hbr = wmCtlColor((HDC)wParam, (HWND)lParam);
		if ( hbr != NULL ) {
			return (LRESULT)hbr;
		}
		break;
		}

	case WM_COMMAND:
		wmCommand(wParam, lParam);
		return 0;

	case WM_VSCROLL:
		wmScroll(wParam, lParam, true);
		return 0;

	case WM_HSCROLL:
		wmScroll(wParam, lParam, false);
		return 0;

	case WM_NOTIFY:
		return wmNotify(wParam, lParam);

	default:
		break;
	}

	return Component::windowProc(message, wParam, lParam);
}

DWORD Container::getWindowStyle() const {
	return WS_CHILD | WS_CLIPCHILDREN | WS_CLIPSIBLINGS;
}

DWORD Container::getWindowExStyle() const {
	return WS_EX_CONTROLPARENT;
}
