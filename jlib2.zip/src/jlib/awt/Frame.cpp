#include <win32/win32.h>
#include <cassert>

#include <jlib/awt/Frame.h>
#include <jlib/awt/MenuBar.h>

#include <jlib/awt/SystemColor.h>

#include <jlib/awt/Image.h>

#include <jlib/awt/Toolkit.h>

using namespace jlib::awt;

int Frame::numOfFrames = 0;

Frame::Frame() 
	: Window(NULL), menuBar(NULL), iconImage(NULL), undecorated(false) {
}

Frame::Frame(const String& title) 
	: Window(NULL), menuBar(NULL), iconImage(NULL), undecorated(false) {
	text = title;
}

Frame::~Frame() {
}

void Frame::addNotify() {
	assert ( parent == NULL );

	Window::addNotify();

	peer_setTitle(text);

	if ( menuBar != NULL ) {
		menuBar->addNotify();
		peer_setMenuBar();
	}

	if ( iconImage != NULL ) {
		peer_setIconImage(iconImage);
	}

	++numOfFrames;
}

void Frame::remove(MenuComponent* mcomp) {
	if ( mcomp == menuBar ) {
		if ( menuBar != NULL ) {
			MenuBar* mb = menuBar;
			menuBar = NULL;
			peer_setMenuBar();
			mb->removeNotify();
		}
	}
}

void Frame::removeNotify() {

	if ( peer != NULL ) {
		if ( menuBar != NULL ) {
			MenuBar* mb = menuBar;
			menuBar = NULL;
			peer_setMenuBar();
			mb->removeNotify();
		}
	}

	Window::removeNotify();
	--numOfFrames;

	if ( numOfFrames == 0 ) {
		Toolkit::getDefaultToolkit()->stopEventLoop();
	}
}

void Frame::setTitle(const String& title) {
	text = title;
	if ( peer != NULL ) {
		peer_setTitle(title);
	}
}

void Frame::setVisible(bool b) {
	Window::setVisible(b);
	if ( b && numOfFrames == 1 ) {
		Toolkit::getDefaultToolkit()->startEventLoop();
	}
}

void Frame::show() {
	setVisible(true);
}

void Frame::setIconImage(Image* img) {
	iconImage = img;
	if ( peer != NULL ) {
		peer_setIconImage(img);
	}
}

Image* Frame::getIconImage() const {
	return iconImage;
}

void Frame::setUndecorated(bool b) {
	assert ( !isDisplayable() );

	undecorated = b;
}

const Color& Frame::getDefaultForeground() const {
	return SystemColor::WINDOW_TEXT;
}

const Color& Frame::getDefaultBackground() const {
	return SystemColor::WINDOW;
}

// peer operations

void Frame::peer_setMenuBar() {
	assert ( peer != NULL );

	::SetMenu(peer, menuBar != NULL ? menuBar->getPeer() : NULL);
	::DrawMenuBar(peer);
}

//Color Frame::peer_getDefaultColor() {
//	COLORREF c = ::GetSysColor(COLOR_WINDOW);
//	bkBrush = ::GetSysColorBrush(COLOR_WINDOW);
//	return Color(GetRValue(c), GetGValue(c), GetBValue(c));
//}

void Frame::peer_setTitle(const String& title) {
	assert ( peer != NULL );

	::SetWindowText(peer, title.c_str());
}

#include <jlib/awt/imp/IPictureImageImp.h>

void Frame::peer_setIconImage(Image* img) {
	assert ( peer != NULL );

	using jlib::awt::imp::IPictureImageImp;
	IPictureImageImp* pic = static_cast<IPictureImageImp*>(img);
	HICON hicon = pic->getHICON();
	::SendMessage(peer, WM_SETICON, ICON_BIG, 
			reinterpret_cast<LPARAM>(hicon));
}

// WIN32

DWORD Frame::getClassStyle() const {
	return CS_HREDRAW | CS_VREDRAW;
}

DWORD Frame::getWindowStyle() const {
	DWORD style = WS_VISIBLE|WS_CLIPCHILDREN;
	if ( !undecorated ) {
		style |= WS_OVERLAPPEDWINDOW;
	} else {
		style |= WS_POPUP|WS_SYSMENU|WS_MINIMIZEBOX|WS_MAXIMIZEBOX;
	}

	return style;
}

DWORD Frame::getWindowExStyle() const {
	return WS_EX_CONTROLPARENT;
}
