#include <win32/win32.h>
#include <commdlg.h>
#include <shlobj.h>

#include <jlib/awt/FileDialog.h>
#include <jlib/awt/Toolkit.h>
#include <jlib/awt/Frame.h>

#include <jlib/io/FilenameFilter.h>

#include <jlib/verify.h>


using namespace jlib::awt;

FileDialog::FileDialog(Frame* parent, const String& title, Mode mode) 
	: Dialog(parent, title), mode(mode), filter(NULL) {
	assert ( mode == LOAD || mode == SAVE );
	setLayout(NULL);
}

UINT_PTR CALLBACK 
FileDialog::OFNHookProc(HWND hwnd, UINT message, WPARAM, LPARAM lParam) {
	HWND hwndFileDlg = ::GetParent(hwnd);
	FileDialog* fd = static_cast<FileDialog*>(
		Toolkit::getDefaultToolkit()->getComponent(hwndFileDlg));

	if ( message == WM_INITDIALOG ) {
		FileDialog* fd = reinterpret_cast<FileDialog*>(
				reinterpret_cast<OPENFILENAME*>(lParam)->lCustData);
		assert ( fd != NULL );

		fd->peer = hwndFileDlg;
		Toolkit::getDefaultToolkit()->addDisplayable(fd);
#ifdef INCLUDEITEM_USABLE
	} else if ( message == WM_NOTIFY ) {
		OFNOTIFYEX* ofn = reinterpret_cast<OFNOTIFYEX*>(lParam);
		if ( ofn->hdr.code == CDN_INCLUDEITEM ) {
			LPITEMIDLIST pidl = static_cast<LPITEMIDLIST>(ofn->pidl);
			TCHAR path[_MAX_PATH];
			verify ( ::SHGetPathFromIDList(pidl, path) );
			if ( fd != NULL && fd->filter != NULL ) {
				if ( fd->filter->accept(path) ) {
					return TRUE;
				}
			}
		}
#endif
	} else if ( message == WM_NCDESTROY ) {
		if ( fd != NULL ) {
			Toolkit::getDefaultToolkit()->removeDisplayable(fd);
			fd->peer = NULL;
		}
	}

	return 0;
}

void FileDialog::setVisible(bool b) {
	// always model, no opportunity to call setVisible(false)
	assert ( b );

	OPENFILENAME ofn;
	TCHAR fileName[_MAX_PATH + 1] = {0};
	TCHAR fileTitle[_MAX_FNAME + 1] = {0};
	memset(fileName, 0, sizeof(fileName));

	memset(&ofn, 0, sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = getParent()->getPeer();
	ofn.lpstrFile = fileName;
	ofn.nMaxFile = _MAX_PATH;
	ofn.lpstrFilter = _T("All Files\0*.*\0");//_T("All\0*.*\0Text\0*.TXT\0");
	ofn.nFilterIndex = 1;
	ofn.lpstrFileTitle = fileTitle;
	ofn.nMaxFileTitle = _MAX_FNAME;
	ofn.lpstrInitialDir = dir.c_str();
	ofn.lpstrTitle = getTitle().c_str();

	ofn.lCustData = reinterpret_cast<LPARAM>(this);
	ofn.Flags = OFN_OVERWRITEPROMPT|OFN_SHOWHELP| 
			OFN_EXPLORER|OFN_ENABLEHOOK;
	// Totally no use, windows only check return value of CDN_INCLUDEITEM
	// when items are in namespace extensions. Code written here is just
	// to show it's no use.
	ofn.lpfnHook = OFNHookProc;

#ifdef INCLUDEITEM_USABLE
	if ( filter != NULL ) {
		ofn.Flags |= OFN_ENABLEINCLUDENOTIFY;
	}
#endif
	BOOL isOk;
	if ( mode == LOAD ) {
		//ofn.Flags |= OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;
		isOk = ::GetOpenFileName(&ofn);
	} else {
		isOk = ::GetSaveFileName(&ofn);
	}

	if ( isOk ) {
		file = ofn.lpstrFileTitle;
		dir = String(ofn.lpstrFile, lstrlen(ofn.lpstrFile) - file.length());
	} else {
		file = _T("");
	}
}

void FileDialog::setMode(FileDialog::Mode mode) {
	assert ( mode == LOAD || mode == SAVE );

	this->mode = mode;
}

void FileDialog::setDirectory(const String& dir) {
	if ( this->dir != dir ) {
		this->dir = dir;
		if ( peer != NULL ) {
			peer_setDirectory(dir);
		}
	}
}

void FileDialog::setFile(const String& file) {
	if ( this->file != file ) {
		this->file = file;
		if ( peer != NULL ) {
			peer_setFile(file);
		}
	}
}

//FilenameFilter getFilenameFilter() const {
//	return filter;
//}

//void setFilenameFilter(FilenameFilter filter) {
//	if ( this->filter != filter ) {
//		this->filter = filter;
//		if ( peer != NULL ) {
//			peer_setFilenameFilter(filter);
//		}
//	}
//}

void FileDialog::peer_addNotify() {
}

void FileDialog::peer_setDirectory(const String& dir) {
}

void FileDialog::peer_setFile(const String& file) {
}
