#include <win32/win32.h>

#define _WIN32_IE 0x0500

#ifndef TCM_SETMINTABWIDTH // workaround for mingw2.0
#	define TCM_SETMINTABWIDTH      (TCM_FIRST + 49)
#endif

#include <commctrl.h>

#include <limits>

#include <jlib/awt/Tab.h>
#include <jlib/awt/ChangeListener.h>
#include <jlib/awt/ChangeEvent.h>

#include <jlib/awt/ImageIcon.h>
#include <jlib/awt/imp/IPictureImageImp.h>

#include <jlib/verify.h>

using namespace jlib::awt;


Tab::Tab(Placement placement, LayoutPolicy layoutPolicy) 
	: placement(placement), layoutPolicy(layoutPolicy), 
	selectedIndex(0), imageList(NULL) {
}

Tab::~Tab() {
	if ( imageList != NULL ) {
		ImageList_Destroy(static_cast<HIMAGELIST>(imageList));
	}
}

void Tab::addNotify() {
	Component::addNotify();
	subClassWindow();

	imageList = ImageList_Create(16, 16, TRUE, 0, 1);
	assert ( imageList != NULL );
	TabCtrl_SetImageList(peer, imageList);

	for ( int i=0; i<getTabCount(); ++i ) {
		peer_insertTab(tabs[i], i);
	}

	peer_setSelectedIndex(selectedIndex);
}

void Tab::removeNotify() {
	Component::removeNotify();
	ImageList_Destroy(static_cast<HIMAGELIST>(imageList));
}

int Tab::getTabCount() const {
	return static_cast<int>(tabs.size());
}

const String& Tab::getTab(int index) const {
	assert ( index >= 0 && index < getTabCount() );

	return tabs[index].title;
}

void Tab::insertTab(const String& title, const Icon* icon,
		const String& tip, int index) {
	assert ( index == -1 || ( index >= 0 && index < getTabCount() ) );

	if ( index == -1 ) {
		index = getTabCount();
	}

	tabs.insert(tabs.begin() + index, TabInfo(title, icon, tip));

	if ( getPeer() != NULL ) {
		peer_insertTab(tabs[index], index);
	}

	invalidate();
}

void Tab::removeTabAt(int index) {
	assert ( index >= 0 && index < getTabCount() );

	tabs.erase(tabs.begin() + index);
	if ( getPeer() != NULL ) {
		peer_removeTabAt(index);
	}

	invalidate();
}

void Tab::setPlacement(Placement v) {
	if ( placement != v ) {
		placement = v;
		if ( getPeer() != NULL ) {
			peer_setPlacement(v);
		}

		invalidate();
	}
}

void Tab::setLayoutPolicy(LayoutPolicy v) {
	if ( layoutPolicy != v ) {
		layoutPolicy = v;
		if ( getPeer() != NULL ) {
			peer_setLayoutPolicy(v);
		}

		invalidate();
	}
}

void Tab::setSelectedIndex(int index) {
	assert ( index >= 0 && index < getTabCount() );

	if ( selectedIndex != index ) {
		selectedIndex = index;
		if ( getPeer() != NULL ) {
			peer_setSelectedIndex(index);
		}
	}
}

void Tab::setTitleAt(int index, const String& title) {
	assert ( index >= 0 && index < getTabCount() );

	if ( tabs[index].title != title ) {
		tabs[index].title = title;
		if ( peer != NULL ) {
			peer_setTitleAt(index, title);
			invalidate();
		}
	}
}

const String& Tab::getTitleAt(int index) const {
	assert ( index >= 0 && index < getTabCount() );

	return tabs[index].title;
}

void Tab::setToolTipTextAt(int index, const String& tip) {
	assert ( index > 0 && index < getTabCount() );

	tabs[index].toolTip = tip;
}

const String& Tab::getToolTipTextAt(int index) const {
	assert ( index >= 0 && index < getTabCount() );

	return tabs[index].toolTip;
}

void Tab::setIconAt(int index, const Icon* icon ) {
	assert ( index >= 0 && index < getTabCount() );

	if ( tabs[index].icon != icon ) {
		tabs[index].icon = icon;

		if ( peer != NULL ) {
			repaint();
		}
	}
}

const Icon* Tab::getIconAt(int index) const {
	assert ( index >= 0 && index < getTabCount() );
	return tabs[index].icon;
}

void Tab::setForegroundAt(int index, Color c) {
	assert ( index >= 0 && index < getTabCount() );

	if ( tabs[index].fore != c ) {
		tabs[index].fore = c;
		tabs[index].foreSet = true;
		if ( peer != NULL ) {
			repaint();
		}
	}
}

Color Tab::getForegroundAt(int index) const {
	assert ( index >= 0 && index < getTabCount() );

	if ( tabs[index].foreSet ) 
		return tabs[index].fore;

	return getForeground();
}

void Tab::setBackgroundAt(int index, Color c) {
	assert ( index >= 0 && index < getTabCount() );

	if ( tabs[index].back != c ) {
		tabs[index].back = c;
		tabs[index].backSet = true;
		if ( peer != NULL ) {
			repaint();
		}
	}
}

Color Tab::getBackgroundAt(int index) const {
	assert ( index >= 0 && index < getTabCount() );

	if ( tabs[index].backSet ) {
		return tabs[index].back;
	}

	return getBackground();
}

Dimension Tab::getPreferredSize() const {
	if ( !valid ) {
		if ( peer != NULL ) {
			prefSize = peer_getPreferredSize();
		}
	}

	return prefSize;
}

void Tab::addChangeListener(ChangeListener* l) {
	changeEventDispatcher.addListener(l);
}

void Tab::removeChangeListener(ChangeListener* l) {
	changeEventDispatcher.removeListener(l);
}

// peer operations

void Tab::peer_insertTab(const TabInfo& info, int index) {
	assert ( getPeer() != NULL );

	TCITEM ti;
	ti.mask = TCIF_TEXT;
	ti.pszText = const_cast<LPTSTR>(info.title.c_str());
	verify ( TabCtrl_InsertItem(getPeer(), index, &ti) != -1 );

	peer_setIconAt(index, info.icon);

	TabCtrl_SetMinTabWidth(getPeer(), 0);
}

void Tab::peer_removeTabAt(int index) {
	assert ( getPeer() != NULL );

	TabCtrl_DeleteItem(getPeer(), index);
}

void Tab::peer_setPlacement(Placement) {
	assert ( getPeer() != NULL );

	::SetWindowLong(getPeer(), GWL_STYLE, getWindowStyle());
}

void Tab::peer_setLayoutPolicy(LayoutPolicy) {
	assert ( getPeer() != NULL );

	::SetWindowLong(getPeer(), GWL_STYLE, getWindowStyle());
}

void Tab::peer_setSelectedIndex(int index) {
	assert ( getPeer() != NULL );

	verify ( TabCtrl_SetCurSel(getPeer(), index) != -1 );
}

void Tab::peer_setTitleAt(int index, const String& title) {
	assert ( getPeer() != NULL );

	TCITEM ti;
	ti.mask = TCIF_TEXT;
	ti.pszText = (LPSTR)title.c_str();
	TabCtrl_SetItem(peer, index, &ti);
}

void Tab::peer_setIconAt(int index, const Icon* icon) {
	assert ( peer != NULL );

	HIMAGELIST himl = static_cast<HIMAGELIST>(imageList);

	int count = ImageList_GetImageCount(himl);
	if ( index >= count ) {
#ifdef __GNUC__
	// workaround for mingw2.0
	typedef BOOL (WINAPI *PImageList_SetImageCount)(HIMAGELIST, UINT);
	static PImageList_SetImageCount	ImageList_SetImageCount
			= (PImageList_SetImageCount)::GetProcAddress(
				::GetModuleHandle(_T("comctl32.dll")),
				"ImageList_SetImageCount");;
#endif
		ImageList_SetImageCount(himl, index + 1);
	}

	int cx, cy;
	verify ( ImageList_GetIconSize(himl, &cx, &cy) );
	if ( cx < icon->getIconWidth() ) {
		cx = icon->getIconWidth();
	}

	if ( cy < icon->getIconHeight() ) {
		cy = icon->getIconHeight();
	}

	ImageList_SetIconSize(himl, cx, cy);

	const ImageIcon* imgIcon = static_cast<const ImageIcon*>(icon);
	using jlib::awt::imp::IPictureImageImp;
	const IPictureImageImp* img = 
			static_cast<const IPictureImageImp*>(imgIcon->getImage());
	ImageList_ReplaceIcon(himl, index, img->getHICON());

	TCITEM ti;
	ti.mask = TCIF_IMAGE;
	ti.iImage = index;

	TabCtrl_SetItem(peer, index, &ti);
}

Dimension Tab::peer_getPreferredSize() const {
	assert ( getPeer() != NULL );

	Dimension d;

	int preferredLength = 0;
	FontMetrics fm = getFontMetrics();
	int iconCount = 0;
	for ( int i=0; i<getTabCount(); ++i ) {
		preferredLength += fm.stringWidth(getTab(i)) + 14;
		if ( tabs[i].icon != NULL ) {
			++iconCount;
		}
	}

	if ( iconCount > 0 ) {
		HIMAGELIST himl = static_cast<HIMAGELIST>(imageList);
		if ( himl != NULL ) {
			int cx, cy;
			verify ( ImageList_GetIconSize(himl, &cx, &cy) );
			if ( placement == TOP || placement == BOTTOM ) {
				preferredLength += ( cx + 6 ) * iconCount;
			} else {
				preferredLength += ( cy + 7 ) * iconCount;
			}
		}
	}

	RECT rc;
	verify ( TabCtrl_GetItemRect(getPeer(), 0, &rc) );

	if ( placement == TOP || placement == BOTTOM ) {
		d.width = preferredLength;
		d.height = rc.bottom - rc.top;
		if ( rc.right > rc.left ) {
			d.height *= TabCtrl_GetRowCount(getPeer());
		}
	} else {
		d.height = preferredLength + getTabCount() * 4;
		d.width = rc.right - rc.left;
		if ( rc.bottom > rc.top ) {
			d.width *= TabCtrl_GetRowCount(getPeer());
		}
	}

	return d;
}

// win32
#include <jlib/awt/imp/DCGraphics.h>

void Tab::drawItem(DRAWITEMSTRUCT* di) {
	TabInfo& tabInfo = tabs[di->itemID];
	Rectangle rc(di->rcItem.left, di->rcItem.top, 
			di->rcItem.right - di->rcItem.left,
			di->rcItem.bottom - di->rcItem.top);
	jlib::awt::imp::DCGraphics g(di->hDC);

	g.setColor(getBackgroundAt(di->itemID));
	g.fillRect(rc.x, rc.y, rc.width, rc.height);

	int iconx = 0, icony = 0, stringx = 0, stringy = 0;
	HFONT hf = NULL, oldhf = NULL;
	int iconh = tabInfo.icon->getIconWidth();
	int iconw = tabInfo.icon->getIconWidth();

	FontMetrics fm = getFontMetrics();
	if ( placement == TOP || placement == BOTTOM ) {
		iconx = rc.x + 3;
		stringx = iconx + iconw + 4;
		if ( placement == TOP ) {
			icony = rc.y + 3;
			stringy = icony + iconh - (iconh - fm.getHeight())/2;
		} else {
			icony = rc.y + rc.height - 3 - iconh;
			stringy = icony + iconh - (iconh - fm.getHeight())/2;
		}
	} else if ( placement == LEFT || placement == RIGHT ) {
		LOGFONT lf;
		verify( ::GetObject(::GetCurrentObject(di->hDC, OBJ_FONT), 
				sizeof(lf), &lf) );
		if ( placement == LEFT ) {
			lf.lfEscapement = 900;
			iconx = rc.x + 3;
			icony = rc.y + rc.height - iconh - 3;
			stringx = rc.x + iconw - (iconw - fm.getHeight())/2;
			stringy = icony - 4;
		} else {
			lf.lfEscapement = 2700;
			iconx = rc.x + rc.width - iconw - 3;
			stringx = iconx + (iconw - fm.getHeight())/2;
			icony = rc.y + 3;
			stringy = icony + iconh + 4;
		}
		hf = ::CreateFontIndirect(&lf);
		oldhf = (HFONT)::SelectObject(di->hDC, hf);
	}

	tabInfo.icon->paintIcon(this, &g, iconx, icony);
	g.setColor(getForegroundAt(di->itemID));
	g.drawString(tabInfo.title, stringx, stringy);

	if ( hf != NULL ) {
		::SelectObject(di->hDC, oldhf);
		::DeleteObject(hf);
	}
}

LRESULT Tab::handleNotify(NMHDR* nmHdr) {
	if ( nmHdr->code == TCN_SELCHANGE ) {
		selectedIndex = TabCtrl_GetCurSel(getPeer());
		if ( !changeEventDispatcher.empty() ) {
			changeEventDispatcher.fireEvent(this, 
					&ChangeListener::stateChanged, ChangeEvent());
		}
	}

	return 0;
}

LPCTSTR Tab::getClassName() const {
	return WC_TABCONTROL;
}

DWORD Tab::getWindowStyle() const {
	DWORD style = WS_CHILD|WS_TABSTOP|TCS_OWNERDRAWFIXED|TCS_TOOLTIPS;
	switch ( placement ) {
	case BOTTOM:
		style |= TCS_BOTTOM;
		break;
	case LEFT:
		style |= TCS_VERTICAL;
		break;
	case RIGHT:
		style |= TCS_VERTICAL|TCS_RIGHT;
		break;
	default:
		break;
	}

	if ( layoutPolicy == WRAP_TAB_LAYOUT ) {
		style |= TCS_MULTILINE;
	}

	return style;
}

LRESULT Tab::windowProc(UINT message, WPARAM wParam, LPARAM lParam) {
	if ( message == WM_ERASEBKGND ) {
		HDC dc = reinterpret_cast<HDC>(wParam);
		RECT rc;
		::GetClipBox(dc, &rc);
		::FillRect(dc, &rc, getBackgroundBrush());
		return TRUE;
	}

	return Component::windowProc(message, wParam, lParam);
}
