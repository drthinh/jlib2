#include <win32/win32.h>

#include <cassert>

#include <jlib/awt/TextField.h>
#include <jlib/awt/Container.h>

#include <jlib/awt/ActionListener.h>
#include <jlib/awt/ActionEvent.h>

#include <jlib/awt/KeyEvent.h>

using namespace jlib::awt;


TextField::TextField(const String& text, int columns) 
	: TextComponent(text),
	columns(columns >= 0 ? columns : 0),
	echoChar(0) {
}

void TextField::setEchoChar(TCHAR c) {
	echoChar = c;
	if (peer != NULL) {
		peer_setEchoChar(c);
	}
}

void TextField::setText(const String& t) {
	TextComponent::setText(t);

	// This could change the preferred size of the Component.
	if (valid) {
		invalidate();
	}
}

void TextField::setColumns(int columns) {
	assert ( columns >= 0 );
	int oldVal = this->columns;
	if (columns != oldVal) {
		this->columns = columns;
		invalidate();
	}
}

Dimension TextField::getPreferredSize(int columns) const {
	return peer != NULL ? 
			peer_getPreferredSize(columns) :
			TextComponent::getPreferredSize();
}

Dimension TextField::getPreferredSize() const {
	return getPreferredSize(columns > 0 ? columns : text.length());
}

Dimension TextField::getMinimumSize(int columns) const {
	return peer != NULL ?
			peer_getMinimumSize(columns) :
			TextComponent::getMinimumSize();
}

Dimension TextField::getMinimumSize() const {
	return getMinimumSize( columns > 0 ? columns : text.length() );
}

void TextField::addActionListener(ActionListener* l) {
	actionEventDispatcher.addListener(l);
}

void TextField::removeActionListener(ActionListener* l) {
	actionEventDispatcher.removeListener(l);
}

void TextField::fireActionEvent() {
	actionEventDispatcher.fireEvent(this, 
		&ActionListener::actionPerformed, ActionEvent(getText()));
}

void TextField::processKeyEvent(const KeyEvent& e) {
	// Can not test KEY_TYPED as WM_CHARs of '\n' are
	// eaten by IsDialogMessage.
	if ( e.getID() == KeyEvent::KEY_RELEASED &&
			e.getKeyCode() == KeyEvent::ENTER ) {
		fireActionEvent();
	}
}

// peer operations
void TextField::peer_setEchoChar(TCHAR ch) {
	assert ( peer != NULL );

	::SendMessage(peer, EM_SETPASSWORDCHAR, (WPARAM)ch, 0); 
}

Dimension TextField::peer_getPreferredSize(int columns) const {
	return peer_getMinimumSize(columns);
}

Dimension TextField::peer_getMinimumSize(int columns) const {
	assert ( peer != NULL );

	FontMetrics fm = getFontMetrics();
	int w = fm.charWidth(_T('0'));
	int h = fm.getHeight();

	return Dimension(w * columns + 24, h + 8);
}

Dimension TextField::peer_getMinimumSize() const {
	assert ( peer != NULL );

	FontMetrics fm = getFontMetrics();
	int w = fm.stringWidth(text);
	int h = fm.getHeight();

	return Dimension(w + 24, h + 8);
}

// WIN32

DWORD TextField::getWindowStyle() const {
	return WS_CHILD|WS_CLIPSIBLINGS|WS_TABSTOP|
		ES_LEFT|ES_AUTOHSCROLL|ES_NOHIDESEL;
}

DWORD TextField::getWindowExStyle() const {
	return WS_EX_CLIENTEDGE;
}
