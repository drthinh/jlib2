/*
 * @(#)GridBagLayout.java	1.37 00/02/02
 *
 * Copyright 1995-2000 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */ 
#include <jlib/awt/GridBagLayout.h>
#include <jlib/awt/Point.h>
#include <jlib/awt/Rectangle.h>

#include <limits>

#ifdef _MSC_VER
#ifndef NDEBUG
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
#define DEBUG_NEW new (_NORMAL_BLOCK, __FILE__, __LINE__)
#define new DEBUG_NEW
#endif
#endif


using namespace jlib::awt;

using namespace jlib::awt;
using std::max;

namespace jlib { namespace awt {
struct GridBagLayoutInfo {
	// number of cells horizontally, vertically
	int width;
	int height;
	// starting point for layout
	int startx;
	int starty;		
	// largest minWidth in each column
	int minWidth[GridBagLayout::MAXGRIDSIZE];
	// largest minHeight in each row
	int minHeight[GridBagLayout::MAXGRIDSIZE];
	// largest weight in each column
	double weightX[GridBagLayout::MAXGRIDSIZE];
	// largest weight in each row
	double weightY[GridBagLayout::MAXGRIDSIZE];

	GridBagLayoutInfo() {
		memset(this, 0, sizeof(*this));
	}
};

}}


GridBagLayout::GridBagLayout() {
	rightToLeft = false;
	layoutInfo = NULL;
}

GridBagLayout::~GridBagLayout() {
	delete layoutInfo;

	ComponentTable::iterator i;
	for ( i = comptable.begin(); i != comptable.end(); ++i ) {
		delete i->second;
	}

	comptable.clear();
}

void GridBagLayout::setConstraints(LayoutComponent* comp, 
		const GridBagConstraints& constraints) {
	GridBagConstraints* con = new GridBagConstraints(constraints);
	comptable[comp] = con;
}

const GridBagConstraints& GridBagLayout::getConstraints(LayoutComponent* comp) const {
	ComponentTable::const_iterator i = comptable.find(comp);
	if ( i != comptable.end() ) {
		return *(i->second);
	}

	const_cast<GridBagLayout*>(this)->
			setConstraints(comp, defaultConstraints);
	i = comptable.find(comp);
	return *(i->second);
}

GridBagConstraints* GridBagLayout::lookupConstraints(LayoutComponent* comp) {
	ComponentTable::iterator i = comptable.find(comp);
	if ( i != comptable.end() ) {
		return i->second;
	}

	setConstraints(comp, defaultConstraints);
	i = comptable.find(comp);
	return i->second;
}

void GridBagLayout::removeConstraints(LayoutComponent* comp) {
	ComponentTable::iterator i = comptable.find(comp);
	if ( i != comptable.end() ) {
		delete i->second;
		comptable.erase(comp);
	}
}

Point GridBagLayout::getLayoutOrigin() const {
	return Point(layoutInfo->startx, layoutInfo->starty);
}

//int [][] GridBagLayout::getLayoutDimensions () {
//	if (layoutInfo == NULL)
//		return new int[2][0];
//
//	int dim[][] = new int [2][];
//	dim[0] = new int[layoutInfo->width];
//	dim[1] = new int[layoutInfo->height];
//
//	System.arraycopy(layoutInfo->minWidth, 0, dim[0], 0, layoutInfo->width);
//	System.arraycopy(layoutInfo->minHeight, 0, dim[1], 0, layoutInfo->height);
//
//	return dim;
//}

    /**
     * Determines the weights of the layout grid's columns and rows.
     * Weights are used to calculate how much a given column or row
     * stretches beyond its preferred size, if the layout has extra
     * room to fill.
     * <p>
     * Most applications do not call this method directly.
     * @return      an array of two arrays, representing the
     *                    horizontal weights of the layout columns
     *                    and the vertical weights of the layout rows
     * @since       JDK1.1
     */
  //public double [][] getLayoutWeights () {
  //  if (layoutInfo == NULL)
  //    return new double[2][0];

  //  double weights[][] = new double [2][];
  //  weights[0] = new double[layoutInfo->width];
  //  weights[1] = new double[layoutInfo->height];

  //  System.arraycopy(layoutInfo->weightX, 0, weights[0], 0, layoutInfo->width);
  //  System.arraycopy(layoutInfo->weightY, 0, weights[1], 0, layoutInfo->height);

  //  return weights;
  //}

/**
 * Determines which cell in the layout grid contains the point
 * specified by <code>(x,&nbsp;y)</code>. Each cell is identified
 * by its column index (ranging from 0 to the number of columns
 * minus 1) and its row index (ranging from 0 to the number of
 * rows minus 1).
 * <p>
 * If the <code>(x,&nbsp;y)</code> point lies
 * outside the grid, the following rules are used.
 * The column index is returned as zero if <code>x</code> lies to the
 * left of the layout for a left-to-right container or to the right of
 * the layout for a right-to-left container.  The column index is returned
 * as the number of columns if <code>x</code> lies
 * to the right of the layout in a left-to-right container or to the left
 * in a right-to-left container.
 * The row index is returned as zero if <code>y</code> lies above the 
 * layout, and as the number of rows if <code>y</code> lies
 * below the layout.  The orientation of a container is determined by its
 * <code>ComponentOrientation</code> property.
 * @param      x    the <i>x</i> coordinate of a point
 * @param      y    the <i>y</i> coordinate of a point
 * @return     an ordered pair of indexes that indicate which cell
 *             in the layout grid contains the point
 *             (<i>x</i>,&nbsp;<i>y</i>).
 * @see        java.awt.ComponentOrientation
 * @since      JDK1.1
 */
Point GridBagLayout::location(int x, int y) {
	Point loc(0,0);

	if ( layoutInfo == NULL )
		return loc;

	int d = layoutInfo->startx;
	int i;
	if ( !rightToLeft ) {
		for (i=0; i<layoutInfo->width; i++) {
			d += layoutInfo->minWidth[i];
			if (d > x)
				break;
		}
	} else {
		for (i=layoutInfo->width-1; i>=0; i--) {
			if (d > x)
				break;
			d += layoutInfo->minWidth[i];
		}
		i++;
	}
	loc.x = i;

	d = layoutInfo->starty;
	for ( i=0; i<layoutInfo->height; i++ ) {
		d += layoutInfo->minHeight[i];
		if (d > y)
			break;
	}

	loc.y = i;

	return loc;
}

void GridBagLayout::addLayoutComponent(LayoutComponent* comp, 
		const LayoutConstraint& constraints) {
	if ( &constraints == &LayoutConstraint::nullConstraint )
		return;

	setConstraints(comp, 
		static_cast<const GridBagConstraints&>(constraints));
}

void GridBagLayout::removeLayoutComponent(LayoutComponent* comp) {
	removeConstraints(comp);
}

Dimension GridBagLayout::preferredLayoutSize(const LayoutContainer* parent) {
    GridBagLayoutInfo info;
	getLayoutInfo(parent, PREFERREDSIZE, &info);
	return getMinSize(parent, info);
}

Dimension GridBagLayout::minimumLayoutSize(const LayoutContainer* parent) {
    GridBagLayoutInfo info;
	getLayoutInfo(parent, MINSIZE, &info);
    return getMinSize(parent, info);
}

Dimension GridBagLayout::maximumLayoutSize(const LayoutContainer*) {
	return Dimension(
		std::numeric_limits<int>::max(), 
		std::numeric_limits<int>::max());
}


void GridBagLayout::getLayoutInfo(const LayoutContainer* parent, 
		int sizeflag, GridBagLayoutInfo* info) {
    LayoutComponent* comp;
    GridBagConstraints* constraints;
    Dimension d;

    int compindex, i, k, px, py, pixels_diff, nextSize;
    int curX, curY, curWidth, curHeight, curRow, curCol;
    double weight_diff, weight;
	//double start, size;
    /*
     * Pass #1
     *
     * Figure out the dimensions of the layout grid (use a value of 1 for
     * zero or negative widths and heights).
     */

    info->width = info->height = 0;
    curRow = curCol = -1;

    int xMax[MAXGRIDSIZE];
    int yMax[MAXGRIDSIZE];

	for (compindex = 0 ; compindex < parent->getComponentCount(); compindex++) {
		comp = parent->getComponent(compindex);
		if (!comp->isVisible())
			continue;

		constraints = lookupConstraints(comp);

		curX = constraints->gridx;
		curY = constraints->gridy;
		curWidth = constraints->gridwidth;
		if (curWidth <= 0)
			curWidth = 1;
		curHeight = constraints->gridheight;
		if (curHeight <= 0)
			curHeight = 1;

		// If x or y is negative, then use relative positioning
		if ( curX < 0 && curY < 0 ) {
			if (curRow >= 0)
				curY = curRow;
			else if (curCol >= 0)
				curX = curCol;
			else
				curY = 0;
		}

		if (curX < 0) {
			px = 0;
			for (i = curY; i < (curY + curHeight); i++)
				px = max(px, xMax[i]);

			curX = px - curX - 1;
			if(curX < 0)
				curX = 0;
		} else if (curY < 0) {
			py = 0;
			for (i = curX; i < (curX + curWidth); i++)
				py = max(py, yMax[i]);

			curY = py - curY - 1;
			if(curY < 0)
				curY = 0;
		}

		/* Adjust the grid width and height */
		for (px = curX + curWidth; info->width < px; info->width++);
		for (py = curY + curHeight; info->height < py; info->height++);

		/* Adjust the xMax and yMax arrays */
		for (i = curX; i < (curX + curWidth); i++) { yMax[i] = py; }
		for (i = curY; i < (curY + curHeight); i++) { xMax[i] = px; }

		/* Cache the current slave's size. */
		if (sizeflag == PREFERREDSIZE)
			d = comp->getPreferredSize();
		else
			d = comp->getMinimumSize();
		constraints->minWidth = d.width;
		constraints->minHeight = d.height;

		/* Zero width and height must mean that this is the last item (or
		* else something is wrong). */
		if (constraints->gridheight == 0 && constraints->gridwidth == 0)
			curRow = curCol = -1;

		/* Zero width starts a new row */
		if (constraints->gridheight == 0 && curRow < 0)
			curCol = curX + curWidth;

		/* Zero height starts a new column */
		else if (constraints->gridwidth == 0 && curCol < 0)
			curRow = curY + curHeight;
	}

	// Apply minimum row/column dimensions
	if ( info->width < static_cast<int>(columnWidths.size()) ) {
		info->width = columnWidths.size();
	}

	if ( info->height < static_cast<int>(rowHeights.size()) ) {
		info->height = rowHeights.size();
	}

    /*
     * Pass #2
     *
     * Negative values for gridX are filled in with the current x value.
     * Negative values for gridY are filled in with the current y value.
     * Negative or zero values for gridWidth and gridHeight end the current
     *  row or column, respectively.
     */

    curRow = curCol = -1;
	for (compindex = 0 ; compindex < parent->getComponentCount(); compindex++) {
		comp = parent->getComponent(compindex);
		if (!comp->isVisible())
			continue;
		constraints = lookupConstraints(comp);

		curX = constraints->gridx;
		curY = constraints->gridy;
		curWidth = constraints->gridwidth;
		curHeight = constraints->gridheight;

		// If x or y is negative, then use relative positioning:
		if (curX < 0 && curY < 0) {
			if(curRow >= 0)
				curY = curRow;
			else if(curCol >= 0)
				curX = curCol;
			else
				curY = 0;
		}

		if (curX < 0) {
			if (curHeight <= 0) {
				curHeight += info->height - curY;
				if (curHeight < 1)
					curHeight = 1;
			}

			px = 0;
			for (i = curY; i < (curY + curHeight); i++)
				px = max(px, xMax[i]);

			curX = px - curX - 1;
			if(curX < 0)
				curX = 0;
		}
		else if (curY < 0) {
			if (curWidth <= 0) {
				curWidth += info->width - curX;
				if (curWidth < 1)
					curWidth = 1;
			}

			py = 0;
			for (i = curX; i < (curX + curWidth); i++)
				py = max(py, yMax[i]);

			curY = py - curY - 1;
			if(curY < 0)
				curY = 0;
		}

		if (curWidth <= 0) {
			curWidth += info->width - curX;
			if (curWidth < 1)
				curWidth = 1;
		}

		if (curHeight <= 0) {
			curHeight += info->height - curY;
			if (curHeight < 1)
				curHeight = 1;
		}

		px = curX + curWidth;
		py = curY + curHeight;

		for (i = curX; i < curX + curWidth; i++) { yMax[i] = py; }
		for (i = curY; i < curY + curHeight; i++) { xMax[i] = px; }

		// Make negative sizes start a new row/column
		if (constraints->gridheight == 0 && constraints->gridwidth == 0)
			curRow = curCol = -1;
		if (constraints->gridheight == 0 && curRow < 0)
			curCol = curX + curWidth;
		else if (constraints->gridwidth == 0 && curCol < 0)
			curRow = curY + curHeight;

		// Assign the new values to the gridbag slave
		constraints->tempX = curX;
		constraints->tempY = curY;
		constraints->tempWidth = curWidth;
		constraints->tempHeight = curHeight;
	}


	// Apply minimum row/column dimensions and weights
	if ( !columnWidths.empty() ) {
		std::copy(columnWidths.begin(), columnWidths.end(), info->minWidth);
	}

	if ( !rowHeights.empty() ) {
		std::copy(rowHeights.begin(), rowHeights.end(), info->minHeight);
	}

	if ( !columnWeights.empty() ) {
		std::copy(columnWeights.begin(), columnWeights.end(), info->weightX);
	}

	if ( !rowWeights.empty() ) {
		std::copy(rowWeights.begin(), rowWeights.end(), info->weightY);
	}

    // Pass #3
    // Distribute the minimun widths and weights:

    nextSize = std::numeric_limits<int>::max();

    for (i = 1; i != std::numeric_limits<int>::max(); 
		i = nextSize, nextSize = std::numeric_limits<int>::max()) {

		for ( compindex = 0; compindex < parent->getComponentCount(); compindex++) {
			comp = parent->getComponent(compindex);
			if (!comp->isVisible()) {
				continue;
			}

			constraints = lookupConstraints(comp);

			if (constraints->tempWidth == i) {
				px = constraints->tempX + constraints->tempWidth; /* right column */

				// Figure out if we should use this slave\'s weight.  If the weight
				// is less than the total weight spanned by the width of the cell,
				// then discard the weight.  Otherwise split the difference
				// according to the existing weights.

				weight_diff = constraints->weightx;
				for (k = constraints->tempX; k < px; k++)
					weight_diff -= info->weightX[k];
				if (weight_diff > 0.0) {
					weight = 0.0;
					for (k = constraints->tempX; k < px; k++)
						weight += info->weightX[k];
					for (k = constraints->tempX; weight > 0.0 && k < px; k++) {
						double wt = info->weightX[k];
						double dx = (wt * weight_diff) / weight;
						info->weightX[k] += dx;
						weight_diff -= dx;
						weight -= wt;
					}
					// Assign the remainder to the rightmost cell
					info->weightX[px-1] += weight_diff;
				}

				
				// Calculate the minWidth array values.
				// First, figure out how wide the current slave needs to be.
				// Then, see if it will fit within the current minWidth values.
				// If it will not fit, add the difference according to the
				// weightX array.

				pixels_diff =
					constraints->minWidth + constraints->ipadx +
					constraints->insets.left + constraints->insets.right;

				for (k = constraints->tempX; k < px; k++)
					pixels_diff -= info->minWidth[k];
				if (pixels_diff > 0) {
					weight = 0.0;
					for (k = constraints->tempX; k < px; k++)
						weight += info->weightX[k];
					for (k = constraints->tempX; weight > 0.0 && k < px; k++) {
						double wt = info->weightX[k];
						int dx = (int)((wt * ((double)pixels_diff)) / weight);
						info->minWidth[k] += dx;
						pixels_diff -= dx;
						weight -= wt;
					}
					// Any leftovers go into the rightmost cell
					info->minWidth[px-1] += pixels_diff;
				}
			}
			else if (constraints->tempWidth > i && constraints->tempWidth < nextSize)
				nextSize = constraints->tempWidth;

			if (constraints->tempHeight == i) {
				py = constraints->tempY + constraints->tempHeight; /* bottom row */

				
				// Figure out if we should use this slave\'s weight.  If the weight
				// is less than the total weight spanned by the height of the cell,
				// then discard the weight.  Otherwise split it the difference
				// according to the existing weights.

				weight_diff = constraints->weighty;
				for (k = constraints->tempY; k < py; k++)
					weight_diff -= info->weightY[k];
				if (weight_diff > 0.0) {
					weight = 0.0;
					for (k = constraints->tempY; k < py; k++)
						weight += info->weightY[k];
					for (k = constraints->tempY; weight > 0.0 && k < py; k++) {
						double wt = info->weightY[k];
						double dy = (wt * weight_diff) / weight;
						info->weightY[k] += dy;
						weight_diff -= dy;
						weight -= wt;
					}
					// Assign the remainder to the bottom cell
					info->weightY[py-1] += weight_diff;
				}


				// Calculate the minHeight array values.
				// First, figure out how tall the current slave needs to be.
				// Then, see if it will fit within the current minHeight values.
				// If it will not fit, add the difference according to the
				// weightY array.

				pixels_diff =
					constraints->minHeight + constraints->ipady +
					constraints->insets.top + constraints->insets.bottom;
				for (k = constraints->tempY; k < py; k++)
					pixels_diff -= info->minHeight[k];
				if (pixels_diff > 0) {
					weight = 0.0;
					for (k = constraints->tempY; k < py; k++)
						weight += info->weightY[k];
					for (k = constraints->tempY; weight > 0.0 && k < py; k++) {
						double wt = info->weightY[k];
						int dy = (int)((wt * ((double)pixels_diff)) / weight);
						info->minHeight[k] += dy;
						pixels_diff -= dy;
						weight -= wt;
					}
					// Any leftovers go into the bottom cell
					info->minHeight[py-1] += pixels_diff;
				}
			}
			else if (constraints->tempHeight > i &&
				constraints->tempHeight < nextSize)
				nextSize = constraints->tempHeight;
		}
	}
	//return r;
   //}
}

void GridBagLayout::adjustForGravity(
		const GridBagConstraints& constraints, Rectangle* r) {
    int diffx, diffy;

    if (!rightToLeft) {
		r->x += constraints.insets.left;
    } else {
		r->x -= r->width - constraints.insets.right;
    }
    r->width -= (constraints.insets.left + constraints.insets.right);
    r->y += constraints.insets.top;
    r->height -= (constraints.insets.top + constraints.insets.bottom);

    diffx = 0;
	if ( (constraints.fill != GridBagConstraints::HORIZONTAL &&
			constraints.fill != GridBagConstraints::BOTH)
			&& r->width > constraints.minWidth + constraints.ipadx ) {
		diffx = r->width - (constraints.minWidth + constraints.ipadx);
		r->width = constraints.minWidth + constraints.ipadx;
    }

    diffy = 0;
	if ( (constraints.fill != GridBagConstraints::VERTICAL &&
			constraints.fill != GridBagConstraints::BOTH)
			&& r->height > constraints.minHeight + constraints.ipady ) {
		diffy = r->height - (constraints.minHeight + constraints.ipady);
		r->height = constraints.minHeight + constraints.ipady;
	}

	switch (constraints.anchor) {
	case GridBagConstraints::CENTER:
		r->x += diffx/2;
		r->y += diffy/2;
		break;
	case GridBagConstraints::PAGE_START:
	case GridBagConstraints::NORTH:
		r->x += diffx/2;
		break;
	case GridBagConstraints::NORTHEAST:
		r->x += diffx;
		break;
	case GridBagConstraints::EAST:
		r->x += diffx;
		r->y += diffy/2;
		break;
	case GridBagConstraints::SOUTHEAST:
		r->x += diffx;
		r->y += diffy;
		break;
	case GridBagConstraints::PAGE_END:
	case GridBagConstraints::SOUTH:
		r->x += diffx/2;
		r->y += diffy;
		break;
	case GridBagConstraints::SOUTHWEST:
		r->y += diffy;
		break;
	case GridBagConstraints::WEST:
		r->y += diffy/2;
		break;
	case GridBagConstraints::NORTHWEST:
		break;
	case GridBagConstraints::LINE_START:
		if (rightToLeft) {
			r->x += diffx;
		}
		r->y += diffy/2;
		break;
	case GridBagConstraints::LINE_END:
		if (!rightToLeft) {
			r->x += diffx;
		}
		r->y += diffy/2;
		break;
	case GridBagConstraints::FIRST_LINE_START:
		if (rightToLeft) {
			r->x += diffx;
		}	
		break;
	case GridBagConstraints::FIRST_LINE_END:
		if (!rightToLeft) {
			r->x += diffx;
		}	
		break;
	case GridBagConstraints::LAST_LINE_START:
		if (rightToLeft) {
			r->x += diffx;
		}
		r->y += diffy;
		break;
	case GridBagConstraints::LAST_LINE_END:
		if (!rightToLeft) {
			r->x += diffx;
		}
		r->y += diffy;
		break;
	default:
		// illegal anchor value
		assert ( false );
	}
}

Dimension GridBagLayout::getMinSize(const LayoutContainer* parent, 
		const GridBagLayoutInfo& info) const {
	Dimension d;
	int i, t;
	Insets insets = parent->getInsets();

	t = 0;
	for(i = 0; i < info.width; i++)
		t += info.minWidth[i];
	d.width = t + insets.left + insets.right;

	t = 0;
	for(i = 0; i < info.height; i++)
		t += info.minHeight[i];
	d.height = t + insets.top + insets.bottom;

	return d;
}

void GridBagLayout::arrangeGrid(LayoutContainer* parent) {
	// If the parent has no slaves anymore, then don't do anything
	// at all:  just leave the parent's size as-is.
	if ( parent->getComponentCount() == 0 && 
			columnWidths.empty() && rowHeights.empty() ) {
		return;
	}

	LayoutComponent* comp;
	int compindex;
	GridBagConstraints* constraints;
	Insets insets = parent->getInsets();
	Dimension d;
	Rectangle r;
	int i, diffw, diffh;
	double weight;
	GridBagLayoutInfo* info = new GridBagLayoutInfo;

	//rightToLeft = !parent->getComponentOrientation().isLeftToRight();
	rightToLeft = false;

	// Pass #1: scan all the slaves to figure out the total amount
	// of space needed.

	getLayoutInfo(parent, PREFERREDSIZE, info);

	d = getMinSize(parent, *info);

	if (parent->getSize().width < d.width || parent->getSize().height < d.height) {
		getLayoutInfo(parent, MINSIZE, info);
		d = getMinSize(parent, *info);
	}

	if ( layoutInfo != NULL ) {
		delete layoutInfo;
	}

	layoutInfo = info;

	r.width = d.width;
	r.height = d.height;


	// If the current dimensions of the window don't match the desired
	// dimensions, then adjust the minWidth and minHeight arrays
	// according to the weights.

	diffw = parent->getSize().width - r.width;
	if (diffw != 0) {
		weight = 0.0;
		for (i = 0; i < info->width; i++)
			weight += info->weightX[i];
		if (weight > 0.0) {
			for (i = 0; i < info->width; i++) {
				int dx = (int)(( ((double)diffw) * info->weightX[i]) / weight);
				info->minWidth[i] += dx;
				r.width += dx;
				if (info->minWidth[i] < 0) {
					r.width -= info->minWidth[i];
					info->minWidth[i] = 0;
				}
			}
		}
		diffw = parent->getSize().width - r.width;
	}
	else {
		diffw = 0;
	}

	diffh = parent->getSize().height - r.height;
	if (diffh != 0) {
		weight = 0.0;
		for (i = 0; i < info->height; i++)
			weight += info->weightY[i];
		if (weight > 0.0) {
			for (i = 0; i < info->height; i++) {
				int dy = (int)(( ((double)diffh) * info->weightY[i]) / weight);
				info->minHeight[i] += dy;
				r.height += dy;
				if (info->minHeight[i] < 0) {
					r.height -= info->minHeight[i];
					info->minHeight[i] = 0;
				}
			}
		}
		diffh = parent->getSize().height - r.height;
	}
	else {
		diffh = 0;
	}

	// Now do the actual layout of the slaves using the layout information
	// that has been collected.

	info->startx = diffw/2 + insets.left;
	info->starty = diffh/2 + insets.top;

	for ( compindex = 0; compindex < parent->getComponentCount(); compindex++ ) {
		comp = parent->getComponent(compindex);
		if ( !comp->isVisible() ) {
			continue;
		}
		constraints = lookupConstraints(comp);

		if (!rightToLeft) {
			r.x = info->startx;
			for(i = 0; i < constraints->tempX; i++)
				r.x += info->minWidth[i];
		} else {
			r.x = parent->getSize().width - (diffw/2 + insets.right);
			for(i = 0; i < constraints->tempX; i++)
				r.x -= info->minWidth[i];
		}

		r.y = info->starty;
		for(i = 0; i < constraints->tempY; i++)
			r.y += info->minHeight[i];

		r.width = 0;
		for(i = constraints->tempX;
			i < constraints->tempX + constraints->tempWidth; i++) {
				r.width += info->minWidth[i];
		}

		r.height = 0;
		for(i = constraints->tempY;
			i < constraints->tempY + constraints->tempHeight;
			i++) {
				r.height += info->minHeight[i];
		}

		adjustForGravity(*constraints, &r);

		// fix for 4408108 - components were being created outside of the container
		if (r.x < 0) {
			r.width -= r.x;
			r.x = 0;
		}

		if (r.y < 0) {
			r.height -= r.y;
			r.y = 0;
		}


		// If the window is too small to be interesting then
		// unmap it.  Otherwise configure it and then make sure
		// it's mapped.
		if ( r.width <= 0 || r.height <= 0 ) {
			comp->setBounds(0, 0, 0, 0);
		} else {
			const Rectangle& bounds = comp->getBounds();
			if (bounds.x != r.x || bounds.y != r.y ||
				bounds.width != r.width || bounds.height != r.height) {
				comp->setBounds(r.x, r.y, r.width, r.height);
			}
		}
	}
}
