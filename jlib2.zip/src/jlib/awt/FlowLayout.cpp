#include <jlib/awt/FlowLayout.h>

#include <algorithm>

using namespace jlib::awt;

Dimension FlowLayout::preferredLayoutSize(const LayoutContainer* target) {
	Dimension dim(0, 0);
	
	bool firstVisibleComponent = true;

	int nmembers = target->getComponentCount();
	for ( int i = 0; i < nmembers; ++i ) {
		LayoutComponent* m = target->getComponent(i);
		if ( m->isVisible() ) {
			Dimension d = m->getPreferredSize();
			dim.height = std::max(dim.height, d.height);
			if ( firstVisibleComponent ) {
				firstVisibleComponent = false;
			} else {
				dim.width += hgap;
			}
			dim.width += d.width;
		}
	}

	const Insets& insets = target->getInsets();
	dim.width += insets.left + insets.right + hgap*2;
	dim.height += insets.top + insets.bottom + vgap*2;
	return dim;
}

Dimension FlowLayout::minimumLayoutSize(const LayoutContainer* target) {
	Dimension dim(0, 0);

	int nmembers = target->getComponentCount();
	for ( int i = 0; i < nmembers; ++i ) {
		LayoutComponent* m = target->getComponent(i);
		if ( m->isVisible() ) {
			Dimension d = m->getMinimumSize();
			dim.height = std::max(dim.height, d.height);
			if (i > 0) {
				dim.width += hgap;
			}
			dim.width += d.width;
		}
	}

	const Insets& insets = target->getInsets();
	dim.width += insets.left + insets.right + hgap*2;
	dim.height += insets.top + insets.bottom + vgap*2;
	return dim;
}

void FlowLayout::layoutContainer(LayoutContainer* target) {
	const Insets& insets = target->getInsets();
	int maxwidth = target->getSize().width - 
			(insets.left + insets.right + hgap*2);

	int nmembers = target->getComponentCount();
	int x = 0, y = insets.top + vgap;
	int rowh = 0, start = 0;

	//bool ltr = target->getComponentOrientation().isLeftToRight();
	bool ltr = true;

	for (int i = 0 ; i < nmembers ; i++) {
		LayoutComponent* m = target->getComponent(i);
		if (m->isVisible()) {
			
			Dimension d = m->getPreferredSize();
			const Rectangle& r = m->getBounds();
			m->setBounds(r.x, r.y, d.width, d.height);

			if ( x == 0 || x + d.width <= maxwidth ) {
				if ( x > 0 ) {
					x += hgap;
				}

				x += d.width;
				rowh = std::max(rowh, d.height);
			} else {
				moveComponents(target, insets.left + hgap, y, maxwidth - x, rowh, start, i, ltr);
				x = d.width;
				y += vgap + rowh;
				rowh = d.height;
				start = i;
			}
		}
	}

	moveComponents(target, insets.left + hgap, y, maxwidth - x, rowh, start, nmembers, ltr);
}

void FlowLayout::moveComponents(LayoutContainer* target, 
		int x, int y, int width, int height, 
		int rowStart, int rowEnd, bool ltr) {

	switch (align) {
	case LEFT:
		x += ltr ? 0 : width;
		break;
	case CENTER:
		x += width / 2;
		break;
	case RIGHT:
		x += ltr ? width : 0;
		break;
	case LEADING:
		break;
	case TRAILING:
		x += width;
		break;
	}

	for (int i = rowStart ; i < rowEnd ; i++) {
		LayoutComponent* m = target->getComponent(i);
		const Rectangle& bounds = m->getBounds();
		if ( m->isVisible() ) {
			if (ltr) {
				m->setBounds(x, y + (height - bounds.height) / 2, 
					bounds.width, bounds.height);
			} else {
				m->setBounds(target->getSize().width - x - bounds.width, 
					y + (height - bounds.height) / 2,
					bounds.width, bounds.height);
			}

			x += bounds.width + hgap;
		}
	}
}
