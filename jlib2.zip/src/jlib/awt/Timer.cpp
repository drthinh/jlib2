#include <win32/win32.h>

#include <jlib/awt/Timer.h>

#include <jlib/awt/ActionListener.h>
#include <jlib/awt/ActionEvent.h>

#include <jlib/awt/EventQueue.h>

#include <jlib/verify.h>

using namespace jlib::awt;


Timer::Timer(int millisecsDelay, ActionListener* listener) 
	: delay(millisecsDelay), running(false) {
	dispatcher.addListener(listener);
}

Timer::~Timer() {
	if ( isRunning() ) {
		stop();
	}
}

void Timer::addActionListener(ActionListener* l) {
	dispatcher.addListener(l);
}

void Timer::removeActionListener(ActionListener* l) {
	dispatcher.removeListener(l);
}

void Timer::setDelay(int millisecs) {
	if ( delay == millisecs ) {
		return;
	}

	delay = millisecs;

	if ( isRunning() ) {
		peer_setDelay(delay);
	}
}

void Timer::start() {
	if ( isRunning() ) {
		return;
	}

	running = true;
	peer_setDelay(delay);
}

void Timer::stop() {
	if ( !isRunning() ) {
		return;
	}

	peer_stop();
	running = false;
}

void Timer::peer_setDelay(int millisecs) {
	verify ( ::SetTimer(EventQueue::instance()->getMessageWindow(), 
			reinterpret_cast<UINT_PTR>(this), millisecs, timerProc) );
}

void Timer::peer_stop() {
	verify ( ::KillTimer(EventQueue::instance()->getMessageWindow(), 
			reinterpret_cast<UINT_PTR>(this)) );

	// After a timer is killed, WM_TIMER messages for it may still be left 
	// in message queue, which should be cleared.
	MSG msg;
	while ( ::PeekMessage(&msg, 
			EventQueue::instance()->getMessageWindow(), 
			WM_TIMER, WM_TIMER, TRUE) ) {
		::DispatchMessage(&msg);
	}
}

void CALLBACK Timer::timerProc(HWND, UINT, UINT_PTR eventId, DWORD) {
	Timer* timer = reinterpret_cast<Timer*>(eventId);
	assert ( timer != NULL );

	timer->dispatcher.fireEvent(timer, &ActionListener::actionPerformed, 
			ActionEvent(_T("")));
}
