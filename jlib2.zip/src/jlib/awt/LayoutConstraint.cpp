#include <jlib/awt/LayoutConstraint.h>

using namespace jlib::awt;
LayoutConstraint LayoutConstraint::nullConstraint;
