#include <win32/win32.h>

#include <jlib/awt/SplitPane.h>
#include <jlib/awt/SplitPaneDivider.h>

#include <jlib/awt/SystemColor.h>

#include <jlib/awt/MouseEvent.h>

#include <cassert>

using namespace jlib::awt;


SplitPane::SplitPane(SplitPane::Orientation orientation, 
		bool continuousLayout, Component* left, Component* right)
	: divider(this, orientation == HORIZONTAL_SPLIT, continuousLayout) {

	resizeWeight = 0;

    setLayout(NULL);

	if ( left != NULL ) {
        setLeftComponent(left);
	} else {
		leftComponent = NULL;
	}

	if ( right != NULL ) {
        setRightComponent(right);
	} else {
		rightComponent = NULL;
	}
}

SplitPane::~SplitPane() {
}

void SplitPane::addNotify() {
	Container::addNotify();
}

void SplitPane::setBounds(int x, int y, int width, int height) {
	Dimension oldSize = getSize();
	Container::setBounds(x, y, width, height);

	if ( oldSize.getWidth() <= 0 || oldSize.getHeight() <= 0 ) {
		return;
	}

	int diff = 0;
	if ( divider.isVertical() ) {
		diff = getWidth() - oldSize.getWidth();
	} else {
		diff = getHeight() - oldSize.getHeight();
	}

	if ( diff != 0 ) {
		divider.setLocation(divider.getLocation() + 
				static_cast<int>(diff * resizeWeight));
		if ( divider.getLocation() < getMinimumDividerLocation() ) {
			divider.setLocation(getMinimumDividerLocation());
		} else if ( divider.getLocation() > getMaximumDividerLocation() ) {
			divider.setLocation(getMaximumDividerLocation());
		}
		repaint();
	}
}

void SplitPane::setDividerSize(int size) {
	divider.setSize(size);
	repaint();
}

int SplitPane::getDividerSize() const {
	return divider.getSize();
}

void SplitPane::setLeftComponent(Component* comp) {
    if ( comp == NULL ) {
        if ( leftComponent != NULL ) {
            remove(leftComponent);
            leftComponent = NULL;
        }
    } else {
        add(comp, 0);
    }
}

Component* SplitPane::getLeftComponent() {
    return leftComponent;
}

void SplitPane::setTopComponent(Component* comp) {
    setLeftComponent(comp);
}

Component* SplitPane::getTopComponent() {
    return leftComponent;
}

void SplitPane::setRightComponent(Component* comp) {
    if ( comp == NULL ) {
        if ( rightComponent != NULL ) {
            remove(rightComponent);
            rightComponent = NULL;
        }
    } else {
        add(comp, 1);
    }
}

Component* SplitPane::getRightComponent() {
    return rightComponent;
}

void SplitPane::setBottomComponent(Component* comp) {
    setRightComponent(comp);
}

Component* SplitPane::getBottomComponent() {
    return rightComponent;
}


void SplitPane::setOneTouchExpandable(bool v) {
    divider.setOneTouchExpandable(v);
	repaint();
}

bool SplitPane::isOneTouchExpandable() const {
    return divider.isOneTouchExpandable();
}

void SplitPane::setLastDividerLocation(int newLastLocation) {
    divider.setLastLocation(newLastLocation);
}

int SplitPane::getLastDividerLocation() const {
    return divider.getLastLocation();
}


void SplitPane::setOrientation(SplitPane::Orientation orientation) {
	divider.setVertical(orientation == HORIZONTAL_SPLIT);
	repaint();
}

SplitPane::Orientation SplitPane::getOrientation() const {
	return divider.isVertical() ? HORIZONTAL_SPLIT : VERTICAL_SPLIT;
}

void SplitPane::setContinuousLayout(bool v) {
    divider.setContinuousLayout(v);
}

bool SplitPane::isContinuousLayout() const {
    return divider.isContinuousLayout();
}

void SplitPane::setResizeWeight(double value) {
	assert ( value >=0 && value <= 1 );
	resizeWeight = value;
}

double SplitPane::getResizeWeight() const {
	return resizeWeight;
}

void SplitPane::resetToPreferredSizes() {
}


void SplitPane::setDividerLocation(double proportionalLocation) {
    assert (proportionalLocation >= 0.0 && 
			proportionalLocation <= 1.0);

	int w = getMaximumDividerLocation() - getMinimumDividerLocation();
    setDividerLocation(static_cast<int>(w * proportionalLocation));
}

void SplitPane::setDividerLocation(int location) {
	int oldValue = divider.getLocation();

	divider.setLocation(location);

	if ( peer != NULL ) {
		if ( divider.getLocation() < getMinimumDividerLocation() ) {
			divider.setLocation(getMinimumDividerLocation());
		} else if ( divider.getLocation() > getMaximumDividerLocation() ) {
			divider.setLocation(getMaximumDividerLocation());
		}
		repaint();
	}
	// And update the last divider location.
	setLastDividerLocation(oldValue);
}

int SplitPane::getDividerLocation() const {
	return divider.getLocation();
}

int SplitPane::getMinimumDividerLocation() const {
	int result;
	if ( peer != NULL ) {
		const Insets& insets = getInsets();
		if ( divider.isVertical() ) {
			result = insets.left;
			if ( leftComponent != NULL ) {
				result += leftComponent->getMinimumSize().getWidth();
			}
		} else {
			result = insets.top;
			if ( leftComponent != NULL ) {
				result += leftComponent->getMinimumSize().getHeight();
			}
		}
	} else {
		result = -1;
	}

	return result;
}

int SplitPane::getMaximumDividerLocation() const {
	int result;
	if ( peer != NULL ) {
		const Insets& insets = getInsets();
		if ( divider.isVertical() ) {
			result = getWidth() - insets.left - insets.right - 
				divider.getSize();
			if ( rightComponent != NULL ) {
				result -= rightComponent->getMinimumSize().getWidth();
			}
		} else {
			result = getHeight() - insets.top - insets.bottom - divider.getSize();
			if ( rightComponent != NULL ) {
				result -= rightComponent->getMinimumSize().getHeight();
			}
		}
	} else {
		result = -1;
	}

	return result;
}


void SplitPane::remove(Component* component) {
    if ( component == leftComponent ) {
        leftComponent = NULL;
    } else if ( component == rightComponent ) {
        rightComponent = NULL;
    }

	Container::remove(component);

	repaint();
}

void SplitPane::remove(int index) {
    Component* comp = getComponent(index);

    if (comp == leftComponent) {
        leftComponent = NULL;
    } else if (comp == rightComponent) {
        rightComponent = NULL;
    }

    Container::remove(index);

	repaint();
}

void SplitPane::removeAll() {
	leftComponent = rightComponent = NULL;
//	Container::removeAll();

	Container::remove(1);
	Container::remove(0);

	repaint();
}

void SplitPane::addImpl(Component* comp, 
	const LayoutConstraint& constraint, int index) {
    Component* toRemove = NULL;

	assert ( index == 0 || index == 1 );

    if ( index == 0 ) {
        toRemove = getLeftComponent();
        if (toRemove != NULL) {
            remove(toRemove);
        }
        leftComponent = comp;
    } else if ( index == 1 ) {
        toRemove = getRightComponent();
        if (toRemove != NULL) {
            remove(toRemove);
        }
        rightComponent = comp;
	}

	Container::addImpl(comp, constraint, index);

	repaint();
}

void SplitPane::processMouseEvent(MouseEvent& e) {
	divider.processMouseEvent(e);
	Container::processMouseEvent(e);
}

void SplitPane::processMouseMotionEvent(MouseEvent& e) {
	divider.processMouseEvent(e);
	Container::processMouseMotionEvent(e);
}

void SplitPane::update(Graphics& g) {
	paint(g);
}

void SplitPane::paint(Graphics& g) {
	divider.paint(g);
}


const Color& SplitPane::getDefaultBackground() const {
	return SystemColor::CONTROL;
}

DWORD SplitPane::getWindowStyle() const {
	// must not clip children, otherwise, child windows will clip the
	// resize line while dragging. If the mode is continuous layout,
	// there is no problem, so I may change to mask the WS_CLIPCHILDREN
	// style only when continuous layout is not set.
	return Container::getWindowStyle() & ~WS_CLIPCHILDREN;
}
