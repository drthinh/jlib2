#include <cassert>
#include <limits>

#include <jlib/awt/CardLayout.h>

using namespace jlib::awt;

void CardLayout::addLayoutComponent(LayoutComponent* comp, 
		const LayoutConstraint& constraints) {
	const Constraints& con = static_cast<const Constraints&>(constraints);

	if ( !cards.empty() ) {
		comp->setVisible(false);
	}

	for ( CardList::iterator i=cards.begin(); i != cards.end(); ++i ) {
		if ( i->name == con.getName() ) {
			cards.erase(i);
			break;
		}
	}

	cards.push_back(Card(con.getName(), comp));
}

void CardLayout::removeLayoutComponent(LayoutComponent* comp) {
	for ( CardList::iterator i = cards.begin(); i != cards.end(); ++i ) {
		if ( comp == i->comp ) {
			cards.erase(i);
			break;
		}
	}

	if ( cards.empty() ) {
		currentCard = 0;
	} else {
		currentCard %= cards.size();
	}
}

Dimension CardLayout::preferredLayoutSize(const LayoutContainer* parent) {
	int w = 0;
	int h = 0;
	for ( CardList::iterator i = cards.begin(); i != cards.end(); ++i ) {
		Dimension d = i->comp->getPreferredSize();
		if ( d.width > w ) {
			w = d.width;
		}
		if ( d.height > h ) {
			h = d.height;
		}
	}

	const Insets& insets = parent->getInsets();
	return Dimension(insets.left + insets.right + w + hgap*2,
			insets.top + insets.bottom + h + vgap*2);
}

Dimension CardLayout::minimumLayoutSize(const LayoutContainer* parent) {
	int w = 0;
	int h = 0;
	for ( CardList::iterator i = cards.begin(); i != cards.end(); ++i ) {
		Dimension d = i->comp->getMinimumSize();
		if ( d.width > w ) {
			w = d.width;
		}
		if ( d.height > h ) {
			h = d.height;
		}
	}

	const Insets& insets = parent->getInsets();
	return Dimension(insets.left + insets.right + w + hgap*2,
			insets.top + insets.bottom + h + vgap*2);
}

Dimension CardLayout::maximumLayoutSize(const LayoutContainer*) {
	return Dimension(std::numeric_limits<int>::max(), 
			std::numeric_limits<int>::max());
}

void CardLayout::layoutContainer(LayoutContainer* parent) {
    if ( cards.empty() ) {
		return;
	}

	const Insets& insets = parent->getInsets();

	LayoutComponent* comp = cards[currentCard].comp;
	const Dimension& d = parent->getSize();
	comp->setBounds(hgap + insets.left, vgap + insets.top,
			d.width - (hgap*2 + insets.left + insets.right),
			d.height - (vgap*2 + insets.top + insets.bottom));
	if ( !comp->isVisible() ) {
		comp->setVisible(true);
	}
}

void CardLayout::first(LayoutContainer* parent) {
	assert ( isTarget(parent) );

	show(parent, 0);
}

void CardLayout::next(LayoutContainer* parent) {
	assert ( isTarget(parent) );

	show(parent, (currentCard + 1) % cards.size());
}

void CardLayout::previous(LayoutContainer* parent) {
	assert ( isTarget(parent) );

	show(parent, (currentCard + cards.size() - 1) % cards.size());
}

void CardLayout::last(LayoutContainer* parent) {
	assert ( isTarget(parent) );

	show(parent, cards.size() - 1);
}

void CardLayout::show(LayoutContainer* parent, const String& name) {
	assert ( isTarget(parent) );

	if ( cards[currentCard].name == name ) {
		return;
	}

	for ( CardList::iterator i=cards.begin(); i!=cards.end(); ++i ) {
		if ( i->name == name ) {
			show(parent, std::distance(cards.begin(), i));
		}
	}
}

void CardLayout::show(LayoutContainer* parent, int index) {
	if ( !cards.empty() && currentCard != index ) {
		cards[currentCard].comp->setVisible(false);
		currentCard = index;
		cards[currentCard].comp->setVisible(true);
		parent->validate();
	}
}

bool CardLayout::isTarget(const LayoutContainer* parent) const {
	return parent->getLayout() == static_cast<const LayoutManager*>(this);
}
