#include <win32/win32.h>

#include <jlib/awt/Scrollbar.h>
#include <jlib/awt/SystemColor.h>
#include <jlib/awt/AdjustmentListener.h>
#include <jlib/awt/AdjustmentEvent.h>

#include <cassert>


using namespace jlib::awt;


Scrollbar::Scrollbar(Scrollbar::Orientation orientation, 
		int value, int visible, int minimum, int maximum) {
	init(orientation, value, visible, minimum, maximum);
}

void Scrollbar::init(Scrollbar::Orientation orientation, int value, 
					 int visible, int minimum, int maximum) {
	assert ( orientation == HORIZONTAL || orientation == VERTICAL );

	this->orientation = orientation;
	lineIncrement = 1;
	pageIncrement = 10;

	setValues(value, visible, minimum, maximum);
	oldScrollType = 0;
	oldValue = -1;
}

void Scrollbar::addNotify() {
	Component::addNotify();
	subClassWindow();
	peer_setValues(value, visibleAmount, minimum, maximum);
}

void Scrollbar::setOrientation(Scrollbar::Orientation orientation) {
	if (orientation != this->orientation) {
		this->orientation = orientation;
		if (peer != NULL) {
			removeNotify();
			addNotify();
			invalidate();
		}
	}
}

void Scrollbar::setUnitIncrement(int v) {
	if (peer != NULL) {
		peer_setLineIncrement(v);
	}
}

void Scrollbar::setBlockIncrement(int v) {
	pageIncrement = v;
	if (peer != NULL) {
		peer_setPageIncrement(v);
	}
}

void Scrollbar::setValues(int value, int visible, 
		int minimum, int maximum) {
	if (maximum <= minimum) {
		maximum = minimum + 1;
	}
	if (visible > maximum - minimum) {
		visible = maximum - minimum;
	}
	if (visible < 1) {
		visible = 1;
	}
	if (value < minimum) {
		value = minimum;
	}
	if (value > maximum - visible) {
		value = maximum - visible;
	}

	this->value = value;
	this->visibleAmount = visible;
	this->minimum = minimum;
	this->maximum = maximum;
	if (peer != NULL) {
		peer_setValues(value, visibleAmount, minimum, maximum);
	}
}

void Scrollbar::addAdjustmentListener(AdjustmentListener* l) {
	adjustmentEventDispatcher.addListener(l);
}

void Scrollbar::removeAdjustmentListener(AdjustmentListener* l) {
	adjustmentEventDispatcher.removeListener(l);
}

Dimension Scrollbar::getMinimumSize() const {
	/*int w = ::GetSystemMetrics(SM_CXHTHUMB);
	if (orientation == VERTICAL) {
		return Dimension(w, 50);
	}

	return Dimension(50, w); */
	if (orientation == VERTICAL) {
		return Dimension(15, 50);
	}

	return Dimension(50, 15); 
}

void Scrollbar::fireScrollEvent(AdjustmentEvent::Type code, int value) {
	if ( !( code == oldScrollType && value == oldValue ) &&
			!adjustmentEventDispatcher.empty() ) {
		AdjustmentEvent e(code, value);
		adjustmentEventDispatcher.fireEvent(this, 
				&AdjustmentListener::adjustmentValueChanged, e);
	}
}

void Scrollbar::lineUp(int value) {
	setValue(value);
	fireScrollEvent(AdjustmentEvent::UNIT_DECREMENT, value);
}

void Scrollbar::lineDown(int value) {
	setValue(value);
	fireScrollEvent(AdjustmentEvent::UNIT_INCREMENT, value);
}

void Scrollbar::pageUp(int value) {
	setValue(value);
	fireScrollEvent(AdjustmentEvent::BLOCK_DECREMENT, value);
}

void Scrollbar::pageDown(int value) {
	setValue(value);
	fireScrollEvent(AdjustmentEvent::BLOCK_INCREMENT, value);
}

void Scrollbar::dragBegin(int /*value*/) {
	// New event model event -- not supported yet.
	//	((Scrollbar)target).setValue(value);
	//	postEvent(new Event(target, Event.SCROLL_BEGIN, new Integer(value)));
}

void Scrollbar::dragEnd(int /*value*/) {
	// New event model event -- not supported yet.
	//	((Scrollbar)target).setValue(value);
	//	postEvent(new Event(target, Event.SCROLL_END, new Integer(value)));
} 

void Scrollbar::dragAbsolute(int value) {
	setValue(value);
	fireScrollEvent(AdjustmentEvent::TRACK, value);
}

const Color& Scrollbar::getDefaultForeground() const {
	return SystemColor::CONTROL;
}

const Color& Scrollbar::getDefaultBackground() const {
	return SystemColor::CONTROL_LT_HIGHLIGHT;
}

// peer operations
void Scrollbar::peer_setLineIncrement(int) {
}

void Scrollbar::peer_setPageIncrement(int) {
}

void Scrollbar::peer_setValues(int value, int visibleAmount, 
		int minimum, int maximum) {

	assert ( peer != NULL );

	SCROLLINFO si;
	si.cbSize = sizeof si;
	si.fMask = SIF_POS | SIF_PAGE | SIF_RANGE;
	si.nMin = minimum;
	si.nMax = maximum - 1;
	si.nPage = visibleAmount;
	si.nPos = value;
	::SetScrollInfo(peer, SB_CTL, &si, ::IsWindowEnabled(peer));
}

// WIN32
void Scrollbar::handleScroll(int code, int /*pos*/, bool /*vertical*/) {
	int minVal, maxVal;    // scrollbar range
	int minPos, maxPos;    // thumb positions (max depends on visible amount)
	int curPos, newPos;

	// For drags we have old (static) and new (dynamic) thumb positions
	int dragP = code == SB_THUMBPOSITION || code == SB_THUMBTRACK;

	SCROLLINFO si;
	si.cbSize = sizeof si;
	si.fMask = SIF_POS | SIF_PAGE | SIF_RANGE;

	// From, _Win32 Programming_, by Rector and Newcommer, p. 185:
	// "In some of the older documentation on Win32 scroll bars,
	// including that published by Microsoft, you may read that
	// you *cannot* obtain the scroll position while in a handler.
	// The SIF_TRACKPOS flag was added after this documentation
	// was published.  Beware of this older documentation; it may
	// have other obsolete features."
	if (dragP)
		si.fMask |= SIF_TRACKPOS;

	::GetScrollInfo(peer, SB_CTL, &si);

	curPos = si.nPos;
	minPos = minVal = si.nMin;

	// Upper bound of the range.  Note that adding 1 here is safe
	// and won't cause a wrap, since we have substracted 1 in the
	// SetValues above.
	maxVal = si.nMax + 1;

	// Meaningful maximum position is maximum - visible.
	maxPos = maxVal - si.nPage;

	// XXX: Documentation for SBM_SETRANGE says that scrollbar
	// range is limited by MAXLONG, which is 2**31, but when a
	// scroll range is greater than that, thumbPos is reported
	// incorrectly due to integer arithmetic wrap(s).
	int thumbPos = 0;
	if (dragP) {
		thumbPos = si.nTrackPos;
	}

	// NB: Beware arithmetic wrap when calculating newPos
	switch (code) {
	case SB_LINEUP:
		if ((__int64)curPos - lineIncrement > minPos)
			newPos = curPos - lineIncrement;
		else
			newPos = minPos;
		if (newPos != curPos)
			lineUp(newPos);
		break;

	case SB_LINEDOWN:
		if ((__int64)curPos + lineIncrement < maxPos)
			newPos = curPos + lineIncrement;
		else
			newPos = maxPos;
		if (newPos != curPos)
			lineDown(newPos);
		break;

	case SB_PAGEUP:
		if ((__int64)curPos - pageIncrement > minPos) {
			newPos = curPos - pageIncrement;
		} else {
			newPos = minPos;
		}

		if (newPos != curPos) {
			pageUp(newPos);
		}

		break;

	case SB_PAGEDOWN:
		if ((__int64)curPos + pageIncrement < maxPos) {
			newPos = curPos + pageIncrement;
		} else {
			newPos = maxPos;
		}

		if (newPos != curPos) {
			pageDown(newPos);
		}

		break;

		// In ideal world we should use different callbacks for
		// SB_THUMBTRACK and SB_THUMBPOSITION.  Application usually
		// processes SB_THUMBTRACK (real time scrolling) if it can
		// scroll fast.  If redraw required for scrolling is expensive,
		// application will process SB_THUMBPOSITION.  But java program
		// cannot control this choice via AWT API.

		// Since we do process SB_THUMBTRACK events and since the
		// position reported in the SB_THUMBPOSITION event is the same
		// as in the last SB_THUMBTRACK event, the guard expression
		// below will *always* be false and dragAbsolute shall never be
		// called.  The code below is left here just in case.

	case SB_THUMBPOSITION:	// Drag finished, final position
		if (thumbPos != curPos)
			dragAbsolute(thumbPos);
		break;

	case SB_THUMBTRACK:	// Track the drag in real time
		if (thumbPos != curPos)
			dragAbsolute(thumbPos);
		break;

	case SB_TOP:
		if (minPos != curPos)
			dragAbsolute(minPos);
		break;

	case SB_BOTTOM:
		if (maxPos != curPos)
			dragAbsolute(maxPos);
		break;

	case SB_ENDSCROLL:
		// XXX: this workaround appears to be no longer necessary!
		// Request a redraw at this point to work around problems
		// with page up/down area not being redrawn correctly after
		// multiple sequential scroll events, in a case when Java
		// listeners take long time to complete.
		::InvalidateRect(peer, NULL, TRUE);
		oldScrollType = 0;
		dragEnd(curPos);
		break;

	case 9 /*SB_BEGINSCROLL*/:
		//m_prevCallback = NULL;
		//DoCallback(SbNdragBegin, "(I)V", curPos);
		break;
	}
}

LPCTSTR Scrollbar::getClassName() const {
	return _T("ScrollBar");
}

DWORD Scrollbar::getWindowStyle() const {
	DWORD style = WS_CHILD|WS_CLIPSIBLINGS;
	style |= orientation == VERTICAL ? SBS_VERT : SBS_HORZ;
	return style;
}
