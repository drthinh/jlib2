#include <win32/win32.h>

#include <jlib/awt/MenuItem.h>
#include <jlib/awt/Menu.h>

#include <jlib/awt/InputEvent.h>
#include <jlib/awt/ActionEvent.h>
#include <jlib/awt/ActionListener.h>

#include <jlib/util/id_list.h>

using namespace jlib::awt;


jlib::util::id_list<MenuItem*> MenuItem::cmdIdList(32767);

MenuItem::MenuItem(const String& label, const MenuShortcut& s)
	: label(label), enabled(true), shortcut(s), id(-1) {
}

void MenuItem::addNotify() {
	if (id == -1) {
		peer_createMenuItem();
	}
}

const String& MenuItem::getLabel() const {
	return label;
}

void MenuItem::setLabel(const String& label) {
	this->label = label;
	if (id != -1) {
		peer_setLabel(label);
	}
}

bool MenuItem::isEnabled() const {
	return enabled;
}

void MenuItem::setEnabled(bool b) {
	enabled = true;
	if (id != -1) {
		peer_setEnabled(b);
	}
}

const MenuShortcut& MenuItem::getShortcut() const {
    return shortcut;
}

void MenuItem::setShortcut(const MenuShortcut& s) {
    shortcut = s;
	if (id != -1) {
		peer_setLabel(label);
	}
}

void MenuItem::deleteShortcut() {
	shortcut = MenuShortcut();
	if ( id != -1 ) {
		peer_setLabel(label);
	}
}

void MenuItem::deleteShortcut(MenuShortcut s) {
    if ( s == shortcut ) {
        shortcut = MenuShortcut();
        if (id != -1) {
            peer_setLabel(label);
        }
    }
}

MenuItem* MenuItem::getShortcutMenuItem(MenuShortcut s) {
    return s == shortcut ? this : NULL;
}


void MenuItem::setActionCommand(const String& command) {
    actionCommand = command;
}

const String& MenuItem::getActionCommand() const {
    return actionCommand.empty() ? label : actionCommand;
}

void MenuItem::addActionListener(ActionListener* l) {
	actionEventDispatcher.addListener(l);
}

void MenuItem::removeActionListener(ActionListener* l) {
	actionEventDispatcher.removeListener(l);
}

Menu* MenuItem::getParentMenu() {
	return const_cast<Menu*>(static_cast<const Menu*>(getParent()));
}

void MenuItem::handleCommand() {
	int modifiers = 0;
	if (HIBYTE(::GetAsyncKeyState(VK_CONTROL))) {
		modifiers |= InputEvent::CTRL_MASK;
	}
	if (HIBYTE(::GetAsyncKeyState(VK_RBUTTON))) {
		modifiers |= InputEvent::META_MASK;
	}
	if (HIBYTE(::GetAsyncKeyState(VK_SHIFT))) {
		modifiers |= InputEvent::SHIFT_MASK;
	}
	if (HIBYTE(::GetAsyncKeyState(VK_MBUTTON))) {
		modifiers |= InputEvent::ALT_MASK;
	}

	doMenuEvent(modifiers);
}

void MenuItem::doMenuEvent(int modifiers) {
	if ( !actionEventDispatcher.empty() ) {
		actionEventDispatcher.fireEvent(this, 
			&ActionListener::actionPerformed, 
			ActionEvent(getLabel(), modifiers));
	}
}

MenuItem* MenuItem::getFromId(int id) {
	return cmdIdList.lookup(id);
}

bool MenuItem::isSeparator() const {
	return getLabel() == _T("-");
}

// peer operations

void MenuItem::peer_createMenuItem() {
	id = cmdIdList.add(this);
	assert ( id != -1 );

	HMENU hmenu = getParentMenu()->getPeer();
	UINT flags = MF_BYPOSITION|MF_STRING;
	if ( label == _T("-") ) {
		flags |= MF_SEPARATOR;
		::AppendMenu(hmenu, flags, 0, NULL);
	} else {
		::AppendMenu(hmenu, flags, id, label.c_str());
	}
}

void MenuItem::peer_setLabel(const String& label) {

	assert ( id != -1 );

    MENUITEMINFO mii, mii1;
    memset(&mii, 0, sizeof(MENUITEMINFO));
    mii.cbSize = sizeof(MENUITEMINFO);
    mii.fMask = MIIM_CHECKMARKS | MIIM_DATA | MIIM_ID
              | MIIM_STATE | MIIM_SUBMENU | MIIM_TYPE;

	HMENU hmenu = getParentMenu()->getPeer();

    ::GetMenuItemInfo(hmenu, getId(), FALSE, &mii);

	mii.cch = (UINT)label.length();
    mii.dwTypeData = (LPTSTR)label.data();

    // find index by menu item id
    int nMenuItemCount = ::GetMenuItemCount(hmenu);
	int idx;
    for (idx = 0; idx < nMenuItemCount; ++idx) {
		memset(&mii1, 0, sizeof(MENUITEMINFO));
        mii1.cbSize = sizeof mii1;
        mii1.fMask = MIIM_ID;
        ::GetMenuItemInfo(hmenu, idx, TRUE, &mii1);
        if (mii.wID == mii1.wID) 
			break;
    }

    ::RemoveMenu(hmenu, idx, MF_BYPOSITION);
    ::InsertMenuItem(hmenu, idx, TRUE, &mii);
}

void MenuItem::peer_setEnabled(bool b) {
	assert ( id != -1 );
	HMENU hmenu = getParentMenu()->getPeer();
	::EnableMenuItem(hmenu, getId(),
		MF_BYCOMMAND | (b ? MF_ENABLED : MF_GRAYED));
}

void MenuItem::peer_dispose() {
	cmdIdList.remove(id);
	id = -1;
}
