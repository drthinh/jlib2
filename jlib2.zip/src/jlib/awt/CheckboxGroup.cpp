#include <win32/win32.h>

#include <jlib/awt/CheckboxGroup.h>
#include <jlib/awt/Checkbox.h>

namespace jlib { namespace awt {

CheckboxGroup::CheckboxGroup() 
	: selectedCheckbox(NULL) {
}

void CheckboxGroup::setSelectedCheckbox(Checkbox* box) {
	if (box != NULL && box->group != this) {
		return;
	}

	Checkbox* oldChoice = selectedCheckbox;
	selectedCheckbox = box;
	if ( oldChoice != NULL && oldChoice != box ) {
		oldChoice->setState(false);
	}
	if (box != NULL && oldChoice != box && !box->getState()) {
		box->setStateInternal(true);
	}
}

}}
