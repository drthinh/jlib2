#include <win32/win32.h>

#include <cassert>

#include <jlib/awt/imp/GdiObj.h>

using jlib::awt::Color;

using namespace jlib::awt::imp;

Pen::~Pen() {
	if ( peer != NULL ) {
		::DeleteObject(peer);
	}
}

HPEN Pen::get() const {
	if ( peer == NULL ) {
		peer = (HPEN)::CreatePen(PS_SOLID, 1, color.getRGB());
		assert ( peer != NULL );
	}

	return peer;
}

void Pen::setColor(Color c) {
	if ( color != c ) {
		color = c;
		if ( peer != NULL ) {
			::DeleteObject(peer);
			peer = NULL;
		}
	}
}

HPEN Pen::getPredefined(int index) {
	HPEN result = (HPEN)::GetStockObject(index);
	assert( result != NULL );
	return result;
}

Brush::~Brush() {
	if ( peer != NULL ) {
		::DeleteObject(peer);
	}
}

void Brush::setColor(Color c) {
	if ( color != c ) {
		color = c;
		if ( peer != NULL ) {
			::DeleteObject(peer);
			peer = NULL;
		}
	}
}

HBRUSH Brush::get() const {
	if ( peer == NULL ) {
		peer = (HBRUSH)::CreateSolidBrush(color.getRGB());
		assert ( peer != NULL );
	}

	return peer;
}

HBRUSH Brush::getPredefined(int index) {
	HBRUSH result = (HBRUSH)::GetStockObject(index);
	assert( result != NULL );
	return result;
}
