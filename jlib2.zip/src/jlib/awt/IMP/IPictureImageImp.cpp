#define STRICT

#define NOSERVICE
#define NOMCX
#define NOIME
#define NOSOUND
#define NOCOMM
#define NORPC

#define NOMINMAX
#include <windows.h>

#ifdef TEXT
#undef TEXT
#endif

#include <jlib/awt/imp/IPictureImageImp.h>
#include <jlib/awt/imp/DCGraphics.h>

#include <ole2.h>
#include <wtypes.h>
#include <olectl.h> // for OleLoadPicture

#include <stdexcept>
#include <cassert>

using jlib::lang::String;
using jlib::awt::Dimension;
using jlib::awt::image::ImageObserver;

using namespace jlib::awt::imp;

namespace {

	class FileStream : public IStream {
	public:
		FileStream(const TCHAR* fileName) {
			file = ::CreateFile(fileName, GENERIC_READ, 
				FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
			if (!file) {
				throw std::runtime_error("cannot open file");
			}
		}

		virtual ~FileStream() {
			::CloseHandle(file);
		}

		HRESULT STDMETHODCALLTYPE 
		QueryInterface(REFIID riid, void **ppvObject) {
			if (riid == IID_IStream || riid == IID_IUnknown) {
				*ppvObject = this;
			} else {
				return E_NOINTERFACE;
			}

			return S_OK;
		}

		ULONG STDMETHODCALLTYPE AddRef() { return 1; }

		ULONG STDMETHODCALLTYPE Release() { return 1; }

		HRESULT STDMETHODCALLTYPE Read(void *pv, ULONG cb, ULONG *pcbRead) {
			BOOL r = ReadFile(file, pv, cb, pcbRead, NULL);
			return r ? S_OK : S_FALSE;
		}

		HRESULT STDMETHODCALLTYPE
		Write(const void*, ULONG, ULONG*) { return E_NOTIMPL; }

		HRESULT STDMETHODCALLTYPE Seek(LARGE_INTEGER move, 
			DWORD origin, ULARGE_INTEGER *newPos) {
			DWORD moveMethod;
			switch (origin) {
			case STREAM_SEEK_SET:
				moveMethod = FILE_BEGIN;
				break;
			case STREAM_SEEK_CUR:
				moveMethod = FILE_CURRENT;
				break;
			case STREAM_SEEK_END:
				moveMethod = FILE_END;
				break;
			default:
				assert (false);
			}
			BOOL r = ::SetFilePointerEx(file, move, 
					(PLARGE_INTEGER)newPos, moveMethod);
			return r ? S_OK : S_FALSE;
		}

		HRESULT STDMETHODCALLTYPE
		SetSize(ULARGE_INTEGER) { return E_NOTIMPL; }

		HRESULT STDMETHODCALLTYPE
		CopyTo(IStream*, ULARGE_INTEGER, ULARGE_INTEGER*, ULARGE_INTEGER*) 
		{ return E_NOTIMPL; }

		HRESULT STDMETHODCALLTYPE
		Commit(DWORD) { return E_NOTIMPL; }

		HRESULT STDMETHODCALLTYPE
		Revert() { return E_NOTIMPL; }

		HRESULT STDMETHODCALLTYPE
		LockRegion(ULARGE_INTEGER, ULARGE_INTEGER, DWORD) 
		{ return E_NOTIMPL; }

		HRESULT STDMETHODCALLTYPE
		UnlockRegion(ULARGE_INTEGER, ULARGE_INTEGER, DWORD) 
		{ return E_NOTIMPL; }

		HRESULT STDMETHODCALLTYPE
		Stat(STATSTG*, DWORD) { return E_NOTIMPL; }

		HRESULT STDMETHODCALLTYPE
		Clone(IStream**) { return E_NOTIMPL; }

	private:
		HANDLE file;
	};
}

IPictureImageImp::IPictureImageImp(const String& name) {
	assert (!name.empty());

	FileStream fs(name.c_str());
	HRESULT hr = ::OleLoadPicture(&fs, 0, FALSE, IID_IPicture, (void**)&pic);
	if (hr != S_OK) {
		throw std::runtime_error("load picture failed");
	}

	initSizes();
}

IPictureImageImp::~IPictureImageImp() {
	pic->Release();
}

int IPictureImageImp::getWidth(ImageObserver* /*observer*/) const {
	return size.width;
}

int IPictureImageImp::getHeight(ImageObserver* /*observer*/) const {
	return size.height;
}

bool IPictureImageImp::drawTo(HDC dc, 
		int x, int y, ImageObserver* /*observer*/) const {
	HRESULT hr = pic->Render(dc, x, y, size.width, size.height, 
		0, hmSize.height, hmSize.width, -hmSize.height, NULL);
	assert ( SUCCEEDED(hr) );

	return true;
}

HICON IPictureImageImp::getHICON() const {
	HRESULT hr;
#ifndef NDEBUG
	short type;
	hr = pic->get_Type(&type);
	assert ( SUCCEEDED(hr) );
	assert ( type == PICTYPE_ICON );
#endif
	OLE_HANDLE handle;
	hr = pic->get_Handle(&handle);
	assert ( SUCCEEDED(hr) );

	return reinterpret_cast<HICON>(handle);
}

void IPictureImageImp::initSizes() {
	HDC hdc = ::GetDC(NULL);

	OLE_XSIZE_HIMETRIC width;
	HRESULT hr = pic->get_Width(&width);
	assert ( SUCCEEDED(hr) );

	OLE_YSIZE_HIMETRIC height;
	hr = pic->get_Height(&height);
	assert ( SUCCEEDED(hr) );

	hmSize.setSize(width, height);
	size = hmSize;
	HMToDevice(hdc, &size);

	::ReleaseDC(NULL, hdc);
}

void IPictureImageImp::HMToDevice(HDC dc, Dimension* d) {
	int cxPerInch = ::GetDeviceCaps(dc, LOGPIXELSX);
	int cyPerInch = ::GetDeviceCaps(dc, LOGPIXELSY);

	const int HIMETRIC_INCH = 2540;
	d->width = ::MulDiv(d->width, cxPerInch, HIMETRIC_INCH);
	d->height = ::MulDiv(d->height, cyPerInch, HIMETRIC_INCH);
}
