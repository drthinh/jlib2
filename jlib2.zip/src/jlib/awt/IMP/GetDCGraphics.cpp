#include <win32/win32.h>

#include <cassert>

#include <jlib/verify.h>

#include <jlib/awt/Component.h>
#include <jlib/awt/imp/GetDCGraphics.h>

using namespace jlib::awt::imp;

using jlib::awt::Component;

GetDCGraphics::GetDCGraphics(const Component* target) 
	: DCGraphics(::GetDC(target == NULL ? NULL : target->getPeer())),
	target(target) {

	assert ( getPeer() != NULL );

	setColor(target->getForeground());
	setBackground(target->getBackground());

	Font font = target->getFont();
	if ( !font ) {
		setFont(font);
	}
}

GetDCGraphics::~GetDCGraphics() {
//	verify ( ::GdiFlush() );
	verify ( ::ReleaseDC(target->getPeer(), getPeer()) );
}
