#include <win32/win32.h>
#include <cassert>
#include <cmath>

#include <jlib/awt/imp/DCGraphics.h>

#include <jlib/verify.h>

#include <jlib/awt/Image.h>
#include <jlib/awt/image/ImageObserver.h>
#include <jlib/awt/imp/IPictureImageImp.h>

#include <jlib/awt/FontMetrics.h>

using namespace jlib::awt::imp;

using jlib::lang::String;
using jlib::awt::Color;
using jlib::awt::Image;
using jlib::awt::image::ImageObserver;
using jlib::awt::Font;
using jlib::awt::FontMetrics;

DCGraphics::DCGraphics(HDC peer)
	: foreColor(Color::WHITE), backColor(Color::BLACK),
	forePen(foreColor), backPen(backColor), 
	foreBrush(foreColor), backBrush(backColor) {
	if ( peer != NULL ) {
		setPeer(peer);
	}
}

void DCGraphics::setColor(Color c) {
	assert ( peer != NULL );

	if ( foreColor != c ) {
		foreColor = c;
		::SetTextColor(peer, c.getRGB());
		forePen.setColor(c);
		foreBrush.setColor(c);
	}
}

void DCGraphics::setBackground(Color c) {
	assert ( peer != NULL );

	if ( backColor != c ) {
		backColor = c;
		backPen.setColor(c);
		backBrush.setColor(c);
	}
}

void DCGraphics::setFont(const Font& f) {
	font = f;

	if ( peer != NULL ) {
		::SelectObject(peer, font.getPeer());
	}
}

const Font& DCGraphics::getFont() const {
	if ( !font ) {
		const_cast<DCGraphics*>(this)->setFont(
				Font(_T("MS Sans Serif"), Font::PLAIN, 12));
	}

	return font;
}

void DCGraphics::drawLine(int x1, int y1, int x2, int y2) {
	DCSelector pen(peer, forePen.get());
	verify ( ::MoveToEx(peer, x1, y1, NULL) );
	verify ( ::LineTo(peer, x2, y2) );
}

void DCGraphics::drawRect(int x, int y, int width, int height) {
	assert ( peer != NULL );

	DCSelector pen(peer, forePen.get());

	HGDIOBJ brush = ::GetStockObject(HOLLOW_BRUSH);
	HGDIOBJ oldBrush = ::SelectObject(peer, brush);

	verify ( ::Rectangle(peer, x, y, x + width, y + height) );

	::SelectObject(peer, oldBrush);
}

void DCGraphics::fillRect(int x, int y, int width, int height) {
	assert ( peer != NULL );

	DCSelector pen(peer, forePen.get());
	DCSelector brush(peer, foreBrush.get());

	//::FillRect(peer, &r, brush);
	verify ( ::Rectangle(peer, x, y, x + width, y + height) );
}

void DCGraphics::clearRect(int x, int y, int width, int height) {
	assert ( peer != NULL );

	Color fore = getColor();

	setColor(getBackground());

	fillRect(x, y, width, height);

	setColor(fore);
}

void DCGraphics::draw3DRect(int x, int y, 
		int width, int height, bool raised) {

	Color c = getColor();
	Color brighter = c.brighter();
	Color darker = c.darker();

	setColor(raised ? brighter : darker);
	drawLine(x, y, x, y + height);
	drawLine(x + 1, y, x + width - 1, y);
	setColor(raised ? darker : brighter);
	drawLine(x + 1, y + height, x + width, y + height);
	drawLine(x + width, y, x + width, y + height - 1);
	setColor(c);
}

void DCGraphics::fill3DRect(int x, int y, 
		int width, int height, bool raised) {
	Color c = getColor();
	Color brighter = c.brighter();
	Color darker = c.darker();

	if (!raised) {
	    setColor(darker);
	}

	fillRect(x+1, y+1, width-2, height-2);
	setColor(raised ? brighter : darker);
	drawLine(x, y, x, y + height - 1);
	drawLine(x + 1, y, x + width - 2, y);
	setColor(raised ? darker : brighter);
	drawLine(x + 1, y + height - 1, x + width - 1, y + height - 1);
	drawLine(x + width - 1, y, x + width - 1, y + height - 2);
	setColor(c); 
}

void DCGraphics::angleToCoord(int angle, int width, int height, 
							  int *x, int *y) {
	const double PI = 3.1415926535;
	const double RADIAN1 = 2 * PI / 360;

	*x = (int)(std::cos((double)angle * RADIAN1) * width) + width/2;
	*y = -(int)(std::sin((double)angle * RADIAN1) * height) + height/2; 
}

void DCGraphics::arc(int x, int y, int width, int height,
		int startAngle, int arcAngle, bool fill) {

	if ( width <= 0 || height <= 0 || arcAngle == 0 ) {
		return;
	}

	int radialx1, radialy1, radialx2, radialy2;
	if ( arcAngle >= 360 || arcAngle <= -360 ) {
		radialx1 = radialx2 = x;// + width;
		radialy1 = radialy2 = y;// + height / 2;
	} else {
		int endAngle = arcAngle + startAngle;
		if ( endAngle < startAngle ) {
			std::swap(startAngle, endAngle);
		}

		angleToCoord(startAngle, width, height, &radialx1, &radialy1);
		radialx1 += x;
		radialy1 += y;

		angleToCoord(endAngle, width, height, &radialx2, &radialy2);
		radialx2 += x;
		radialy2 += y;
	}

	BOOL (WINAPI* arcFun)(HDC, int, int, int, int, int, int, int, int);
	HGDIOBJ obj;

	if ( fill ) {
		obj = foreBrush.get();
		arcFun = &::Pie;
	} else {
		obj = forePen.get();
		arcFun = &::Arc;
	}

	DCSelector sel(peer, obj);

	verify ( arcFun(peer, x, y, x+width+1, y+height+1,
			radialx1, radialy1, radialx2, radialy2));
}

void DCGraphics::drawArc(int x, int y, int width, int height,
						 int startAngle, int arcAngle) {
	arc(x, y, width, height, startAngle, arcAngle, false); 
}

void DCGraphics::fillArc(int x, int y, int width, int height,
						 int startAngle, int arcAngle) {
	arc(x, y, width, height, startAngle, arcAngle, true); 
}

void DCGraphics::fillPolygon(
		const int* xPoints, const int* yPoints, int nPoints) {
	assert ( peer != NULL );

	POINT *pts = new POINT[nPoints];
	for ( int i=0; i<nPoints; ++i ) {
		pts[i].x = xPoints[i];
		pts[i].y = yPoints[i];
	}

	DCSelector brush(peer, foreBrush.get());
	verify ( ::Polygon(peer, pts, nPoints) );
	delete[] pts;
}

bool DCGraphics::drawImage(const Image& img, 
		int x, int y, ImageObserver* observer) {
	assert ( peer != NULL );

	const IPictureImageImp& imp = static_cast<const IPictureImageImp&>(img);
	return imp.drawTo(peer, x, y, observer);
}

void DCGraphics::drawString(const String& str, int x, int y) {
	drawChars(str.data(), 0, static_cast<int>(str.length()), x, y); 
}

void DCGraphics::drawChars(const TCHAR* chars, 
		int off, int len, int x, int y) {
	verify( ::TextOut(peer, x, y, chars + off, len) );
}

void DCGraphics::setClip(int x, int y, int width, int height) {
	verify ( ::SelectClipRgn(peer, NULL) != ERROR );
	verify ( ::IntersectClipRect(peer, x, y, x+width, y+height) != ERROR );
}

void DCGraphics::clipRect(int x, int y, int width, int height) {
	verify ( ::IntersectClipRect(peer, x, y, x+width, y+height) != ERROR );
}

jlib::awt::Rectangle DCGraphics::getClipBounds() const {
	RECT r;
	verify ( ::GetClipBox(peer, &r) != ERROR );
	return Rectangle(r.left, r.top, r.right - r.left, r.bottom - r.top);
}

void DCGraphics::setXORMode(Color /*c*/) {
	assert ( peer != NULL);

	verify ( ::SetROP2(peer, R2_XORPEN) != 0 );
}

void DCGraphics::setPaintMode() {
	assert ( peer != NULL);

	verify ( ::SetROP2(peer, R2_COPYPEN) != 0 );
}

void DCGraphics::translate(int x, int y) {
	assert ( peer != NULL);

	verify ( ::SetViewportOrgEx(peer, x, y, NULL) );
}

void DCGraphics::setPeer(HDC dc) {
	assert ( dc != NULL );

	peer = dc;
	verify ( ::SetTextAlign(peer, TA_BASELINE) != GDI_ERROR );
	verify ( ::SetBkMode(peer, TRANSPARENT) != 0 );
}
