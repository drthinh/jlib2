#include <win32/win32.h>
#include <jlib/awt/FontMetrics.h>

using namespace jlib::awt;

int FontMetrics::getLeading() const {
	return leading;
}

int FontMetrics::getAscent() const {
	return ascent;
}

int FontMetrics::getDescent() const {
	return descent;
}

int FontMetrics::getHeight() const {
	return getLeading() + getAscent() + getDescent();
}

int FontMetrics::getMaxAscent() const {
	return getAscent();
}

int FontMetrics::getMaxDescent() const {
	return getDescent();
}

int FontMetrics::getMaxAdvance() const {
	return -1;
}

int FontMetrics::charWidth(TCHAR ch) const {
	return charsWidth(&ch, 0, 1);
}

int FontMetrics::stringWidth(const String& str) const {
	return charsWidth(str.data(), 0, static_cast<int>(str.length()));
}

int FontMetrics::charsWidth(const TCHAR* data, int off, int len) const {
	HDC dc = ::GetDC(NULL);
	HGDIOBJ oldFont = ::SelectObject(dc, font.getPeer());

	SIZE size;
	::GetTextExtentPoint32(dc, data + off, len, &size);
	::SelectObject(dc, oldFont);

	::ReleaseDC(NULL, dc);

	return size.cx;
}

FontMetrics::FontMetrics(const Font& font) 
	: font(font) {

	HDC dc = ::GetDC(NULL);

	HGDIOBJ oldFont = ::SelectObject(dc, font.getPeer());

	TEXTMETRIC tm;
	::GetTextMetrics(dc, &tm);
	ascent = tm.tmAscent;
	descent = tm.tmDescent;
	leading = tm.tmExternalLeading;

	::SelectObject(dc, oldFont);

	::ReleaseDC(NULL, dc);
}
