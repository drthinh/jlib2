#include <win32/win32.h>

#include <jlib/awt/CheckboxMenuItem.h>
#include <jlib/awt/Menu.h>

#include <jlib/awt/ItemListener.h>
#include <jlib/awt/ItemEvent.h>

#include <cassert>

using namespace jlib::awt;

CheckboxMenuItem::CheckBitmap CheckboxMenuItem::checkBitmap;

CheckboxMenuItem::CheckBitmap::CheckBitmap() 
	: bitmap(NULL) {
}

CheckboxMenuItem::CheckBitmap::~CheckBitmap() {
	if (bitmap) {
		::DeleteObject(bitmap);
	}
}

HBITMAP CheckboxMenuItem::CheckBitmap::getBitmap() const {
	if (bitmap == NULL) {
		static const BYTE bmpBits[] = {
			0xff, 0xf8, 0, 0,
			0xff, 0xf8, 0, 0,
			0xff, 0xf8, 0, 0,
			0xff, 0x78, 0, 0,
			0xfe, 0x78, 0, 0,
			0xdc, 0x78, 0, 0,
			0xc8, 0xf8, 0, 0,
			0xc1, 0xf8, 0, 0,
			0xe3, 0xf8, 0, 0,
			0xf7, 0xf8, 0, 0,
			0xff, 0xf8, 0, 0,
			0xff, 0xf8, 0, 0,
			0xff, 0xf8, 0, 0
		};

		static const BITMAP bmp = {
			0, //bmType
			13, // bmWidth
			13, // bmHeight,
			4, // bmWidthBytes, bytes per scan line
			1, // bmPlanes
			1, // bmBitsPixel
			(LPVOID)bmpBits
		};

		//bitmap = ::LoadBitmap(hmod, _T("CHECK"));
		bitmap = ::CreateBitmapIndirect(&bmp);

		assert (bitmap != NULL);
	}

	return bitmap;
}

CheckboxMenuItem::CheckboxMenuItem(const String& label, bool state)
	: MenuItem(label), state(state) {
}

void CheckboxMenuItem::addNotify() {
	MenuItem::addNotify();
	peer_setState(state);
}

void CheckboxMenuItem::setState(bool b) {
	state = b;
	if (id != -1) {
		peer_setState(b);
	}
}

void CheckboxMenuItem::addItemListener(ItemListener* l) {
	itemEventDispatcher.addListener(l);
}

void CheckboxMenuItem::removeItemListener(ItemListener* l) {
	itemEventDispatcher.removeListener(l);
}

void CheckboxMenuItem::doMenuEvent(int /*modifiers*/) {
	setState(!state);
	if (!itemEventDispatcher.empty()) {
		ItemEvent e(getLabel(),
				state ? ItemEvent::SELECTED : ItemEvent::DESELECTED);
		itemEventDispatcher.fireEvent(this, 
				&ItemListener::itemStateChanged, e);
	}
}

// peer operations
void CheckboxMenuItem::peer_setState(bool b) {
	assert (id != -1);

	const Menu* pm = getParentMenu();
	if (pm != NULL) {
		HMENU hmenu = getParentMenu()->getPeer();
		if (hmenu != NULL) {
			::SetMenuItemBitmaps(hmenu, id, MF_BYCOMMAND, NULL, 
					checkBitmap.getBitmap());
			::CheckMenuItem(hmenu, id, 
					MF_BYCOMMAND | ( b ? MF_CHECKED : MF_UNCHECKED));
		}
	}
}
