#include <win32/win32.h>
#include <commctrl.h>

#include <jlib/awt/Table.h>

using namespace jlib::awt;

Table::Table(int rows, int columns) {
}

void Table::addNotify() {
	Component::addNotify();
	subClassWindow();
}

DWORD Table::getWindowStyle() const {
	return WS_CHILD|WS_TABSTOP|WS_CLIPCHILDREN|LVS_REPORT;
}

LPCTSTR Table::getClassName() const {
	return WC_LISTVIEW;
}
