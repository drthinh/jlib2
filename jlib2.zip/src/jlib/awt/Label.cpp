#include <win32/win32.h>
#include <cassert>

#include <jlib/awt/Label.h>
#include <jlib/awt/Container.h>

using jlib::lang::String;

using namespace jlib::awt;

Label::Label(const String& text, Alignment alignment)
	: alignment(alignment) {
	this->text = text;
}

Label::~Label() {
}

void Label::addNotify() {
	Component::addNotify();
	subClassWindow();

	setText(text);
}

void Label::setAlignment(Alignment v) {
	if ( alignment != v ) {
		alignment = v;
		if ( peer != NULL ) {
			DWORD align = 0;
			switch ( alignment ) {
			case Label::LEFT:
				align = SS_LEFT;
				break;
			case Label::CENTER:
				align = SS_CENTER;
				break;
			case Label::RIGHT:
				align = SS_RIGHT;
				break;
			default:
				assert ( false );
			}

			DWORD dwStyle = ::GetWindowLong(peer, GWL_STYLE);
			dwStyle &= ~(SS_LEFT|SS_CENTER|SS_RIGHT);
			dwStyle |= align;
			::SetWindowLong(peer, GWL_STYLE, dwStyle);
		}
	}
}

void Label::setText(const String& v) {
	if ( text != v ) {
		text = v;
		if ( peer != NULL ) {
			::SetWindowText(peer, getText().c_str());
		}

		if ( valid ) {
			invalidate();
		}
	}
}

Dimension Label::getPreferredSize() const {
	if ( !valid ) {
		FontMetrics fm = getFontMetrics();
		prefSize.width = fm.stringWidth(text) + 14;
		prefSize.height = fm.getHeight() + 8;
	}

	return prefSize;
}

void Label::drawItem(DRAWITEMSTRUCT *di) {
	COLORREF oldBk = ::SetBkColor(di->hDC, getBackground().getRGB());
	COLORREF oldText = ::SetTextColor(di->hDC, getForeground().getRGB());

	int textLen = static_cast<int>(text.length());

	SIZE size;
	::GetTextExtentPoint32(di->hDC, text.data(), textLen, &size);

	::FillRect(di->hDC, &di->rcItem, getBackgroundBrush());
	int y = (di->rcItem.top + di->rcItem.bottom - size.cy) / 2;
	int x = 0;
	switch (alignment) {
	case LEFT:
		x = di->rcItem.left + 2;
		break;
	case CENTER:
		x = (di->rcItem.left + di->rcItem.right - size.cx) / 2;
		break;
	case RIGHT:
		x = di->rcItem.right - 2 - size.cx;
		break;
	default:
		assert ( false );
	}

	if ( (di->itemState & ODS_DISABLED) == 0 ) {
		::TextOut(di->hDC, x, y, text.data(), textLen);
	} else {
		COLORREF oldColor = ::SetTextColor(di->hDC, 
				::GetSysColor(COLOR_BTNHILIGHT));
		int oldMode = ::SetBkMode(di->hDC, TRANSPARENT);
		::TextOut(di->hDC, x + 1, y + 1, text.data(), textLen);
		::SetTextColor(di->hDC, ::GetSysColor(COLOR_BTNSHADOW));
		::TextOut(di->hDC, x, y, text.data(), textLen);

		::SetBkMode(di->hDC, oldMode);
		::SetTextColor(di->hDC, oldColor);
	}

	::SetTextColor(di->hDC, oldText);
	::SetBkColor(di->hDC, oldBk);
}

DWORD Label::getWindowStyle() const {
	DWORD dwStyle = WS_CHILD|WS_CLIPSIBLINGS|SS_OWNERDRAW;
	DWORD align = 0;
	switch ( alignment ) {
	case Label::LEFT:
		align = SS_LEFT;
		break;
	case Label::CENTER:
		align = SS_CENTER;
		break;
	case Label::RIGHT:
		align = SS_RIGHT;
		break;
	default:
		// improper alignment
		assert ( false );
	}

	return dwStyle|align;
}

LPCTSTR Label::getClassName() const {
	return _T("Static");
}
