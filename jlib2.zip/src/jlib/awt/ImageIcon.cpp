#include <win32/win32.h>

#include <jlib/awt/ImageIcon.h>
#include <jlib/awt/imp/IPictureImageImp.h>
#include <jlib/awt/Graphics.h>
#include <jlib/awt/Component.h>

using namespace jlib::awt;

ImageIcon::ImageIcon(const jlib::lang::String& filename) {
	image = new jlib::awt::imp::IPictureImageImp(filename);
	owned = true;
}

ImageIcon::ImageIcon(Image* image) 
	: image(image) {
}

int ImageIcon::getIconWidth() const {
	return image->getWidth(NULL);
}

int ImageIcon::getIconHeight() const {
	return image->getHeight(NULL);
}

void ImageIcon::paintIcon(Component* c, Graphics* g, int x, int y) const {
	if ( c != NULL ) {
		g->setColor(c->getForeground());
	}

	g->drawImage(*image, x, y, NULL);
}

ImageIcon::~ImageIcon() {
	if ( owned ) {
		delete image;
	}
}
