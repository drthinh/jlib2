#include <win32/win32.h>

#include <jlib/awt/List.h>

#include <jlib/awt/ItemEvent.h>
#include <jlib/awt/ItemListener.h>
#include <jlib/awt/ActionListener.h>
#include <jlib/awt/ActionEvent.h>
#include <jlib/awt/SystemColor.h>
#include <jlib/awt/Container.h>

#include <jlib/util/EventDispatcher.h>

#include <algorithm>
#include <cassert>

using jlib::lang::String;


using namespace jlib::awt;

void List::addNotify() {
	Component::addNotify();
	subClassWindow();
	visibleIndex = -1;
	if ( !items.empty() ) {
		ItemsList::iterator i;
		for ( i = items.begin(); i != items.end(); ++i ) {
			::SendMessage(peer, LB_ADDSTRING, 0, 
				reinterpret_cast<LPARAM>(i->c_str()));
		}

		if ( !selected.empty() ) {
			SelectedList::iterator j;
			for ( j = selected.begin(); j != selected.end(); ++j ) {
				::SendMessage(peer, LB_SETSEL, TRUE, *j);
			}
		}
	}
}

void List::removeNotify() {
	if ( peer != NULL ) {
		selected = getSelectedIndexes();
	}

	Component::removeNotify();
}

void List::add(const String& item) {
	add(item, -1);
}

void List::add(const String& item, int index) {
	if (index < -1 || index >= static_cast<int>(items.size())) {
		index = -1;
	}

	if (index == -1) {
		items.push_back(item);
	} else {
		items.insert(items.begin() + index, item);
	}

	if ( peer != NULL ) {
		::SendMessage(peer, LB_INSERTSTRING, index, 
			reinterpret_cast<LPARAM>(item.c_str()));
	}
}

void List::replaceItem(const String& newValue, int index) {
	remove(index);
	add(newValue, index);
}

void List::removeAll() {
	items.clear();
	selected.clear();
	if ( peer != NULL ) {
		::SendMessage(peer, LB_RESETCONTENT, 0, 0);
	}
}

void List::remove(const String& item) {
	ItemsList::iterator i = std::find(items.begin(), items.end(), item);
	if ( i != items.end() ) {
		remove(static_cast<int>(std::distance(items.begin(), i)));
	}
}

void List::remove(int position) {
	delItems(position, position);
}

int List::getSelectedIndex() const {
	getSelectedIndexes();
	return selected.size() == 1 ? selected[0] : -1;
}

List::SelectedList List::getSelectedIndexes() const {
	if ( peer != NULL ) {
		SelectedList& selected = const_cast<List*>(this)->selected;
		if ( !multipleMode ) {
			selected.clear();
			int curSel = static_cast<int>(
					::SendMessage(peer, LB_GETCURSEL, 0, 0));
			if ( curSel != LB_ERR ) {
				selected.push_back(curSel);
			}
		} else {
			int* buffer = new int[items.size()];
			int result = static_cast<int>(
					::SendMessage(peer, LB_GETSELITEMS, 
							static_cast<WPARAM>(items.size()), 
							reinterpret_cast<LPARAM>(buffer)));
			if ( result == LB_ERR ) {
				selected.clear();
			} else {
				selected.assign(buffer, buffer + result);
			}

			delete buffer;
		}
	}

	return selected;
}

String List::getSelectedItem() const {
	int index = getSelectedIndex();
	return index < 0 ? _T("") : getItem(index);
}

List::ItemsList List::getSelectedItems() const {
	ItemsList result;
	SelectedList::const_iterator i;
	for ( i = selected.begin(); i != selected.end(); ++i ) {
		result.push_back(getItem(*i));
	}

	return result;
}

void List::select(int index) {

	if ( peer != NULL ) {
		::SendMessage(peer, LB_SETSEL, TRUE, index);
	}

	bool alreadySelected = false; 

	SelectedList::iterator i;
	for (i = selected.begin() ; i != selected.end(); ++i) { 
		if ( *i == index ) {
			alreadySelected = true;
			break;
		}
	} 

	if (!alreadySelected) { 
		if (!multipleMode) {
			selected.clear();
		}
		selected.push_back(index);
	}
}

void List::deselect(int index) {
	if ( peer != NULL ) {
		::SendMessage(peer, LB_SETSEL, FALSE, index);
	}

	SelectedList::iterator i;
	for ( i = selected.begin(); i != selected.end(); ++i ) {
		if ( *i == index ) {
			selected.erase(i);
			break;
		}
	}
}

bool List::isIndexSelected(int index) const {

	if ( peer != NULL ) {
		return ::SendMessage(peer, LB_GETSEL, index, 0) != 0;
	}

	getSelectedIndexes();
	SelectedList::const_iterator i;
	for ( i = selected.begin(); i != selected.end(); ++i ) {
		if ( *i == index ) {
			return true;
		}
	}

	return false;
}


void List::setMultipleMode(bool b) {
	if ( multipleMode != b && peer != NULL ) {
		DWORD dwStyle = ::GetWindowLong(peer, GWL_STYLE);
		if ( b )
			dwStyle |= LBS_MULTIPLESEL;
		else
			dwStyle &= ~LBS_MULTIPLESEL;

		::SetWindowLong(peer, GWL_STYLE, dwStyle);
	}

	multipleMode = b;
}

int List::getVisibleIndex() const {
	if ( peer != NULL ) {
		const_cast<List*>(this)->visibleIndex = static_cast<int>(
				::SendMessage(peer, LB_GETTOPINDEX, 0, 0));
	}

	return visibleIndex;
}

void List::makeVisible(int index) {
	assert ( index >= 0 && index < static_cast<int>(items.size()) );

	visibleIndex = index;
	if ( peer != NULL ) {
		::SendMessage(peer, LB_SETTOPINDEX, index, 0);
	}
}

Dimension List::getPreferredSize(int rows) const {
	Dimension d = getMinimumSize(rows);
	if ( peer != NULL ) {
		FontMetrics fm = getFontMetrics();
		int maxWidth = 0;
		ItemsList::const_iterator i;
		for ( i = items.begin(); i != items.end(); ++i ) {
			int w = fm.stringWidth(*i);
			if ( maxWidth < w ) {
				maxWidth = w;
			}
		}

		if ( maxWidth + 20 > d.width) {
			d.width = maxWidth + 20;
		}
	}

	return d;
}

Dimension List::getPreferredSize() const {
	const_cast<List*>(this)->prefSize = 
		rows > 0 ? getPreferredSize(rows) : Component::getPreferredSize();
	return prefSize;
}

Dimension List::getMinimumSize(int rows) const {
	FontMetrics fm = getFontMetrics();
	int w = fm.stringWidth(_T("0123456789abcde"));
	int h = fm.getHeight();

	return Dimension(w + 20, h * rows + 4);
}

Dimension List::getMinimumSize() const {
	if ( isValid() ) {
		return prefSize;
	}
	minSize = rows > 0 ? 
			getMinimumSize(rows) : Component::getMinimumSize();
	return minSize;
}

void List::addItemListener(ItemListener* l) {
	itemEventDispatcher.addListener(l);
}

void List::removeItemListener(ItemListener* l) {
	itemEventDispatcher.removeListener(l);
}

void List::addActionListener(ActionListener* l) {
	actionEventDispatcher.addListener(l);
}

void List::removeActionListener(ActionListener* l) {
	actionEventDispatcher.removeListener(l);
}

void List::delItems(int start, int end) {
	items.erase(items.begin() + start, items.begin() + end);
	if ( peer != NULL ) {
		for (int i = end; i >= start; --i) {
			::SendMessage(peer, LB_DELETESTRING, i, 0);
		}
	}
}

const Color& List::getDefaultForeground() const {
	return SystemColor::WINDOW_TEXT;
}

const Color& List::getDefaultBackground() const {
	return SystemColor::WINDOW;
}

DWORD List::getWindowStyle() const {
	DWORD dwStyle = WS_CHILD | WS_CLIPSIBLINGS | WS_TABSTOP |
			LBS_NOINTEGRALHEIGHT | LBS_NOTIFY;
	if ( multipleMode ) {
		dwStyle |= LBS_MULTIPLESEL;
	}

	return dwStyle;
}

LPCTSTR List::getClassName() const {
	return _T("ListBox");
}

void List::handleCommand(UINT notifyCode) {
	if ( notifyCode == LBN_SELCHANGE || notifyCode == LBN_DBLCLK ) {
		int curSel = static_cast<int>(
				::SendMessage(peer, LB_GETCURSEL, 0, 0));
		String item = getItem(curSel);
		if ( notifyCode == LBN_SELCHANGE ) {
			ItemEvent event(item, isIndexSelected(curSel) ? 
						ItemEvent::SELECTED : ItemEvent::DESELECTED);
			itemEventDispatcher.fireEvent(this, 
					&ItemListener::itemStateChanged, event);
		} else if ( notifyCode == LBN_DBLCLK ) {
			actionEventDispatcher.fireEvent(this, 
					&ActionListener::actionPerformed, ActionEvent(item));
		}
	}
}
