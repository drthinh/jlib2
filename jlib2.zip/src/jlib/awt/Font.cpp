#include <win32/win32.h>

#include <cassert>
#include <map>

#include <jlib/awt/Font.h>

using namespace jlib::awt;

class Font::NativeFontCache {
public:
	~NativeFontCache() {
		FontCache::iterator i;
		for ( i = cache.begin(); i != cache.end(); ++i ) {
			::DeleteObject(i->second);
		}
	}

	HFONT get(const Font& font) {
		FontDescriptor desc(font);
		FontCache::iterator i = cache.find(desc);
		HFONT hf = NULL;
		if ( i == cache.end() ) {
			hf = createFont(font);
			cache.insert(FontCache::value_type(desc, hf));
		} else {
			hf = i->second;
		}

		assert ( hf !=NULL );

		return hf;
	}

private:

	HFONT createFont(const Font& font) {
		LOGFONT lf = {0};
		lf.lfHeight = font.getSize();
		lf.lfItalic = font.isItalic();
		lf.lfWeight = font.isBold() ? 700 : 400;
		lstrcpy(lf.lfFaceName, font.getName().c_str());

		return ::CreateFontIndirect(&lf);
	}

	struct FontDescriptor {
		FontDescriptor(const Font& f)
			: name(f.getName()), style(f.getStyle()), size(f.getSize()) {
			}

		String name;
		int style;
		int size;
	};

	struct FontComparator {
		bool operator()(const FontDescriptor& l, 
				const FontDescriptor& r) const {
			if ( l.size < r.size ) {
				return true;
			} else if ( l.size > r.size ) {
				return false;
			} else if ( l.style < r.style ) {
				return true;
			} else if ( l.style > r.style ) {
				return false;
			} else if ( l.name < r.name ) {
				return true;
			}

			return false;
		}
	};

	typedef std::map<FontDescriptor, HFONT, FontComparator> FontCache;
	mutable FontCache cache;
};

Font::NativeFontCache Font::cache;

Font::Font(const String& name, int style, int size) 
		: name(name), style(style), size(size), peer(NULL) {
	assert ( !name.empty() );
	assert ( style >= PLAIN && style <= (BOLD|ITALIC) );
	assert ( size > 0 );
}

HFONT Font::getPeer() const {
	if ( !*this ) {
		return NULL;
	}

	if ( peer == NULL ) {
		peer = cache.get(*this);
	}

	return peer;
}
