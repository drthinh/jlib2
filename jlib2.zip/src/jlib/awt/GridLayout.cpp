#include <jlib/awt/GridLayout.h>

#include <cassert>

using namespace jlib::awt;

GridLayout::GridLayout(int rows, int cols, int hgap, int vgap) {
	assert ( ! ( rows == 0 && cols == 0 ) );

	this->rows = rows;
	this->cols = cols;
	this->hgap = hgap;
	this->vgap = vgap;
}

void GridLayout::setRows(int rows) {
	assert ( !( rows == 0 && this->cols == 0 ) );

	this->rows = rows;
}

void GridLayout::setColumns(int cols) {
	assert ( !( cols == 0 && this->rows == 0 ) );

	this->cols = cols;
}

Dimension GridLayout::preferredLayoutSize(LayoutContainer* parent) {
	const Insets& insets = parent->getInsets();
	int ncomponents = parent->getComponentCount();
	int nrows = rows;
	int ncols = cols;

	if (nrows > 0) {
		ncols = (ncomponents + nrows - 1) / nrows;
	} else {
		nrows = (ncomponents + ncols - 1) / ncols;
	}

	int w = 0;
	int h = 0;
	for (int i = 0 ; i < ncomponents ; i++) {
		LayoutComponent* comp = parent->getComponent(i);
		Dimension d = comp->getPreferredSize();
		if (w < d.width) {
			w = d.width;
		}
		if (h < d.height) {
			h = d.height;
		}
	}
	return Dimension(
		insets.left + insets.right + ncols*w + (ncols-1)*hgap, 
		insets.top + insets.bottom + nrows*h + (nrows-1)*vgap);
}

Dimension GridLayout::minimumLayoutSize(const LayoutContainer* parent) {
	const Insets& insets = parent->getInsets();
	int ncomponents = parent->getComponentCount();
	int nrows = rows;
	int ncols = cols;

	if (nrows > 0) {
		ncols = (ncomponents + nrows - 1) / nrows;
	} else {
		nrows = (ncomponents + ncols - 1) / ncols;
	}

	int w = 0;
	int h = 0;
	for (int i = 0 ; i < ncomponents ; i++) {
		LayoutComponent* comp = parent->getComponent(i);
		Dimension d = comp->getMinimumSize();
		if (w < d.width) {
			w = d.width;
		}
		if (h < d.height) {
			h = d.height;
		}
	}
	return Dimension(
		insets.left + insets.right + ncols*w + (ncols-1)*hgap, 
		insets.top + insets.bottom + nrows*h + (nrows-1)*vgap);
}

void GridLayout::layoutContainer(LayoutContainer* parent) {
	int ncomponents = parent->getComponentCount();
	if (ncomponents == 0) {
		return;
	}

	const Insets& insets = parent->getInsets();
	int nrows = rows;
	int ncols = cols;

	if (nrows > 0) {
		ncols = (ncomponents + nrows - 1) / nrows;
	} else {
		nrows = (ncomponents + ncols - 1) / ncols;
	}

	const Dimension& d = parent->getSize();
	int w = d.width - (insets.left + insets.right);
	int h = d.height - (insets.top + insets.bottom);
	w = ( w - (ncols - 1) * hgap ) / ncols;
	h = ( h - (nrows - 1) * vgap ) / nrows;

	for (int c = 0, x = insets.left; c < ncols; c++, x += w + hgap) {
		for (int r = 0, y = insets.top; r < nrows; r++, y += h + vgap) {
			int i = r * ncols + c;
			if (i < ncomponents) {
				parent->getComponent(i)->setBounds(x, y, w, h);
			}
		}
	}
}
