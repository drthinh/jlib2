#include <win32/win32.h>

#include <jlib/awt/Window.h>
#include <jlib/awt/BorderLayout.h>

#include <jlib/awt/WindowListener.h>
#include <jlib/awt/WindowEvent.h>

#include <jlib/awt/ComponentListener.h>
#include <jlib/awt/ComponentEvent.h>

#include <algorithm>
#include <functional>
#include <cassert>

using namespace jlib::awt;

Window* Window::currentActive = NULL;

Window::Window(Window* parent) {
	visible = false;
	this->parent = parent;
	owner = parent;
	if ( owner != NULL ) {
		owner->addOwnedWindow(this);
	}

	defLayout = new BorderLayout;
	setLayout(defLayout);
	
	HFONT hf = (HFONT)::GetStockObject(SYSTEM_FONT);
	LOGFONT lf;
	::GetObject(hf, sizeof(lf), &lf);
	
	int style = Font::PLAIN;
	if ( lf.lfItalic != 0 ) {
		style |= Font::ITALIC;
	}

	if ( lf.lfWeight >= 700 ) {
		style |= Font::BOLD;
	}

	setFont(Font(lf.lfFaceName, style, lf.lfHeight));
}

Window::~Window() {
	if ( owner != NULL ) {
		owner->removeOwnedWindow(this);
	}

	delete defLayout;
}

void Window::addNotify() {
	Container::addNotify();
	peer_updateInsets();
}

void Window::pack() {
	Container* parent = getParent();
	if ( parent != NULL && !parent->isDisplayable() ) {
		(static_cast<Component*>(parent))->addNotify();
	}

	if ( !isDisplayable() ) {
		addNotify();
	}

	Dimension d = getPreferredSize();
	setSize(d.width, d.height);
	validate();
}

void Window::show() {
	Container::show();
}

void Window::toFront() {
	if ( peer != NULL ) {
		peer_toFront();
	}
}

void Window::toBack() {
	if ( peer != NULL ) {
		peer_toBack();
	}
}

void Window::setVisible(bool b) {
	if ( b ) {
		bool opened = peer != NULL;
		if ( !opened ) {
			addNotify();
		}

		validate();

		if ( visible ) {
			toFront();
		} else {
			Container::setVisible(b);
		}

		if ( !opened && !windowEventDispatcher.empty() ) {
			windowEventDispatcher.fireEvent(this, 
					&WindowListener::windowOpened, 
					WindowEvent(WindowEvent::WINDOW_OPENED));
		}
	} else {
		Container::setVisible(false);
	}
}

void Window::dispose() {
	std::for_each(ownedWindows.begin(), ownedWindows.end(), 
			std::mem_fun(&Window::dispose));

	setVisible(false);
	removeNotify();

	windowEventDispatcher.fireEvent(this, 
			&WindowListener::windowClosed,
			WindowEvent(WindowEvent::WINDOW_CLOSED));
}

void Window::addOwnedWindow(Window* w) {
	WindowList::iterator end = ownedWindows.end();
	if ( end == std::find(ownedWindows.begin(), end, w) ) {
		ownedWindows.push_back(w);
	}
}

void Window::removeOwnedWindow(Window* w) {
	WindowList::iterator end = ownedWindows.end();
	WindowList::iterator i = std::find(ownedWindows.begin(), end, w);
	if ( i != end ) {
		ownedWindows.erase(i);
	}
}

Window* Window::getActiveWindow() {
	return currentActive;
}

void Window::addWindowListener(WindowListener* l) {
	windowEventDispatcher.addListener(l);
}

void Window::removeWindowListener(WindowListener* l) {
	windowEventDispatcher.removeListener(l);
}

// peer operations
bool Window::peer_updateInsets() {
	assert ( peer != NULL );
	if ( ::IsIconic(peer) )
		return false;

	Insets old = insets;

	RECT outside;
    ::GetWindowRect(peer, &outside);

	RECT inside;
	::GetClientRect(peer, &inside);

    // Update our inset member
    if ( outside.right - outside.left > 0 && 
			outside.bottom - outside.top > 0 ) {
        ::MapWindowPoints(peer, 0, reinterpret_cast<POINT*>(&inside), 2);
        insets.top = inside.top - outside.top;
        insets.bottom = outside.bottom - inside.bottom;
        insets.left = inside.left - outside.left;
        insets.right = outside.right - inside.right;
    } else {
		insets.top = -1;
    }

	if (insets.left < 0 || insets.top < 0 ||
			insets.right < 0 || insets.bottom < 0) {
		// This window hasn't been sized yet -- use system metrics.
		// Get outer frame sizes.
		DWORD style = ::GetWindowLong(peer, GWL_STYLE);
		if ( ( style & WS_THICKFRAME ) != 0 ) {
			insets.left = insets.right = 
				::GetSystemMetrics(SM_CXSIZEFRAME);
			insets.top = insets.bottom = 
				::GetSystemMetrics(SM_CYSIZEFRAME);
		} else {
			insets.left = insets.right = 
				::GetSystemMetrics(SM_CXDLGFRAME);
			insets.top = insets.bottom = 
				::GetSystemMetrics(SM_CYDLGFRAME);
		}

		// Add in title.
		insets.top += ::GetSystemMetrics(SM_CYCAPTION);

		// Add in menuBar, if any.
		if ( ::GetMenu(peer) != NULL ) {
			insets.top += ::GetSystemMetrics(SM_CYMENU);
		}
	}

    return insets != old;
}

void Window::peer_toFront() {
	assert ( peer != NULL );

	::SetWindowPos(peer, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);
	::SetForegroundWindow(peer); 
}

void Window::peer_toBack() {
	assert ( peer != NULL );

	::SetWindowPos(peer, HWND_BOTTOM, 0, 0, 0, 0,
		SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE); 
}

// WIN32

void Window::wmClose() {
	windowEventDispatcher.fireEvent(this, 
		&WindowListener::windowClosing,
		WindowEvent(WindowEvent::WINDOW_CLOSING));
}

void Window::wmMove(WPARAM, LPARAM lParam) {
	int x = LOWORD(lParam);
	int y = HIWORD(lParam);
	if ( x != this->x || y != this->y ) {
		this->x = x;
		this->y = y;
		if ( !componentEventDispatcher.empty() ) {
			componentEventDispatcher.fireEvent(this, 
					&ComponentListener::componentMoved,
					ComponentEvent(ComponentEvent::COMPONENT_MOVED));
		}
	}
}

void Window::wmSize(WPARAM wParam, LPARAM lParam) {
	if ( wParam == SIZE_MINIMIZED ) {
		windowEventDispatcher.fireEvent(this, 
				&WindowListener::windowIconified,
				WindowEvent(WindowEvent::WINDOW_ICONIFIED));
		return;
	}

	if ( wParam == SIZE_RESTORED ) {
		windowEventDispatcher.fireEvent(this, 
				&WindowListener::windowDeiconified,
				WindowEvent(WindowEvent::WINDOW_DEICONIFIED));
	}

	int w = LOWORD(lParam);
	int h = HIWORD(lParam);

	peer_updateInsets();

	bool resized = false;

	int newW = w + insets.left + insets.right;
	if ( w != width ) {
		width = newW;
		resized = true;
	}

	int newH = h + insets.top + insets.bottom;
	if ( h != height ) {
		height = newH;
		resized = true;
	}

	invalidate();
	validate();

	if ( resized ) {
		if ( !componentEventDispatcher.empty() ) {
			componentEventDispatcher.fireEvent(this, 
					&ComponentListener::componentResized,
					ComponentEvent(ComponentEvent::COMPONENT_RESIZED));
		}
	}
}

void Window::wmActivate(WPARAM wParam, LPARAM lParam) {
	bool active = wParam == WA_ACTIVE || wParam == WA_CLICKACTIVE;
	if ( active ) {
		currentActive = this;
	}

	if ( windowEventDispatcher.empty() ) {
		return;
	}

	Window* opposite = NULL;
	HWND oppositeHWND = reinterpret_cast<HWND>(lParam);
	Component* oppositeComponent = Component::getComponent(oppositeHWND);
	if ( oppositeComponent != NULL ) {
		if ( oppositeComponent->isWindow() ) {
			opposite = static_cast<Window*>(oppositeComponent);
		}
	}

	if ( active ) {
		windowEventDispatcher.fireEvent(this, 
				&WindowListener::windowActivated,
				WindowEvent(WindowEvent::WINDOW_ACTIVATED, opposite));
	} else {
		windowEventDispatcher.fireEvent(this, 
				&WindowListener::windowDeactivated,
				WindowEvent(WindowEvent::WINDOW_DEACTIVATED, opposite));
	}
}

LRESULT Window::windowProc(UINT message, WPARAM wParam, LPARAM lParam) {
	switch ( message ) {
	case WM_MOVE:
		wmMove(wParam, lParam);
		break;

	case WM_SIZE:
		wmSize(wParam, lParam);
		return 0;

	case WM_ACTIVATE:
		wmActivate(wParam, lParam);
		break;

	case WM_CLOSE:
		wmClose();
		return 0;

	default:
		break;
	}

	return Container::windowProc(message, wParam, lParam);
}
