#include <jlib/awt/BorderLayout.h>

#include <cassert>

#include <algorithm>
#include <limits>

using namespace jlib::awt;

const BorderLayout::Constraint BorderLayout::NORTH;
const BorderLayout::Constraint BorderLayout::SOUTH;
const BorderLayout::Constraint BorderLayout::EAST;
const BorderLayout::Constraint BorderLayout::WEST;
const BorderLayout::Constraint BorderLayout::CENTER;

const BorderLayout::Constraint BorderLayout::BEFORE_FIRST_LINE;
const BorderLayout::Constraint BorderLayout::AFTER_LAST_LINE;
const BorderLayout::Constraint BorderLayout::BEFORE_LINE_BEGINS;
const BorderLayout::Constraint BorderLayout::AFTER_LINE_ENDS;

const BorderLayout::Constraint& BorderLayout::PAGE_START = 
		BorderLayout::BEFORE_FIRST_LINE;
const BorderLayout::Constraint& BorderLayout::PAGE_END = 
		BorderLayout::AFTER_LAST_LINE;

const BorderLayout::Constraint& BorderLayout::LINE_START = 
		BorderLayout::BEFORE_LINE_BEGINS;
const BorderLayout::Constraint& BorderLayout::LINE_END = 
		BorderLayout::AFTER_LINE_ENDS;


BorderLayout::BorderLayout(int hgap, int vgap) {
	this->hgap = hgap;
	this->vgap = vgap;

	north = NULL;
	west = NULL;
	east = NULL;
	south = NULL;
	center = NULL;

	firstLine = NULL;
	lastLine = NULL;
	firstItem = NULL;
	lastItem = NULL;
}

void BorderLayout::addLayoutComponent(LayoutComponent* comp, const LayoutConstraint& constraints) {
	if ( &constraints == &LayoutConstraint::nullConstraint) {
		center = comp;
	} else if ( &constraints == &CENTER ) {
		center = comp;
	} else if ( &constraints == &NORTH ) {
		north = comp;
	} else if ( &constraints == &SOUTH ) {
		south = comp;
	} else if ( &constraints == &EAST ) {
		east = comp;
	} else if ( &constraints == &WEST ) {
		west = comp;
	} else if ( &constraints == &BEFORE_FIRST_LINE) {
		firstLine = comp;
	} else if ( &constraints == &AFTER_LAST_LINE) {
		lastLine = comp;
	} else if ( &constraints == &BEFORE_LINE_BEGINS) {
		firstItem = comp;
	} else if ( &constraints == &AFTER_LINE_ENDS ) {
		lastItem = comp;
	} else {
		assert ( false );
	}
}

void BorderLayout::removeLayoutComponent(LayoutComponent* comp) {
	if (comp == center) {
		center = NULL;
	} else if (comp == north) {
		north = NULL;
	} else if (comp == south) {
		south = NULL;
	} else if (comp == east) {
		east = NULL;
	} else if (comp == west) {
		west = NULL;
	}

	if (comp == firstLine) {
		firstLine = NULL;
	} else if (comp == lastLine) {
		lastLine = NULL;
	} else if (comp == firstItem) {
		firstItem = NULL;
	} else if (comp == lastItem) {
		lastItem = NULL;
	}
}

Dimension BorderLayout::minimumLayoutSize(const LayoutContainer* target) {
	Dimension dim(0, 0);

	//bool ltr = target.getComponentOrientation().isLeftToRight();
	bool ltr = true;
	LayoutComponent* c = NULL;

	if ( ( c = getChild(EAST, ltr) ) != NULL ) {
		Dimension d = c->getMinimumSize();
		dim.width += d.width + hgap;
		dim.height = std::max(d.height, dim.height);
	}

	if ( ( c = getChild(WEST, ltr) ) != NULL ) {
		Dimension d = c->getMinimumSize();
		dim.width += d.width + hgap;
		dim.height = std::max(d.height, dim.height);
	}

	if ( ( c = getChild(CENTER, ltr) ) != NULL ) {
		Dimension d = c->getMinimumSize();
		dim.width += d.width;
		dim.height = std::max(d.height, dim.height);
	}
	if ( ( c = getChild(NORTH, ltr) ) != NULL ) {
		Dimension d = c->getMinimumSize();
		dim.width = std::max(d.width, dim.width);
		dim.height += d.height + vgap;
	}

	if ( ( c = getChild(SOUTH,ltr) ) != NULL ) {
		Dimension d = c->getMinimumSize();
		dim.width = std::max(d.width, dim.width);
		dim.height += d.height + vgap;
	}

	const Insets& insets = target->getInsets();
	dim.width += insets.left + insets.right;
	dim.height += insets.top + insets.bottom;

	return dim;
}

Dimension BorderLayout::preferredLayoutSize(const LayoutContainer* target) {
	Dimension dim(0, 0);

	//bool ltr = target.getComponentOrientation().isLeftToRight();
	bool ltr = true;
	LayoutComponent* c = NULL;

	if ( ( c = getChild(EAST, ltr) ) != NULL ) {
		Dimension d = c->getPreferredSize();
		dim.width += d.width + hgap;
		dim.height = std::max(d.height, dim.height);
	}
	if ( ( c = getChild(WEST,ltr)) != NULL ) {
		Dimension d = c->getPreferredSize();
		dim.width += d.width + hgap;
		dim.height = std::max(d.height, dim.height);
	}
	if ( ( c = getChild(CENTER,ltr)) != NULL ) {
		Dimension d = c->getPreferredSize();
		dim.width += d.width;
		dim.height = std::max(d.height, dim.height);
	}
	if ( ( c = getChild(NORTH,ltr)) != NULL ) {
		Dimension d = c->getPreferredSize();
		dim.width = std::max(d.width, dim.width);
		dim.height += d.height + vgap;
	}
	if ( ( c = getChild(SOUTH,ltr)) != NULL ) {
		Dimension d = c->getPreferredSize();
		dim.width = std::max(d.width, dim.width);
		dim.height += d.height + vgap;
	}

	const Insets& insets = target->getInsets();
	dim.width += insets.left + insets.right;
	dim.height += insets.top + insets.bottom;

	return dim;
}

Dimension BorderLayout::maximumLayoutSize(const LayoutContainer*) {
	return Dimension(std::numeric_limits<int>::max(), 
			std::numeric_limits<int>::max());
}

void BorderLayout::layoutContainer(LayoutContainer* target) {
	const Insets& insets = target->getInsets();
	const Dimension& tagetSize = target->getSize();
	int top = insets.top;
	int bottom = tagetSize.height - insets.bottom;
	int left = insets.left;
	int right = tagetSize.width - insets.right;

	//bool ltr = target.getComponentOrientation().isLeftToRight();
	bool ltr = true;
	LayoutComponent* c = NULL;
	Dimension d;

	if ( ( c = getChild(NORTH, ltr)) != NULL) {
		const Rectangle& r = c->getBounds();
		c->setBounds(r.x, r.y, right - left, r.height);
		d = c->getPreferredSize();
		c->setBounds(left, top, right - left, d.height);
		top += d.height + vgap;
	}

	if ( ( c = getChild(SOUTH, ltr)) != NULL) {
		const Rectangle& r = c->getBounds();
		c->setBounds(r.x, r.y, right - left, r.height);
		d = c->getPreferredSize();
		c->setBounds(left, bottom - d.height, right - left, d.height);
		bottom -= d.height + vgap;
	}

	if ( ( c = getChild(EAST, ltr)) != NULL) {
		const Rectangle& r = c->getBounds();
		c->setBounds(r.x, r.y, r.width, bottom - top);
		d = c->getPreferredSize();
		c->setBounds(right - d.width, top, d.width, bottom - top);
		right -= d.width + hgap;
	}

	if ( ( c = getChild(WEST, ltr)) != NULL) {
		const Rectangle& r = c->getBounds();
		c->setBounds(r.x, r.y, r.width, bottom - top);
		d = c->getPreferredSize();
		c->setBounds(left, top, d.width, bottom - top);
		left += d.width + hgap;
	}

	if ( ( c = getChild(CENTER, ltr)) != NULL ) {
		c->setBounds(left, top, right - left, bottom - top);
	}
}

LayoutComponent* BorderLayout::getChild(
		const BorderLayout::Constraint& key, bool ltr) {

	LayoutComponent* result = NULL;

	if ( &key == &NORTH ) {
		result = (firstLine != NULL) ? firstLine : north;
	} else if ( &key == &SOUTH ) {
		result = (lastLine != NULL) ? lastLine : south;
	} else if ( &key == &WEST ) {
		result = ltr ? firstItem : lastItem;
		if (result == NULL) {
			result = west;
		}
	} else if ( &key == &EAST ) {
		result = ltr ? lastItem : firstItem;
		if (result == NULL) {
			result = east;
		}
	} else if ( &key == &CENTER ) {
		result = center;
	}

	if ( result != NULL && !result->isVisible() ) {
		result = NULL;
	}

	return result;
}
