#include <jlib/awt/BoxLayout.h>

#include <cassert>

#include <algorithm>
#include <limits>


using namespace jlib::awt;

BoxLayout::BoxLayout(LayoutContainer* target, Axis axis)
	: target(target), axis(axis) {
	xChildren = NULL;
	yChildren = NULL;
}

BoxLayout::~BoxLayout() {
	delete[] xChildren;
	delete[] yChildren;
}

void BoxLayout::invalidateLayout(LayoutContainer* target) {
	assert ( isTarget(target) );

	if ( xChildren != NULL ) {
		delete[] xChildren;
		xChildren = NULL;
	}

	if ( yChildren != NULL ) {
		delete[] yChildren;
		yChildren = NULL;
	}
}

Dimension BoxLayout::minimumLayoutSize(const LayoutContainer* target) {
	assert ( isTarget(target) );

	checkRequests();
	Dimension size(xTotal.minimum, yTotal.minimum);

	const Insets& insets = target->getInsets();
	size.width = std::min(
		size.width + insets.left + insets.right, 
		std::numeric_limits<int>::max());
	size.height = std::min(
		size.height + insets.top + insets.bottom, 
		std::numeric_limits<int>::max());

	return size;

}

Dimension BoxLayout::preferredLayoutSize(const LayoutContainer* target) {
	assert ( isTarget(target) );

	checkRequests();
	Dimension size(xTotal.preferred, yTotal.preferred);

	const Insets& insets = target->getInsets();
	size.width = std::min(
		size.width + insets.left + insets.right, 
		std::numeric_limits<int>::max());
	size.height = std::min(
		size.height + insets.top + insets.bottom, 
		std::numeric_limits<int>::max());

	return size;
}

Dimension BoxLayout::maximumLayoutSize(const LayoutContainer* target) {
	assert ( isTarget(target) );

	checkRequests();
	Dimension size(xTotal.maximum, yTotal.maximum);

	const Insets& insets = target->getInsets();
	size.width = std::min(
		size.width + insets.left + insets.right, 
		std::numeric_limits<int>::max());
	size.height = std::min(
		size.height + insets.top + insets.bottom, 
		std::numeric_limits<int>::max());

	return size;
}

float BoxLayout::getLayoutAlignmentX(const LayoutContainer* target) const {
	assert ( isTarget(target) );

	const_cast<BoxLayout*>(this)->checkRequests();
	return xTotal.alignment;
}

float BoxLayout::getLayoutAlignmentY(const LayoutContainer* target) const {
	assert ( isTarget(target) );

	const_cast<BoxLayout*>(this)->checkRequests();
	return yTotal.alignment;
}

void BoxLayout::layoutContainer(LayoutContainer* target) {
	assert ( isTarget(target) );

	int nChildren = target->getComponentCount();
	int* xOffsets = new int[nChildren];
	int* xSpans = new int[nChildren];
	int* yOffsets = new int[nChildren];
	int* ySpans = new int[nChildren];

	Dimension alloc = target->getSize();
	const Insets& in = target->getInsets();
	alloc.width -= in.left + in.right;
	alloc.height -= in.top + in.bottom;

	// Resolve axis to an absolute value (either X_AXIS or Y_AXIS)
//	ComponentOrientation o = target->getComponentOrientation();
//	int absoluteAxis = resolveAxis( axis, o );
	int absoluteAxis = resolveAxis(axis);
//	boolean ltr = (absoluteAxis != axis) ? o.isLeftToRight() : true;
	bool ltr = true;

	checkRequests();

	if (absoluteAxis == X_AXIS) {
		SizeRequirements::calculateTiledPositions(alloc.width, xTotal,
			xChildren, nChildren, xOffsets, xSpans, ltr);
		SizeRequirements::calculateAlignedPositions(alloc.height, yTotal,
			yChildren, nChildren, yOffsets, ySpans);
	} else {
		SizeRequirements::calculateAlignedPositions(alloc.width, xTotal,
			xChildren, nChildren, xOffsets, xSpans, ltr);
		SizeRequirements::calculateTiledPositions(alloc.height, yTotal,
			yChildren, nChildren, yOffsets, ySpans);
	}

	// flush changes to the container
	for (int i = 0; i < nChildren; i++) {
		LayoutComponent* c = target->getComponent(i);
		c->setBounds(
				std::min(in.left + xOffsets[i], 
						std::numeric_limits<int>::max()),
				std::min(in.top + yOffsets[i], 
						std::numeric_limits<int>::max()),
				xSpans[i], ySpans[i]);
	}

	delete[] xOffsets;
	delete[] xSpans;
	delete[] yOffsets;
	delete[] ySpans;
}

bool BoxLayout::isTarget(const LayoutContainer* target) const {
	return this->target == target;
}
    
void BoxLayout::checkRequests() {
    if ( xChildren == NULL || yChildren == NULL ) {
        // The requests have been invalidated... recalculate
        // the request information.
        int n = target->getComponentCount();
        xChildren = new SizeRequirements[n];
        yChildren = new SizeRequirements[n];
        for ( int i = 0; i < n; ++i ) {
            LayoutComponent* c = target->getComponent(i);
			if ( !c->isVisible() ) {
				xChildren[i] = SizeRequirements(0,0,0, c->getAlignmentX());
				yChildren[i] = SizeRequirements(0,0,0, c->getAlignmentY());
				continue;
			}
			Dimension min = c->getMinimumSize();
			Dimension typ = c->getPreferredSize();
			Dimension max = c->getMaximumSize();
			xChildren[i] = SizeRequirements(min.width, typ.width, 
					max.width, c->getAlignmentX());
			yChildren[i] = SizeRequirements(min.height, typ.height, 
					max.height, c->getAlignmentY());
		}
    
	    // Resolve axis to an absolute value (either X_AXIS or Y_AXIS)
		int absoluteAxis = resolveAxis(axis);//,target.getComponentOrientation());

        if ( absoluteAxis == X_AXIS ) {
            xTotal = SizeRequirements::getTiledSizeRequirements(xChildren, n);
            yTotal = SizeRequirements::getAlignedSizeRequirements(yChildren, n);
        } else {
            xTotal = SizeRequirements::getAlignedSizeRequirements(xChildren, n);
            yTotal = SizeRequirements::getTiledSizeRequirements(yChildren, n);
        }
    }
}

int BoxLayout::resolveAxis(int axis/*, ComponentOrientation o*/) {
	return axis == LINE_AXIS || axis == PAGE_AXIS ? X_AXIS : axis;
	//int absoluteAxis;
	//if( axis == LINE_AXIS ) {
	//	absoluteAxis = o.isHorizontal() ? X_AXIS : Y_AXIS;
	//} else if( axis == PAGE_AXIS ) {
	//	absoluteAxis = o.isHorizontal() ? Y_AXIS : X_AXIS;
	//} else {
	//	absoluteAxis = axis;
	//} 
	//return absoluteAxis;
}
