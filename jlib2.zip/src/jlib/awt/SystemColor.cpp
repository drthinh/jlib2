#include <jlib/awt/SystemColor.h>
#include <win32/win32.h>

namespace jlib { namespace awt {

SystemColor SystemColor::DESKTOP(COLOR_DESKTOP);

SystemColor SystemColor::ACTIVE_CAPTION(COLOR_ACTIVECAPTION);
SystemColor SystemColor::ACTIVE_CAPTION_TEXT(COLOR_CAPTIONTEXT);
SystemColor SystemColor::ACTIVE_CAPTION_BORDER(COLOR_ACTIVEBORDER);
SystemColor SystemColor::INACTIVE_CAPTION(COLOR_INACTIVECAPTION);
SystemColor SystemColor::INACTIVE_CAPTION_TEXT(COLOR_INACTIVECAPTIONTEXT);
SystemColor SystemColor::INACTIVE_CAPTION_BORDER(COLOR_INACTIVEBORDER);

SystemColor SystemColor::WINDOW(COLOR_WINDOW);
SystemColor SystemColor::WINDOW_BORDER(COLOR_WINDOWFRAME);
SystemColor SystemColor::WINDOW_TEXT(COLOR_WINDOWTEXT);

SystemColor SystemColor::MENU(COLOR_MENU);
SystemColor SystemColor::MENU_TEXT(COLOR_MENUTEXT);

//SystemColor SystemColor::TEXT(COLOR_3DFACE);
//SystemColor SystemColor::TEXT_TEXT(COLOR_BTNTEXT);
SystemColor SystemColor::TEXT(COLOR_WINDOW);
SystemColor SystemColor::TEXT_TEXT(COLOR_WINDOWTEXT);
SystemColor SystemColor::TEXT_HIGHLIGHT(COLOR_HIGHLIGHT);
SystemColor SystemColor::TEXT_HIGHLIGHT_TEXT(COLOR_HIGHLIGHTTEXT);
SystemColor SystemColor::TEXT_INACTIVE_TEXT(COLOR_GRAYTEXT);

SystemColor SystemColor::CONTROL(COLOR_3DFACE);
SystemColor SystemColor::CONTROL_TEXT(COLOR_BTNTEXT);
SystemColor SystemColor::CONTROL_HIGHLIGHT(COLOR_3DLIGHT);
SystemColor SystemColor::CONTROL_LT_HIGHLIGHT(COLOR_3DHILIGHT);
SystemColor SystemColor::CONTROL_SHADOW(COLOR_3DSHADOW);
SystemColor SystemColor::CONTROL_DK_SHADOW(COLOR_3DDKSHADOW);

SystemColor SystemColor::SCROLLBAR(COLOR_SCROLLBAR);

SystemColor SystemColor::INFO(COLOR_INFOBK);
SystemColor SystemColor::INFO_TEXT(COLOR_INFOTEXT);

SystemColor::SystemColor(int index) 
	: Color(::GetSysColor(index)) {
}

}}
