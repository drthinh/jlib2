#include <win32/win32.h>

#include <jlib/awt/TextArea.h>

#include <cassert>

using namespace jlib::awt;

TextArea::TextArea(int rows, int columns)
	: TextComponent(_T("")), 
	rows(rows), columns(columns), scrollbarVisibility(SCROLLBARS_BOTH) {
}

TextArea::TextArea(const String& text, int rows, int columns, 
		ScrollbarVisibility scrollbars)
	: TextComponent(text), rows(rows), columns(columns), 
		scrollbarVisibility(scrollbars) {

	assert ( rows >= 0 );
	assert ( columns >=0 );
    assert ( scrollbars >= SCROLLBARS_BOTH && 
			scrollbars <= SCROLLBARS_NONE );
}

void TextArea::insert(const String& str, int pos) {
	if (peer != NULL) {
		peer_insert(str, pos);
	} else {
		text.insert(pos, str);
	}
}

void TextArea::append(const String& str) {
	if (peer != NULL) {
		insert(str, getText().length());
	} else {
		text = text + str;
	}
}

void TextArea::peer_insert(const String& str, int pos) {
	assert ( peer != NULL );

	::SendMessage(peer, EM_SETSEL, pos, pos);
	::SendMessage(peer, EM_REPLACESEL, 
			(WPARAM)FALSE, (LPARAM)str.c_str());
}

void TextArea::replaceRange(const String& str, int start, int end) {
	if (peer != NULL) {
		peer_replaceRange(str, start, end);
	} else {
		text.replace(start, end - start, str);
	}
}

void TextArea::setRows(int rows) {
	assert ( rows >= 0 );
	if (rows != this->rows) {
		this->rows = rows;
		invalidate();
	}
}

void TextArea::setColumns(int columns) {
	assert ( columns >= 0 );

	if (columns != this->columns) {
		this->columns = columns;
		invalidate();
	}
}

Dimension TextArea::getPreferredSize(int rows, int columns) const {
	return peer != NULL ? 
		peer_getPreferredSize(rows, columns) :
		TextComponent::getPreferredSize();
}

Dimension TextArea::getPreferredSize() const {
	return rows > 0 && columns > 0 ? 
		getPreferredSize(rows, columns) :
		TextComponent::getPreferredSize();
}

Dimension TextArea::getMinimumSize(int rows, int columns) const {
	return peer != NULL ? 
		peer_getMinimumSize(rows, columns) :
		TextComponent::getMinimumSize();
}

Dimension TextArea::getMinimumSize() const {
	return rows > 0 && columns > 0 ? 
		getMinimumSize(rows, columns) :
	TextComponent::getMinimumSize();
}

void TextArea::peer_replaceRange(const String& str, int start, int end) {
	assert ( peer != NULL );

	::SendMessage(peer, EM_SETSEL, start, end);
	::SendMessage(peer, EM_REPLACESEL, 
			(WPARAM)FALSE, (LPARAM)str.c_str());
}

Dimension TextArea::peer_getPreferredSize(int rows, int columns) const {
	return peer_getMinimumSize(rows, columns);
}

Dimension TextArea::peer_getMinimumSize(int rows, int columns) const {
	assert ( peer != NULL );

	FontMetrics fm = getFontMetrics();
	int w = fm.charWidth(_T('0'));
	int h = fm.getHeight();

	return Dimension(w * columns + 20, h * rows + 20);
}

DWORD TextArea::getWindowStyle() const {
	DWORD style = WS_CHILD | WS_CLIPSIBLINGS | WS_TABSTOP |
			ES_LEFT | ES_MULTILINE | ES_WANTRETURN | ES_NOHIDESEL;

	DWORD scrollStyle = 0;
	switch (scrollbarVisibility) {
	case SCROLLBARS_NONE:
		scrollStyle = ES_AUTOVSCROLL;
		break;
	case SCROLLBARS_VERTICAL_ONLY:
		scrollStyle = WS_VSCROLL | ES_AUTOVSCROLL;
		break;
	case SCROLLBARS_HORIZONTAL_ONLY:
		scrollStyle = WS_HSCROLL | ES_AUTOHSCROLL | ES_AUTOVSCROLL;
		break;
	case SCROLLBARS_BOTH:
		scrollStyle = WS_VSCROLL | WS_HSCROLL |
				ES_AUTOVSCROLL | ES_AUTOHSCROLL;
		break;
	default:
		assert ( false );
	}

	return style | scrollStyle;
}

DWORD TextArea::getWindowExStyle() const {
	return WS_EX_CLIENTEDGE;
}
