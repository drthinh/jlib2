#include <win32/win32.h>

#include <jlib/awt/Slider.h>
#include <jlib/awt/DefaultBoundedRangeModel.h>

#include <jlib/awt/ChangeListener.h>
#include <jlib/awt/ChangeEvent.h>

#define _WIN32_IE 0x0500
#include <commctrl.h>

#include <limits>
#include <cassert>

using namespace jlib::awt;

const Dimension Slider::PREFERRED_HORIZONTAL_SIZE(200, 25);
const Dimension Slider::PREFERRED_VERTICAL_SIZE(25, 200);
const Dimension Slider::MINIMUM_HORIZONTAL_SIZE(36, 25);
const Dimension Slider::MINIMUM_VERTICAL_SIZE(25, 36);

Slider::Slider(Slider::Orientation orientation) {
    init(orientation, 0, 100, 50);
}

Slider::Slider(int min, int max) {
    init(HORIZONTAL, min, max, 50);
}

Slider::Slider(int min, int max, int value) {
    init(HORIZONTAL, min, max, value);
}

Slider::Slider(Slider::Orientation orientation, int min, int max, int value) {
	init(orientation, min, max, value);
}

Slider::Slider(BoundedRangeModel* brm) {
    orientation = HORIZONTAL;
    setModel(brm);
    model->addChangeListener(this);

	paintTicks = false;
	paintTrack = true;
	paintLabels = false;
	isInverted = false;

	scrolling = false;
	owningModel = false;
}

Slider::~Slider() {
	if ( owningModel ) {
		delete model;
	}
}

void Slider::addNotify() {
	Component::addNotify();
	subClassWindow();

	peer_setRangeProperties(model->getValue(), model->getExtent(),
			model->getMinimum(), model->getMaximum());

	peer_setPaintTicks(paintTicks);
}

void Slider::addChangeListener(ChangeListener* l) {
	changeEventDispatcher.addListener(l);
}

void Slider::removeChangeListener(ChangeListener* l) {
	changeEventDispatcher.removeListener(l);
}

BoundedRangeModel* Slider::getModel() const {
    return model;
}

void Slider::setModel(BoundedRangeModel* m) {
	assert ( m != NULL );

	if ( m != model ) {
		model->removeChangeListener(this);
		if ( owningModel ) {
			delete model;
			owningModel = false;
		}

		model = m;
	}
}

int Slider::getValue() const { 
    return getModel()->getValue(); 
}

void Slider::setValue(int n) {
    getModel()->setValue(n);
}

int Slider::getMinimum() const { 
    return getModel()->getMinimum();
}

void Slider::setMinimum(int minimum) {
    getModel()->setMinimum(minimum);
}

int Slider::getMaximum() const { 
    return getModel()->getMaximum();
}

void Slider::setMaximum(int maximum) { 
    getModel()->setMaximum(maximum);
}

bool Slider::getValueIsAdjusting() const { 
    return getModel()->getValueIsAdjusting(); 
}

void Slider::setValueIsAdjusting(bool b) { 
    getModel()->setValueIsAdjusting(b);
}

int Slider::getExtent() const { 
    return getModel()->getExtent(); 
}

void Slider::setExtent(int extent) { 
    getModel()->setExtent(extent); 
}

Slider::Orientation Slider::getOrientation() const { 
    return orientation; 
}

void Slider::setOrientation(Slider::Orientation orientation) { 
    if ( orientation != this->orientation ) {
		this->orientation = orientation;
		if ( peer != NULL ) {
			peer_setOrientation(orientation);
		}
		invalidate();
    }
}

bool Slider::getInverted() const { 
    return isInverted; 
}

void Slider::setInverted(bool b) { 
    if ( b != isInverted ) {
		isInverted = b;
        repaint();
    }
}

int Slider::getMajorTickSpacing() const { 
    return majorTickSpacing; 
}

void Slider::setMajorTickSpacing(int n) {
	if ( n != majorTickSpacing ) {
		majorTickSpacing = n;
		if ( getPaintTicks() ) {
			repaint();
		}
	}
}

int Slider::getMinorTickSpacing() const { 
    return minorTickSpacing; 
}

void Slider::setMinorTickSpacing(int n) { 
	if ( n != minorTickSpacing ) {
		minorTickSpacing = n;
		if ( getPaintTicks() ) {
			if ( peer != NULL ) {
				peer_setTickSpacing(n);
			}
			repaint();
		}
	}
}

bool Slider::getSnapToTicks() const { 
    return snapToTicks; 
}

bool Slider::getSnapToValue() const { 
    return snapToValue;
}

void Slider::setSnapToTicks(bool b) { 
    snapToTicks = b;
}

void Slider::setSnapToValue(bool b) { 
    snapToValue = b;
}

bool Slider::getPaintTicks() const { 
    return paintTicks; 
}

void Slider::setPaintTicks(bool b) { 
	if ( b != paintTicks ) {
		paintTicks = b;
		if ( peer != NULL ) {
			peer_setPaintTicks(b);
		}
		invalidate();
	}
}

bool Slider::getPaintTrack() const { 
    return paintTrack; 
}

void Slider::setPaintTrack(bool b) { 
    if ( paintTrack != b ) {
		paintTrack = b;
		if ( peer != NULL ) {
			peer_setPaintTrack(b);
		}
		invalidate();
//        repaint();
    }
}

//	bool getPaintLabels() const { 
//        return paintLabels; 
//    }
//
//
//void Slider::setPaintLabels(bool b) {
//    bool oldValue = paintLabels;
//    paintLabels = b;
//    if ( labelTable == NULL && getMajorTickSpacing() > 0 ) {
//        setLabelTable( createStandardLabels( getMajorTickSpacing() ) );
//    }
//    if (paintLabels != oldValue) {
//        revalidate();
//        repaint();
//    }
//}

void Slider::init(Slider::Orientation orientation, 
		int min, int max, int value) {
	this->orientation = orientation;
	model = new DefaultBoundedRangeModel(value, 0, min, max);
	model->addChangeListener(this);
	paintTicks = false;
	paintTrack = true;
	paintLabels = false;
	isInverted = false;

	scrolling = false;
	owningModel = true;
}

void Slider::stateChanged(const ChangeEvent& e) {
	if ( !scrolling && peer != NULL ) {
		int value = model->getValue();
		int extent = model->getExtent();
		int min = model->getMinimum();
		int max = model->getMaximum();
		peer_setRangeProperties(value, extent, min, max);
	}

	changeEventDispatcher.fireEvent(this, &ChangeListener::stateChanged, e);
}

const Dimension& Slider::getPreferredHorizontalSize() const {
    return PREFERRED_HORIZONTAL_SIZE;
}

const Dimension& Slider::getPreferredVerticalSize() const {
    return PREFERRED_VERTICAL_SIZE;
}

const Dimension& Slider::getMinimumHorizontalSize() const {
    return MINIMUM_HORIZONTAL_SIZE;
}

const Dimension& Slider::getMinimumVerticalSize() const {
    return MINIMUM_VERTICAL_SIZE;
}

Dimension Slider::getPreferredSize() const {
//	recalculateIfInsetsChanged();
	Dimension d;
	if ( getOrientation() == VERTICAL ) {
		d = getPreferredVerticalSize();
		//d.width = insetCache.left + insetCache.right;
		//d.width += focusInsets.left + focusInsets.right;
		//d.width += trackRect.width + tickRect.width + labelRect.width;
	} else {
		d = getPreferredHorizontalSize();
		//d.height = insetCache.top + insetCache.bottom;
		//d.height += focusInsets.top + focusInsets.bottom;
		//d.height += trackRect.height + tickRect.height + labelRect.height;
	}

    return d;
}

Dimension Slider::getMinimumSize() const {
	//	recalculateIfInsetsChanged();
	Dimension d;

	if ( getOrientation() == VERTICAL ) {
		d = getMinimumVerticalSize();
		//d.width = insetCache.left + insetCache.right;
		//d.width += focusInsets.left + focusInsets.right;
		//d.width += trackRect.width + tickRect.width + labelRect.width;
	} else {
		d = getMinimumHorizontalSize();
		//d.height = insetCache.top + insetCache.bottom;
		//d.height += focusInsets.top + focusInsets.bottom;
		//d.height += trackRect.height + tickRect.height + labelRect.height;
	}

	return d;
}

Dimension Slider::getMaximumSize() const {
	Dimension d = getPreferredSize();
	if ( getOrientation() == VERTICAL ) {
		d.height = std::numeric_limits<short>::max();
	} else {
		d.width = std::numeric_limits<short>::max();
	}

	return d;
} 

//class ModelListener : ChangeListener {
//public:
//	ModelListener(Slider* slider) : slider(slider) {}
//
//	void stateChanged(const ChangeEvent& e) {
//        slider->fireStateChanged();
//    }
//
//private:
//	Slider* slider;
//};
//
//ChangeListener* Slider::createChangeListener() {
//    return new ModelListener();
//}
//
//void Slider::fireStateChanged() {
//	changeEventDispatcher.fireEvent(this, 
//		&ChangeListener::stateChanged, ChangeEvent());
//}
//

// peer operations
void Slider::peer_setOrientation(int orientation) {
	assert ( peer != NULL );

	DWORD style = ::GetWindowLong(peer, GWL_STYLE);
	if ( orientation == VERTICAL ) {
		style |= TBS_HORZ;
	} else {
		style |= TBS_VERT;
	}

	::SetWindowLong(peer, GWL_STYLE, style);
}

void Slider::peer_setValue(int v) {
	assert ( peer != NULL );

	::SendMessage(peer, TBM_SETPOS, TRUE, (LPARAM)(LONG)v);
}

void Slider::peer_setMinimum(int n) {
	assert ( peer != NULL );

	::SendMessage(peer, TBM_SETRANGEMIN, TRUE, (LPARAM)n);
}

void Slider::peer_setMaximum(int n) {
	assert ( peer != NULL );

	::SendMessage(peer, TBM_SETRANGEMAX, TRUE, (LPARAM)n);
}
void Slider::peer_setRangeProperties(
		int value, int extent, int min, int max) {
	assert ( peer != NULL );

	::SendMessage(peer, TBM_SETRANGEMIN, FALSE, min);
	::SendMessage(peer, TBM_SETRANGEMAX, FALSE, max);
	if ( extent > 0 ) {
		DWORD style = ::GetWindowLong(peer, GWL_STYLE);
		if ( ( style & TBS_ENABLESELRANGE ) == 0 ) {
			style |= TBS_ENABLESELRANGE;
			::SetWindowLong(peer, GWL_STYLE, style);
		}

		::SendMessage(peer, TBM_SETSELSTART, FALSE, min);
		::SendMessage(peer, TBM_SETSELEND, FALSE, max - extent);
	}

	::SendMessage(peer, TBM_SETPOS, TRUE, value);
}

void Slider::peer_setPaintTicks(bool b) {
	assert ( peer != NULL );

	DWORD style = ::GetWindowLong(peer, GWL_STYLE);
	if ( b ) {
		style &= ~TBS_NOTICKS;
		if ( minorTickSpacing > 0 ) {
			style |= TBS_AUTOTICKS;
		}
	} else {
		style |= TBS_NOTICKS;
	}

	::SetWindowLong(peer, GWL_STYLE, style);

	if ( b && minorTickSpacing > 0 ) {
		peer_setTickSpacing(minorTickSpacing);
	}
}

void Slider::peer_setTickSpacing(int n) {
	assert ( peer != NULL );

	::SendMessage(peer, TBM_SETTICFREQ, (WPARAM)n, 0);
}

void Slider::peer_setPaintTrack(bool b) {
	assert ( peer != NULL );

	DWORD style = ::GetWindowLong(peer, GWL_STYLE);
	if ( b ) {
		style &= ~TBS_NOTHUMB;
	} else {
		style |= TBS_NOTHUMB;
	}

	::SetWindowLong(peer, GWL_STYLE, style);
}

// win32

void Slider::handleScroll(int, int, bool) {
	int value = (int)::SendMessage(peer, TBM_GETPOS, 0, 0);
	if ( value != model->getValue() ) {
		scrolling = true;
		model->setValue(value);
		scrolling = false;
		int v = model->getValue();
		if ( v != value ) {
			peer_setValue(v);
		}
	}
}

LRESULT Slider::handleNotify(NMHDR* nmHdr) {
	if ( nmHdr->code == NM_CUSTOMDRAW ) {
		NMCUSTOMDRAW* ncd = (LPNMCUSTOMDRAW)nmHdr;
		if ( ncd->dwDrawStage == CDDS_PREPAINT ) {
			::SetTextColor(ncd->hdc, getForeground().getRGB());
			::SetBkColor(ncd->hdc, getBackground().getRGB());

			return CDRF_DODEFAULT;
		}
	}

	return 0;
}

LPCTSTR Slider::getClassName() const {
	return TRACKBAR_CLASS;
}

DWORD Slider::getStyle() const {
	DWORD style = WS_CHILD|WS_CLIPSIBLINGS|WS_TABSTOP;

	if ( orientation == VERTICAL ) {
		style |= TBS_HORZ;
	} else {
		style |= TBS_VERT;
	}

	//if ( getModel()->getExtent() > 0 ) {
	//	style |= TBS_ENABLESELRANGE;
	//} else {
	//}

	//if ( paintTicks ) {
	//	style &= ~TBS_NOTICKS;
	//	if ( minorTickSpacing > 0 ) {
	//		style |= TBS_AUTOTICKS;
	//	}
	//} else {
	//	style |= TBS_NOTICKS;
	//}

	return style;
}
