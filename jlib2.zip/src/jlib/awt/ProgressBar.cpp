#include <win32/win32.h>

#include <jlib/awt/ProgressBar.h>

#include <jlib/awt/ChangeListener.h>
#include <jlib/awt/ChangeEvent.h>
#include <jlib/awt/Graphics.h>

#include <jlib/lang/StringStream.h>

#include <limits>

using namespace jlib::awt;

using jlib::lang::OStringStream;


void ProgressBar::init(Orientation orient, int minimum, int maximum) {
	orientation = orient;
	model.setRangeProperties(0, minimum, maximum);
	setBorderPainted(true);
	setStringPainted(false);
}

void ProgressBar::setOrientation(Orientation v) {
	assert ( v == HORIZONTAL || v == VERTICAL );

	if ( v != orientation ) {
		orientation = v;
		invalidate();
    }
}

void ProgressBar::setStringPainted(bool b) {
    if ( shouldPaintString != b ) {
		shouldPaintString = b;
		if ( isVisible() ) {
			repaint();
		}
        invalidate();
    }
}

String ProgressBar::getString() const {
	if ( !progressString.empty() ) {
		return progressString;	
	}

	// Is there a "round" function in c/c++ standard library ?
	int percentage = (int)(100 * getPercentComplete() + 0.5);
	OStringStream oss;
	oss << percentage << '%';
	return oss.str();
}

void ProgressBar::setString(const String& s){
    if ( progressString != s ) {
		progressString = s;
		if ( isVisible() ) {
			repaint();
		}
		invalidate();
    }
}

double ProgressBar::getPercentComplete() const {
	long span = model.getMaximum() - model.getMinimum();
	double currentValue = model.getValue();
	return ( currentValue - model.getMinimum() ) / span;
}

void ProgressBar::setBorderPainted(bool b) {
    if ( shouldPaintBorder != b) {
		shouldPaintBorder = b;
        repaint();
    }
}

void ProgressBar::addChangeListener(ChangeListener* l) {
	changeEventDispatcher.addListener(l);
}

void ProgressBar::removeChangeListener(ChangeListener* l) {
	changeEventDispatcher.removeListener(l);
}

void ProgressBar::setValue(int v) {
	if ( v != model.getValue() ) {
		model.setValue(v);
		changeEventDispatcher.fireEvent(this, 
				&ChangeListener::stateChanged, ChangeEvent());
		repaint();
	}
}

void ProgressBar::setMinimum(int v) {
	if ( v != model.getMinimum() ) {
		model.setMinimum(v);
		repaint();
	}
}

void ProgressBar::setMaximum(int v) {
	if ( v != model.getMaximum() ) {
		model.setMaximum(v);
		repaint();
	}
}

void ProgressBar::update(Graphics& g) {
	int x = 0;
	int y = 0;
	int width = this->width;
	int height = this->height;

	if ( shouldPaintBorder ) {
		paintBorder(g);

		++x;
		++y;
		width -= 2;
		height -= 2;
	}

	int boundary;
	
	if ( getOrientation() == HORIZONTAL ) {
		boundary = (int)(getPercentComplete() * width + 0.5);
		g.setColor(getSelectionForeground());
		g.fillRect(x, y, boundary, height);
		g.setColor(getSelectionBackground());
		g.fillRect(boundary + 1, y, width - boundary, height);
	} else {
		boundary = (int)(getPercentComplete() * height + 0.5);
		g.setColor(getSelectionBackground());
		g.fillRect(x, y, width, height - boundary);
		g.setColor(getSelectionForeground());
		g.fillRect(x, height - boundary + 1, width, boundary);
	}

	if ( isStringPainted() ) {
		paintString(g, x, y, width, height, boundary);
	}
}

void ProgressBar::paint(Graphics& g) {
	update(g);
}

void ProgressBar::paintBorder(Graphics& g) {
	g.drawRect(0, 0, width, height);
}

void ProgressBar::paintString(Graphics& g, 
		int x, int y, int width, int height, int boundary) {
	String str = getString();
	g.setFont(getFont());
	Point p = getStringPlacement(g, str, x, y, width, height);
	Rectangle oldClip = g.getClipBounds();
	g.setColor(getSelectionBackground());
	if ( getOrientation() == HORIZONTAL ) {
		g.setColor(getSelectionForeground());
		g.drawString(str, p.x, p.y);
		g.setColor(getSelectionBackground());
		g.setClip(x, y, boundary, height);
		g.drawString(str, p.x, p.y);
	} else {
		g.setColor(getSelectionBackground());
		g.drawString(str, p.x, p.y);
		g.setColor(getSelectionForeground());
		g.setClip(x, y, width, height - boundary);
		g.drawString(str, p.x, p.y);
	}

	g.setClip(oldClip.x, oldClip.y, oldClip.width, oldClip.height);
}

Point ProgressBar::getStringPlacement(Graphics& /*g*/, 
			const String& progressString, 
			int x, int y, int width, int height) {
	FontMetrics fm = getFontMetrics();

	int stringWidth = fm.stringWidth(progressString);
	int stringHeight = fm.getAscent() + fm.getDescent();

	int xx = x + (width - stringWidth)/2;
	int yy = y + (height + stringHeight)/2 - fm.getDescent();

	return Point(xx, yy);
} 

Dimension ProgressBar::getMinimumSize() const {
	Dimension dim = getPreferredSize();
	( getOrientation() == HORIZONTAL ? dim.width : dim.height ) = 10;

	return dim;
}

const Dimension ProgressBar::PREFERRED_INNER_HORIZONTAL(146, 12);
const Dimension ProgressBar::PREFERRED_INNER_VERTICAL(12, 146); 

Dimension ProgressBar::getPreferredSize() const {
	if ( !isValid() ) {
		String test;
		if ( getOrientation() == HORIZONTAL ) {
			prefSize = getPreferredInnerHorizontal();
			test = getString();
		} else {
			prefSize = getPreferredInnerVertical();
			test = _T("100%");
		}

		if ( isStringPainted() ) {
			FontMetrics fm = getFontMetrics();
			int w = fm.stringWidth(test);
			int h = fm.getHeight();
			if ( w > prefSize.width ) {
				prefSize.width = w;
			}
			if ( h > prefSize.height ) {
				prefSize.height = h;
			}
		}

		if ( isBorderPainted() ) {
			prefSize.width += 2;
			prefSize.height += 2;
		}
	}

	return prefSize;
}

Dimension ProgressBar::getMaximumSize() const {
	Dimension dim = getPreferredSize();
	( getOrientation() == HORIZONTAL ? dim.width : dim.height ) = 
		dim.width = std::numeric_limits<int>::max();

	return dim;
}

const Color& ProgressBar::getDefaultForeground() const {
	return Color::BLUE;
}

const Color& ProgressBar::getDefaultBackground() const {
	return Color::WHITE;
}
