#include <win32/win32.h>

#include <jlib/awt/Canvas.h>
#include <jlib/awt/Container.h>
#include <jlib/awt/Graphics.h>

using namespace jlib::awt;

void Canvas::update(Graphics& g) {
	g.clearRect(0, 0, getWidth(), getHeight());
	paint(g);
}

bool Canvas::wmMouseDown(WPARAM wParam, LPARAM lParam, int button) {
	if ( ::GetCapture() != peer ) {
		::SetCapture(peer);
	}

	return Component::wmMouseDown(wParam, lParam, button);
}

bool Canvas::wmMouseUp(WPARAM wParam, LPARAM lParam, int button) {
	bool isMouseCaptured = ::GetCapture() == peer;
	bool areButtonsReleased = 
			( wParam & (MK_LBUTTON|MK_MBUTTON|MK_RBUTTON) ) == 0;

	if ( isMouseCaptured && areButtonsReleased ) {
		// user has released all buttons, so release the capture
		::ReleaseCapture();
	} 

	return Component::wmMouseUp(wParam, lParam, button);
}

