#include <win32/win32.h>

#include <jlib/awt/Menu.h>

#include <algorithm>
#include <functional>
#include <cassert>



using namespace jlib::awt;

Menu::Menu(const String& label, bool tearOff) 
	: MenuItem(label), 
	tearOff(tearOff), 
	isHelp(false),
	peer(NULL) {
}

void Menu::addNotify() {
	if (peer == NULL)
		peer = peer_createMenu();

	MenuItemList::iterator i;
	for ( i = items.begin(); i != items.end(); ++i ) {
		(*i)->addNotify();
	}
}

void Menu::removeNotify() {
	std::for_each(items.begin(), items.end(),
			std::mem_fun(&MenuItem::removeNotify));

	MenuItem::removeNotify();
}

bool Menu::isTearOff() const {
	return tearOff;
}

int Menu::getItemCount() const {
	return static_cast<int>(items.size());
}

MenuItem* Menu::getItem(int index) const {
	return items[index];
}

MenuItem* Menu::add(MenuItem* mi) {
	if (mi->getParent() != NULL) {
		mi->getParent()->remove(mi);
	}

	items.push_back(mi);
	mi->setParent(this);

	if (peer != NULL) {
		mi->addNotify();
		peer_addItem(mi);
	}

	return mi;
}

void Menu::insert(MenuItem* menuItem, int index) {
	assert ( index >=0 );

	int nitems = getItemCount();
	MenuItemList tempItems;

	for ( int i = index; i < nitems; ++i ) {
		tempItems.push_back(getItem(index));
		remove(index);
	}

	add(menuItem);

	MenuItemList::iterator j;
	for ( j = tempItems.begin(); j != tempItems.end(); ++j ) {
		add(*j);
	} 
}

MenuItem* Menu::getSeparator() {
	static MenuItem separator(_T("-"));
	return &separator;
}

void Menu::addSeparator() {
	add(getSeparator());
}

void Menu::insertSeparator(int index) {
	assert ( index >= 0 );

	insert(getSeparator(), index);
}

void Menu::remove(int index) {
	MenuItem* mi = getItem(index);
	items.erase(items.begin() + index);

	if (peer != NULL) {
		mi->removeNotify();
		mi->setParent(NULL);
		peer_delItem(index);
	}
}

void Menu::remove(MenuItem* item) {
	MenuItemList::iterator i = 
			std::find(items.begin(), items.end(), item);
	if ( i != items.end() ) {
		items.erase(i);
	}
}

void Menu::removeAll() {
	for (int i = static_cast<int>(items.size()) - 1; i >= 0; --i) {
	    remove(i);
	}
}

// peer operations
HMENU Menu::peer_createMenu() {
	return ::CreateMenu();
}

void Menu::peer_addItem(MenuItem*) {
}

void Menu::peer_delItem(int index) {
	::RemoveMenu(peer, index, MF_BYPOSITION);
}

void Menu::peer_dispose() {
	::DestroyMenu(peer);
	peer = NULL;
}
