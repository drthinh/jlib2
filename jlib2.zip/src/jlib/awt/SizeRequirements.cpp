#include <jlib/awt/SizeRequirements.h>

#include <limits>
#include <algorithm>

using namespace jlib::awt;
using std::numeric_limits;

SizeRequirements SizeRequirements::getTiledSizeRequirements(
	const SizeRequirements* children, int len) {
	SizeRequirements total;
	for (int i = 0; i < len; i++) {
		const SizeRequirements& req = children[i];
		total.minimum = std::min(
			total.minimum + req.minimum, 
			numeric_limits<int>::max());
		total.preferred = std::min(
			total.preferred + req.preferred, 
			numeric_limits<int>::max());
		total.maximum = std::min(
			total.maximum + req.maximum, 
			numeric_limits<int>::max());
	}

	return total;
}

SizeRequirements SizeRequirements::getAlignedSizeRequirements(
	const SizeRequirements* children, int len) {
	SizeRequirements totalAscent;
	SizeRequirements totalDescent;
	for (int i = 0; i < len; i++) {
		const SizeRequirements& req = children[i];

		int ascent = (int) (req.alignment * req.minimum);
		int descent = req.minimum - ascent;
		totalAscent.minimum = std::max(ascent, totalAscent.minimum);
		totalDescent.minimum = std::max(descent, totalDescent.minimum);

		ascent = (int) (req.alignment * req.preferred);
		descent = req.preferred - ascent;
		totalAscent.preferred = std::max(ascent, totalAscent.preferred);
		totalDescent.preferred = std::max(descent, totalDescent.preferred);

		ascent = (int) (req.alignment * req.maximum);
		descent = req.maximum - ascent;
		totalAscent.maximum = std::max(ascent, totalAscent.maximum);
		totalDescent.maximum = std::max(descent, totalDescent.maximum);
	}
	int min = std::min(totalAscent.minimum + totalDescent.minimum, 
			numeric_limits<int>::max());
	int pref = std::min(totalAscent.preferred + totalDescent.preferred, 
			numeric_limits<int>::max());
	int max = std::min(totalAscent.maximum + totalDescent.maximum, 
			numeric_limits<int>::max());
	float alignment = 0.0f;
	if (min > 0) {
		alignment = (float) totalAscent.minimum / min;
		alignment = alignment > 1.0f ? 1.0f : alignment < 0.0f ? 0.0f : alignment;
	}
	return SizeRequirements(min, pref, max, alignment);
}

void SizeRequirements::calculateTiledPositions(
		int allocated, const SizeRequirements& total,
		const SizeRequirements* children, int childrenLen,
		int* offsets, int* spans) {
	calculateTiledPositions(allocated, total, 
			children, childrenLen,
			offsets, spans, true);
}

void SizeRequirements::calculateTiledPositions(int allocated,
	const SizeRequirements& /*total*/,
	const SizeRequirements* children, int childrenLen,
	int* offsets, int* spans, bool forward) {
	// The total argument turns out to be a bad idea since the
	// total of all the children can overflow the integer used to
	// hold the total.  The total must therefore be calculated and
	// stored in long variables.
	long min = 0;
	long pref = 0;
	long max = 0;
	for (int i = 0; i < childrenLen; i++) {
		min += children[i].minimum;
		pref += children[i].preferred;
		max += children[i].maximum;
	}
	if (allocated >= pref) {
		expandedTile(allocated, min, pref, max, 
			children, childrenLen,
			offsets, spans, forward);
	} else {
		compressedTile(allocated, min, pref, max, 
			children, childrenLen, 
			offsets, spans, forward);
	}
}

void SizeRequirements::compressedTile(
		int allocated, long min, long pref, long /*max*/,
		const SizeRequirements* request, int requestLen,
		int* offsets, int* spans, bool forward) {

	// ---- determine what we have to work with ----
	float totalPlay = static_cast<float>(
			std::min(pref - allocated, pref - min));
	float factor = (pref - min == 0) ? 0.0f : totalPlay / (pref - min);

	// ---- make the adjustments ----
	int totalOffset;
	if( forward ) {
		// lay out with offsets increasing from 0
		totalOffset = 0;
		for (int i = 0; i < requestLen; i++) {
			offsets[i] = totalOffset;
			const SizeRequirements& req = request[i];
			int play = (int)(factor * (req.preferred - req.minimum));
			spans[i] = req.preferred - play;
			totalOffset = std::min(totalOffset + spans[i], 
					numeric_limits<int>::max());
		}
	} else {
		// lay out with offsets decreasing from the end of the allocation
		totalOffset = allocated;
		for (int i = 0; i < requestLen; i++) {
			const SizeRequirements& req = request[i];
			int play = (int)(factor * (req.preferred - req.minimum));
			spans[i] = req.preferred - play;
			offsets[i] = totalOffset - spans[i];
			totalOffset = std::max(totalOffset - spans[i], 0);
		}
	}
}

void SizeRequirements::expandedTile(
		int allocated, long /*min*/, long pref, long max,
		const SizeRequirements* request, int requestLen,
		int* offsets, int* spans, bool forward) {

	// ---- determine what we have to work with ----
	float totalPlay = static_cast<float>(
			std::min(allocated - pref, max - pref));
	float factor = (max - pref == 0) ? 0.0f : totalPlay / (max - pref);

	// ---- make the adjustments ----
	int totalOffset;
	if( forward ) {
		// lay out with offsets increasing from 0
		totalOffset = 0;
		for (int i = 0; i < requestLen; i++) {
			offsets[i] = totalOffset;
			const SizeRequirements& req = request[i];
			int play = (int)(factor * (req.maximum - req.preferred));
			spans[i] = std::min(req.preferred + play, 
					numeric_limits<int>::max());
			totalOffset = std::min(totalOffset + spans[i], 
					numeric_limits<int>::max());
		}
	} else {
		// lay out with offsets decreasing from the end of the allocation
		totalOffset = allocated;
		for (int i = 0; i < requestLen; i++) {
			const SizeRequirements& req = request[i];
			int play = (int)(factor * (req.maximum - req.preferred));
			spans[i] = std::min(req.preferred + play, 
				numeric_limits<int>::max());
			offsets[i] = totalOffset - spans[i];
			totalOffset = std::max(totalOffset - spans[i], 0);
		}
	}
}

void SizeRequirements::calculateAlignedPositions(
		int allocated,
		const SizeRequirements& total,
		const SizeRequirements* children, int childrenLen,
		int* offsets, int* spans) {
	calculateAlignedPositions(allocated, total, 
		children, childrenLen, offsets, spans, true);
}

void SizeRequirements::calculateAlignedPositions(
		int allocated, const SizeRequirements& total,
		const SizeRequirements* children, int childrenLen,
		int* offsets, int* spans, bool normal) {
	float totalAlignment = normal ? total.alignment : 1.0f - total.alignment;
	int totalAscent = (int)(allocated * totalAlignment);
	int totalDescent = allocated - totalAscent;
	for (int i = 0; i < childrenLen; i++) {
		const SizeRequirements& req = children[i];
		float alignment = normal ? req.alignment : 1.0f - req.alignment;
		int maxAscent = (int)(req.maximum * alignment);
		int maxDescent = req.maximum - maxAscent;
		int ascent = std::min(totalAscent, maxAscent);
		int descent = std::min(totalDescent, maxDescent);

		offsets[i] = totalAscent - ascent;
		spans[i] = std::min(ascent + descent, numeric_limits<int>::max());
	}     
}
