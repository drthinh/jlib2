#include <win32/win32.h>
#include <commctrl.h>

#include <jlib/verify.h>

#include <jlib/awt/MouseStateTracker.h>

#include <jlib/awt/Component.h>
#include <jlib/awt/Toolkit.h>
#include <jlib/awt/MouseEvent.h>

using namespace jlib::awt;

MouseStateTracker& MouseStateTracker::instance() {
	static MouseStateTracker tracker;
	return tracker;
}

MouseStateTracker::MouseStateTracker() {
	multiClickTime = ::GetDoubleClickTime();
	multiClickMaxX = ::GetSystemMetrics(SM_CXDOUBLECLK);
	multiClickMaxY = ::GetSystemMetrics(SM_CYDOUBLECLK);

	lastWnd = NULL;
	lastClickComp = NULL;
	lastComp = NULL;

	lastTime = 0;
	lastClickX = lastClickY = 0;
	lastX = lastY = 0;
	lastButton = 0;
	clickCount = 0;

	dragged = false;
}

bool MouseStateTracker::mouseDown(Component* comp, UINT /*flags*/, 
		int x, int y, int button) {
	LONG when = ::GetMessageTime();
	if ( lastClickComp == comp && 
		lastButton == button && 
		when - lastTime <= multiClickTime && 
		abs(x - lastClickX) <= multiClickMaxX &&
		abs(y - lastClickY) <= multiClickMaxY) {
		clickCount++;
	} else {
		clickCount = 1;
		lastClickComp = comp;
		lastButton = button;
		lastClickX = x;
		lastClickY = y;
	}

	lastTime = when;
	dragged = false;

	MouseEvent e(MouseEvent::MOUSE_PRESSED, when, 
		Toolkit::getJavaModifiers(button), x, y, clickCount, false);

	comp->processMouseEvent(e);
	return e.isConsumed();
}

bool MouseStateTracker::mouseUp(Component* comp, UINT /*flags*/,
		int x, int y, int button) {

	long when = ::GetMessageTime();
	MouseEvent e(MouseEvent::MOUSE_RELEASED, ::GetMessageTime(), 
			Toolkit::getJavaModifiers(button), x, y, 
			clickCount, button == VK_RBUTTON ? 1 : 0);
	comp->processMouseEvent(e);

	// If no movement, then report a click following the button release
	if ( !dragged ) {
		MouseEvent e(MouseEvent::MOUSE_CLICKED, when, x, y, 
				Toolkit::getJavaModifiers(button), clickCount, 0);
		comp->processMouseEvent(e);
	}

	dragged = FALSE;

	return e.isConsumed();
}

bool MouseStateTracker::mouseMove(Component* comp, 
		UINT flags, int x, int y) {
	if ( lastComp != comp || x != lastX || y != lastY ) {
		lastComp = comp;
		lastX = x;
		lastY = y;

		MouseEvent::EventId id;
		if ( ( flags & (MK_LBUTTON|MK_MBUTTON|MK_RBUTTON) ) != 0 ) {
			dragged = TRUE;
			id = MouseEvent::MOUSE_DRAGGED;
		} else {
			id = MouseEvent::MOUSE_MOVED;
		}

		int button;
		if ( flags & MK_LBUTTON ) {
			button = VK_LBUTTON;
		} else if (flags & MK_MBUTTON) {
			button = VK_MBUTTON;
		} else if (flags & MK_RBUTTON) {
			button = VK_RBUTTON;
		} else {
			button = 0;
		}

		filterEnter(comp, x, y, button);

		MouseEvent e(id, ::GetMessageTime(), 
				Toolkit::getJavaModifiers(button), x, y, 0, false);
		comp->processMouseMotionEvent(e);
		return e.isConsumed();
	}

	return true;
}

bool MouseStateTracker::mouseLeave(Component* comp) {
	if ( comp->getPeer() == lastWnd ) {
		lastWnd = NULL;
	}

	MouseEvent e(MouseEvent::MOUSE_EXITED,
			::GetMessageTime(), 0, 0, 0, 0, false);
	comp->processMouseEvent(e);
	return e.isConsumed();
}

void MouseStateTracker::filterEnter(Component* comp, 
		int x, int y, int button) {
	if ( comp->getPeer() != lastWnd ) {
		lastWnd = comp->getPeer();

		TRACKMOUSEEVENT tme;
		tme.cbSize = sizeof(tme);
		tme.dwFlags = TME_LEAVE;
		tme.hwndTrack = comp->getPeer();
        verify ( _TrackMouseEvent(&tme) );

		MouseEvent e(MouseEvent::MOUSE_ENTERED,
				::GetMessageTime(), Toolkit::getJavaModifiers(button),
				x, y, 0, false);
		comp->processMouseEvent(e);
	}
}
