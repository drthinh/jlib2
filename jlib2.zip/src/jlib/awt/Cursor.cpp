#include <win32/win32.h>

#include <cassert>

#include <jlib/awt/Cursor.h>

namespace jlib { namespace awt {

class Cursor::Predefined {
public:
	enum {
		NUM_OF_PREDEFINED = Cursor::MOVE_CURSOR + 1
	};

	Predefined() {
		memset(cache, 0, sizeof(cache));
	}

	~Predefined() {
		for ( int i=0; i<NUM_OF_PREDEFINED; ++i ) {
			if ( cache[i] != NULL ) {
				delete cache[i];
			}
		}
	}

	const Cursor& get(int type) const {
		assert ( type >= DEFAULT_CURSOR && type <= MOVE_CURSOR );

		if ( cache[type] == NULL ) {
			LPCTSTR nativeName = NULL;
			LPCTSTR name = NULL;

			switch( type ) {
			case DEFAULT_CURSOR:
				nativeName = IDC_ARROW;
				name = _T("Default Cursor");
				break;
			case CROSSHAIR_CURSOR:
				nativeName = IDC_CROSS;
				name = _T("Crosshair Cursor");
				break;
			case TEXT_CURSOR:
				nativeName = IDC_IBEAM;
				name = _T("Text Cursor");
				break;
			case WAIT_CURSOR:
				nativeName = IDC_WAIT;
				name = _T("Wait Cursor");
				break;
			case SW_RESIZE_CURSOR:
				nativeName = IDC_SIZENESW;
				name = _T("Southwest Resize Cursor");
				break;
			case SE_RESIZE_CURSOR:
				nativeName = IDC_SIZENWSE;
				name = _T("Southeast Resize Cursor");
				break;
			case NW_RESIZE_CURSOR:
				nativeName = IDC_SIZENWSE;
				name = _T("Northwest Resize Cursor");
				break;
			case NE_RESIZE_CURSOR:
				nativeName = IDC_SIZENESW;
				name = _T("Northeast Resize Cursor");
				break;
			case N_RESIZE_CURSOR:
				nativeName = IDC_SIZENS;
				name = _T("North Resize Cursor");
				break;
			case S_RESIZE_CURSOR:
				nativeName = IDC_SIZENS;
				name = _T("South Resize Cursor");
				break;
			case W_RESIZE_CURSOR:
				nativeName = IDC_SIZEWE;
				name = _T("West Resize Cursor");
				break;
			case E_RESIZE_CURSOR:
				nativeName = IDC_SIZEWE;
				name = _T("East Resize Cursor");
				break;
			case HAND_CURSOR:
				nativeName = IDC_HAND;
				name = _T("Hand Cursor");
				break;
			case MOVE_CURSOR:
				nativeName = IDC_SIZEALL;
				name = _T("Move Cursor");
				break;
			default:
				assert ( false );
			}

			cache[type] = new Cursor(type, name, nativeName);
		}

		return *cache[type];
	}

private:
	mutable Cursor* cache[NUM_OF_PREDEFINED];
};


Cursor::Cursor() { 
	*this = getDefaultCursor();
}

Cursor::Cursor(int type) {
	assert (type >= DEFAULT_CURSOR && type <= Cursor::MOVE_CURSOR);
	*this = getPredefinedCursor(type);
}

Cursor::Cursor(const String& name)
	: type(Cursor::CUSTOM_CURSOR), name(name), peer(NULL) {
	// custom cursors are not yet supported
	assert ( false );
}


const Cursor& Cursor::getPredefinedCursor(int type) {
	assert ( type >= DEFAULT_CURSOR && type <= MOVE_CURSOR );

	static Predefined predefined;
	return predefined.get(type);
}

const Cursor& Cursor::getDefaultCursor() {
	return getPredefinedCursor(Cursor::DEFAULT_CURSOR);
}


Cursor::Cursor(int type, LPCTSTR name, LPCTSTR nativeName)
	: type(type), name(name) {

	assert ( type >= DEFAULT_CURSOR && type <= MOVE_CURSOR );

	peer = ::LoadCursor(NULL, nativeName);
	assert ( peer != NULL );
}

}}
