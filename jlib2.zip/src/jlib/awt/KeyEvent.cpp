#include <win32/win32.h>

#include <cassert>

#include <jlib/awt/KeyEvent.h>

using namespace jlib::awt;

#ifdef UNICODE
const TCHAR KeyEvent::CHAR_UNDEFINED = (TCHAR)0x0FFFF;
#else
const TCHAR KeyEvent::CHAR_UNDEFINED = (TCHAR)-1;
#endif

KeyEvent::KeyEvent(EventId id, long when, int modifiers, 
		int keyCode, TCHAR keyChar) 
		: InputEvent(when, modifiers), 
		id(id), keyCode(keyCode), keyChar(keyChar) {
}

bool KeyEvent::isActionKey() const {
	switch (keyCode) {
	case HOME:
	case END:
	case PAGE_UP:
	case PAGE_DOWN:
	case UP:
	case DOWN:
	case LEFT:
	case RIGHT:

	case KP_LEFT: 
	case KP_UP: 
	case KP_RIGHT: 
	case KP_DOWN: 

	case F1:
	case F2:
	case F3:
	case F4:
	case F5:
	case F6:
	case F7:
	case F8:
	case F9:
	case F10:
	case F11:
	case F12:
	case F13:
	case F14:
	case F15:
	case F16:
	case F17:
	case F18:
	case F19:
	case F20:
	case F21:
	case F22:
	case F23:
	case F24:
	case PRINTSCREEN:
	case SCROLL_LOCK:
	case CAPS_LOCK:
	case NUM_LOCK:
	case PAUSE:
	case INSERT:
	case FINAL:
	case HELP:
		return true;
	}

	return false;
}
