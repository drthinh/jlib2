#include <win32/win32.h>

#include <jlib/awt/Panel.h>
#include <jlib/awt/FlowLayout.h>

using namespace jlib::awt;

Panel::Panel() 
	: defLayout(new FlowLayout) {
	setLayout(defLayout);
}

Panel::Panel(LayoutManager* layout) 
	: defLayout(NULL) {
	setLayout(layout);
}

Panel::~Panel() {
	if ( defLayout != NULL ) {
		delete defLayout;
	}
}
