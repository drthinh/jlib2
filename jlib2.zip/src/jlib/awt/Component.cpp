#include <win32/win32.h>

#include <jlib/verify.h>

#include <jlib/awt/Component.h>

#include <jlib/awt/Container.h>

#include <jlib/awt/SystemColor.h>

#include <jlib/awt/imp/GetDCGraphics.h>

#include <jlib/awt/Toolkit.h>
#include <jlib/awt/ToolTipManager.h>

#include <jlib/awt/ComponentListener.h>
#include <jlib/awt/ComponentEvent.h>

#include <jlib/awt/MouseListener.h>
#include <jlib/awt/MouseMotionListener.h>
#include <jlib/awt/MouseEvent.h>

#include <jlib/awt/KeyListener.h>
#include <jlib/awt/KeyEvent.h>

#include <jlib/awt/FocusListener.h>
#include <jlib/awt/FocusEvent.h>

#include <jlib/awt/HierarchyListener.h>
#include <jlib/awt/HierarchyEvent.h>

#include <jlib/awt/MouseStateTracker.h>

//#include <jlib/awt/KeyboardFocusManager.h>

#include <memory>
#include <limits>

using namespace jlib::awt;


LPCTSTR Component::className = _T("jlib.awt.Component");

const float Component::TOP_ALIGNMENT = 0.0f;
const float Component::CENTER_ALIGNMENT = 0.5f;
const float Component::BOTTOM_ALIGNMENT = 1.0f;
const float Component::LEFT_ALIGNMENT = 0.0f;
const float Component::RIGHT_ALIGNMENT = 1.0f; 


Component::Component()
	: foregroundSet(false),	backgroundSet(false), fontSet(false), 
	visible(true), parent(NULL), enabled(true), valid(false), 
	peer(NULL), id(0), backgroundBrush(NULL), defaultWndProc(NULL) {
}

Component::~Component() {
	if ( backgroundBrush != NULL ) {
		::DeleteObject(backgroundBrush);
	}
}

void Component::addNotify() {
	peer_initClass();
	peer = peer_create();

	peer_setFont(font);

	if ( !hierarchyEventDispatcher.empty() ) {
		HierarchyEvent e(HierarchyEvent::HIERARCHY_CHANGED, this, parent, 
				HierarchyEvent::DISPLAYABILITY_CHANGED |
				( isShowing() ? HierarchyEvent::SHOWING_CHANGED : 0 ) );

		processHierarchyEvent(e);
	}
}

void Component::removeNotify() {
	if ( peer != NULL ) {
		peer_destroy();	
		peer = NULL;
	}

	if ( !hierarchyEventDispatcher.empty() ) {
		HierarchyEvent e(HierarchyEvent::HIERARCHY_CHANGED, this, parent, 
				HierarchyEvent::DISPLAYABILITY_CHANGED |
				( isShowing() ? HierarchyEvent::SHOWING_CHANGED : 0 ) );

		processHierarchyEvent(e);
	}
}

void Component::setForeground(const Color& c) {
	if ( foreground != c ) {
		foreground = c;
		foregroundSet = true;
		if ( peer != NULL ) {
			peer_setForeground();
		}
	}
}

inline void Component::unsetForeground() {
	if ( foregroundSet ) {
		foregroundSet = false;
		if ( peer != NULL ) {
			peer_setForeground();
		}
	}
}

const Color& Component::getForeground() const {
	const Component* comp = this;
	while ( !comp->isForegroundSet() && !comp->isWindow() ) {
		comp = comp->getParent();
	}

	if ( comp->isForegroundSet() ) {
		return comp->foreground;
	}

	return getDefaultForeground();
}

void Component::setBackground(const Color& c) {
	if ( background != c ) {
		background = c;
		backgroundSet = true;
		if ( peer != NULL ) {
			peer_setBackground();
		}
	}
}

inline void Component::unsetBackground() {
	if ( backgroundSet ) {
		backgroundSet = false;
		if ( peer != NULL ) {
			peer_setBackground();
		}
	}
}

const Color& Component::getBackground() const {
	const Component* comp = this;
	while ( !comp->isBackgroundSet() && !comp->isWindow() ) {
		comp = comp->getParent();
	}

	if ( comp->isBackgroundSet() ) {
		return comp->background;
	}

	return getDefaultBackground();
}

const Color& Component::getDefaultForeground() const {
	Component* parent = getParent();
	if ( parent != NULL ) {
		return parent->getDefaultForeground();
	}

	return SystemColor::CONTROL_TEXT;
}

const Color& Component::getDefaultBackground() const {
	Component* parent = getParent();
	if ( parent != NULL ) {
		return parent->getDefaultBackground();
	}

	return SystemColor::CONTROL;
}

HBRUSH Component::getBackgroundBrush() const {
	if ( backgroundBrush == NULL ) {
		backgroundBrush = ::CreateSolidBrush(getBackground().getRGB());
		assert ( backgroundBrush != NULL );
	}

	return backgroundBrush;
}

void Component::setVisible(bool b) {
	if ( peer != NULL && b != visible ) {
		peer_setVisible(b);
	}

	if ( !visible && b ) {
		visible = true;
		if ( !componentEventDispatcher.empty() ) {
			componentEventDispatcher.fireEvent(this, 
				&ComponentListener::componentShown, 
				ComponentEvent(ComponentEvent::COMPONENT_SHOWN));
		}
	} else if ( visible && !b ) {
		visible = false;
		if ( !componentEventDispatcher.empty() ) {
			componentEventDispatcher.fireEvent(this, 
				&ComponentListener::componentHidden, 
				ComponentEvent(ComponentEvent::COMPONENT_HIDDEN));
		}
	}

	if ( parent != NULL ) {
		parent->invalidate();
	}

	visible = b;
}

bool Component::isShowing() const {
	if ( isVisible() && getPeer() != NULL ) {
		return parent == NULL || parent->isShowing();
	}

	return false;
}

void Component::setBounds(int x, int y, int width, int height) {
	bool moved = this->x != x || this->y != y;
	bool resized = this->width != width || this->height != height;

	this->x = x;
	this->y = y;
	this->width = width;
	this->height = height;
	if ( peer != NULL ) {
		peer_setBounds(x, y, width, height);

		if ( resized ) {
			invalidate();
		}

		if ( parent != NULL && parent->isValid() ) {
			parent->invalidate();
		}
	}

	if ( !componentEventDispatcher.empty() ) {
		if ( moved ) {
			componentEventDispatcher.fireEvent(this, 
					&ComponentListener::componentMoved,
					ComponentEvent(ComponentEvent::COMPONENT_MOVED));
		}

		if ( resized ) {
			componentEventDispatcher.fireEvent(this, 
					&ComponentListener::componentResized,
					ComponentEvent(ComponentEvent::COMPONENT_RESIZED));
		}
	}
}

void Component::setLocation(int x, int y) {
	setBounds(x, y, width, height);
}

void Component::setSize(int width, int height) {
	setBounds(x, y, width, height);
}

void Component::setFont(const Font& f) {
	Font old = font;
	if ( old != f ) {
		font = f;
		fontSet = true;

		if ( peer != NULL ) {
			peer_setFont(font);
		}

		if ( valid ) {
			invalidate();
		}
	}
}

void Component::unsetFont() {
	setFont(Font());
}

const Font& Component::getFont() const {
	if ( !font ) {
		if ( parent != NULL ) {
			return parent->getFont();
		}
	}

	return font;
}

FontMetrics Component::getFontMetrics() const {
	return FontMetrics(getFont());
}

void Component::setCursor(const Cursor& c) {
	if ( cursor != c ) {
		cursor = c;
		cursorSet = true;
		if ( peer != NULL ) {
			peer_setCursor(c);
		}
	}
}

void Component::unsetCursor() {
	if ( cursorSet ) {
		cursorSet = false;
		if ( peer != NULL ) {
			peer_setCursor(getCursor());
		}
	}
}

const Cursor& Component::getCursor() const {
	for ( const Component* comp = this; 
			!comp->isCursorSet() && !comp->isWindow();
				comp = comp->getParent() ) {
		if ( comp->isCursorSet() ) {
			return comp->cursor;
		}
	}

	return Cursor::getDefaultCursor();
}

void Component::setEnabled(bool b) {
	if ( enabled != b ) {
		enabled = b;
		if ( peer != NULL ) {
			peer_setEnabled(b);
		}
	}
}

void Component::setToolTipText(const String& text) {
	if ( text != toolTipText ) {
		ToolTipManager& toolTipMgr = ToolTipManager::getSharedInstance();
		if ( !toolTipText.empty() ) {
			toolTipMgr.unregisterComponent(this);
		}

		toolTipText = text;
		if ( !toolTipText.empty() ) {
			toolTipMgr.registerComponent(this);
		}
	}
}

Dimension Component::getPreferredSize() const {
	if ( isValid() ) {
		return prefSize;
	}

	prefSize = getMinimumSize();
	return prefSize;
}

Dimension Component::getMaximumSize() const {
	return Dimension(
			std::numeric_limits<int>::max(), 
			std::numeric_limits<int>::max());
}

void Component::invalidate() {
	valid = false;
	if ( parent != NULL && parent->isValid() ) {
		parent->invalidate();
	}
}

void Component::validate() {
	if ( !valid ) {
		if ( peer != NULL ) {
			peer_setFont(font);
		}

		valid = true;
	}
}

void Component::addComponentListener(ComponentListener* l) {
	componentEventDispatcher.addListener(l);
}

void Component::removeComponentListener(ComponentListener* l) {
	componentEventDispatcher.removeListener(l);
}

void Component::processMouseEvent(MouseEvent& e) {
	if ( !mouseEventDispatcher.empty() ) {
		void (MouseListener::*toFire)(MouseEvent&) = NULL;
		switch ( e.getID() ) {
		case MouseEvent::MOUSE_PRESSED:
			toFire = &MouseListener::mousePressed;
			break;
		case MouseEvent::MOUSE_RELEASED:
			toFire = &MouseListener::mouseReleased;
			break;
		case MouseEvent::MOUSE_CLICKED:
			toFire = &MouseListener::mouseClicked;
			break;
		case MouseEvent::MOUSE_ENTERED:
			toFire = &MouseListener::mouseEntered;
			break;
		case MouseEvent::MOUSE_EXITED:
			toFire = &MouseListener::mouseExited;
			break;
		default:
			assert ( false );
		}

		mouseEventDispatcher.fireMutableEvent(this, toFire, e);
	}
}

void Component::processMouseMotionEvent(MouseEvent& e) {
	if ( !mouseMotionEventDispatcher.empty() ) {
		void (MouseMotionListener::*toFire)(MouseEvent&) = NULL;
		switch ( e.getID() ) {
		case MouseEvent::MOUSE_DRAGGED:
			toFire = &MouseMotionListener::mouseDragged;
			break;
		case MouseEvent::MOUSE_MOVED:
			toFire = &MouseMotionListener::mouseMoved;
			break;
		default:
			assert ( false );
		}

		mouseMotionEventDispatcher.fireMutableEvent(this, toFire, e);
	}
}

void Component::addMouseListener(MouseListener* l) {
	mouseEventDispatcher.addListener(l);
}

void Component::removeMouseListener(MouseListener* l) {
	mouseEventDispatcher.removeListener(l);
}

void Component::addMouseMotionListener(MouseMotionListener* l) {
	mouseMotionEventDispatcher.addListener(l);
}

void Component::removeMouseMotionListener(MouseMotionListener* l) {
	mouseMotionEventDispatcher.removeListener(l);
}

void Component::addKeyListener(KeyListener* l) {
	keyEventDispatcher.addListener(l);
}

void Component::removeKeyListener(KeyListener* l) {
	keyEventDispatcher.removeListener(l);
}

void Component::processKeyEvent(KeyEvent& e) {
//	KeyboardFocusManager* kfm = 
//			KeyboardFocusManager::getCurrentKeyboardFocusManager();

//	kfm->dispatchEvent(e);
	
	if (!keyEventDispatcher.empty()) {
		void (KeyListener::*toFire)(KeyEvent&) = NULL;
		switch (e.getID()) {
		case KeyEvent::KEY_PRESSED:
			toFire = &KeyListener::keyPressed;
			break;
		case KeyEvent::KEY_RELEASED:
			toFire = &KeyListener::keyReleased;
			break;
		case KeyEvent::KEY_TYPED:
			toFire = &KeyListener::keyTyped;
			break;
		default:
			assert ( false );
		}

		keyEventDispatcher.fireMutableEvent(this, toFire, e);
	}
}

void Component::addFocusListener(FocusListener* l) {
	focusEventDispatcher.addListener(l);
}

void Component::removeFocusListener(FocusListener* l) {
	focusEventDispatcher.removeListener(l);
}

void Component::processHierarchyEvent(const HierarchyEvent& e) {
	if (!hierarchyEventDispatcher.empty()) {
		hierarchyEventDispatcher.fireEvent(this, 
				&HierarchyListener::hierarchyChanged, e);
	}
}

void Component::addHierarchyListener(HierarchyListener* l) {
	hierarchyEventDispatcher.addListener(l);
}

void Component::removeHierarchyListener(HierarchyListener* l) {
	hierarchyEventDispatcher.removeListener(l);
}

bool Component::imageUpdate(Image* /*img*/, int /*infoflags*/, 
		int /*x*/, int /*y*/, int /*width*/, int /*height*/) {
	return true;
}


DWORD Component::getClassStyle() const {
	return CS_HREDRAW | CS_VREDRAW;
}

LPCTSTR Component::getClassName() const {
	return _T("jlib.awt.Component");
}

std::auto_ptr<Graphics> Component::getGraphics() const {
	return std::auto_ptr<Graphics>(new jlib::awt::imp::GetDCGraphics(this));
}

void Component::paint(Graphics& /*g*/) {
}

void Component::update(Graphics& g) {
	paint(g);
}

void Component::repaint() {
	repaint(0, 0, getWidth(), getHeight());
}

void Component::repaint(int x, int y, int width, int height) {
	if ( peer != NULL ) {
		jlib::awt::imp::GetDCGraphics g(this);
		g.setClip(x, y, width, height);
		update(g);
	}
}

// peer operations

void Component::peer_initClass() {
	WNDCLASSEX wcex;

	HMODULE hmod = Toolkit::getDefaultToolkit()->getModuleHandle();

	if (!::GetClassInfoEx(hmod, getClassName(), &wcex)) {
		wcex.cbSize = sizeof(WNDCLASSEX); 
		wcex.style			= CS_HREDRAW | CS_VREDRAW;
		wcex.lpfnWndProc	= (WNDPROC)jlib_awt_Component_wndProc;
		wcex.cbClsExtra		= 0;
		wcex.cbWndExtra		= 0;
		wcex.hInstance		= hmod;
		wcex.hIcon			= NULL;
		wcex.hCursor		= ::LoadCursor(NULL, IDC_ARROW);
		wcex.hbrBackground	= NULL; //(HBRUSH)(COLOR_WINDOW + 1);
		wcex.lpszMenuName	= NULL;
		wcex.lpszClassName	= getClassName();
		wcex.hIconSm		= NULL;

		verify ( RegisterClassEx(&wcex) );
	}

	if (!defaultWndProc) {
		defaultWndProc = ::DefWindowProc;
	}
}

HWND Component::peer_create() {
	HWND hwndParent = NULL;
	if (parent) {
		hwndParent = parent->getPeer();
	}

	DWORD style = getWindowStyle();
	if (visible) {
		style |= WS_VISIBLE;
	} else {
		style &= ~WS_VISIBLE;
	}

	peer = ::CreateWindowEx(getWindowExStyle(), 
			getClassName(), text.c_str(), style, 
			x, y, width, height, hwndParent, 
			reinterpret_cast<HMENU>(id), NULL, this);
	assert (peer);

	return peer;
}

void Component::peer_destroy() {
	::DestroyWindow(peer);
}

void Component::peer_setBounds(int x, int y, int w, int h) {
	assert (peer);

	if (!isWindow()) {
		x -= parent->getInsets().left;
		y -= parent->getInsets().top;
    }

    DWORD flags = SWP_NOACTIVATE | SWP_NOZORDER;
    
    RECT	r;
    verify(::GetWindowRect(peer, &r));

    // if the component size is changing , don't copy window bits
    if ( r.right - r.left != w || r.bottom - r.top != h ) {
		flags |= SWP_NOCOPYBITS;
	}

	verify(::SetWindowPos(peer, 0, x, y, w, h, flags));
}

void Component::setId(UINT id) {
	if ( this->id != id ) {
		this->id = id;
		if (peer) {
			::SetWindowLong(peer, GWL_ID, id);
		}
	}
}


void Component::peer_setFont(const Font& /*font*/) {
	assert (peer);

	HFONT hfont = getFont().getPeer();
	if (!hfont) {
		hfont = (HFONT)::GetStockObject(SYSTEM_FONT);
	}

	::SendMessage(peer, WM_SETFONT, (WPARAM)hfont, (LPARAM)TRUE);
}

void Component::peer_setCursor(const Cursor& cursor) {
	assert (peer);

	HCURSOR hcur = cursor.getPeer();
	::SetCursor(hcur);
}

void Component::peer_setForeground() {
	assert (peer);

	::InvalidateRect(peer, NULL, TRUE);
}

void Component::peer_setBackground() {
	assert (peer);

	//if ( bkBrush != NULL ) {
	//	::DeleteObject(bkBrush);
	//	bkBrush = NULL;
	//}

	::InvalidateRect(peer, NULL, TRUE);
}

void Component::peer_setVisible(bool b) {
	assert (peer);

	::ShowWindow(peer, b ? SW_SHOW : SW_HIDE);
}

void Component::peer_setEnabled(bool b) {
	assert (peer);

	::EnableWindow(peer, b);
}

void Component::peer_paintDamagedAreaImmediately() {
	assert (peer);

	verify (::UpdateWindow(peer));
}

bool Component::peer_shouldClearRectBeforePaint() {
	return false;
}

// win32

void Component::wmPaint() {
	RECT r;
	if (!::GetUpdateRect(peer, &r, FALSE)) {
		return;
	}

	::CallWindowProc(defaultWndProc, peer, WM_PAINT, 0, 0);

	jlib::awt::imp::GetDCGraphics g(this);
	int x = r.left;
	int y = r.top;
	int w = r.right - r.left;
	int h = r.bottom - r.top;

	g.setClip(x, y, w, h);
	if (peer_shouldClearRectBeforePaint()) {
		g.clearRect(x, y, w, h);
	}

	paint(g);
}

bool Component::wmMouseMove(WPARAM wParam, LPARAM lParam) {
	return MouseStateTracker::instance().mouseMove(this, wParam, 
			(short)LOWORD(lParam), (short)HIWORD(lParam));
}

bool Component::wmMouseLeave() {
	return MouseStateTracker::instance().mouseLeave(this);
}

bool Component::wmMouseDown(WPARAM wParam, LPARAM lParam, int button) {
	return MouseStateTracker::instance().mouseDown(this, wParam, 
			(short)LOWORD(lParam), (short)HIWORD(lParam), button);
}

bool Component::wmMouseUp(WPARAM wParam, LPARAM lParam, int button) {
	return MouseStateTracker::instance().mouseUp(this, wParam, 
			(short)LOWORD(lParam), (short)HIWORD(lParam), button);
}

bool Component::wmKeyDown(WPARAM wParam, LPARAM lParam, bool /*system*/) {
	int modifiers = Toolkit::getJavaModifiers(HIWORD(lParam));
	KeyEvent e(KeyEvent::KEY_PRESSED,
			::GetMessageTime(), modifiers, 
			Toolkit::windowsKeyToJavaKey(wParam, modifiers), 
			KeyEvent::CHAR_UNDEFINED);
	processKeyEvent(e);
	return e.isConsumed();
}

bool Component::wmKeyUp(WPARAM wParam, LPARAM lParam, bool /*system*/) {
	int modifiers = Toolkit::getJavaModifiers(HIWORD(lParam));
	KeyEvent e(KeyEvent::KEY_RELEASED, 
			::GetMessageTime(), modifiers, 
			Toolkit::windowsKeyToJavaKey(wParam, modifiers), 
			KeyEvent::CHAR_UNDEFINED);
	processKeyEvent(e);
	return e.isConsumed();
}

bool Component::wmChar(WPARAM wParam, LPARAM lParam, bool system) {
	UINT flags = HIWORD(lParam);
	int modifiers = Toolkit::getJavaModifiers(flags);
	if ( system && (flags & (1 << 13)) != 0 ) {
		modifiers &= ~KeyEvent::ALT_MASK;
		modifiers |= KeyEvent::ALT_GRAPH_MASK;
	}

	KeyEvent e(KeyEvent::KEY_TYPED, ::GetMessageTime(), modifiers, 
			KeyEvent::UNDEFINED, static_cast<TCHAR>(wParam));
	processKeyEvent(e);
	return e.isConsumed();
}

namespace {
	HWND getTopLevelWindow(HWND hwnd) {
		assert (::IsWindow(hwnd));

		while (::GetWindowLong(hwnd, GWL_STYLE) & WS_CHILD) {
			hwnd = ::GetParent(hwnd);
		}

		return hwnd;
	}
}

void Component::wmFocusChange(WPARAM wParam, LPARAM, bool gained) {
	if (!focusEventDispatcher.empty()) {
		bool temp = false;
		HWND hwndOpposite = reinterpret_cast<HWND>(wParam);
		if (hwndOpposite != NULL) {
			HWND oppositeTopLevel = getTopLevelWindow(hwndOpposite);
			HWND myTopLevel = getTopLevelWindow(peer);
			temp = oppositeTopLevel != myTopLevel;
		}

		Component* opposite = 
				Toolkit::getDefaultToolkit()->getComponent(hwndOpposite);
		if (gained) {
			focusEventDispatcher.fireEvent(this,
					&FocusListener::focusGained, 
					FocusEvent(FocusEvent::FOCUS_GAINED, temp, opposite));
		} else {
			focusEventDispatcher.fireEvent(this,
					&FocusListener::focusLost, 
					FocusEvent(FocusEvent::FOCUS_LOST, temp, opposite));
		}
	}
}

bool Component::wmSetCursor(WPARAM, LPARAM lParam) {
	if ( LOWORD(lParam) == HTCLIENT ) {
		peer_setCursor(getCursor());
		return true;
	}

	return false;
}

LRESULT Component::windowProc(UINT message, WPARAM wParam, LPARAM lParam) {
	switch (message) {
	case WM_SETCURSOR:
		if (wmSetCursor(wParam, lParam)) {
			//return TRUE;
		}

		break;

	case WM_MOUSEMOVE:
		if (wmMouseMove(wParam, lParam)) {
			return 0;
		}
		break;

	case WM_MOUSELEAVE:
		if (wmMouseLeave()) {
			return 0;
		}
		break;

	case WM_LBUTTONDOWN:
	case WM_LBUTTONDBLCLK:
		if (wmMouseDown(wParam, lParam, VK_LBUTTON)) {
			return 0;
		}
		break;

	case WM_RBUTTONDOWN:
	case WM_RBUTTONDBLCLK:
		if (wmMouseDown(wParam, lParam, VK_RBUTTON)) {
			return 0;
		}
		break;

	case WM_MBUTTONDOWN:
	case WM_MBUTTONDBLCLK:
		if (wmMouseDown(wParam, lParam, VK_MBUTTON)) {
			return 0;
		}
		break;

	case WM_LBUTTONUP:
		if (wmMouseUp(wParam, lParam, VK_LBUTTON)) {
			return 0;
		}
		break;

	case WM_RBUTTONUP:
		if (wmMouseUp(wParam, lParam, VK_RBUTTON)) {
			return 0;
		}
		break;

	case WM_MBUTTONUP:
		if (wmMouseUp(wParam, lParam, VK_MBUTTON)) {
			return 0;
		}
		break;

	// paint messages
	case WM_PAINT:
		wmPaint();
		return 0;

	// keyboard messages
	case WM_KEYDOWN:
		if (wmKeyDown(wParam, lParam, false)) {
			return 0;
		}
		break;

	case WM_SYSKEYDOWN:
		if (wmKeyDown(wParam, lParam, true)) {
			return 0;
		}
		break;

	case WM_KEYUP:
		if (wmKeyUp(wParam, lParam, false)) {
			return 0;
		}
		break;

	case WM_SYSKEYUP:
		if (wmKeyUp(wParam, lParam, true)) {
			return 0;
		}
		break;

	case WM_CHAR:
		if (wmChar(wParam, lParam, false)) {
			return 0;
		}
		break;

	case WM_SYSCHAR:
		if (wmKeyDown(wParam, lParam, true)) {
			return 0;
		}
		break;

	case WM_SETFOCUS:
		wmFocusChange(wParam, lParam, true);
		break;

	case WM_KILLFOCUS:
		wmFocusChange(wParam, lParam, false);
		break;

	default:
		break;
	}

	return ::CallWindowProc(defaultWndProc, peer, message, wParam, lParam);
}

//

void Component::subClassWindow() {
	defaultWndProc = (WNDPROC)::SetWindowLongPtr(peer, 
			GWLP_WNDPROC, (LONG_PTR)jlib_awt_Component_wndProc);

	Toolkit::getDefaultToolkit()->addDisplayable(this);
}

Component* Component::getComponent(HWND hwnd) {
	return Toolkit::getDefaultToolkit()->getComponent(hwnd);
}

LRESULT CALLBACK 
Component::jlib_awt_Component_wndProc(
		HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {
	Component* component = Toolkit::getDefaultToolkit()->getComponent(hwnd);

	switch (message) {
	case WM_NCCREATE:
		component = static_cast<Component*>(
			reinterpret_cast<LPCREATESTRUCT>(lParam)->lpCreateParams);
		component->peer = hwnd;
		Toolkit::getDefaultToolkit()->addDisplayable(component);
		return TRUE;

	case WM_NCDESTROY:
		Toolkit::getDefaultToolkit()->removeDisplayable(component);
		component->peer = NULL;
		return 0;

	default:
		break;
	}

	// Call its message proc method.
	if (component) {
		return component->windowProc(message, wParam, lParam);
	}
	
	return ::DefWindowProc(hwnd, message, wParam, lParam);
}
