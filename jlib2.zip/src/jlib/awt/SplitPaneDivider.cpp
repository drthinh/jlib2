#include <win32/win32.h>

#include <algorithm> // for std::min

#include <jlib/awt/SplitPaneDivider.h>
#include <jlib/awt/SplitPane.h>

#include <jlib/awt/Graphics.h>

#include <jlib/awt/MouseEvent.h>
#include <jlib/awt/Cursor.h>

#include <cassert>

using namespace jlib::awt;


SplitPaneDivider::SplitPaneDivider(SplitPane* target, 
		bool vertical, bool continuousLayout) 
	: target(target), 
	vertical(vertical), 
	continuousLayout(continuousLayout), 
	oneTouchExpandable(false), 
	lastLocation(0),
	valid(false),
	tracking(false) {
	setLocation(-1);
	setSize(8);
}

const jlib::awt::Rectangle& SplitPaneDivider::getBounds() const {
	if ( !valid ) {
		const_cast<SplitPaneDivider*>(this)->updateBounds();
		valid = true;
	}

	return *this;
}

void SplitPaneDivider::setSize(int dividerSize) {
	(vertical ? width : height) = dividerSize;
	invalidate();
}

int SplitPaneDivider::getSize() const {
	return vertical ? width : height;
}

void SplitPaneDivider::setLocation(int location) {
	(vertical ? x : y) = location;
	invalidate();
}

int SplitPaneDivider::getLocation() const {
	return vertical ? x : y;
}

void SplitPaneDivider::setLastLocation(int v) {
	lastLocation = v;
}

int SplitPaneDivider::getLastLocation() const {
	return lastLocation;
}

void SplitPaneDivider::setOneTouchExpandable(bool v) {
	oneTouchExpandable = v;
}

bool SplitPaneDivider::isOneTouchExpandable() const {
	return oneTouchExpandable;
}

void SplitPaneDivider::setVertical(bool vertical) {
	if ( this->vertical != vertical ) {
		this->vertical = vertical;

		std::swap(x, y);
		std::swap(width, height);

		invalidate();
	}
}

bool SplitPaneDivider::isVertical() const {
	return vertical;
}

void SplitPaneDivider::setContinuousLayout(bool v) {
	continuousLayout = v;
}

bool SplitPaneDivider::isContinuousLayout() const {
	return continuousLayout;
}

void SplitPaneDivider::invalidate() {
	valid = false;
}

void SplitPaneDivider::validate() {
	updateBounds();
	valid = true;
}

void SplitPaneDivider::processMouseEvent(const MouseEvent& e) {
	switch ( e.getID() ) {
		case MouseEvent::MOUSE_PRESSED:
			mousePressed(e.getPoint());
			break;
		case MouseEvent::MOUSE_MOVED:
			mouseMoved(e.getPoint());
			break;
		case MouseEvent::MOUSE_DRAGGED:
			mouseDragged(e.getPoint());
			break;
		case MouseEvent::MOUSE_RELEASED:
			mouseReleased(e.getPoint());
			break;
		case MouseEvent::MOUSE_EXITED:
			mouseExited();
		default:
			break;
	}
}

void SplitPaneDivider::mousePressed(const Point& point) {
	if ( !valid ) {
		validate();
	}

	if ( contains(point) ) {
		if ( oneTouchExpandable ) {
			Rectangle left, right;
			calcOneTouchButtonRect(&left, &right);
			if ( left.contains(point) || right.contains(point) ) {
				return;
			}
		}

		tracking = true;
		zDelta = ( vertical ? 
				point.x : point.y ) - getLocation();
		prevLocation = getLocation();

		setSplitCursor();
		doTracking(point);
	}
}

void SplitPaneDivider::mouseMoved(const Point& point) {
	if ( !valid ) {
		validate();
	}

	bool shouldShowSplitCursor = false;

	if ( contains(point) ) {
		if ( oneTouchExpandable ) {
			// is on one touch buttons ?
			Rectangle left, right;
			calcOneTouchButtonRect(&left, &right);
			if ( !left.contains(point) && !right.contains(point) ) {
				shouldShowSplitCursor = true;
			}
		} else {
			shouldShowSplitCursor = true;
		}
	}
	
	if ( shouldShowSplitCursor ) {
		setSplitCursor();
	} else {
		target->setCursor(
			Cursor::getPredefinedCursor(Cursor::DEFAULT_CURSOR));
	}
}

void SplitPaneDivider::mouseDragged(const Point& point) {
	if ( !valid ) {
		validate();
	}

	if ( !tracking ) {
		if ( contains(point) ) {
			if ( oneTouchExpandable ) {
				Rectangle left, right;
				calcOneTouchButtonRect(&left, &right);
				if ( left.contains(point) || right.contains(point) ) {
					return;
				}
			}

			setSplitCursor();
		}

		return;
	}

	doTracking(point);
}

void SplitPaneDivider::mouseReleased(const Point& point) {
	if ( !valid ) {
		validate();
	}

	if ( !tracking ) {
		if ( oneTouchExpandable ) {
			Rectangle left, right;
			calcOneTouchButtonRect(&left, &right);
			const Insets& i = target->getInsets();
			int minL;
			int maxL;
			if ( vertical ) {
				minL = i.left;
				maxL = target->getWidth() - i.left - i.right - getSize();
			} else {
				minL = i.top;
				maxL = target->getHeight() - i.top - i.bottom - getSize();
			}

			if ( left.contains(point) ) {
				if ( getLocation() == maxL ) {
					target->setDividerLocation(lastLocation);
				} else {
					if ( getLocation() > minL ) {
						lastLocation = getLocation();
						setLocation(minL);
						target->repaint();
					}
				}
			} else if ( right.contains(point) ) {
				if ( getLocation() == minL ) {
					target->setDividerLocation(lastLocation);
				} else {
					if ( getLocation() < maxL ) {
						lastLocation = getLocation();
						setLocation(maxL);
						target->repaint();
					}
				}
			}
		}

		return;
	}

	tracking = false;

	bool shouldShowSplitCursor = false;

	if ( contains(point) ) {
		if ( oneTouchExpandable ) {
			// is on one touch buttons ?
			Rectangle left, right;
			calcOneTouchButtonRect(&left, &right);
			if ( !left.contains(point) && !right.contains(point) ) {
				shouldShowSplitCursor = true;
			}
		} else {
			shouldShowSplitCursor = true;
		}
	}
	
	if ( shouldShowSplitCursor ) {
		setSplitCursor();
	} else {
		target->setCursor(
			Cursor::getPredefinedCursor(Cursor::DEFAULT_CURSOR));
	}

	setLocation(doTracking(point));
	target->repaint();
}

void SplitPaneDivider::mouseExited() {
	target->unsetCursor();
}

void SplitPaneDivider::paint(Graphics& g) {
	if ( !valid ) {
		validate();
	}

	const Insets& insets = target->getInsets();
	Rectangle r;
	r.setBounds(insets.left, insets.top, 
			target->getWidth() - insets.left - insets.right,
			target->getHeight() - insets.top - insets.bottom);

	Component* leftComp = target->getLeftComponent();
	if ( leftComp != NULL ) {
		if ( vertical ) {
			leftComp->setBounds(r.x, r.y, getLocation(), r.height);
		} else {
			leftComp->setBounds(r.x, r.y, r.width, getLocation());
		}
		leftComp->peer_paintDamagedAreaImmediately();
	} 
	
	Component* rightComp = target->getRightComponent();
	if ( rightComp != NULL ) {
		int l = getLocation() + getSize();
		if ( vertical ) {
			rightComp->setBounds(l, r.y, r.width - l, r.height);
		} else {
			rightComp->setBounds(r.x, l, r.width, r.height - l);
		}
		rightComp->peer_paintDamagedAreaImmediately();
	}

	g.setColor(target->getBackground());
	//g.setColor(Color::BLUE);
	g.fillRect(x, y, width, height);

	if ( oneTouchExpandable ) {
		drawOneTouchButtons(g);
	}
}

void SplitPaneDivider::updateBounds() {
	const Insets& i = target->getInsets();
	Rectangle& bounds = const_cast<SplitPaneDivider&>(*this);
	if ( vertical ) {
		bounds.y = i.top;
		bounds.height = target->getHeight() - i.top - i.bottom;
		bounds.x = std::min(x, 
				target->getWidth() - i.right - getSize());
	} else {
		bounds.x = i.left;
		bounds.width = target->getWidth() - i.right - i.left;
		bounds.y = std::min(y, 
				target->getHeight() - i.bottom - getSize());
	}
}

void SplitPaneDivider::calcOneTouchButtonRect(Rectangle* left, Rectangle* right) {
	assert ( left != NULL && right != NULL );

	if ( !valid ) {
		validate();
	}

	if ( vertical ) {
		left->setBounds(x + width/4, y + 2, width/2, width);
		*right = *left;
		right->translate(0, left->height + 2);
	} else {
		left->setBounds(x + 2, y + height/4, height, height/2);
		*right = *left;
		right->translate(left->width + 2, 0);
	}
}

void SplitPaneDivider::drawOneTouchButtons(Graphics& g) {
	Rectangle left;
	Rectangle right;
	calcOneTouchButtonRect(&left, &right);

	int xx[6];
	int yy[6];
	if ( vertical ) {
		xx[0] = left.x + left.width;
		yy[0] = left.y;
		xx[1] = xx[0];
		yy[1] = left.y + left.height;
		xx[2] = left.x;
		yy[2] = left.y + left.height/2;
		xx[3] = right.x;
		yy[3] = right.y;
		xx[4] = xx[3];
		yy[4] = right.y + getSize();
		xx[5] = right.x + right.width;
		yy[5] = right.y + right.height/2;
	} else {
		xx[0] = left.x;
		yy[0] = left.y + left.height;
		xx[1] = left.x + left.width;
		yy[1] = yy[0];
		xx[2] = left.x + left.width / 2;
		yy[2] = left.y;
		xx[3] = right.x;
		yy[3] = right.y;
		xx[4] = right.x + right.width;
		yy[4] = yy[3];
		xx[5] = right.x + right.width / 2;
		yy[5] = right.y + right.height;
	}

	g.setColor(target->getForeground());
	g.fillPolygon(xx, yy, 3);
	g.fillPolygon(&xx[3], &yy[3], 3);
}

int SplitPaneDivider::doTracking(const Point& point) {
	int location = ( vertical ? point.x : point.y ) - zDelta;
	if ( location < target->getMinimumDividerLocation() ) {
		location = target->getMinimumDividerLocation();
	} else {
		if ( location > target->getMaximumDividerLocation() ) {
			location = target->getMaximumDividerLocation();
		}
	}

	if ( location != prevLocation ) {
		if ( !continuousLayout )  {
			Rectangle rc = getBounds();
			if ( vertical ) {
				rc.translate(prevLocation - getLocation(), 0);
			} else {
				rc.translate(0, prevLocation - getLocation());
			}

			drawResizeLine(rc);

			if ( vertical ) {
				rc.translate(location - prevLocation, 0);
			} else {
				rc.translate(0, location - prevLocation);
			}

			drawResizeLine(rc);
		} else {
			setLocation(location);
			target->repaint();
		}

		prevLocation = location;
	}

	return location;
}

void SplitPaneDivider::drawResizeLine(const Rectangle& rect) {
	std::auto_ptr<Graphics> g = target->getGraphics();
	//g.setColor(Color::BLUE);
	//g.setXORMode(Color::BLUE);
	g->setColor(target->getBackground());
	g->setXORMode(target->getBackground());
	g->fillRect(rect.x, rect.y, rect.width, rect.height);
}

void SplitPaneDivider::setSplitCursor() {
	static const Cursor& horizontalCursor = 
			Cursor::getPredefinedCursor(Cursor::E_RESIZE_CURSOR);
	static const Cursor& verticalCursor = 
			Cursor::getPredefinedCursor(Cursor::S_RESIZE_CURSOR);
	target->setCursor(vertical ? horizontalCursor : verticalCursor);
}
