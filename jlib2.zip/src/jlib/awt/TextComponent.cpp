#include <win32/win32.h>

#include <jlib/awt/TextComponent.h>
#include <jlib/awt/SystemColor.h>
#include <jlib/awt/TextListener.h>
#include <jlib/awt/TextEvent.h>
#include <jlib/awt/Container.h>

#include <algorithm>
#include <cassert>

using namespace jlib::awt;


TextComponent::TextComponent(const String& text) 
	: editable(true), selectionStart(0), selectionEnd(0) {
	this->text = text;
	setCursor(Cursor::getPredefinedCursor(Cursor::TEXT_CURSOR));
}

void TextComponent::addNotify() {
	Component::addNotify();
	assert ( peer != NULL );

	subClassWindow();

	peer_setText(text);
	peer_select(selectionStart, selectionEnd);
	peer_setEditable(editable);
}

void TextComponent::removeNotify() {
	if (peer != NULL) {
		text = peer_getText();
		selectionStart = peer_getSelectionStart();
		selectionEnd = peer_getSelectionEnd();
	}

	Component::removeNotify();
}

void TextComponent::setText(const String& t) {
	text = t;
	if (peer != NULL) {
		peer_setText(t);
	}
}

const String& TextComponent::getText() const {
	if (peer != NULL) {
		const_cast<TextComponent*>(this)->text = peer_getText();
	}

	return text;
}

String TextComponent::getSelectedText() const {
	const String& t = getText();
	return String(t.begin() + getSelectionStart(),
		t.begin() + getSelectionEnd());
}

void TextComponent::setEditable(bool b) {
	editable = b;

	if (peer != NULL) {
		peer_setEditable(b);
	}
}

int TextComponent::getSelectionStart() const {
	if (peer != NULL) {
		selectionStart = peer_getSelectionStart();
	}
	return selectionStart;
}

void TextComponent::setSelectionStart(int selectionStart) {
	select(selectionStart, getSelectionEnd());
}

int TextComponent::getSelectionEnd() const {
	if (peer != NULL) {
		selectionEnd = peer_getSelectionEnd();
	}
	return selectionEnd;
}

void TextComponent::setSelectionEnd(int selectionEnd) {
	select(getSelectionStart(), selectionEnd);
}

void TextComponent::select(int selectionStart, int selectionEnd) {
	const String& text = getText();
	if (selectionStart < 0) {
		selectionStart = 0;
	}

	if (selectionEnd > static_cast<int>(text.length())) {
		selectionEnd = text.length();
	}

	if (selectionEnd < selectionStart) {
		selectionEnd = selectionStart;
	}

	if (selectionStart > selectionEnd) {
		selectionStart = selectionEnd;
	}

	this->selectionStart = selectionStart;
	this->selectionEnd = selectionEnd;

	if (peer != NULL) {
		peer_select(selectionStart, selectionEnd);
	}
}

void TextComponent::selectAll() {
	text = getText();
	this->selectionStart = 0;
	this->selectionEnd = getText().length();
	if (peer != NULL) {
		peer_select(selectionStart, selectionEnd);
	}
}

void TextComponent::setCaretPosition(int position) {
	assert ( position >= 0 );
	assert ( peer != NULL );

	int maxposition = getText().length();
	if (position > maxposition) {
		position = maxposition;
	}

	peer_setCaretPosition(position);
}

int TextComponent::getCaretPosition() const {
	int position = 0;

	if ( peer != NULL ) {
		position = peer_getCaretPosition();
	} 
	return position;
}

const Color& TextComponent::getDefaultForeground() const {
	return SystemColor::TEXT_TEXT;
}

const Color& TextComponent::getDefaultBackground() const {
	return SystemColor::TEXT;
}

void TextComponent::addTextListener(TextListener* l) {
	textEventDispatcher.addListener(l);
}

void TextComponent::removeTextListener(TextListener* l) {
	textEventDispatcher.removeListener(l);
}


// peer operations

void TextComponent::peer_setText(const String& t) {
	assert ( peer != NULL );

	::SetWindowText(peer, t.c_str());
}

String TextComponent::peer_getText() const {
	assert ( peer != NULL );

	String t;
	int len = ::GetWindowTextLength(peer);
	if ( len > 0 ) {
		TCHAR* buffer = new TCHAR[len + 1];
		::GetWindowText(peer, buffer, len + 1);
		t.assign(buffer, buffer + len);
		delete[] buffer;
	}

	return t;
}

void TextComponent::peer_setEditable(bool b) {
	assert ( peer != NULL );

	DWORD dwStyle = ::GetWindowLong(peer, GWL_STYLE);
	if ( b ) {
		dwStyle &= ~ES_READONLY;
	} else {
		dwStyle  |= ES_READONLY;
	}

	::SetWindowLong(peer, GWL_STYLE, dwStyle);
}

int TextComponent::peer_getSelectionStart() const {
	assert ( peer != NULL );
	int selStart;
	::SendMessage(peer, EM_GETSEL, (WPARAM)&selStart, 0);
	return selStart;
}

int TextComponent::peer_getSelectionEnd() const {
	assert ( peer != NULL );

	int selEnd;
	::SendMessage(peer, EM_GETSEL, 0, (LPARAM)&selEnd);
	return selEnd;
}

void TextComponent::peer_select(int start, int end) {
	::SendMessage(peer, EM_SETSEL, (WPARAM)start, (LPARAM)end);
}

void TextComponent::peer_setCaretPosition(int pos) {
	assert ( peer != NULL );

	::SendMessage(peer, EM_SETSEL, (WPARAM)pos, (LPARAM)pos);
}

int TextComponent::peer_getCaretPosition() const {
	assert ( peer != NULL );

	int caretPos;
	::SendMessage(peer, EM_GETSEL, 0, (LPARAM)&caretPos);
	return caretPos;
}

// WIN32

void TextComponent::handleCommand(UINT notifyCode) {
	if ( notifyCode == EN_CHANGE ) {
		textEventDispatcher.fireEvent(this,
				&TextListener::textValueChanged, TextEvent());
	}
}

LPCTSTR TextComponent::getClassName() const {
	return _T("Edit");
}
