#include <win32/win32.h>

#include <cassert>

#include <jlib/awt/Toolkit.h>
#include <jlib/awt/Window.h>

#include <jlib/awt/imp/IPictureImageImp.h>
#include <jlib/awt/EventQueue.h>
#include <jlib/awt/KeyEvent.h>

using namespace jlib::awt;


Toolkit::Toolkit(HMODULE hmod) : hmod(hmod) {
	toolkit = this;
	eventQueue = new EventQueue;
}

Toolkit::~Toolkit() {
	delete eventQueue;
}

Toolkit* Toolkit::toolkit = NULL;

Dimension Toolkit::getScreenSize() const {
	int cx = ::GetSystemMetrics(SM_CXSCREEN);
	int cy = ::GetSystemMetrics(SM_CYSCREEN);
	return Dimension(cx, cy);
}

int Toolkit::getScreenResolution() const {
	HWND hWnd = ::GetDesktopWindow();
	HDC hDC = ::GetDC(hWnd);
	long result = ::GetDeviceCaps(hDC, LOGPIXELSX);
	::ReleaseDC(hWnd, hDC);
	return result; 
}

void Toolkit::beep() {
	::MessageBeep(MB_OK);
}

std::auto_ptr<Image> Toolkit::createImage(const String& filename) {
	assert ( !filename.empty() );
	return std::auto_ptr<Image>(
			new jlib::awt::imp::IPictureImageImp(filename));
}

HMODULE Toolkit::getModuleHandle() const {
	return hmod;
}

void Toolkit::startEventLoop() {
	eventQueue->enter();
}

void Toolkit::stopEventLoop() {
	eventQueue->leave();
}

void Toolkit::addDisplayable(Component* c) {
	assert ( c != NULL );
	assert ( c->getPeer() != NULL );
	displayableComponents.push_back(c);
	::SetWindowLong(c->getPeer(), GWL_USERDATA, 
			displayableComponents.size());
}

void Toolkit::removeDisplayable(Component* c) {
	assert ( c != NULL );
	assert ( c->getPeer() != NULL );
	size_t id = ::GetWindowLong(c->getPeer(), GWL_USERDATA);
	assert ( id >= 1 && id <= displayableComponents.size() );
	if ( id != displayableComponents.size() ) {
		// not the last, move the last to this place
		Component* last = displayableComponents.back();
		assert ( last->getPeer() != NULL );
		::SetWindowLong(last->getPeer(), GWL_USERDATA, id);
		displayableComponents[id - 1] = last;
	}

	displayableComponents.pop_back();
}

Component* Toolkit::getComponent(HWND hwnd) const {
	if ( !::IsWindow(hwnd) ) {
		return NULL;
	}

	size_t id = ::GetWindowLong(hwnd, GWL_USERDATA);
	if ( id < 1 || id > displayableComponents.size() ) {
		return NULL;
	}

	return displayableComponents[id - 1];
}

namespace {
	struct KeyMapEntry {
		int javaKey;
		WORD windowsKey;
	};

	const KeyMapEntry keyMapTable[] = {
		{KeyEvent::ENTER, VK_RETURN},
		{KeyEvent::BACK_SPACE, VK_BACK},
		{KeyEvent::TAB, VK_TAB},
		{KeyEvent::CANCEL, VK_CANCEL},
		{KeyEvent::CLEAR, VK_CLEAR},
		{KeyEvent::SHIFT, VK_SHIFT},
		{KeyEvent::CONTROL, VK_CONTROL},
		{KeyEvent::ALT, VK_MENU},
		{KeyEvent::PAUSE, VK_PAUSE},
		{KeyEvent::CAPS_LOCK, VK_CAPITAL},
		{KeyEvent::ESCAPE, VK_ESCAPE},
		{KeyEvent::SPACE, VK_SPACE},
		{KeyEvent::PAGE_UP, VK_PRIOR},
		{KeyEvent::PAGE_DOWN, VK_NEXT},
		{KeyEvent::END, VK_END},
		{KeyEvent::HOME, VK_HOME},
		{KeyEvent::LEFT, VK_LEFT},
		{KeyEvent::UP, VK_UP},
		{KeyEvent::RIGHT, VK_RIGHT},
		{KeyEvent::DOWN, VK_DOWN},
		{KeyEvent::COMMA, 0x00BC},
		{KeyEvent::MINUS, 0x00BD},
		{KeyEvent::PERIOD, 0x00BE},
		{KeyEvent::SLASH, 0x0BF},
		{KeyEvent::SEMICOLON, 0x00BA},
		{KeyEvent::EQUALS, 0x00BB},
		{KeyEvent::OPEN_BRACKET, 0x00DB},
		{KeyEvent::BACK_SLASH, 0x00DC},
		{KeyEvent::CLOSE_BRACKET, 0x00DD},
		{KeyEvent::NUMPAD0, VK_NUMPAD0},
		{KeyEvent::NUMPAD1, VK_NUMPAD1},
		{KeyEvent::NUMPAD2, VK_NUMPAD2},
		{KeyEvent::NUMPAD3, VK_NUMPAD3},
		{KeyEvent::NUMPAD4, VK_NUMPAD4},
		{KeyEvent::NUMPAD5, VK_NUMPAD5},
		{KeyEvent::NUMPAD6, VK_NUMPAD6},
		{KeyEvent::NUMPAD7, VK_NUMPAD7},
		{KeyEvent::NUMPAD8, VK_NUMPAD8},
		{KeyEvent::NUMPAD9, VK_NUMPAD9},
		{KeyEvent::MULTIPLY, VK_MULTIPLY},
		{KeyEvent::ADD, VK_ADD},
		{KeyEvent::SEPARATER, VK_SEPARATOR},
		{KeyEvent::SUBTRACT, VK_SUBTRACT},
		{KeyEvent::DECIMAL, VK_DECIMAL},
		{KeyEvent::DIVIDE, VK_DIVIDE},
		{KeyEvent::DELETE, VK_DELETE},
		{KeyEvent::NUM_LOCK, VK_NUMLOCK},
		{KeyEvent::SCROLL_LOCK, VK_SCROLL},
		{KeyEvent::F1, VK_F1},
		{KeyEvent::F2, VK_F2},
		{KeyEvent::F3, VK_F3},
		{KeyEvent::F4, VK_F4},
		{KeyEvent::F5, VK_F5},
		{KeyEvent::F6, VK_F6},
		{KeyEvent::F7, VK_F7},
		{KeyEvent::F8, VK_F8},
		{KeyEvent::F9, VK_F9},
		{KeyEvent::F10, VK_F10},
		{KeyEvent::F11, VK_F11},
		{KeyEvent::F12, VK_F12},
		{KeyEvent::F13, VK_F13},
		{KeyEvent::F14, VK_F14},
		{KeyEvent::F15, VK_F15},
		{KeyEvent::F16, VK_F16},
		{KeyEvent::F17, VK_F17},
		{KeyEvent::F18, VK_F18},
		{KeyEvent::F19, VK_F19},
		{KeyEvent::F20, VK_F20},
		{KeyEvent::F21, VK_F21},
		{KeyEvent::F22, VK_F22},
		{KeyEvent::F23, VK_F23},
		{KeyEvent::F24, VK_F24},
		{KeyEvent::PRINTSCREEN, VK_SNAPSHOT},
		{KeyEvent::INSERT, VK_INSERT},
		{KeyEvent::HELP, VK_HELP},
		{KeyEvent::BACK_QUOTE, 0x00C0},
		{KeyEvent::QUOTE, 0x00DE},
//		{KeyEvent::CONVERT, VK_CONVERT},
//		{KeyEvent::NONCONVERT, VK_NONCONVERT},
//		{KeyEvent::INPUT_METHOD_ON_OFF, VK_KANJI},
//		{KeyEvent::ALPHANUMERIC, VK_DBE_ALPHANUMERIC},
//		{KeyEvent::KATAKANA, VK_DBE_KATAKANA},
//		{KeyEvent::HIRAGANA, VK_DBE_HIRAGANA},
//		{KeyEvent::FULL_WIDTH, VK_DBE_DBCSCHAR},
//		{KeyEvent::HALF_WIDTH, VK_DBE_SBCSCHAR},
//		{KeyEvent::ROMAN_CHARACTERS, VK_DBE_ROMAN},
		{KeyEvent::UNDEFINED, 0}
	};
}

int Toolkit::windowsKeyToJavaKey(UINT windowsKey, int /*modifiers*/) {
	if ( windowsKey >= '0' && windowsKey <= '9' ) {
		return static_cast<int>(windowsKey);
	}

	if ( windowsKey >= 'A' && windowsKey <= 'Z' ) {
		return static_cast<int>(windowsKey);
	}

	for ( int i = 0; keyMapTable[i].windowsKey != 0; ++i ) {
		if ( keyMapTable[i].windowsKey == windowsKey ) {
			return keyMapTable[i].javaKey;
		}
	}

	return KeyEvent::UNDEFINED; 
}

WORD Toolkit::javaKeyToWindowsKey(int javaKey) {
	if ( javaKey >= '0' && javaKey <= '9' ) {
		return static_cast<WORD>(javaKey);
	}

	if ( javaKey >= 'A' && javaKey <= 'Z' ) {
		return static_cast<WORD>(javaKey);
	}

	for ( int i = 0; 
		keyMapTable[i].javaKey != KeyEvent::UNDEFINED; ++i ) {
		if ( keyMapTable[i].javaKey == javaKey ) {
			return keyMapTable[i].windowsKey;
		}
	}

	return 0;
}

int Toolkit::getJavaModifiers(int mouseButton) {
	int modifiers = 0;

	if ( HIBYTE(::GetAsyncKeyState(VK_CONTROL)) || 
			mouseButton == VK_MBUTTON ) {
		modifiers |= InputEvent::CTRL_MASK;
	}

	if ( HIBYTE(::GetAsyncKeyState(VK_SHIFT)) ) {
		modifiers |= InputEvent::SHIFT_MASK;
	}

	if ( HIBYTE(::GetAsyncKeyState(VK_MBUTTON) ) || 
			HIBYTE(::GetAsyncKeyState(VK_MENU)) ) {
		modifiers |= InputEvent::ALT_MASK;
	}

	// set "right mouse" mask depending on whether system is set to be
	// left or right-handed.
	if ( ::GetSystemMetrics(SM_SWAPBUTTON) ) {
		if ( HIBYTE(::GetAsyncKeyState(VK_LBUTTON)) ) {
			modifiers |= InputEvent::META_MASK;
		}
	} else {
		if (HIBYTE(::GetAsyncKeyState(VK_RBUTTON))) {
			modifiers |= InputEvent::META_MASK;
		}
	}

	// Mouse buttons are already set correctly for left/right handedness
	if ( mouseButton == VK_LBUTTON ) {
		modifiers |= InputEvent::BUTTON1_MASK;
	}
	if ( mouseButton == VK_MBUTTON ) {
		modifiers |= InputEvent::ALT_MASK;
	}
	if ( mouseButton == VK_RBUTTON ) {
		modifiers |= InputEvent::META_MASK;
	}

	return modifiers;
}
