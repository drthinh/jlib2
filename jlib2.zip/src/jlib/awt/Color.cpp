#include <jlib/awt/Color.h>

using namespace jlib::awt;

const Color Color::BLACK(0, 0, 0); //  The color black.  
const Color Color::BLUE(0, 0, 255); //  The color blue.  
const Color Color::CYAN(0, 255, 255); //  The color cyan.  
const Color Color::DARKGRAY(64, 64, 64); //  The color dark gray.  
const Color Color::GRAY(128, 128, 128); //  The color gray.  
const Color Color::GREEN(0, 255, 0); //  The color green.  
const Color Color::LIGHTGRAY(192, 192, 192); //  The color light gray.  
const Color Color::MAGENTA(255, 0, 255); //  The color magneta.  
const Color Color::ORANGE(255, 200, 0); //  The color orange.  
const Color Color::PINK(255, 175, 175); //  The color pink.  
const Color Color::RED(255, 0, 0); //  The color red.  
const Color Color::WHITE(255, 255, 255); //  The color white.  
const Color Color::YELLOW(255, 255, 0); //  The color yellow. 

const float Color::FACTOR = 0.7f;

Color Color::darker() const {
	return Color(static_cast<int>(getRed()*FACTOR),
			 static_cast<int>(getGreen()*FACTOR),
			 static_cast<int>(getBlue()*FACTOR));
}

Color Color::brighter() const {
	int r = getRed();
	int g = getGreen();
	int b = getBlue();

	int i = static_cast<int>(1.0f/(1.0f-FACTOR));
	if ( r == 0 && g == 0 && b == 0) {
		return Color(i, i, i);
	}

	if ( r > 0 && r < i ) r = i;
	if ( g > 0 && g < i ) g = i;
	if ( b > 0 && b < i ) b = i;

	return Color(static_cast<int>(r/FACTOR),
			static_cast<int>(g/FACTOR),
			static_cast<int>(b/FACTOR)); 
}
