#include <win32/win32.h>

#include <limits>
#include <cassert>

#include <jlib/awt/ScrollPane.h>
#include <jlib/awt/LayoutConstraint.h>
#include <jlib/awt/Adjustable.h>

#include <jlib/awt/AdjustmentEvent.h>

using namespace jlib::awt;


namespace jlib { namespace awt {

class ScrollPaneAdjustable : public Adjustable {
public:
    ScrollPaneAdjustable(ScrollPane* sp, 
			AdjustmentListener* l, Orientation orientation)
		: sp(sp), orientation(orientation) {

		minimum = 0;
		maximum = 0;
		visibleAmount = 0;
		unitIncrement = 1;
		blockIncrement = 1;
		value = 0;

		addAdjustmentListener(l);
    }

    void setSpan(int min, int max, int visible) {
		// adjust the values to be reasonable
		minimum = min;
		maximum = std::max(max, minimum + 1);
		visibleAmount = std::min(visible, maximum - minimum);
		visibleAmount = std::max(visibleAmount, 1);
		blockIncrement = std::max((int)(visible * 0.9), 1);
		setValue(value);
    }

	Orientation getOrientation() const {
        return orientation;
    }

	void setMinimum(int /*min*/) {
		assert ( false );
    }

	int getMinimum() const {
        return 0;
    }

	void setMaximum(int /*max*/) {
		assert ( false );
    }

    int getMaximum() const {
        return maximum;
    }

	void setUnitIncrement(int u) {
		if (u != unitIncrement) {
			unitIncrement = u;
			if (sp->getPeer() != NULL) {
				sp->peer_setUnitIncrement(this, u);
			}
		}
    }

    int getUnitIncrement() const {
        return unitIncrement;
    }

    void setBlockIncrement(int b) {
        blockIncrement = b;
    }

    int getBlockIncrement() const {
        return blockIncrement;
    }

    void setVisibleAmount(int) {
		assert ( false );
    }

    int getVisibleAmount() const {
        return visibleAmount;
    }

	void setValue(int v) {
		// bounds check
		v = std::max(v, minimum);
		v = std::min(v, maximum - visibleAmount);

        if (v != value) {
			value = v;
			adjustmentEventDispatcher.fireEvent(this,
					&AdjustmentListener::adjustmentValueChanged, 
					AdjustmentEvent(AdjustmentEvent::TRACK, value));
		}
    }

    int getValue() const {
        return value;
    }

	void addAdjustmentListener(AdjustmentListener* l) {
		adjustmentEventDispatcher.addListener(l);
    }

	void removeAdjustmentListener(AdjustmentListener* l){
		adjustmentEventDispatcher.removeListener(l);
    }

private:
	ScrollPane* sp;

	Orientation orientation;
	int minimum;
	int maximum;
	int visibleAmount;
	int unitIncrement;
	int blockIncrement;
	int value;

	typedef jlib::util::EventDispatcher<
			AdjustmentListener> AdjustEventDispatcher;
	AdjustEventDispatcher adjustmentEventDispatcher;

private:
	ScrollPaneAdjustable(const ScrollPaneAdjustable&);
	ScrollPaneAdjustable& operator=(const ScrollPaneAdjustable&);
};

}}

ScrollPane::ScrollPane(ScrollbarDisplayPolicy scrollbarDisplayPolicy) {
	this->layoutMgr = NULL;
	this->width = 100;
	this->height = 100;
	this->scrollbarDisplayPolicy = scrollbarDisplayPolicy;

	vAdjustable = new ScrollPaneAdjustable(this, this, Adjustable::VERTICAL);
	hAdjustable = new ScrollPaneAdjustable(this, this, Adjustable::HORIZONTAL);
}

ScrollPane::~ScrollPane() {
	delete vAdjustable;
	delete hAdjustable;
}

void ScrollPane::addImpl(Component* comp, 
		const LayoutConstraint& constraints, int index) {
	assert ( index <= 0 );

	if (getComponentCount() > 0) {
		remove(0);
	}

	Container::addImpl(comp, constraints, index);
}

Dimension ScrollPane::getViewportSize() const {
	const Insets& i = getInsets();
	return Dimension(width - i.right - i.left,
			    height - i.top - i.bottom);
}

int ScrollPane::getHScrollbarHeight() const {
	int h = 0;
	if (scrollbarDisplayPolicy != SCROLLBARS_NEVER) {
		if (peer != NULL) {
			h = peer_getHScrollbarHeight();
		}
	}
	return h;
}

int ScrollPane::getVScrollbarWidth() const {
	int w = 0;
	if (scrollbarDisplayPolicy != SCROLLBARS_NEVER) {
		if (peer != NULL) {
			w = peer_getVScrollbarWidth();
		}
	}
	return w;
}

Adjustable* ScrollPane::getVAdjustable() {
    return vAdjustable;
}

Adjustable* ScrollPane::getHAdjustable() {
    return hAdjustable;
}

void ScrollPane::setScrollPosition(int x, int y) {
	assert ( getComponentCount() == 1 );

	hAdjustable->setValue(x);
	vAdjustable->setValue(y);
}

void ScrollPane::setScrollPosition(const Point& p) {
	setScrollPosition(p.x, p.y);
}

Point ScrollPane::getScrollPosition() const {
	assert ( getComponentCount() == 1 );

	return Point(hAdjustable->getValue(), vAdjustable->getValue());
}

void ScrollPane::setLayout(LayoutManager*) {
	assert ( false );
}

void ScrollPane::doLayout() {
	if ( getComponentCount() > 0) {
		Component* c = getComponent(0);
		Point p = getScrollPosition();
		Dimension cs = calculateChildSize();
		Dimension vs = getViewportSize();
		const Insets& i = getInsets();

		c->setBounds(i.left - p.x, i.top - p.y, cs.width, cs.height);
		if (peer != NULL) {
			peer_childResized(cs.width, cs.height);
		}

		// update adjustables... the viewport size may have changed
		// with the scrollbars coming or going so the viewport size
		// is updated before the adjustables.
		vs = getViewportSize();
		hAdjustable->setSpan(0, cs.width, vs.width);
		vAdjustable->setSpan(0, cs.height, vs.height);
	}

}

//void printComponents(Graphics g) {
//	if (ncomponents > 0) {
//		Component c = component[0];
//		Point p = c.getLocation();
//		Dimension vs = getViewportSize();
//		Insets i = getInsets();

//		Graphics cg = g.create();
//		try {
//			cg.clipRect(i.left, i.top, vs.width, vs.height);
//			cg.translate(p.x, p.y);
//			c.printAll(cg);
//		} finally {
//			cg.dispose();
//		}
//	}
//}

void ScrollPane::addNotify() {
	int vAdjustableValue = 0;
	int hAdjustableValue = 0;

	// Bug 4124460. Save the current adjustable values,
	// so they can be restored after addnotify. Set the
	// adjustibles to 0, to prevent crashes for possible
	// negative values.
	if (getComponentCount() > 0) {
		vAdjustableValue = vAdjustable->getValue();
		hAdjustableValue = hAdjustable->getValue();
		vAdjustable->setValue(0);
		hAdjustable->setValue(0);
	}

//	    if (peer == NULL)
//	        peer = getToolkit().createScrollPane(this);

	Container::addNotify();

	peer_setInsets();

	// Bug 4124460. Restore the adjustable values.
	if (getComponentCount() > 0) {
		vAdjustable->setValue(vAdjustableValue);
		hAdjustable->setValue(hAdjustableValue);
	}
}

Dimension ScrollPane::calculateChildSize() {
	//
	// calculate the view size, accounting for border but not scrollbars
	// - don't use right/bottom insets since they vary depending
	//   on whether or not scrollbars were displayed on last resize
	//
	const Dimension& size = getSize();
	const Insets& insets = getInsets();
	int viewWidth = size.width - insets.left * 2;
	int viewHeight = size.height - insets.top * 2;

	//
	// determine whether or not horz or vert scrollbars will be displayed
	//
	bool vbarOn;
	bool hbarOn;
	Component* child = getComponent(0);
	Dimension childSize(child->getPreferredSize());

	if ( scrollbarDisplayPolicy == SCROLLBARS_AS_NEEDED ) {
		vbarOn = childSize.height > viewHeight;
		hbarOn = childSize.width  > viewWidth;
	} else if (scrollbarDisplayPolicy == SCROLLBARS_ALWAYS) {
		vbarOn = hbarOn = true;
	} else { // SCROLLBARS_NEVER
		vbarOn = hbarOn = false;
	}

	// adjust predicted view size to account for scrollbars
	int vbarWidth = getVScrollbarWidth(); 
	int hbarHeight = getHScrollbarHeight();

	if (vbarOn) {
		viewWidth -= vbarWidth;
	}

	if(hbarOn) {
		viewHeight -= hbarHeight;
	}

	// if child is smaller than view, size it up
	if (childSize.width < viewWidth) {
		childSize.width = viewWidth;
	}
	if (childSize.height < viewHeight) {
		childSize.height = viewHeight;
	}

	return childSize;
}

void ScrollPane::adjustmentValueChanged(const AdjustmentEvent& e) {
	Adjustable* adj = e.getAdjustable();
	int value = e.getValue();
	if (getPeer() != NULL) {
		peer_setValue(adj, value);
	}

	Component* c = getComponent(0);
	switch(adj->getOrientation()) {
	case Adjustable::VERTICAL:
		c->setLocation(c->getX(), -value);
		break;
	case Adjustable::HORIZONTAL:
		c->setLocation(-value, c->getY());
		break;
	default:
		assert ( false );
	}
}

// peer operations
int ScrollPane::peer_getHScrollbarHeight() const {
	return ::GetSystemMetrics(SM_CYHSCROLL);
}

int ScrollPane::peer_getVScrollbarWidth() const {
	return ::GetSystemMetrics(SM_CXVSCROLL);
}

void ScrollPane::peer_setInsets() {
	RECT outside;
	::GetWindowRect(peer, &outside);

	RECT inside;
	::GetClientRect(peer, &inside);

	::MapWindowPoints(peer, 0, reinterpret_cast<POINT*>(&inside), 2);

	insets.left = inside.left - outside.left;
	insets.top = inside.top - outside.top;
	insets.right = outside.right - inside.right;
	insets.bottom = outside.bottom - inside.bottom;
}

void ScrollPane::peer_childResized(int width, int height) {
	peer_setSpans(getWidth(), getHeight(), width, height); 
}

void ScrollPane::peer_setSpans(int parentWidth, int parentHeight,
		int childWidth, int childHeight) {

	int horzBorder = ::GetSystemMetrics(SM_CXEDGE);
	int vertBorder = ::GetSystemMetrics(SM_CYEDGE);
    
    parentWidth -= horzBorder * 2;
    parentHeight -= vertBorder * 2;

    bool needsHorz = 
			scrollbarDisplayPolicy == SCROLLBARS_ALWAYS ||
				(scrollbarDisplayPolicy == SCROLLBARS_AS_NEEDED && 
					childWidth > parentWidth);
    if (needsHorz) {
		parentHeight -= ::GetSystemMetrics(SM_CYHSCROLL);
    }

    bool needsVert =
			scrollbarDisplayPolicy == SCROLLBARS_ALWAYS ||
				(scrollbarDisplayPolicy == SCROLLBARS_AS_NEEDED && 
					childHeight > parentHeight);
	if (needsVert) {
		parentWidth -= ::GetSystemMetrics(SM_CXVSCROLL);
	}

	//Since the vertical scrollbar may have reduced the parent width
	//enough to now require a horizontal scrollbar, we need to
	//recalculate the horizontal metrics and scrollbar boolean.
    if (!needsHorz) {
		needsHorz = scrollbarDisplayPolicy == SCROLLBARS_ALWAYS ||
						(scrollbarDisplayPolicy == SCROLLBARS_AS_NEEDED && 
							childWidth > parentWidth);
		if (needsHorz) {
			parentHeight -= ::GetSystemMetrics(SM_CYHSCROLL);
		}
	}

	// Now set ranges -- setting the min and max the same disables them.
	if (needsHorz) {
		hAdjustable->setBlockIncrement(parentWidth);
		peer_setScrollInfo(SB_HORZ, childWidth - 1, parentWidth, 
				scrollbarDisplayPolicy == SCROLLBARS_ALWAYS);
	} else {
		peer_setScrollInfo(SB_HORZ, 0, 0, 
				scrollbarDisplayPolicy == SCROLLBARS_ALWAYS);
    }

    if ( needsVert ) {
		vAdjustable->setBlockIncrement(parentHeight);
        peer_setScrollInfo(SB_VERT, childHeight - 1, parentHeight, 
				scrollbarDisplayPolicy == SCROLLBARS_ALWAYS);
	} else {
		peer_setScrollInfo(SB_VERT, 0, 0, 
				scrollbarDisplayPolicy == SCROLLBARS_ALWAYS);
	} 
}

void ScrollPane::peer_setScrollInfo(int orient, int max, 
		int page, bool disableNoScroll) {

	int posBefore = ::GetScrollPos(peer, orient);

	SCROLLINFO si;
	si.cbSize = sizeof(SCROLLINFO);
	si.nMin = 0;
	si.nMax = max;
	si.fMask = SIF_RANGE;
	if ( disableNoScroll ) {
		si.fMask |= SIF_DISABLENOSCROLL;
	}

	if ( page > 0 ) {
		si.fMask |= SIF_PAGE;
		si.nPage = page;
	}

	::SetScrollInfo(peer, orient, &si, TRUE);

	// scroll position may have changed when thumb is at the end of the bar
	// and the page size changes
	int posAfter = ::GetScrollPos(peer, orient);
	if (posBefore != posAfter) {
		handleScroll(SB_THUMBPOSITION, posAfter, orient == SB_VERT);
	}
}


void ScrollPane::peer_setUnitIncrement(ScrollPaneAdjustable*, int) {
}

void ScrollPane::peer_setValue(Adjustable* adj, int v) {
	assert ( peer != NULL );

	int orient = adj->getOrientation() == 
			Adjustable::VERTICAL ? SB_VERT : SB_HORZ;
	::SetScrollPos(peer, orient, v, TRUE);
}


// WIN32

void ScrollPane::handleScroll(int scrollCode, int pos, bool vertical) {
	if (scrollCode == SB_ENDSCROLL) {
		return;
	}
	
	Adjustable* adj = vertical ? getVAdjustable() : getHAdjustable();
	if (adj == NULL) {
		return;
	}

	int	unitInc = adj->getUnitIncrement();
	int	blockInc = adj->getBlockIncrement();
	int	newpos = adj->getValue();

	switch (scrollCode) {
	case SB_LINEUP:
		newpos -= unitInc;
		break;
	case SB_LINEDOWN:
		newpos += unitInc;
		break;
	case SB_PAGEUP:
		newpos -= blockInc;
		break;
	case SB_PAGEDOWN:
		newpos += blockInc;
		break;
	case SB_THUMBPOSITION:
	case SB_THUMBTRACK:
		newpos = pos;
		break;
	default:
		assert ( false );
		break;
	}

	// keep scroll position in acceptable range
	newpos = std::max(adj->getMinimum(), newpos);
	newpos = std::min(adj->getMaximum(), newpos);

	adj->setValue(newpos);
}

// !!! Must have this method, if a new window class had not been
// registered, the scroll bars will never be created. Don't know why.
LPCTSTR ScrollPane::getClassName() const {
	return _T("jlib.awt.ScrollPane");
}

DWORD ScrollPane::getWindowStyle() const {
	DWORD style = WS_CHILD | WS_CLIPCHILDREN | WS_CLIPSIBLINGS;
	if ( scrollbarDisplayPolicy == SCROLLBARS_ALWAYS ) {
		style |= WS_HSCROLL | WS_VSCROLL;
	}

	return style;
}

DWORD ScrollPane::getWindowExStyle() const {
	return WS_EX_CLIENTEDGE | WS_EX_CONTROLPARENT;
}

bool ScrollPane::wmMouseWheel(WPARAM wParam, LPARAM /*lParam*/) {
	int keys = LOWORD(wParam);
	if ( ( keys & (MK_SHIFT|MK_CONTROL) ) != 0 ) {
		return false;
	}

	Adjustable* toScroll  = NULL;

	SCROLLINFO si;
	si.cbSize = sizeof(si);
	si.fMask = SIF_PAGE | SIF_RANGE | SIF_POS;
	BOOL ret = ::GetScrollInfo(peer, SB_VERT, &si);
	if ( ret && static_cast<int>(si.nPage) < si.nMax - si.nMin ) {
		// vertical scrollbar present and usable
		toScroll = getVAdjustable();
	} else {
		ret = ::GetScrollInfo(peer, SB_HORZ, &si);
		if ( ret && static_cast<int>(si.nPage) < si.nMax - si.nMin ) {
			// horizontal scrollbar present and usable
			toScroll = getHAdjustable();
		}
	}

	if ( toScroll != NULL ) {
		int lines = GET_WHEEL_DELTA_WPARAM(wParam)/WHEEL_DELTA;
		int pos = si.nPos - lines * toScroll->getUnitIncrement();
		bool vertical = toScroll == getVAdjustable();
		handleScroll(SB_THUMBPOSITION, pos, vertical);
	}

	return true;
}

LRESULT ScrollPane::windowProc(UINT message, WPARAM wp, LPARAM lp) {
	switch (message) {
	case WM_MOUSEWHEEL:
		if (wmMouseWheel(wp, lp))
			return 0;
		break;
	default:
		break;
	}

	return Container::windowProc(message, wp, lp);
}
