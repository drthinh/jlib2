#include <win32/win32.h>
#include <cassert>

#include <jlib/awt/Toolkit.h>
#include <jlib/awt/EventQueue.h>
#include <jlib/lang/Runnable.h>
#include <jlib/lang/Lock.h>

#include <jlib/awt/Window.h>
#include <jlib/awt/Frame.h>
#include <jlib/awt/MenuBar.h>


using namespace jlib::lang;
using namespace jlib::awt;

using jlib::lang::Runnable;

EventQueue* EventQueue::me;

bool EventQueue::isEventDispatchThread() {
	assert ( me != NULL );

	return ::GetCurrentThreadId() == me->threadId;
}

void EventQueue::invokeLater(Runnable* target) {
	assert ( me != NULL );

	me->privateInvokeLater(target);
}

void EventQueue::invokeAndWait(Runnable* target) {
	assert ( me != NULL );

	me->privateInvokeAndWait(target);
}

LRESULT CALLBACK EventQueue::invocationHandlerWindowProc(
		HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {

	if ( message == WM_USER && me != NULL ) {
		me->processInvocationEvent(
				reinterpret_cast<BOOL*>(wParam),
				reinterpret_cast<Runnable*>(lParam));
		return 0;
	}

	return ::DefWindowProc(hwnd, message, wParam, lParam);
}

EventQueue::EventQueue() {
	assert ( me == NULL);

	// int Windows 2000 and later versions, I can use 
	// a message only window, see "HWND_MESSAGE"
	WNDCLASS wc;
	wc.lpszClassName = _T("jlib.InvocationHandler");
	wc.style = 0;
	wc.lpfnWndProc = (WNDPROC)invocationHandlerWindowProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = Toolkit::getDefaultToolkit()->getModuleHandle();
	wc.hIcon = NULL;
	wc.hCursor = NULL;
	wc.hbrBackground = NULL;
	wc.lpszMenuName	= NULL;
	ATOM atom = RegisterClass(&wc);
	assert ( atom != 0 );

	invocationHandler = ::CreateWindow(wc.lpszClassName, _T(""), WS_POPUP, 0, 0, 0, 0,
		NULL, NULL, NULL, NULL);

	threadId = ::GetCurrentThreadId();
	result = 0;

	me = this;
}

EventQueue::~EventQueue() {
	::DestroyWindow(invocationHandler);
}

void EventQueue::enter() {
	win32MessageLoop();
}

void EventQueue::leave() {
	::PostQuitMessage(0);
}

void EventQueue::privateInvokeLater(Runnable* target) {
	::PostMessage(invocationHandler, WM_USER, 
			0, reinterpret_cast<LPARAM>(target));
}

void EventQueue::privateInvokeAndWait(Runnable* target) {
	assert ( !isEventDispatchThread() );

	BOOL done = FALSE;
	synchronized ( invocationLock ) {		
		::PostMessage(invocationHandler, WM_USER, 
				reinterpret_cast<WPARAM>(&done), 
				reinterpret_cast<LPARAM>(target));
		while ( !done ) {
			invocationLock.wait();
		}
	}
}

void EventQueue::processInvocationEvent(BOOL* done, Runnable* target) {
	target->run();
	if ( done != NULL ) {
		synchronized ( invocationLock ) {
			*done = true;
			invocationLock.notifyAll();
		}
	}
}

void EventQueue::win32MessageLoop() {
	MSG msg;
	while ( ::GetMessage(&msg, NULL, 0, 0) ) {
		Window* activeWindow = Window::getActiveWindow();
		if ( activeWindow != NULL ) {
			MenuBar* menuBar = NULL;
			if ( activeWindow->getParent() == NULL ) { // is a Frame
				Frame* frame = static_cast<Frame*>(activeWindow);
				menuBar = frame->getMenuBar();
			}

			HWND hwndActive = activeWindow->getPeer();
			if ( menuBar != NULL ) {
				HACCEL haccel = menuBar->getHACCEL();
				if ( ::TranslateAccelerator(hwndActive, haccel, &msg) ) {
					continue;
				}
			} else {
				if ( ::IsDialogMessage(hwndActive, &msg) ) {
					continue;
				}
			}
		}

		::TranslateMessage(&msg);	
		::DispatchMessage(&msg);
	}

	result = static_cast<int>(msg.wParam);
}
