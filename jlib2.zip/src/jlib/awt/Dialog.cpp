#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <jlib/awt/Dialog.h>
#include <jlib/awt/Frame.h>

#include <jlib/awt/Toolkit.h>
#include <jlib/awt/SystemColor.h>

#include <algorithm>
#include <cassert>

using namespace jlib::awt;


LPCTSTR Dialog::className = NULL;

Dialog::Dialog(Frame* owner, const String& title, bool modal)
	: Window(owner), modal(modal), resizable(false) {
	text = title;
}

Dialog::Dialog(Dialog* owner, const String& title, bool modal)
	: Window(owner), modal(modal), resizable(false) {
	text = title;
}

void Dialog::addNotify() {
	Window::addNotify();
	subClassWindow();

	peer_setTitle(text);
}

void Dialog::setTitle(const String& title) {
	text = title;
	if (peer != NULL) {
		peer_setTitle(title);
	}
}

void Dialog::setVisible(bool b) {
	if ( modal && !b) {
		peer_modalsetEnabledParentWindows(false);
		Toolkit::getDefaultToolkit()->stopEventLoop();
	}

	Window::setVisible(b);

	if ( modal && b ) {
		peer_modalsetEnabledParentWindows(true);
		Toolkit::getDefaultToolkit()->startEventLoop();
	}
}

void Dialog::setResizable(bool b) {
	resizable = b;

	if (peer != NULL) {
		peer_setResizable(b);
		if ( valid ) {
			invalidate();
		}
	}
}

const Color& Dialog::getDefaultForeground() const {
	return SystemColor::CONTROL_TEXT;
}

const Color& Dialog::getDefaultBackground() const {
	return SystemColor::CONTROL;
}

// peer operations

void Dialog::peer_setTitle(const String& title) {
	assert( peer != NULL );

	::SetWindowText(peer, title.c_str());
}

void Dialog::peer_setResizable(bool b) {
	assert ( peer != NULL);

	DWORD style = ::GetWindowLong(peer, GWL_STYLE);
	const DWORD sizeStyles = WS_THICKFRAME|WS_MAXIMIZEBOX;
	if (b) {
		style |= sizeStyles;
	} else {
		style &= ~sizeStyles;
	}
	::SetWindowLong(peer, GWL_STYLE, style);
	::SetWindowPos(peer, NULL, 0, 0, 0, 0, 
			SWP_FRAMECHANGED | SWP_NOMOVE | SWP_NOSIZE | 
			SWP_NOZORDER | SWP_NOACTIVATE | SWP_NOCOPYBITS | 
			SWP_NOREPOSITION | SWP_NOSENDCHANGING | SWP_ASYNCWINDOWPOS);  
}

void Dialog::peer_modalsetEnabledParentWindows(bool b) {
	if ( b ) {
		::EnumThreadWindows(::GetCurrentThreadId(), 
				&windowsDisableProc, (LPARAM)this);
	} else {
		std::vector<HWND>::iterator i;
		for ( i = disabledWindows.begin(); 
				i != disabledWindows.end(); ++i ) {
			if ( ::IsWindow(*i) ) {
				::EnableWindow(*i, TRUE);
			}
		}
		
		disabledWindows.clear();
	}
}

BOOL CALLBACK Dialog::windowsDisableProc(HWND hwnd, LPARAM lParam) {
	Dialog* pThis = (Dialog*)lParam;
	if ( hwnd != pThis->peer && ::IsWindowEnabled(hwnd) ) {
		::EnableWindow(hwnd, FALSE);
		pThis->disabledWindows.push_back(hwnd);
	}

	return TRUE;
}


// WIN32
LPCTSTR Dialog::getClassName() const {
	return _T("#32770");
}

DWORD Dialog::getWindowStyle() const {
	return WS_POPUPWINDOW|WS_DLGFRAME|DS_SETFONT|DS_MODALFRAME;
}
