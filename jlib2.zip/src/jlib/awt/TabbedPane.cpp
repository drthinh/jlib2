#include <win32/win32.h>

#include <jlib/awt/TabbedPane.h>
#include <jlib/awt/SingleSelectionModel.h>

#include <cassert>

using namespace jlib::awt;


TabbedPane::TabbedPane(Placement placement, LayoutPolicy layoutPolicy) 
	: tab(placement, layoutPolicy), bl(0, 0), cl(0, 0), model(NULL) {
	setLayout(&bl);
	panel.setLayout(&cl);
	add(&panel);
	tab.addChangeListener(this);
	placeTab();
}

void TabbedPane::setModel(SingleSelectionModel* m) {
	if ( model != m ) {
		if (model) {
			model->removeChangeListener(this);
		}

		model = m;

		if (model) {
			model->addChangeListener(this);
			if ( getSelectedIndex() != model->getSelectedIndex() ) {
				setSelectedIndex(model->getSelectedIndex() );
			}
		}
	}
}

void TabbedPane::addTab(const String& title, Icon* icon, 
		Component* comp, const String& tip) {
	insertTab(title, icon, comp, tip, -1);
}

void TabbedPane::addTab(const String& title, Component* comp) {
	insertTab(title, NULL, comp, _T(""), -1);
}

void TabbedPane::insertTab(const String& title, Icon* icon, 
		Component* comp, const String& tip, int index) {
	tab.insertTab(title, icon, tip, index);
	panel.add(comp, CardLayout::Constraints(title), index);
}

void TabbedPane::removeTabAt(int index) {
	//String title = tab.getTab(index);
	tab.removeTabAt(index);
	panel.remove(index);
}

void TabbedPane::setComponentAt(int index, Component* comp) {
	assert ( index >= 0 && index < getTabCount() );

	panel.remove(index);
	panel.add(comp, CardLayout::Constraints(tab.getTab(index)), index);
}

Component* TabbedPane::getComponentAt(int index) const {
	assert ( index >= 0 && index < getTabCount() );

	return panel.getComponent(index);
}

void TabbedPane::setTitleAt(int index, const String& title) {
	tab.setTitleAt(index, title);
}

const String& TabbedPane::getTitleAt(int index) const {
	return tab.getTitleAt(index);
}

int TabbedPane::getSelectedIndex() const {
	return tab.getSelectedIndex();
}

void TabbedPane::setTabPlacement(TabbedPane::Placement p) {
	if ( p != tab.getPlacement() ) {
		tab.setPlacement(p);
		placeTab();
	}
}

void TabbedPane::setForegroundAt(int index, Color c) {
	assert ( index >= 0 && index < getTabCount() );

	tab.setForegroundAt(index, c);
}

Color TabbedPane::getForegroundAt(int index) const {
	assert ( index >= 0 && index < getTabCount() );

	return tab.getForegroundAt(index);
}

void TabbedPane::setBackgroundAt(int index, Color c) {
	assert ( index >= 0 && index < getTabCount() );

	tab.setBackgroundAt(index, c);
}

Color TabbedPane::getBackgroundAt(int index) const {
	assert ( index >= 0 && index < getTabCount() );

	return tab.getBackgroundAt(index);
}

void TabbedPane::setSelectedIndex(int index) {
	tab.setSelectedIndex(index);
	if ( model != NULL ) {
		model->setSelectedIndex(index);
	}

	cl.show(&panel, tab.getTab(tab.getSelectedIndex()));
}

void TabbedPane::addChangeListener(ChangeListener* l) {
	changeEventDispatcher.addListener(l);
}

void TabbedPane::removeChangeListener(ChangeListener* l) {
	changeEventDispatcher.removeListener(l);
}

void TabbedPane::stateChanged(const ChangeEvent& e) {
	cl.show(&panel, tab.getTab(tab.getSelectedIndex()));
	if ( e.getSource() == &tab ) {
		if ( model != NULL ) {
			model->setSelectedIndex(getSelectedIndex());
		}
	}

	changeEventDispatcher.fireEvent(this, &ChangeListener::stateChanged, e);
}

void TabbedPane::placeTab() {
	const BorderLayout::Constraint* constraint = NULL;
	switch ( tab.getPlacement() ) {
	case TOP:
		constraint = &BorderLayout::NORTH;
		break;
	case BOTTOM:
		constraint = &BorderLayout::SOUTH;
		break;
	case LEFT:
		constraint = &BorderLayout::WEST;
		break;
	case RIGHT:
		constraint = &BorderLayout::EAST;
		break;
	default:
		assert ( false );
	}

	remove(&tab);
	add(&tab, *constraint);
}

void TabbedPane::setLayout(LayoutManager* mgr) {
	if ( mgr != &bl ) {
		assert ( false );
	}

	Container::setLayout(mgr);
}

#include <commctrl.h>
LRESULT TabbedPane::windowProc(UINT message, WPARAM wParam, LPARAM lParam) {
	if ( message == WM_NOTIFY ) {
		NMHDR* nmHdr = reinterpret_cast<NMHDR*>(lParam);
		if ( nmHdr->code == TTN_NEEDTEXT &&
				nmHdr->hwndFrom == TabCtrl_GetToolTips(tab.getPeer()) ) {
			TOOLTIPTEXT* ttt = reinterpret_cast<TOOLTIPTEXT*>(nmHdr);
			ttt->lpszText = (LPSTR)
					tab.getToolTipTextAt(nmHdr->idFrom).c_str();
			ttt->hinst = NULL;
			return 0;
		}
	}

	return Container::windowProc(message, wParam, lParam);
}
