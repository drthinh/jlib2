#include <win32/win32.h>

#include <cassert>

#include <jlib/awt/Button.h>
#include <jlib/awt/SystemColor.h>
#include <jlib/awt/Container.h>

#include <jlib/awt/ActionEvent.h>

using namespace jlib::awt;

Button::Button(const String& label) {
	text = label;
}

void Button::addActionListener(ActionListener* l) {
	actionEventDispatcher.addListener(l);
}

void Button::removeActionListener(ActionListener* l) {
	actionEventDispatcher.removeListener(l);
}

void Button::setLabel(const String& label) {
	if (text != label) {
		text = label;
		if (peer) {
			::SetWindowText(peer, label.c_str());
		}
		invalidate();
	}
}

void Button::addNotify() {
	Component::addNotify();
	Component::subClassWindow();
}

Dimension Button::getMinimumSize() const {
	if (!isValid()) {
		FontMetrics fm = getFontMetrics();
		int w = fm.stringWidth(text);
		int h = fm.getHeight();
		prefSize.setSize(w + 14, h + 8);
	}

	return prefSize;
}

const Color& Button::getDefaultForeground() const {
	return SystemColor::CONTROL_TEXT;
}

const Color& Button::getDefaultBackground() const {
	return SystemColor::CONTROL;
}

LPCTSTR Button::getClassName() const {
	return _T("Button");
}

DWORD Button::getWindowStyle() const {
	return WS_CHILD|WS_CLIPSIBLINGS|WS_TABSTOP|BS_PUSHBUTTON|BS_OWNERDRAW;
}

void Button::drawItem(DRAWITEMSTRUCT* di) {
	Color bkgnd = getBackground();
	COLORREF oldBk = ::SetBkColor(di->hDC, bkgnd.getRGB());

	Color frgnd = getForeground();
	COLORREF oldText = ::SetTextColor(di->hDC, frgnd.getRGB());

	// Draw the button frame.
	::FillRect(di->hDC, &di->rcItem, getBackgroundBrush() );

	UINT nState = DFCS_BUTTONPUSH;	
	if ( di->itemState & ODS_SELECTED )
		nState |= DFCS_PUSHED;

	UINT edgeType = nState & DFCS_PUSHED ? EDGE_SUNKEN : EDGE_RAISED;

	RECT rc = di->rcItem;
	::DrawEdge(di->hDC, &rc, edgeType, BF_RECT|BF_SOFT);

	RECT rc2 = rc;
	::OffsetRect(&rc2, 1, 1);

	if ((di->itemState & ODS_DISABLED) == 0) {
		::DrawText(di->hDC, 
				text.data(), static_cast<int>(text.length()), 
				nState & DFCS_PUSHED ? &rc2 : &rc, 
				DT_SINGLELINE|DT_VCENTER|DT_CENTER);
	} else {
		COLORREF oldColor = ::SetTextColor(di->hDC, 
				::GetSysColor(COLOR_BTNHILIGHT));
		int oldMode = ::SetBkMode(di->hDC, TRANSPARENT);
		::DrawText(di->hDC, 
				text.data(), static_cast<int>(text.length()), 
				&rc2, DT_SINGLELINE|DT_VCENTER|DT_CENTER);
		::SetTextColor(di->hDC, ::GetSysColor(COLOR_BTNSHADOW));
		::DrawText(di->hDC, 
				text.data(), static_cast<int>(text.length()), 
				&rc, DT_SINGLELINE|DT_VCENTER|DT_CENTER);
		::SetBkMode(di->hDC, oldMode);
		::SetTextColor(di->hDC, oldColor);
	}

	// Draw focus rect
	if (di->itemState & ODS_FOCUS) {
		const int inf = 3; /* heuristic decision */
		::InflateRect(&rc, -inf, -inf);
		::DrawFocusRect(di->hDC, &rc);
	}

	::SetBkColor(di->hDC, oldBk);
	::SetTextColor(di->hDC, oldText);
}

void Button::handleCommand(UINT notifyCode) {
	if (notifyCode == BN_CLICKED) {
		if (!actionEventDispatcher.empty()) {
			actionEventDispatcher.fireEvent(this, 
					&ActionListener::actionPerformed, 
					ActionEvent(getActionCommand()));
		}
	}
}
