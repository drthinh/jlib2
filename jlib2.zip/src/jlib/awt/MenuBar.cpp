#include <win32/win32.h>

#include <list>

#include <algorithm>
#include <functional>

#include <jlib/awt/MenuBar.h>
#include <jlib/awt/Menu.h>

#include <jlib/awt/Toolkit.h>


#include <jlib/awt/Frame.h>

#include <cassert>


using namespace jlib::awt;

MenuBar::MenuBar() 
	: peer(NULL), haccel(NULL) {
}

void MenuBar::addNotify() {
	if ( peer == NULL ) {
		peer = peer_createMenuBar();
	}

	MenuList::iterator i;
	for ( i = menus.begin(); i != menus.end(); ++i ) {
		(*i)->addNotify();
		peer_addMenu(*i);
	}

	peer_createShortcuts();
}

void MenuBar::removeNotify() {
	peer_delShortcuts();
	std::for_each(menus.begin(), menus.end(), 
			std::mem_fun(&Menu::removeNotify));
	MenuComponent::removeNotify();
}

Menu* MenuBar::getHelpMenu() const {
	return helpMenu;
}

void MenuBar::setHelpMenu(Menu* m) {
	if (helpMenu == m) {
		return;
	}

	if (helpMenu != NULL) {
		remove(helpMenu);
	}

	if (m->getParent() != this) {
		add(m);
	}

	helpMenu = m;
	if (m != NULL) {
		m->setHelpMenu(true);
		m->setParent(this);
		if (peer != NULL) {
			if ( m->getPeer() != NULL ) {
				m->addNotify();
			}

			peer_addHelpMenu(m);
		}
	}
}

Menu* MenuBar::add(Menu* m) {
	if (m->getParent() != NULL) {
	    m->getParent()->remove(m);
	}

	menus.push_back(m);
	m->setParent(this);

	if (peer != NULL) {
	    if (m->getPeer() == NULL) {
			m->addNotify();
		}
		peer_addMenu(m);
	}
	return m;
}

void MenuBar::remove(int index) {
	Menu* m = getMenu(index);
	menus.erase(menus.begin() + index);
	if (peer != NULL) {
		m->removeNotify();
		m->setParent(NULL);
		peer_delMenu(index);
	}
}

void MenuBar::remove(Menu* m) {
	MenuList::iterator i = std::find(menus.begin(), menus.end(), m);
	if ( i != menus.end() ) {
	    menus.erase(i);
	}
}

int MenuBar::getMenuCount() const {
	return static_cast<int>(menus.size());
}

Menu* MenuBar::getMenu(int i) const {
	assert ( i >= 0 && i < getMenuCount() );

	return menus[i];
}

void MenuBar::remove(MenuComponent* mcomp) {
	remove(static_cast<Menu*>(mcomp));
}


// peer operations

class MenuBar::ShortcutInfo {
public:
	ShortcutInfo(int id, const MenuShortcut* shortcut) 
		: id(id), shortcut(shortcut) {
		}

	int id;
	const MenuShortcut* shortcut;
};

void MenuBar::peer_createShortcuts() {
	assert ( peer != NULL );

	typedef std::list<ShortcutInfo> SCL;
	SCL shortcuts;
	for ( int i=0; i<getMenuCount(); ++i ) {
		Menu* menu = getMenu(i);
		for ( int j=0; j<menu->getItemCount(); ++j ) {
			MenuItem* item = menu->getItem(j);
			if ( !item->getShortcut() ) {
				continue;
			}

			ShortcutInfo info(item->getId(), &item->getShortcut());
			shortcuts.push_back(info);
		}
	}

	if ( !shortcuts.empty() ) {
		ACCEL* accels = new ACCEL[shortcuts.size()];
		SCL::iterator i;
		ACCEL* accel;
		for ( i = shortcuts.begin(), accel = accels; 
			i != shortcuts.end(); 
			++i, ++accel ) {
			ShortcutInfo si = *i;
			accel->fVirt = FVIRTKEY|FCONTROL;
			if ( si.shortcut->usesShiftModifier() ) {
				accel->fVirt |= FSHIFT;
			}

			accel->key = Toolkit::getDefaultToolkit()->
					javaKeyToWindowsKey(si.shortcut->getKey());
			accel->cmd = static_cast<WORD>(si.id);
		}

		haccel = ::CreateAcceleratorTable(accels, 
				static_cast<int>(shortcuts.size()));
		delete[] accels;
	}
}

void MenuBar::peer_delShortcuts() {
	if ( haccel != NULL ) {
		::DestroyAcceleratorTable(haccel);
		haccel = NULL;
	}
}

HMENU MenuBar::peer_createMenuBar() {
	return ::CreateMenu();
}

void MenuBar::peer_addHelpMenu(Menu* m) {
	peer_addMenu(m);
}

void MenuBar::peer_addMenu(Menu* m) {
	::InsertMenu(peer, (UINT)-1, MF_BYPOSITION|MF_POPUP, 
			(UINT_PTR)m->getPeer(), m->getLabel().c_str());
}

void MenuBar::peer_delMenu(int index) {
	::RemoveMenu(peer, index, MF_BYPOSITION);
	
	HWND hwndOwner = NULL;
	MenuContainer* parent = getParent();
	if ( parent != NULL ) {
		hwndOwner = static_cast<Frame*>(parent)->getPeer();
	}

    if ( hwndOwner != NULL ) {
        ::InvalidateRect(hwndOwner, 0, TRUE);
    }

    ::DrawMenuBar(hwndOwner);
}

void MenuBar::peer_dispose() {
	::DestroyMenu(peer);
	peer = NULL;
}
