#include <win32/win32.h>

#include <jlib/awt/MenuComponent.h>
#include <jlib/awt/MenuContainer.h>

using namespace jlib::awt;

MenuComponent::MenuComponent()
	: parent(NULL) {
}

MenuComponent::~MenuComponent() {
}

const Font& MenuComponent::getFont() const {
	if ( !font ) {
		if ( parent != NULL ) {
			return parent->getFont();
		}
	}

	return font;
}

void MenuComponent::setFont(const Font& f) {
	font = f;
}

void MenuComponent::removeNotify() {
	peer_dispose();
}

void MenuComponent::peer_dispose(){
}
