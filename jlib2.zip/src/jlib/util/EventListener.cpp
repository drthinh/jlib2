#include <jlib/util/EventListener.h>
#include <jlib/util/EventDispatcher.h>

#include <algorithm>
#include <functional>
#include <cassert>

using jlib::util::imp::EventDispatcherHelper;

namespace jlib { namespace util {

EventListener::~EventListener() {
	using std::for_each;
	using std::bind2nd;
	using std::mem_fun;

	for_each(dispatchers.begin(), dispatchers.end(), 
		bind2nd(mem_fun(&EventDispatcherHelper::remove), this));
}

void EventListener::addDispatcher(EventDispatcherHelper* d) {
	dispatchers.push_back(d);
}

void EventListener::removeDispatcher(EventDispatcherHelper* d) {
	Dispatchers::iterator i = 
		std::find(dispatchers.begin(), dispatchers.end(), d);
	assert (i != dispatchers.end());
	dispatchers.erase(i);
}

}}
