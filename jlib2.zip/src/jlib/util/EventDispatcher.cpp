#include <jlib/util/EventDispatcher.h>
#include <jlib/util/EventListener.h>

#include <vector>
#include <algorithm>
#include <functional>
#include <cassert>


namespace jlib { namespace util { namespace imp {

EventDispatcherHelper::~EventDispatcherHelper() {
	using namespace std;
	for_each(listeners.begin(), listeners.end(), 
		bind2nd(mem_fun(&EventListener::removeDispatcher), this));
}

bool EventDispatcherHelper::empty() const {
		return listeners.empty();
}

int EventDispatcherHelper::count() const {
	return static_cast<int>(listeners.size());
}

EventListener* EventDispatcherHelper::at(int index) const {
	return listeners[index];
}

void EventDispatcherHelper::add(EventListener* l) {
	listeners.push_back(l);
	try {
		l->addDispatcher(this);
	} catch (...) {
		listeners.pop_back();
		throw;
	}
}

void EventDispatcherHelper::remove(EventListener* l) {
	Listeners::iterator i = 
			std::find(listeners.begin(), listeners.end(), l);
	if (i != listeners.end()) {
		(*i)->removeDispatcher(this);
		listeners.erase(i);
	}
}

EventDispatcherHelper* EventDispatcherHelper::create() {
	return new EventDispatcherHelper;
}

}}}

