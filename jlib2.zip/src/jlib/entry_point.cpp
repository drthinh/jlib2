#include <win32/win32.h>
#include <tchar.h>

#include <jlib/entry_point.h>
#include <jlib/awt/Toolkit.h>

extern void jlib_main(const ArgumentList&);

#ifdef _MSC_VER
#include <crtdbg.h>
#endif

#ifndef _CONSOLE

int APIENTRY _tWinMain(HINSTANCE hinst, 
		HINSTANCE, 
		LPTSTR /*cmdLine*/, 
		int /*cmdShow*/) {

	HMODULE hmod = (HMODULE)hinst;

	int argc = __argc;

	TCHAR** argv =
#	ifdef _UNICODE
		__wargv;
#	else
		__argv;
#	endif
#else
int _tmain(int argc, TCHAR* argv[]) {

	HMODULE hmod = ::GetModuleHandle(NULL);
#endif

#ifdef _MSC_VER
	_CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#endif

	ArgumentList args;
	args.reserve(argc);
	while ( --argc ) {
		args.push_back(jlib::lang::String(*(++argv)));
	}
	class ConcreteToolkit : public jlib::awt::Toolkit {
	public:
		ConcreteToolkit(HMODULE hmod) : Toolkit(hmod) {
		}
	} toolkit(hmod);
	jlib_main(args);
	return 0;
}
