#include <jlib/lang/Monitor.h>
#include <jlib/lang/Runtime.h>
#include <jlib/lang/Native.h>

#include <cassert>

using namespace jlib::lang;

Monitor::Monitor() {
	peer = Runtime::nativeFactory()->createMonitor(this);
}

Monitor::~Monitor() {
	delete peer;
}

void Monitor::wait(long timeout) {
	assert ( timeout >= 0 );

	peer->wait(timeout);
}

void Monitor::notify() {
	peer->notify();
}

void Monitor::notifyAll() {
	peer->notifyAll();
}

void Monitor::enter() {
	peer->enter();
}

void Monitor::leave() {
	peer->leave();
}
