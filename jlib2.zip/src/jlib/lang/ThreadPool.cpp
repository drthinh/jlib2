#include <jlib/lang/ThreadPool.h>
#include <jlib/lang/Thread.h>
#include <jlib/lang/Lock.h>

#include <algorithm>
#include <functional>

using namespace jlib::lang;

class ThreadPool::PooledThread : public Thread {
public:
	PooledThread(ThreadPool* pool, jlib::lang::Runnable* target) 
		: pool(pool), target(target) {
		pool->registerThread(this);
	}

	~PooledThread() {
		pool->unregisterThread(this);
	}

private:
	void run() {
		do {
			try {
				target->run();
			} catch ( ... ) {
				// should store the exception information in future version
				// to make an InvocationTargetException, which can be thrown
				// by Thread::join or provide an uncaughtExeption method to
				// be overridden.
			}

			target = pool->waitNextTask();
		} while ( target != NULL );

		delete this;
	}

	ThreadPool* pool;
	jlib::lang::Runnable* target;
};


ThreadPool::ThreadPool(long waitTime) 
	: waitTime(waitTime), priority(Thread::NORM_PRIORITY), 
	numOfBusy(0), pooledCount(0), bejoined(false), threadCount(0) {
}

ThreadPool::~ThreadPool() {
	close();
}

void ThreadPool::setWaitTime(long waitTime) {
	this->waitTime = waitTime;
}

int ThreadPool::getWaitTime() const {
	return waitTime;
}

void ThreadPool::setPriority(int v) {
	if ( priority != v ) {
		
		synchronized ( queueLock ) {
			priority = v;
		}
	}
}

int ThreadPool::getPriority() const {
	return priority;
}

void ThreadPool::execute(Runnable* target) {
	synchronized ( queueLock ) {
		if ( pooledCount > 0 ) {
			taskQueue.push(target);
			--pooledCount;
			queueLock.notify();
		} else {
			PooledThread* t = new PooledThread(this, target);
			t->setPriority(priority);
			t->start();
		}

		++numOfBusy;
	}
}

Runnable* ThreadPool::waitNextTask() {
	Runnable* task = NULL;

	synchronized ( queueLock ) {
		--numOfBusy;
		++pooledCount;
		synchronized ( threadLock ) {
			if ( bejoined && numOfBusy == 0 ) {
				threadLock.notifyAll();
			}
		}

		queueLock.wait(waitTime);
		if ( taskQueue.empty() ) {
			return NULL;
		}

		task = taskQueue.back();
		taskQueue.pop();
	}

	Thread::currentThread().setPriority(priority);

	return task;
}

void ThreadPool::registerThread(PooledThread*) {
	synchronized ( threadLock ) {
		++threadCount;
	}
}

void ThreadPool::unregisterThread(PooledThread*) {
	synchronized ( threadLock ) {
		if ( --threadCount == 0 ) {
			threadLock.notifyAll();
		}
	}
}

void ThreadPool::join() {
	synchronized ( threadLock ) {
		bejoined = true;
		while ( !taskQueue.empty() || numOfBusy > 0 ) {
			threadLock.wait();
		}
		bejoined = false;
	}
}

void ThreadPool::join(long timeout) {
	synchronized ( threadLock ) {
		bejoined = true;
		while ( !taskQueue.empty() && numOfBusy > 0 ) {
			threadLock.wait(timeout);
		}
		bejoined = false;
	}
}

void ThreadPool::close() {
	join();

	synchronized ( queueLock ) {
		queueLock.notifyAll();
	}

	synchronized ( threadLock ) {
		while ( threadCount > 0 ) {
			threadLock.wait();
		}
	}
}
