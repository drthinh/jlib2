#include <jlib/lang/Thread.h>
#include <jlib/lang/Runtime.h>
#include <jlib/lang/Lock.h>
#include <jlib/lang/Monitor.h>

#include <string>
#include <cassert>
#include <cstdlib>

using namespace jlib::lang;

namespace {
	Monitor serialNumberLock;
	int currentThreadNumber = 0;

	int nextThreadNum() {
		int num = 0;
		synchronized ( serialNumberLock ) {
			num = currentThreadNumber++;
		}

		return num;
	}
}

Thread::Thread(Runnable* target) {
	assert ( target != NULL );

	char name[0x20] = "Thread-";
	itoa(nextThreadNum(), &name[strlen(name)], 10);

	peer = Runtime::nativeFactory()->createThread(target, name);
}

Thread::Thread(Runnable* target, const std::string& name) {
	assert ( target != NULL );

	peer = Runtime::nativeFactory()->createThread(target, name);
}

Thread::Thread(const std::string& name) {
	peer = Runtime::nativeFactory()->createThread(this, name);
}

Thread::Thread() {
	char buffer[0x20];
	itoa(nextThreadNum(), buffer, 10);
	std::string name = std::string("Thread-") + buffer;

	peer = Runtime::nativeFactory()->createThread(this, name);
}

Thread::Thread(NativeThread* peer)
	: peer(peer) {
}

Thread::~Thread() {
	peer->release();
}

void Thread::setName(const std::string& name) {
	peer->setName(name);
}

const std::string& Thread::getName() const {
	return peer->getName();
}

int Thread::getPriority() const {
	return peer->getPriority();
}

void Thread::setPriority(int priority) {
	assert( priority >= MIN_PRIORITY && priority <= MAX_PRIORITY );

	peer->setPriority(priority);
}

bool Thread::isAlive() const {
	return peer->isAlive();
}


Thread Thread::currentThread() {
	NativeThread* t = Runtime::nativeFactory()->currentThread();
	t->addRef();
	return t;
}

void Thread::start() {
	peer->start();
}

void Thread::join() {
	join(0);
}

void Thread::join(long millis) {
	assert( millis >= 0 );
	
	peer->join(millis);
}

void Thread::yield() {
	Runtime::nativeFactory()->yield();
}

void Thread::sleep(long millis) {
	assert ( millis >= 0 );

	Runtime::nativeFactory()->sleep(millis);
}

void Thread::interrupt() {
	peer->interrupt();
}

bool Thread::isInterrupted() const {
	return peer->isInterrupted();
}

void Thread::destroy() {
	peer->destroy();
}

void Thread::run() {
}


