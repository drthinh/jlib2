#include <jlib/lang/Runtime.h>

#ifdef WIN32
#	define WIN32_LEAN_AND_MEAN
#	include <windows.h>
#	include <jlib/lang/Win32Native.h>
	typedef jlib::win32::lang::Win32NativeFactory PlatformNativeFactory;
#else
#	error Only Win32 is currently supported !
#endif

using namespace jlib::lang;

namespace {
	// Initialize singletons as global static object is dangerous as
	// the sequence of initialization is undeterminable. Make singletons
	// as function static objects is better but in a multithreading
	// program, this may cause race condition. So I declared the factory
	// object as a funciton static object but make a fake global object
	// call the function, this guaranteed the sequence of initialization 
	// at startup time and avoid the race condition as the object has
	// already been initialized. This scheme will broken if there are 
	// more than one thread use this singleton. However, I think it's not 
	// possible for most applications.
	struct Trailer {
		Trailer() {
			Runtime::nativeFactory();
		}
	} trailer;
}

Runtime::Runtime() {
}

NativeFactory* Runtime::nativeFactory() {
	static PlatformNativeFactory factory;
	return &factory;
}
