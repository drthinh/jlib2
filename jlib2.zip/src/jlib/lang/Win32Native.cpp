#ifdef _MSC_VER
#	ifdef _MFC_VER
#		define MFC
#	endif
#endif

#define NOUSER
#define NOGDI
#include <win32/win32.h>

#include <process.h>
#include <cassert>

#include <exception>
#include <vector>
#include <string>

#include <jlib/lang/Runnable.h>
#include <jlib/lang/Thread.h>
#include <jlib/lang/Lock.h>
#include <jlib/lang/Win32Native.h>
#include <jlib/lang/Runtime.h>
#include <jlib/lang/ThreadingException.h>


using namespace jlib::lang;
using namespace jlib::win32::lang;

Win32Thread::Win32Thread(Runnable* target, const std::string& name)
	: target(target), name(name) {
	priority = Thread::NORM_PRIORITY;
	refCount = 1;

	handle = NULL;
	id = 0;
	event = NULL;
	interrupted = false;
#ifdef MFC
	mfcThread = NULL;
#endif
}

Win32Thread::Win32Thread() {
	handle = ::GetCurrentThread();
	id = static_cast<unsigned int>(::GetCurrentThreadId());

	event = NULL;

	interrupted = false;

	target = NULL; // no runnable object for external threads

	char buffer[0x20] = "NativeThread-";
	itoa(::GetCurrentThreadId(), &buffer[strlen(buffer)], 16);
	name = buffer;

	priority = Win32PriorityToJavaPriority(::GetThreadPriority(handle));
}

Win32Thread::~Win32Thread() {
#	ifdef MFC
	_mfcThread = NULL;
#	else
	::CloseHandle(handle);
#	endif
	if ( event != NULL ) {
		::CloseHandle(event);
	}
}

void Win32Thread::addRef() {
	::InterlockedIncrement(&refCount);
	// 1 after created
	// 2 after started
	// 3 if currentThread attached
	assert ( refCount > 1 && refCount <=3 );
}

void Win32Thread::release() {
	if ( ::InterlockedDecrement(&refCount) == 0 ) {
		delete this;
	} else {
		lock_t<Win32Monitor> l(lock);
		lock.notifyAll();
	}
}

#ifdef MFC
UINT Win32Thread::MFC_sThreadProc(LPVOID lParam) {
	return Win32Thread::sThreadProc(lParam);
}
#endif


namespace {

	// This function was found in MSDN for Visual Studio.NET, one
	// can search string - "THREADNAME_INFO" to find it.
	//
	// Usage: SetThreadName (-1, "MainThread");

	void SetThreadName( DWORD dwThreadID, LPCSTR szThreadName) {
#ifdef _MSC_VER
		typedef struct tagTHREADNAME_INFO {
			DWORD dwType; // must be 0x1000
			LPCSTR szName; // pointer to name (in user addr space)
			DWORD dwThreadID; // thread ID (-1=caller thread)
			DWORD dwFlags; // reserved for future use, must be zero
		} THREADNAME_INFO;

		THREADNAME_INFO info;
		info.dwType = 0x1000;
		info.szName = szThreadName;
		info.dwThreadID = dwThreadID;
		info.dwFlags = 0;

		__try {
			RaiseException(0x406D1388, 0, sizeof(info)/sizeof(DWORD), 
				reinterpret_cast<DWORD*>(&info));
		} __except(EXCEPTION_CONTINUE_EXECUTION) {
		}
#endif
	}
}

void Win32Thread::setName(const std::string& name) {
	lock_t<Win32Monitor> l(lock);
	if ( isAlive() ) {
		SetThreadName(id, name.c_str());
	}
}

const std::string& Win32Thread::getName() const {
	lock_t<Win32Monitor> l(lock);
	return name;
}

void Win32Thread::start() {
	lock_t<Win32Monitor> l(lock);

	assert ( handle == NULL );

#ifdef MFC
	_mfcThread = ::AfxBeginThread(MFC_sThreadProc, this, 
			THREAD_PRIORITY_NORMAL, 0, CREATE_SUSPENDED, NULL);

	handle = _mfcThread->m_hThread;
#else
	handle = reinterpret_cast<HANDLE>(::_beginthreadex(NULL, 0, 
			sThreadProc, this, CREATE_SUSPENDED, &id));
#endif
	if ( handle == NULL ) {
		throw ResourceException("Can not start new thread");
	}

	addRef();

	int p = Win32Thread::javaPriorityToWin32Priority(priority);
	::SetThreadPriority(handle, p);

	::ResumeThread(handle);
}

void Win32Thread::interrupt() {
	lock_t<Win32Monitor> l(lock);
	if ( interrupted == FALSE ) {
		interrupted = TRUE;
		if ( event != NULL ) {
			::SetEvent(event);
		}
	}
}

bool Win32Thread::isInterrupted() const {
	lock_t<Win32Monitor> l(lock);
	return interrupted;
}

void Win32Thread::destroy() {
	//::TerminateThread(handle, 0);
	//_mfcThread-> CWinThread
	//cleanup();
}

bool Win32Thread::isAlive() const {
	lock_t<Win32Monitor> l(lock);
	if ( handle != NULL ) {
		DWORD r;
		::GetExitCodeThread(handle, &r);
		if ( r == STILL_ACTIVE ) {
			return true;
		}
	}

	return false;
}

void Win32Thread::setPriority(int p) {
	lock_t<Win32Monitor> l(lock);
	if ( priority != p ) {
		priority = p;
		if( isAlive() ) {
			::SetThreadPriority(handle, javaPriorityToWin32Priority(p));
		}
	}
}

int Win32Thread::getPriority() const {
	lock_t<Win32Monitor> l(lock);
	return priority;
}

int Win32Thread::javaPriorityToWin32Priority(int priority) {
	int osPriority = 0;
	switch(priority) {
	case 0: // MIN_PRIORITY
		osPriority = THREAD_PRIORITY_IDLE;
		break;
	case 1: case 2:
		osPriority = THREAD_PRIORITY_LOWEST;
		break;
	case 3: case 4:
		osPriority = THREAD_PRIORITY_BELOW_NORMAL;
		break;
	case 5: // NORM_PRIORITY
		osPriority = THREAD_PRIORITY_NORMAL;
		break;
	case 6: case 7:
		osPriority = THREAD_PRIORITY_ABOVE_NORMAL;
		break;
	case 8: case 9:
		osPriority = THREAD_PRIORITY_HIGHEST;
		break;
	case 10: // MAX_PRIORITY
		osPriority = THREAD_PRIORITY_TIME_CRITICAL;
		break;
	default:
		assert (false);
	}

	return osPriority;
}

int Win32Thread::Win32PriorityToJavaPriority(int priority) {
	int javaPriority = 0;

	switch( priority ) {
	case THREAD_PRIORITY_IDLE:
		javaPriority = 0;
		break;
	case THREAD_PRIORITY_LOWEST:
		javaPriority = 2;
		break;
	case THREAD_PRIORITY_BELOW_NORMAL:
		javaPriority = 4;
		break;
	case THREAD_PRIORITY_NORMAL:
		javaPriority = 5;
		break;
	case THREAD_PRIORITY_ABOVE_NORMAL:
		javaPriority = 6;
		break;
	case THREAD_PRIORITY_HIGHEST:
		javaPriority = 8;
		break;
	case THREAD_PRIORITY_TIME_CRITICAL:
		javaPriority = 10;
		break;
	default:
		assert (false);
	}

	return javaPriority;
}

void Win32Thread::sleep(long millis) {
	Win32Thread* current = 
			Win32NativeFactory::instance()->currentThread();
	lock_t<Win32Monitor> l(current->lock);
	current->lock.wait(millis);
}

void Win32Thread::join(long millis) {
	assert( millis >= 0 );
	
	lock_t<Win32Monitor> l(lock);
	if ( isAlive() ) {
		lock.wait(millis);
	}
}

void Win32Thread::wait(Win32Monitor* monitor, long timeout) {
	assert ( timeout >= 0 );
	assert ( monitor->isLocking() );

	if ( timeout == 0 ) {
		timeout = INFINITE;
	}

	{
		lock_t<Win32Monitor> l(lock);
		if ( event == NULL ) {
			event = ::CreateEvent(NULL, TRUE, FALSE, NULL);
			if ( event == NULL ) {
				throw ResourceException("Can not create event object");
			}
		} else {
			::ResetEvent(event);
		}
	}

	WaitingNode n(event);
	monitor->addWaiting(&n);

	monitor->leave();


	// Must use a manual reset event. Suppose a autoreset event is used,
	// if a notify call from other thread squeezed after this thread
	// call WaitForSingleObject() and before enter(), the
	// event will be left with signaled state until next call for
	// WaitForSingleObject, and will not be blocked because the event
	// was in signaled state, which is definitely wrong.

	DWORD r = ::WaitForSingleObject(event, timeout);
	//if ( r == WAIT_TIMEOUT ) {
	//	OutputDebugString("timeout\n");
	//}
	assert ( r == WAIT_OBJECT_0 || r == WAIT_TIMEOUT );

	monitor->enter();

	if ( !n.notified ) {
		monitor->removeWaiting(&n);
	}

	{
		lock_t<Win32Monitor> l(lock);
		if ( interrupted ) {
			interrupted = false;
			throw InterruptedException();
		}
	}
}

void Win32Thread::threadProc() {
	struct Sentry {
		Sentry(Win32Thread* self) : self(self) {}
		~Sentry() {	self->release(); }
		Win32Thread* self;
	} sentry(this);

	try {
		{
			lock_t<Win32Monitor> l(lock);
			SetThreadName(id, name.c_str());
		}
		Win32NativeFactory::instance()->registerThread(this);

		target->run();

#ifdef MFC
	} catch ( CException* mfce ) {
		mfce->ReportError();
		mfce->Delete();
#endif
	} catch ( const std::exception& e ) {
		::OutputDebugString(
				(std::string("exception : ") + e.what()).c_str());
	}
}

unsigned int __stdcall Win32Thread::sThreadProc(void* argv) {
	Win32Thread* pthis = static_cast<Win32Thread*>(argv);
	pthis->threadProc();
	return 0;
}


// implement Win32Monitor

Win32Monitor::Win32Monitor() {
}

void Win32Monitor::notify() {
	assert ( isLocking() );

	if ( !waitings.empty() ) {
		waitings.front()->notify();
		waitings.pop_front();
	}
}

void Win32Monitor::notifyAll() {
	assert ( isLocking() );

	while( !waitings.empty() ) {
		waitings.front()->notify();
		waitings.pop_front();
	}
}

void Win32Monitor::wait(long timeout) {
	assert ( isLocking() );

	Win32Thread* currentThread = 
		Win32NativeFactory::instance()->currentThread();
	currentThread->wait(this, timeout);
}
	
void Win32Monitor::enter() {
	mutex.lock();
}

void Win32Monitor::leave() {
	assert (isLocking() );

	mutex.unlock();
}

void Win32Monitor::addWaiting(WaitingNode* n) {
	assert ( isLocking() );

	waitings.push_back(n);
}

void Win32Monitor::removeWaiting(WaitingNode* n) {
	assert ( isLocking() );

	waitings.erase(n);
}

bool Win32Monitor::isLocking() const {
	return mutex.getLockCount() > 0;
}

// Implement Win32NativeFactory

Win32NativeFactory* Win32NativeFactory::me;

Win32NativeFactory::Win32NativeFactory() {
	assert ( me == NULL );
	me = this;
}

Win32NativeFactory::~Win32NativeFactory() {
	Win32ThreadList::reverse_iterator i;
	for ( i = externalThreads.rbegin(); i != externalThreads.rend(); ++i ) {
		delete *i;
	}

	externalThreads.clear();
}

NativeThread* Win32NativeFactory::createThread(
		Runnable* target, const std::string& name) {
	return new Win32Thread(target, name);
}

Win32Thread* Win32NativeFactory::currentThread() {
	Win32Thread* t = threadSlot.get();
	if ( t == NULL ) {
		t = new Win32Thread;
		registerThread(t);

		lock_t<Win32Monitor> l(externalThreadsLock);
		externalThreads.push_back(t);
	}

	return t;
}

void Win32NativeFactory::sleep(long millis) {
	assert ( millis >= 0 );

	Win32Thread::sleep(millis);
}

void Win32NativeFactory::yield() {
	::Sleep(0);
}

void Win32NativeFactory::registerThread(Win32Thread* thread) {
	threadSlot.set(thread);
}

NativeMonitor* Win32NativeFactory::createMonitor(Monitor*) {
	return new Win32Monitor();
}
