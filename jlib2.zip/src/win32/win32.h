#ifndef JLIB_WIN32_WIN32
#define JLIB_WIN32_WIN32

#define STRICT

#define WIN32_LEAN_AND_MEAN
#define NOSERVICE
#define NOMCX
#define NOIME
#define NOSOUND
#define NOCOMM
#define NORPC

#define NOMINMAX
#include <windows.h>

#ifdef TEXT
#undef TEXT
#endif

#endif
