#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tchar.h>

#include <jlib/jlib.h>
#include <jlib/lang/Runnable.h>
#include <jlib/lang/ThreadPool.h>

#define USE_POOL
#define TEST_COUNT 10000

class ThreadPoolDemo {
	ThreadPoolDemo() {
		class Tester : public  
#ifdef USE_POOL	
			Runnable
#else
			Thread
#endif
		{
		public:
			void run() {
				static int i=0;
				++i;
				char buffer[0x30];
				wsprintf(buffer, " run %d\n", i);
				//OutputDebugStringA(Thread::currentThread()->getName());
				OutputDebugStringA(buffer);
				
				//Thread::sleep(50);
			}
		};

		Tester tester[TEST_COUNT];

#ifdef USE_POOL
		ThreadPool threadPool;
		threadPool.setWaitTime(1000);

		//Thread::currentThread()->setPriority(Thread::NORM_PRIORITY+1);
		//threadPool.setPriority(Thread::MIN_PRIORITY);
		for ( int i=0; i<TEST_COUNT; ++i ) {		
			threadPool.execute(&tester[i]);
			//OutputDebugString("\n");
			//Thread::yield();
		}

		OutputDebugStringA("!!! sleep\n");
		//Thread::sleep(5000);
		OutputDebugStringA("!!! JOIN\n");
		threadPool.join();
		OutputDebugStringA("After join\n");
#else
		for ( int i=0; i<TEST_COUNT; ++i ) {
			tester[i].start();
		}

		OutputDebugStringA("!!! JOIN\n");
		for ( int i=0; i<TEST_COUNT; ++i ) {
			tester[i].join();
		}
		OutputDebugStringA("After join\n");
#endif
		//threadPool.close();
		//Thread::sleep(100);
	}


public:
	static void main(const ArgumentList&) {
		ThreadPoolDemo demo;
	}
};

MAIN_CLASS(ThreadPoolDemo)