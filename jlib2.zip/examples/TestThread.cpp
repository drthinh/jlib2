#define _CONSOLE
#include <jlib/jlib.h>
#include <jlib/lang/Thread.h>
#include <jlib/lang/Lock.h>

class TestThread : public Thread {
public:
	TestThread(Monitor* m) : monitor(m) {
	}

	void run() {
		//for (int i=0; i<10; ++i) {
			synchronized ( *monitor ) {
				printf("wait in %s\n", getName().c_str());
				monitor->wait();
				printf("resumed in %s\n", getName().c_str());
			}
		//}
	}
private:
	Monitor* monitor;
};

class Test {
	public: static void main(const ArgumentList&) {
		Monitor lock;
		TestThread t1(&lock);
		TestThread t2(&lock);
		TestThread t3(&lock);

		t1.start();
		t2.start();
		t3.start();

		Thread::sleep(2000);
		synchronized ( lock ) {
			lock.notify();
		}

		Thread::sleep(2000);
		synchronized ( lock ) {
			lock.notifyAll();
		}

		t1.join();
		t2.join();
		t3.join();
	}
};

MAIN_CLASS(Test)