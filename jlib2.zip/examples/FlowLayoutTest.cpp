#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tchar.h>

#include <jlib/jlib.h>

#include <jlib/awt/Panel.h>
#include <jlib/awt/Button.h>
#include <jlib/awt/TextField.h>
#include <jlib/awt/Label.h>

#include <jlib/awt/Frame.h>
#include <jlib/awt/FlowLayout.h>
#include <jlib/awt/BorderLayout.h>

#include <jlib/awt/event/WindowAdapter.h>
#include <jlib/awt/event/WindowEvent.h>
#include <jlib/awt/event/ActionListener.h>
#include <jlib/awt/event/ActionEvent.h>

using namespace jlib::awt;
using namespace jlib::awt::event;

class SouthPanel : public Panel {
	Button button1;
	Button button2;
public:
	SouthPanel() {
		button1.setLabel(_T("Button1"));
		button2.setLabel(_T("Button2"));
		add(&button1);
		add(&button2);
	}
};

class FlowLayoutTest : public Frame {
	SouthPanel south;
	FlowLayoutTest() {
		add(&south, BorderLayout::SOUTH);
	}
public:
	static void main(const ArgumentList& /*args*/) {
		FlowLayoutTest test;
		test.setBounds(0, 0, 320, 240);
		test.show();
	}
};

//MAIN_CLASS(FlowLayoutTest)