#include <windows.h>

#include <jlib/jlib.h>
#include <jlib/awt/Tab.h>
#include <jlib/awt/Frame.h>
#include <jlib/awt/BorderLayout.h>
#include <jlib/awt/event/WindowAdapter.h>
#include <jlib/awt/event/WindowEvent.h>


using namespace jlib::awt;
using namespace jlib::awt::event;

class TestFrame : public Frame, WindowAdapter {
	Tab tab;

	TestFrame() 
		: Frame("TabTest"), tab(Tab::RIGHT, Tab::WRAP_TAB_LAYOUT) {
		tab.insertTab("1", -1);
		tab.insertTab("2", -1);
		tab.insertTab("3", -1);
		tab.insertTab("4", -1);
		tab.insertTab("5", -1);
		tab.insertTab("This is a test, isn't it?", -1);
		add(&tab, BorderLayout::EAST);
		addWindowListener(this);
	}

	void windowClosing(const WindowEvent&) {
		dispose();
	}

public:
	static void main(const ArgumentList&) {
		TestFrame t;
		t.pack();
		t.show();
	}
};

MAIN_CLASS(TestFrame)