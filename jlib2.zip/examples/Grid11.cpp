#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tchar.h>

#include <jlib/jlib.h>

#include <jlib/awt/Frame.h>

#include <jlib/awt/Label.h>
#include <jlib/awt/GridLayout.h>

#include <jlib/awt/event/WindowAdapter.h>
#include <jlib/awt/event/WindowEvent.h>

using namespace jlib::awt;
using namespace jlib::awt::event;


class Grid11 : public Frame, WindowAdapter {
	Label l;
	GridLayout gl;
	Grid11() 
		: Frame(_T("Grid11")), l(_T("1*1")), gl(1,1) {
		setLayout(&gl);

		l.setBackground(Color::BLUE);
		add(&l);

		addWindowListener(this);
	}

	void windowClosing(const WindowEvent&) {
		dispose();
	}

public:
	static void main(const ArgumentList&) {
		Grid11 test;
		test.setBounds(100, 100, 200, 200);
		test.show();
	}
};

MAIN_CLASS(Grid11)