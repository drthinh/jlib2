#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tchar.h>

#include <jlib/jlib.h>

#include <jlib/awt/Frame.h>

#include <jlib/awt/Label.h>
#include <jlib/awt/Button.h>
#include <jlib/awt/Checkbox.h>

#include <jlib/awt/ScrollPane.h>

#include <jlib/awt/BorderLayout.h>
#include <jlib/awt/BoxLayout.h>
#include <jlib/awt/GridLayout.h>

#include <jlib/awt/Panel.h>

#include <jlib/awt/event/WindowAdapter.h>
#include <jlib/awt/event/WindowEvent.h>
#include <jlib/awt/event/ActionListener.h>
#include <jlib/awt/event/ActionEvent.h>

#include <jlib/lang/StringStream.h>

using namespace jlib::awt;
using namespace jlib::awt::event;


class NullLayout : public Frame, WindowAdapter {

	NullLayout() 
		: Frame(_T("NullLayout")) {

		setLayout(NULL);
		for( int i=0; i<12; ++i ) {
			OStringStream oss;
			oss << _T("ScrollPane Test, button ") << i;
			Button* l = new Button(oss.str());
			l->setBounds(10, 30*i, 225, 25);
			add(l);
		}
		addWindowListener(this);
	}

	void windowClosing(const WindowEvent&) {
		dispose();
	}

	void actionPerformed(const ActionEvent&) {
	}

public:
	static void main(const ArgumentList&) {
		NullLayout test;
		test.setBounds(0, 0, 320, 240);
		test.show();
		jlib::awt::Rectangle r(1, 1, 2, 2);
		r.x = 2;
	}
};

MAIN_CLASS(NullLayout)