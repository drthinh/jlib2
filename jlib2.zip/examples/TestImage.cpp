#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tchar.h>

#include <jlib/jlib.h>

#include <jlib/awt/Frame.h>

#include <jlib/awt/Graphics.h>
#include <jlib/awt/Image.h>
#include <jlib/awt/Toolkit.h>

#include <jlib/awt/Panel.h>

#include <jlib/awt/event/WindowAdapter.h>
#include <jlib/awt/event/WindowEvent.h>

#include <jlib/awt/event/ItemListener.h>
#include <jlib/awt/event/ItemEvent.h>

#include <jlib/awt/event/ActionListener.h>
#include <jlib/awt/event/ActionEvent.h>

#include <jlib/awt/SplitPane.h>

using namespace jlib::awt;
using namespace jlib::awt::event;


class TestImage : public Frame, WindowAdapter {
	std::auto_ptr<Image> img;

	void paint(Graphics& g) {
		g.drawImage(*img.get(), 0, 0, this);
	}

	TestImage() {
		img = Toolkit::getDefaultToolkit()->createImage(
				_T("e:\\vcproj\\jlib\\src\\test\\moon.bmp"));

		addWindowListener(this);
	}

	void windowClosing(const WindowEvent&) {
		dispose();
	}

public:
	static void main(const ArgumentList&) {
		TestImage test;
		test.setBounds(0, 0, 800, 480);
		test.show();
	}
};

MAIN_CLASS(TestImage)