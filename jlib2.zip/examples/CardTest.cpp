/*
 * Copyright (c) 2002 Sun Microsystems, Inc. All  Rights Reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * -Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 * 
 * -Redistribution in binary form must reproduct the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the distribution.
 * 
 * Neither the name of Sun Microsystems, Inc. or the names of contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 * 
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
 * ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
 * OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN AND ITS LICENSORS SHALL NOT
 * BE LIABLE FOR ANY DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT
 * OF OR RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THE SOFTWARE OR ITS
 * DERIVATIVES. IN NO EVENT WILL SUN OR ITS LICENSORS BE LIABLE FOR ANY LOST
 * REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL,
 * INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY
 * OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE, EVEN
 * IF SUN HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * You acknowledge that Software is not designed, licensed or intended for
 * use in the design, construction, operation or maintenance of any nuclear
 * facility.
 */ 
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <jlib/jlib.h>

#include <jlib/awt/Panel.h>
#include <jlib/awt/Button.h>
#include <jlib/awt/Choice.h>

#include <jlib/awt/Frame.h>
#include <jlib/awt/BorderLayout.h>
#include <jlib/awt/FlowLayout.h>
#include <jlib/awt/GridLayout.h>
#include <jlib/awt/CardLayout.h>

#include <jlib/awt/event/WindowAdapter.h>
#include <jlib/awt/event/WindowEvent.h>

#include <jlib/awt/event/ItemListener.h>
#include <jlib/awt/event/ItemEvent.h>

#include <jlib/awt/event/ActionListener.h>
#include <jlib/awt/event/ActionEvent.h>

using namespace jlib::awt;
using namespace jlib::awt::event;

class Card : public Panel {
	Button b1, b2, b3, b4, b5, b6;
public:
	Card(LayoutManager* layoutMgr, ActionListener* listener) {
		setLayout(layoutMgr);
		b1.setLabel(_T("one"));
		b1.addActionListener(listener);
		add(&b1, BorderLayout::NORTH);
		b2.setLabel(_T("two"));
		b2.addActionListener(listener);
		add(&b2, BorderLayout::WEST);
		b3.setLabel(_T("three"));
		b3.addActionListener(listener);
		add(&b3, BorderLayout::SOUTH);
		b4.setLabel(_T("four"));
		b4.addActionListener(listener);
		add(&b4, BorderLayout::EAST);
		b5.setLabel(_T("five"));
		b5.addActionListener(listener);
		add(&b5, BorderLayout::CENTER);
		b6.setLabel(_T("six"));
		b6.addActionListener(listener);
		add(&b6, BorderLayout::CENTER);
	}
};

class CardPanel : public Panel {
	FlowLayout l1;
	BorderLayout l2;
	GridLayout l3;
	BorderLayout l4;
	FlowLayout l5;
	GridLayout l6;

	Card c1, c2, c3, c4, c5, c6;

	CardLayout cardLayout;

public:
	CardPanel(ActionListener* listener) 
		: l3(2, 2), l4(10, 10), 
		l5(FlowLayout::LEFT, 10, 10), l6(2, 2, 10, 10),
		c1(&l1, listener), c2(&l2, listener), 
		c3(&l3, listener), c4(&l4, listener),
		c5(&l5, listener), c6(&l6, listener) {

		setLayout(&cardLayout);
		add(&c1, CardLayout::Constraints(_T("one")));
		add(&c2, CardLayout::Constraints(_T("two")));
		add(&c3, CardLayout::Constraints(_T("three")));
		add(&c4, CardLayout::Constraints(_T("four")));
		add(&c5, CardLayout::Constraints(_T("five")));
		add(&c6, CardLayout::Constraints(_T("six")));
	}

	Dimension getPreferredSize() const {
		return Dimension(200, 100);
	}
};

class CardTest : Frame, ActionListener, ItemListener, WindowAdapter {
	CardPanel cards;
	Panel p;
	FlowLayout fl;
	Button b1, b2, b3, b4;
	Choice c;

	CardTest()
		: Frame(_T("CardTest")), cards(this),
			b1(_T("first")), b2(_T("next")), 
			b3(_T("previous")), b4(_T("last")) {

		add(&cards, BorderLayout::CENTER);
		p.setLayout(&fl);
		add(&p, BorderLayout::SOUTH);

		b1.addActionListener(this);
		p.add(&b1);

		b2.addActionListener(this);
		p.add(&b2);

		b3.addActionListener(this);
		p.add(&b3);

		b4.addActionListener(this);
		p.add(&b4);

		c.addItem(_T("one"));
		c.addItem(_T("two"));
		c.addItem(_T("three"));
		c.addItem(_T("four"));
		c.addItem(_T("five"));
		c.addItem(_T("six"));
		c.addItemListener(this);
		p.add(&c);

		addWindowListener(this);
	}

	void itemStateChanged(const ItemEvent& e) {
		CardLayout* l = static_cast<CardLayout*>(cards.getLayout());
		l->show(&cards, e.getItem());
	}

	void actionPerformed(const ActionEvent& e) {
		String arg = e.getActionCommand();
		CardLayout* l = static_cast<CardLayout*>(cards.getLayout());

		if ( _T("first") == arg ) {
			l->first(&cards);
		} else if ( _T("next") == arg ) {
			l->next(&cards);
		} else if ( _T("previous") == arg ) {
			l->previous(&cards);
		} else if ( _T("last") == arg ) {
			l->last(&cards);
		} else {
			l->show(&cards, arg);
		}
	}

	void windowClosing(const WindowEvent&) {
		dispose();
	}

public:
	static void main(const ArgumentList&) {
		CardTest cardTest;

		cardTest.setSize(360, 360);
		cardTest.show();
	}

	String getAppletInfo() const {
		return _T("Demonstrates the different types of layout managers.");
	}
};

MAIN_CLASS(CardTest)
