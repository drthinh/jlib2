file(REMOVE_RECURSE
  "CMakeFiles/SplitPaneTest.dir/SplitPaneTest/SplitPaneTest.cpp.obj"
  "CMakeFiles/SplitPaneTest.dir/SplitPaneTest/SplitPaneTest.cpp.obj.d"
  "CMakeFiles/SplitPaneTest.dir/app.rc.obj"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/SplitPaneTest/SplitPaneTest.exe"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/SplitPaneTest/SplitPaneTest.exe.manifest"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/SplitPaneTest/SplitPaneTest.pdb"
  "libSplitPaneTest.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX RC)
  include(CMakeFiles/SplitPaneTest.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
