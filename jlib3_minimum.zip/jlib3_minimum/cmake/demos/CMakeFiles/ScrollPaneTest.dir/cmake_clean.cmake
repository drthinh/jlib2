file(REMOVE_RECURSE
  "CMakeFiles/ScrollPaneTest.dir/ScrollPaneTest/ScrollPaneTest.cpp.obj"
  "CMakeFiles/ScrollPaneTest.dir/ScrollPaneTest/ScrollPaneTest.cpp.obj.d"
  "CMakeFiles/ScrollPaneTest.dir/app.rc.obj"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/ScrollPaneTest/ScrollPaneTest.exe"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/ScrollPaneTest/ScrollPaneTest.exe.manifest"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/ScrollPaneTest/ScrollPaneTest.pdb"
  "libScrollPaneTest.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX RC)
  include(CMakeFiles/ScrollPaneTest.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
