# Empty compiler generated dependencies file for NervousText.
# This may be replaced when dependencies are built.
