file(REMOVE_RECURSE
  "CMakeFiles/NervousText.dir/NervousText/NervousText.cpp.obj"
  "CMakeFiles/NervousText.dir/NervousText/NervousText.cpp.obj.d"
  "CMakeFiles/NervousText.dir/app.rc.obj"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/NervousText/NervousText.exe"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/NervousText/NervousText.exe.manifest"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/NervousText/NervousText.pdb"
  "libNervousText.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX RC)
  include(CMakeFiles/NervousText.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
