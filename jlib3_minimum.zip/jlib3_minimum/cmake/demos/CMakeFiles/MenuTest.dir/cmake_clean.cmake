file(REMOVE_RECURSE
  "CMakeFiles/MenuTest.dir/MenuTest/MenuTest.cpp.obj"
  "CMakeFiles/MenuTest.dir/MenuTest/MenuTest.cpp.obj.d"
  "CMakeFiles/MenuTest.dir/app.rc.obj"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/MenuTest/MenuTest.exe"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/MenuTest/MenuTest.exe.manifest"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/MenuTest/MenuTest.pdb"
  "libMenuTest.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX RC)
  include(CMakeFiles/MenuTest.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
