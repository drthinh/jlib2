file(REMOVE_RECURSE
  "CMakeFiles/ControlsDemo.dir/ControlsDemo/ControlsDemo.cpp.obj"
  "CMakeFiles/ControlsDemo.dir/ControlsDemo/ControlsDemo.cpp.obj.d"
  "CMakeFiles/ControlsDemo.dir/app.rc.obj"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/ControlsDemo/ControlsDemo.exe"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/ControlsDemo/ControlsDemo.exe.manifest"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/ControlsDemo/ControlsDemo.pdb"
  "libControlsDemo.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX RC)
  include(CMakeFiles/ControlsDemo.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
