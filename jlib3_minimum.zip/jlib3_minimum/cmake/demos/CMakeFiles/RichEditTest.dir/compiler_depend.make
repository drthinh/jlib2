# Empty compiler generated dependencies file for RichEditTest.
# This may be replaced when dependencies are built.
