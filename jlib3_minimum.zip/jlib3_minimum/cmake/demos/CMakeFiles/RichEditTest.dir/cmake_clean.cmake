file(REMOVE_RECURSE
  "CMakeFiles/RichEditTest.dir/RichEditTest/RichEditTest.cpp.obj"
  "CMakeFiles/RichEditTest.dir/RichEditTest/RichEditTest.cpp.obj.d"
  "CMakeFiles/RichEditTest.dir/app.rc.obj"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/RichEditTest/RichEditTest.exe"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/RichEditTest/RichEditTest.exe.manifest"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/RichEditTest/RichEditTest.pdb"
  "libRichEditTest.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX RC)
  include(CMakeFiles/RichEditTest.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
