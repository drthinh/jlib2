file(REMOVE_RECURSE
  "CMakeFiles/Hello.dir/Hello/Hello.cpp.obj"
  "CMakeFiles/Hello.dir/Hello/Hello.cpp.obj.d"
  "CMakeFiles/Hello.dir/app.rc.obj"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/Hello/Hello.exe"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/Hello/Hello.exe.manifest"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/Hello/Hello.pdb"
  "libHello.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX RC)
  include(CMakeFiles/Hello.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
