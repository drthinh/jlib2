file(REMOVE_RECURSE
  "CMakeFiles/DialogTest.dir/DialogTest/DialogTest.cpp.obj"
  "CMakeFiles/DialogTest.dir/DialogTest/DialogTest.cpp.obj.d"
  "CMakeFiles/DialogTest.dir/app.rc.obj"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/DialogTest/DialogTest.exe"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/DialogTest/DialogTest.exe.manifest"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/DialogTest/DialogTest.pdb"
  "libDialogTest.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX RC)
  include(CMakeFiles/DialogTest.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
