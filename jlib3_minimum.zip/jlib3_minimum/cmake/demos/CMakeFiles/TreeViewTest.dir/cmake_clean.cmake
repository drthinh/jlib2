file(REMOVE_RECURSE
  "CMakeFiles/TreeViewTest.dir/TreeViewTest/TreeViewTest.cpp.obj"
  "CMakeFiles/TreeViewTest.dir/TreeViewTest/TreeViewTest.cpp.obj.d"
  "CMakeFiles/TreeViewTest.dir/app.rc.obj"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/TreeViewTest/TreeViewTest.exe"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/TreeViewTest/TreeViewTest.exe.manifest"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/TreeViewTest/TreeViewTest.pdb"
  "libTreeViewTest.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX RC)
  include(CMakeFiles/TreeViewTest.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
