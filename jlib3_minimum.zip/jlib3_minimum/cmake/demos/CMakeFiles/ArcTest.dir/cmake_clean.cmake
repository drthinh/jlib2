file(REMOVE_RECURSE
  "CMakeFiles/ArcTest.dir/ArcTest/ArcTest.cpp.obj"
  "CMakeFiles/ArcTest.dir/ArcTest/ArcTest.cpp.obj.d"
  "CMakeFiles/ArcTest.dir/app.rc.obj"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/ArcTest/ArcTest.exe"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/ArcTest/ArcTest.exe.manifest"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/ArcTest/ArcTest.pdb"
  "libArcTest.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX RC)
  include(CMakeFiles/ArcTest.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
