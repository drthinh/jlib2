# Empty compiler generated dependencies file for CardTest.
# This may be replaced when dependencies are built.
