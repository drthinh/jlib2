file(REMOVE_RECURSE
  "CMakeFiles/CardTest.dir/CardTest/CardTest.cpp.obj"
  "CMakeFiles/CardTest.dir/CardTest/CardTest.cpp.obj.d"
  "CMakeFiles/CardTest.dir/app.rc.obj"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/CardTest/CardTest.exe"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/CardTest/CardTest.exe.manifest"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/CardTest/CardTest.pdb"
  "libCardTest.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX RC)
  include(CMakeFiles/CardTest.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
