file(REMOVE_RECURSE
  "CMakeFiles/TabbedPaneTest.dir/TabbedPaneTest/TabbedPaneTest.cpp.obj"
  "CMakeFiles/TabbedPaneTest.dir/TabbedPaneTest/TabbedPaneTest.cpp.obj.d"
  "CMakeFiles/TabbedPaneTest.dir/app.rc.obj"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/TabbedPaneTest/TabbedPaneTest.exe"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/TabbedPaneTest/TabbedPaneTest.exe.manifest"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/TabbedPaneTest/TabbedPaneTest.pdb"
  "libTabbedPaneTest.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX RC)
  include(CMakeFiles/TabbedPaneTest.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
