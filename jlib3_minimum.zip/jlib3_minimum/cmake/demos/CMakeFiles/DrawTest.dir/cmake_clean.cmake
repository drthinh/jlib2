file(REMOVE_RECURSE
  "CMakeFiles/DrawTest.dir/DrawTest/DrawTest.cpp.obj"
  "CMakeFiles/DrawTest.dir/DrawTest/DrawTest.cpp.obj.d"
  "CMakeFiles/DrawTest.dir/app.rc.obj"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/DrawTest/DrawTest.exe"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/DrawTest/DrawTest.exe.manifest"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/DrawTest/DrawTest.pdb"
  "libDrawTest.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX RC)
  include(CMakeFiles/DrawTest.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
