# Empty compiler generated dependencies file for TrayDemo.
# This may be replaced when dependencies are built.
