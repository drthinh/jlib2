file(REMOVE_RECURSE
  "CMakeFiles/TrayDemo.dir/TrayDemo/TrayDemo.cpp.obj"
  "CMakeFiles/TrayDemo.dir/TrayDemo/TrayDemo.cpp.obj.d"
  "CMakeFiles/TrayDemo.dir/app.rc.obj"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/TrayDemo/TrayDemo.exe"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/TrayDemo/TrayDemo.exe.manifest"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/TrayDemo/TrayDemo.pdb"
  "libTrayDemo.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX RC)
  include(CMakeFiles/TrayDemo.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
