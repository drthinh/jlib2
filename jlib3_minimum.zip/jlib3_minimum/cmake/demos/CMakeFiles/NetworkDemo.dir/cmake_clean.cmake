file(REMOVE_RECURSE
  "CMakeFiles/NetworkDemo.dir/NetworkDemo/NetworkDemo.cpp.obj"
  "CMakeFiles/NetworkDemo.dir/NetworkDemo/NetworkDemo.cpp.obj.d"
  "CMakeFiles/NetworkDemo.dir/app.rc.obj"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/NetworkDemo/NetworkDemo.exe"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/NetworkDemo/NetworkDemo.exe.manifest"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/NetworkDemo/NetworkDemo.pdb"
  "libNetworkDemo.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX RC)
  include(CMakeFiles/NetworkDemo.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
