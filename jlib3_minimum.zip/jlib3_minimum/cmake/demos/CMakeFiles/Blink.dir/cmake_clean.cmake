file(REMOVE_RECURSE
  "CMakeFiles/Blink.dir/Blink/Blink.cpp.obj"
  "CMakeFiles/Blink.dir/Blink/Blink.cpp.obj.d"
  "CMakeFiles/Blink.dir/app.rc.obj"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/Blink/Blink.exe"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/Blink/Blink.exe.manifest"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/Blink/Blink.pdb"
  "libBlink.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX RC)
  include(CMakeFiles/Blink.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
