# Empty compiler generated dependencies file for GridBagLayoutTest.
# This may be replaced when dependencies are built.
