# Empty compiler generated dependencies file for SimpleGraph.
# This may be replaced when dependencies are built.
