file(REMOVE_RECURSE
  "CMakeFiles/SimpleGraph.dir/SimpleGraph/SimpleGraph.cpp.obj"
  "CMakeFiles/SimpleGraph.dir/SimpleGraph/SimpleGraph.cpp.obj.d"
  "CMakeFiles/SimpleGraph.dir/app.rc.obj"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/SimpleGraph/SimpleGraph.exe"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/SimpleGraph/SimpleGraph.exe.manifest"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/SimpleGraph/SimpleGraph.pdb"
  "libSimpleGraph.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX RC)
  include(CMakeFiles/SimpleGraph.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
