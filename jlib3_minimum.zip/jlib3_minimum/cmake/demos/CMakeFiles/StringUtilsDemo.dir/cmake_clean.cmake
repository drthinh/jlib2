file(REMOVE_RECURSE
  "CMakeFiles/StringUtilsDemo.dir/StringUtilsDemo/StringUtilsDemo.cpp.obj"
  "CMakeFiles/StringUtilsDemo.dir/StringUtilsDemo/StringUtilsDemo.cpp.obj.d"
  "CMakeFiles/StringUtilsDemo.dir/app.rc.obj"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/StringUtilsDemo/StringUtilsDemo.exe"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/StringUtilsDemo/StringUtilsDemo.exe.manifest"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/StringUtilsDemo/StringUtilsDemo.pdb"
  "libStringUtilsDemo.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX RC)
  include(CMakeFiles/StringUtilsDemo.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
