# Empty compiler generated dependencies file for StringUtilsDemo.
# This may be replaced when dependencies are built.
