
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "RC"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_RC
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/app.rc" "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/cmake/demos/CMakeFiles/Clock.dir/app.rc.obj"
  )

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_RC
  "NDEBUG"
  "NTDDI_VERSION=0x06010000"
  "UNICODE"
  "WIN32_LEAN_AND_MEAN"
  "_CRT_SECURE_NO_WARNINGS"
  "_UNICODE"
  "_WIN32_IE=0x0700"
  "_WIN32_WINNT=0x0601"
  "__MINGW_USE_VC2005_COMPAT"
  )

# The include file search paths:
set(CMAKE_RC_TARGET_INCLUDE_PATH
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/include"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/src"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/Include"
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/Clock/Clock.cpp" "demos/CMakeFiles/Clock.dir/Clock/Clock.cpp.obj" "gcc" "demos/CMakeFiles/Clock.dir/Clock/Clock.cpp.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
