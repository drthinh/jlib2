file(REMOVE_RECURSE
  "CMakeFiles/Clock.dir/Clock/Clock.cpp.obj"
  "CMakeFiles/Clock.dir/Clock/Clock.cpp.obj.d"
  "CMakeFiles/Clock.dir/app.rc.obj"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/Clock/Clock.exe"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/Clock/Clock.exe.manifest"
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/demos/Clock/Clock.pdb"
  "libClock.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX RC)
  include(CMakeFiles/Clock.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
