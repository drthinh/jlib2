file(REMOVE_RECURSE
  "D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/lib/libjlib.a"
)
