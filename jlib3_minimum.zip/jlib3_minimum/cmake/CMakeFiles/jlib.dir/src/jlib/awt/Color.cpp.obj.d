CMakeFiles/jlib.dir/src/jlib/awt/Color.cpp.obj: \
 D:\Projects\CPP_Windows\jlib3_update_22_10_25\jlib3_minimum\jlib3\src\jlib\awt\Color.cpp \
 D:/Projects/CPP_Windows/jlib3_update_22_10_25/jlib3_minimum/jlib3/include/jlib/awt/Color.h
